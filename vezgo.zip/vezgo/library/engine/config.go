package engine

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
	"strconv"
	"time"
	"../hashmap"

	"fmt"
	"os"
	"strings"
)

/* server */

const LINE_HOST_DOMAIN = "https://legy-jp.line-apps.com"
//const LINE_HOST_DOMAIN = "https://legy-jp-addr-long.line.naver.jp"
const LINE_HOST_DOMAIN_PROXY = "https://gwx.line.naver.jp"
const LINE_W_DOMAIN = "https://w.line.me"
const LINE_API_DOMAIN = "https://api.line.me"
const LINE_ACCESS_DOMAIN = "https://access.line.me"
const LINE_SQUARE_API = "https://square-api.line.me"

const LINE_LOGIN_QUERY_PATH = "/api/v4/TalkService.do"
const LINE_AUTH_QUERY_PATH = "/RS4"
const LINE_AUTH_LOGIN_QUERY_PATH = "/api/v4p/rs"
const LINE_SQ_QUERY_PATH = "/acct/lgn/sq/v1"
const LINE_SQ_VERIFY_QUERY_PATH = "/acct/lp/lgn/sq/v1"
const LINE_SQ_LOGIN_QUERY_PATH = "/ACCT/lgn/sq/v1"

const LINE_API_QUERY_PATH_FIR = "/S5"
const LINE_API_QUERY_PATH_SEC = "/S4"
const LINE_POLL_QUERY_PATH_FIR = "/SYNC4"
const LINE_POLL_QUERY_PATH_SEC = "/P4"
const LINE_COMPACT_MESSAGE_QUERY_PATH = "/CA5"
const LINE_ENC_COMPACT_MESSAGE_QUERY_PATH = "/ECA5"
const LINE_POLL_QUERY_PATH_THI = "/NP4"
const LINE_CALL_QUERY_PATH = "/V4"
const LINE_RELATION_QUERY_PATH = "/RE4"
const LINE_CERTIFICATE_PATH = "/Q"
const LINE_CHAN_QUERY_PATH = "/CH4"
const LINE_SQUARE_QUERY_PATH = "/SQ1"
const LINE_SHOP_QUERY_PATH = "/SHOP4"
const LINE_LIFF_QUERY_PATH = "/LIFF1"

const PRIMARY_DEVICE = "IOS\t14.6.3\tiOS\t15.2.1"
const SECONDARY_DEVICE2 = "IOSIPAD\t13.18.1\tiOS\t16.7.2"
const SECONDARY_DEVICE = "DESKTOPMAC\t8.7.0.3302\tMacBook-Pro-SelfTcr2025\t14.4.1"
const SECONDARY_DEVICE3 = "DESKTOPWIN\t8.7.0.3302\tWINDOWS\t14.4.0"
const THIRD_DEVICE = "ANDROIDLITE\t2.17.1\tAndroid OS\t1"
const ANDROID_DEVICE = "ANDROID\t15.2.1\tAndroid OS\t13.0.%v"
const IOS_DEVICE = "IOS\t14.6.1\tiOS\t17.3.%v"

// ANDROID 14.6.1 Android OS 9
const SYSTEM_NAME = "SELFTCR"
const LINE_LIFF_ID = "1655728903-2Nn14Vbq"

const TIMELINE_CHANNEL_ID = "1341209950"
const OPENCHAT_CHANNEL_ID = "1573545970"
const WEBTOON_CHANNEL_ID = "1401600689"
const TODAY_CHANNEL_ID = "1518712866"
const STORE_CHANNEL_ID = "1376922440"
const MUSIC_CHANNEL_ID = "1381425814"
const SERVICES_CHANNEL_ID = "1459630796"

var (
	EncMetode       = false
	Media       = true
	Vnum            = getVnum()
	Version         = "SelfTcr 6.1.5"
	JsonFile        = "database/setting/" + os.Args[1] + ".json"
	Cmd             = "database/cmd/" + os.Args[1] + ".json"
	Settings        string
	SetTemp         = make(map[string]string)
	SetCMD          string
	Client          = []*LineClient{}
	ListSelf        = []*LineClient{}
	Mclient         = map[string]*LineClient{}
	SelfAcc         = map[string]*LineClient{}
	TeamName        = "SelfTcr 2025"
	ApikeyVHtear    = "nanaNanaKui123"
	TeamIcon        = "https://i.ibb.co/RzpKZgL/20240113-220500.jpg"
	TeamUrl         = "https://google.com"
	GenName         = []string{"Aaren", "Aarika", "Abagael", "Abagail", "Abbe", "Abbey", "Abbi", "Abbie", "Abby", "Abbye", "Abigael", "Abigail", "Abigale", "Abra", "Ada", "Adah", "Adaline", "Adan", "Adara", "Adda", "Addi", "Addia", "Addie", "Addy", "Adel", "Adela", "Adelaida", "Adelaide", "Adele", "Adelheid", "Adelice", "Adelina", "Adelind", "Adeline", "Adella", "Adelle", "Adena", "Adey", "Adi", "Adiana", "Adina", "Adora", "Adore", "Adoree", "Adorne", "Adrea", "Adria", "Adriaens", "Adrian", "Adriana", "Adriane", "Adrianna", "Adrianne", "Adriena", "Adrienne", "Aeriel", "Aeriela", "Aeriell", "Afton", "Ag", "Agace", "Agata", "Agatha", "Agathe", "Aggi", "Aggie", "Aggy", "Agna", "Agnella", "Agnes", "Agnese", "Agnesse", "Agneta", "Agnola", "Agretha", "Aida", "Aidan", "Aigneis", "Aila", "Aile", "Ailee", "Aileen", "Ailene", "Ailey", "Aili", "Ailina", "Ailis", "Ailsun", "Ailyn", "Aime", "Aimee", "Aimil", "Aindrea", "Ainslee", "Ainsley", "Ainslie", "Ajay", "Alaine", "Alameda", "Alana", "Alanah", "Alane", "Alanna", "Alayne", "Alberta", "Albertina", "Albertine", "Albina", "Alecia", "Aleda", "Aleece", "Aleen", "Alejandra", "Alejaa", "Alena", "Alene", "Alessandra", "Aleta", "Alethea", "Alex", "Alexa", "Alexandra", "Alexandrina", "Alexi", "Alexia", "Alexina", "Alexine", "Alexis", "Alfi", "Alfie", "Alfreda", "Alfy", "Ali", "Alia", "Alica", "Alice", "Alicea", "Alicia", "Alida", "Alidia", "Alie", "Alika", "Alikee", "Alina", "Aline", "Alis", "Alisa", "Alisha", "Alison", "Alissa", "Alisun", "Alix", "Aliza", "Alla", "Alleen", "Allegra", "Allene", "Alli", "Allianora", "Allie", "Allina", "Allis", "Allison", "Allissa", "Allix", "Allsun", "Allx", "Ally", "Allyce", "Allyn", "Allys", "Allyson", "Alma", "Almeda", "Almeria", "Almeta", "Almira", "Almire", "Aloise", "Aloisia", "Aloysia", "Alta", "Althea", "Alvera", "Alverta", "Alvina", "Alvinia", "Alvira", "Alyce", "Alyda", "Alys", "Alysa", "Alyse", "Alysia", "Alyson", "Alyss", "Alyssa", "Amabel", "Amabelle", "Amalea", "Amalee", "Amaleta", "Amalia", "Amalie", "Amalita", "Amalle", "Amanda", "Amandi", "Amandie", "Amandy", "Amara", "Amargo", "Amata", "Amber", "Amberly", "Ambur", "Ame", "Amelia", "Amelie", "Amelina", "Ameline", "Amelita", "Ami", "Amie", "Amii", "Amil", "Amitie", "Amity", "Ammamaria", "Amy", "Amye", "Ana", "Anabal", "Anabel", "Anabella", "Anabelle", "Analiese", "Analise", "Anallese", "Anallise", "Anastasia", "Anastasie", "Anastassia", "Anatola", "Andee", "Andeee", "Anderea", "Andi", "Andie", "Andra", "Andrea", "Andreana", "Andree", "Andrei", "Andria", "Andriana", "Andriette", "Andromache", "Andy", "Anestassia", "Anet", "Anett", "Anetta", "Anette", "Ange", "Angel", "Angela", "Angele", "Angelia", "Angelica", "Angelika", "Angelina", "Angeline", "Angelique", "Angelita", "Angelle", "Angie", "Angil", "Angy", "Ania", "Anica", "Anissa", "Anita", "Anitra", "Anjanette", "Anjela", "Ann", "Ann-Marie", "Anna", "Anna-Diana", "Anna-Diane", "Anna-Maria", "Annabal", "Annabel", "Annabela", "Annabell", "Annabella", "Annabelle", "Annadiana", "Annadiane", "Annalee", "Annaliese", "Annalise", "Annamaria", "Annamarie", "Anne", "Anne-Corinne", "Anne-Marie", "Annecorinne", "Anneliese", "Annelise", "Annemarie", "Annetta", "Annette", "Anni", "Annice", "Annie", "Annis", "Annissa", "Annmaria", "Annmarie", "Annnora", "Annora", "Anny", "Anselma", "Ansley", "Anstice", "Anthe", "Anthea", "Anthia", "Anthiathia", "Antoinette", "Antonella", "Antonetta", "Antonia", "Antonie", "Antonietta", "Antonina", "Anya", "Appolonia", "April", "Aprilette", "Ara", "Arabel", "Arabela", "Arabele", "Arabella", "Arabelle", "Arda", "Ardath", "Ardeen", "Ardelia", "Ardelis", "Ardella", "Ardelle", "Arden", "Ardene", "Ardenia", "Ardine", "Ardis", "Ardisj", "Ardith", "Ardra", "Ardyce", "Ardys", "Ardyth", "Aretha", "Ariadne", "Ariana", "Aridatha", "Ariel", "Ariela", "Ariella", "Arielle", "Arlana", "Arlee", "Arleen", "Arlen", "Arlena", "Arlene", "Arleta", "Arlette", "Arleyne", "Arlie", "Arliene", "Arlina", "Arlinda", "Arline", "Arluene", "Arly", "Arlyn", "Arlyne", "Aryn", "Ashely", "Ashia", "Ashien", "Ashil", "Ashla", "Ashlan", "Ashlee", "Ashleigh", "Ashlen", "Ashley", "Ashli", "Ashlie", "Ashly", "Asia", "Astra", "Astrid", "Astrix", "Atalanta", "Athena", "Athene", "Atlanta", "Atlante", "Auberta", "Aubine", "Aubree", "Aubrette", "Aubrey", "Aubrie", "Aubry", "Audi", "Audie", "Audra", "Audre", "Audrey", "Audrie", "Audry", "Audrye", "Audy", "Augusta", "Auguste", "Augustina", "Augustine", "Aundrea", "Aura", "Aurea", "Aurel", "Aurelea", "Aurelia", "Aurelie", "Auria", "Aurie", "Aurilia", "Aurlie", "Auroora", "Aurora", "Aurore", "Austin", "Austina", "Austine", "Ava", "Aveline", "Averil", "Averyl", "Avie", "Avis", "Aviva", "Avivah", "Avril", "Avrit", "Ayn", "Bab", "Babara", "Babb", "Babbette", "Babbie", "Babette", "Babita", "Babs", "Bambi", "Bambie", "Bamby", "Barb", "Barbabra", "Barbara", "Barbara-Anne", "Barbaraanne", "Barbe", "Barbee", "Barbette", "Barbey", "Barbi", "Barbie", "Barbra", "Barby", "Bari", "Barrie", "Barry", "Basia", "Bathsheba", "Batsheva", "Bea", "Beatrice", "Beatrisa", "Beatrix", "Beatriz", "Bebe", "Becca", "Becka", "Becki", "Beckie", "Becky", "Bee", "Beilul", "Beitris", "Bekki", "Bel", "Belia", "Belicia", "Belinda", "Belita", "Bell", "Bella", "Bellanca", "Belle", "Bellina", "Belva", "Belvia", "Bendite", "Benedetta", "Benedicta", "Benedikta", "Benetta", "Benita", "Benni", "Bennie", "Benny", "Benoite", "Berenice", "Beret", "Berget", "Berna", "Bernadene", "Bernadette", "Bernadina", "Bernadine", "Bernardina", "Bernardine", "Bernelle", "Bernete", "Bernetta", "Bernette", "Berni", "Bernice", "Bernie", "Bernita", "Berny", "Berri", "Berrie", "Berry", "Bert", "Berta", "Berte", "Bertha", "Berthe", "Berti", "Bertie", "Bertina", "Bertine", "Berty", "Beryl", "Beryle", "Bess", "Bessie", "Bessy", "Beth", "Bethanne", "Bethany", "Bethena", "Bethina", "Betsey", "Betsy", "Betta", "Bette", "Bette-Ann", "Betteann", "Betteanne", "Betti", "Bettina", "Bettine", "Betty", "Bettye", "Beulah", "Bev", "Beverie", "Beverlee", "Beverley", "Beverlie", "Beverly", "Bevvy", "Bianca", "Bianka", "Bibbie", "Bibby", "Bibbye", "Bibi", "Biddie", "Biddy", "Bidget", "Bili", "Bill", "Billi", "Billie", "Billy", "Billye", "Binni", "Binnie", "Binny", "Bird", "Birdie", "Birgit", "Birgitta", "Blair", "Blaire", "Blake", "Blakelee", "Blakeley", "Blanca", "Blanch", "Blancha", "Blanche", "Blinni", "Blinnie", "Blinny", "Bliss", "Blisse", "Blithe", "Blondell", "Blondelle", "Blondie", "Blondy", "Blythe", "Bobbe", "Bobbee", "Bobbette", "Bobbi", "Bobbie", "Bobby", "Bobbye", "Bobette", "Bobina", "Bobine", "Bobinette", "Bonita", "Bonnee", "Bonni", "Bonnibelle", "Bonnie", "Bonny", "Brana", "Brandais", "Brande", "Brandea", "Brandi", "Brandice", "Brandie", "Brandise", "Brandy", "Breanne", "Brear", "Bree", "Breena", "Bren", "Brena", "Brenda", "Brenn", "Brenna", "Brett", "Bria", "Briana", "Brianna", "Brianne", "Bride", "Bridget", "Bridgette", "Bridie", "Brier", "Brietta", "Brigid", "Brigida", "Brigit", "Brigitta", "Brigitte", "Brina", "Briney", "Brinn", "Brinna", "Briny", "Brit", "Brita", "Britney", "Britni", "Britt", "Britta", "Brittan", "Brittaney", "Brittani", "Brittany", "Britte", "Britteny", "Brittne", "Brittney", "Brittni", "Brook", "Brooke", "Brooks", "Brunhilda", "Brunhilde", "Bryana", "Bryn", "Bryna", "Brynn", "Brynna", "Brynne", "Buffy", "Bunni", "Bunnie", "Bunny", "Cacilia", "Cacilie", "Cahra", "Cairistiona", "Caitlin", "Caitrin", "Cal", "Calida", "Calla", "Calley", "Calli", "Callida", "Callie", "Cally", "Calypso", "Cam", "Camala", "Camel", "Camella", "Camellia", "Cami", "Camila", "Camile", "Camilla", "Camille", "Cammi", "Cammie", "Cammy", "Candace", "Candi", "Candice", "Candida", "Candide", "Candie", "Candis", "Candra", "Candy", "Caprice", "Cara", "Caralie", "Caren", "Carena", "Caresa", "Caressa", "Caresse", "Carey", "Cari", "Caria", "Carie", "Caril", "Carilyn", "Carin", "Carina", "Carine", "Cariotta", "Carissa", "Carita", "Caritta", "Carla", "Carlee", "Carleen", "Carlen", "Carlene", "Carley", "Carlie", "Carlin", "Carlina", "Carline", "Carlita", "Carlota", "Carlotta", "Carly", "Carlye", "Carlyn", "Carlynn", "Carlynne", "Carma", "Carmel", "Carmela", "Carmelia", "Carmelina", "Carmelita", "Carmella", "Carmelle", "Carmen", "Carmencita", "Carmina", "Carmine", "Carmita", "Carmon", "Caro", "Carol", "Carol-Jean", "Carola", "Carolan", "Carolann", "Carole", "Carolee", "Carolin", "Carolina", "Caroline", "Caroljean", "Carolyn", "Carolyne", "Carolynn", "Caron", "Carree", "Carri", "Carrie", "Carrissa", "Carroll", "Carry", "Cary", "Caryl", "Caryn", "Casandra", "Casey", "Casi", "Casie", "Cass", "Cassandra", "Cassandre", "Cassandry", "Cassaundra", "Cassey", "Cassi", "Cassie", "Cassondra", "Cassy", "Catarina", "Cate", "Caterina", "Catha", "Catharina", "Catharine", "Cathe", "Cathee", "Catherin", "Catherina", "Catherine", "Cathi", "Cathie", "Cathleen", "Cathlene", "Cathrin", "Cathrine", "Cathryn", "Cathy", "Cathyleen", "Cati", "Catie", "Catina", "Catlaina", "Catlee", "Catlin", "Catrina", "Catriona", "Caty", "Caye", "Cayla", "Cecelia", "Cecil", "Cecile", "Ceciley", "Cecilia", "Cecilla", "Cecily", "Ceil", "Cele", "Celene", "Celesta", "Celeste", "Celestia", "Celestina", "Celestine", "Celestyn", "Celestyna", "Celia", "Celie", "Celina", "Celinda", "Celine", "Celinka", "Celisse", "Celka", "Celle", "Cesya", "Chad", "Chanda", "Chandal", "Chandra", "Channa", "Chantal", "Chantalle", "Charil", "Charin", "Charis", "Charissa", "Charisse", "Charita", "Charity", "Charla", "Charlean", "Charleen", "Charlena", "Charlene", "Charline", "Charlot", "Charlotta", "Charlotte", "Charmain", "Charmaine", "Charmane", "Charmian", "Charmine", "Charmion", "Charo", "Charyl", "Chastity", "Chelsae", "Chelsea", "Chelsey", "Chelsie", "Chelsy", "Cher", "Chere", "Cherey", "Cheri", "Cherianne", "Cherice", "Cherida", "Cherie", "Cherilyn", "Cherilynn", "Cherin", "Cherise", "Cherish", "Cherlyn", "Cherri", "Cherrita", "Cherry", "Chery", "Cherye", "Cheryl", "Cheslie", "Chiarra", "Chickie", "Chicky", "Chiquia", "Chiquita", "Chlo", "Chloe", "Chloette", "Chloris", "Chris", "Chrissie", "Chrissy", "Christa", "Christabel", "Christabella", "Christal", "Christalle", "Christan", "Christean", "Christel", "Christen", "Christi", "Christian", "Christiana", "Christiane", "Christie", "Christin", "Christina", "Christine", "Christy", "Christye", "Christyna", "Chrysa", "Chrysler", "Chrystal", "Chryste", "Chrystel", "Cicely", "Cicily", "Ciel", "Cilka", "Cinda", "Cindee", "Cindelyn", "Cinderella", "Cindi", "Cindie", "Cindra", "Cindy", "Cinnamon", "Cissiee", "Cissy", "Clair", "Claire", "Clara", "Clarabelle", "Clare", "Claresta", "Clareta", "Claretta", "Clarette", "Clarey", "Clari", "Claribel", "Clarice", "Clarie", "Clarinda", "Clarine", "Clarissa", "Clarisse", "Clarita", "Clary", "Claude", "Claudelle", "Claudetta", "Claudette", "Claudia", "Claudie", "Claudina", "Claudine", "Clea", "Clem", "Clemence", "Clementia", "Clementina", "Clementine", "Clemmie", "Clemmy", "Cleo", "Cleopatra", "Clerissa", "Clio", "Clo", "Cloe", "Cloris", "Clotilda", "Clovis", "Codee", "Codi", "Codie", "Cody", "Coleen", "Colene", "Coletta", "Colette", "Colleen", "Collen", "Collete", "Collette", "Collie", "Colline", "Colly", "Con", "Concettina", "Conchita", "Concordia", "Conni", "Connie", "Conny", "Consolata", "Constance", "Constancia", "Constancy", "Constanta", "Constantia", "Constantina", "Constantine", "Consuela", "Consuelo", "Cookie", "Cora", "Corabel", "Corabella", "Corabelle", "Coral", "Coralie", "Coraline", "Coralyn", "Cordelia", "Cordelie", "Cordey", "Cordi", "Cordie", "Cordula", "Cordy", "Coreen", "Corella", "Corenda", "Corene", "Coretta", "Corette", "Corey", "Cori", "Corie", "Corilla", "Corina", "Corine", "Corinna", "Corinne", "Coriss", "Corissa", "Corliss", "Corly", "Cornela", "Cornelia", "Cornelle", "Cornie", "Corny", "Correna", "Correy", "Corri", "Corrianne", "Corrie", "Corrina", "Corrine", "Corrinne", "Corry", "Cortney", "Cory", "Cosetta", "Cosette", "Costanza", "Courtenay", "Courtnay", "Courtney", "Crin", "Cris", "Crissie", "Crissy", "Crista", "Cristabel", "Cristal", "Cristen", "Cristi", "Cristie", "Cristin", "Cristina", "Cristine", "Cristionna", "Cristy", "Crysta", "Crystal", "Crystie", "Cthrine", "Cyb", "Cybil", "Cybill", "Cymbre", "Cynde", "Cyndi", "Cyndia", "Cyndie", "Cyndy", "Cynthea", "Cynthia", "Cynthie", "Cynthy", "Dacey", "Dacia", "Dacie", "Dacy", "Dael", "Daffi", "Daffie", "Daffy", "Dagmar", "Dahlia", "Daile", "Daisey", "Daisi", "Daisie", "Daisy", "Dale", "Dalenna", "Dalia", "Dalila", "Dallas", "Daloris", "Damara", "Damaris", "Damita", "Dana", "Danell", "Danella", "Danette", "Dani", "Dania", "Danica", "Danice", "Daniela", "Daniele", "Daniella", "Danielle", "Danika", "Danila", "Danit", "Danita", "Danna", "Danni", "Dannie", "Danny", "Dannye", "Danya", "Danyelle", "Danyette", "Daphene", "Daphna", "Daphne", "Dara", "Darb", "Darbie", "Darby", "Darcee", "Darcey", "Darci", "Darcie", "Darcy", "Darda", "Dareen", "Darell", "Darelle", "Dari", "Daria", "Darice", "Darla", "Darleen", "Darlene", "Darline", "Darlleen", "Daron", "Darrelle", "Darryl", "Darsey", "Darsie", "Darya", "Daryl", "Daryn", "Dasha", "Dasi", "Dasie", "Dasya", "Datha", "Daune", "Daveen", "Daveta", "Davida", "Davina", "Davine", "Davita", "Dawn", "Dawna", "Dayle", "Dayna", "Ddene", "De", "Deana", "Deane", "Deanna", "Deanne", "Deb", "Debbi", "Debbie", "Debby", "Debee", "Debera", "Debi", "Debor", "Debora", "Deborah", "Debra", "Dede", "Dedie", "Dedra", "Dee", "Dee Dee", "Deeann", "Deeanne", "Deedee", "Deena", "Deerdre", "Deeyn", "Dehlia", "Deidre", "Deina", "Deirdre", "Del", "Dela", "Delcina", "Delcine", "Delia", "Delila", "Delilah", "Delinda", "Dell", "Della", "Delly", "Delora", "Delores", "Deloria", "Deloris", "Delphine", "Delphinia", "Demeter", "Demetra", "Demetria", "Demetris", "Dena", "Deni", "Denice", "Denise", "Denna", "Denni", "Dennie", "Denny", "Deny", "Denys", "Denyse", "Deonne", "Desdemona", "Desirae", "Desiree", "Desiri", "Deva", "Devan", "Devi", "Devin", "Devina", "Devinne", "Devon", "Devondra", "Devonna", "Devonne", "Devora", "Di", "Diahann", "Dian", "Diana", "Diandra", "Diane", "Diane-Marie", "Dianemarie", "Diann", "Dianna", "Dianne", "Diannne", "Didi", "Dido", "Diena", "Dierdre", "Dina", "Dinah", "Dinnie", "Dinny", "Dion", "Dione", "Dionis", "Dionne", "Dita", "Dix", "Dixie", "Dniren", "Dode", "Dodi", "Dodie", "Dody", "Doe", "Doll", "Dolley", "Dolli", "Dollie", "Dolly", "Dolores", "Dolorita", "Doloritas", "Domeniga", "Dominga", "Domini", "Dominica", "Dominique", "Dona", "Donella", "Donelle", "Donetta", "Donia", "Donica", "Donielle", "Donna", "Donnamarie", "Donni", "Donnie", "Donny", "Dora", "Doralia", "Doralin", "Doralyn", "Doralynn", "Doralynne", "Dore", "Doreen", "Dorelia", "Dorella", "Dorelle", "Dorena", "Dorene", "Doretta", "Dorette", "Dorey", "Dori", "Doria", "Dorian", "Dorice", "Dorie", "Dorine", "Doris", "Dorisa", "Dorise", "Dorita", "Doro", "Dorolice", "Dorolisa", "Dorotea", "Doroteya", "Dorothea", "Dorothee", "Dorothy", "Dorree", "Dorri", "Dorrie", "Dorris", "Dorry", "Dorthea", "Dorthy", "Dory", "Dosi", "Dot", "Doti", "Dotti", "Dottie", "Dotty", "Dre", "Dreddy", "Dredi", "Drona", "Dru", "Druci", "Drucie", "Drucill", "Drucy", "Drusi", "Drusie", "Drusilla", "Drusy", "Dulce", "Dulcea", "Dulci", "Dulcia", "Dulciana", "Dulcie", "Dulcine", "Dulcinea", "Dulcy", "Dulsea", "Dusty", "Dyan", "Dyana", "Dyane", "Dyann", "Dyanna", "Dyanne", "Dyna", "Dynah", "Eachelle", "Eada", "Eadie", "Eadith", "Ealasaid", "Eartha", "Easter", "Eba", "Ebba", "Ebonee", "Ebony", "Eda", "Eddi", "Eddie", "Eddy", "Ede", "Edee", "Edeline", "Eden", "Edi", "Edie", "Edin", "Edita", "Edith", "Editha", "Edithe", "Ediva", "Edna", "Edwina", "Edy", "Edyth", "Edythe", "Effie", "Eileen", "Eilis", "Eimile", "Eirena", "Ekaterina", "Elaina", "Elaine", "Elana", "Elane", "Elayne", "Elberta", "Elbertina", "Elbertine", "Eleanor", "Eleanora", "Eleanore", "Electra", "Eleen", "Elena", "Elene", "Eleni", "Elenore", "Eleonora", "Eleonore", "Elfie", "Elfreda", "Elfrida", "Elfrieda", "Elga", "Elianora", "Elianore", "Elicia", "Elie", "Elinor", "Elinore", "Elisa", "Elisabet", "Elisabeth", "Elisabetta", "Elise", "Elisha", "Elissa", "Elita", "Eliza", "Elizabet", "Elizabeth", "Elka", "Elke", "Ella", "Elladine", "Elle", "Ellen", "Ellene", "Ellette", "Elli", "Ellie", "Ellissa", "Elly", "Ellyn", "Ellynn", "Elmira", "Elna", "Elnora", "Elnore", "Eloisa", "Eloise", "Elonore", "Elora", "Elsa", "Elsbeth", "Else", "Elset", "Elsey", "Elsi", "Elsie", "Elsinore", "Elspeth", "Elsy", "Elva", "Elvera", "Elvina", "Elvira", "Elwira", "Elyn", "Elyse", "Elysee", "Elysha", "Elysia", "Elyssa", "Em", "Ema", "Emalee", "Emalia", "Emelda", "Emelia", "Emelina", "Emeline", "Emelita", "Emelyne", "Emera", "Emilee", "Emili", "Emilia", "Emilie", "Emiline", "Emily", "Emlyn", "Emlynn", "Emlynne", "Emma", "Emmalee", "Emmaline", "Emmalyn", "Emmalynn", "Emmalynne", "Emmeline", "Emmey", "Emmi", "Emmie", "Emmy", "Emmye", "Emogene", "Emyle", "Emylee", "Engracia", "Enid", "Enrica", "Enrichetta", "Enrika", "Enriqueta", "Eolanda", "Eolande", "Eran", "Erda", "Erena", "Erica", "Ericha", "Ericka", "Erika", "Erin", "Erina", "Erinn", "Erinna", "Erma", "Ermengarde", "Ermentrude", "Ermina", "Erminia", "Erminie", "Erna", "Ernaline", "Ernesta", "Ernestine", "Ertha", "Eryn", "Esma", "Esmaria", "Esme", "Esmeralda", "Essa", "Essie", "Essy", "Esta", "Estel", "Estele", "Estell", "Estella", "Estelle", "Ester", "Esther", "Estrella", "Estrellita", "Ethel", "Ethelda", "Ethelin", "Ethelind", "Etheline", "Ethelyn", "Ethyl", "Etta", "Etti", "Ettie", "Etty", "Eudora", "Eugenia", "Eugenie", "Eugine", "Eula", "Eulalie", "Eunice", "Euphemia", "Eustacia", "Eva", "Evaleen", "Evangelia", "Evangelin", "Evangelina", "Evangeline", "Evania", "Evanne", "Eve", "Eveleen", "Evelina", "Eveline", "Evelyn", "Evey", "Evie", "Evita", "Evonne", "Evvie", "Evvy", "Evy", "Eyde", "Eydie", "Ezmeralda", "Fae", "Faina", "Faith", "Fallon", "Fan", "Fanchette", "Fanchon", "Fancie", "Fancy", "Fanechka", "Fania", "Fanni", "Fannie", "Fanny", "Fanya", "Fara", "Farah", "Farand", "Farica", "Farra", "Farrah", "Farrand", "Faun", "Faunie", "Faustina", "Faustine", "Fawn", "Fawne", "Fawnia", "Fay", "Faydra", "Faye", "Fayette", "Fayina", "Fayre", "Fayth", "Faythe", "Federica", "Fedora", "Felecia", "Felicdad", "Felice", "Felicia", "Felicity", "Felicle", "Felipa", "Felisha", "Felita", "Feliza", "Fenelia", "Feodora", "Ferdinanda", "Ferdinande", "Fern", "Fernanda", "Fernande", "Fernandina", "Ferne", "Fey", "Fiann", "Fianna", "Fidela", "Fidelia", "Fidelity", "Fifi", "Fifine", "Filia", "Filide", "Filippa", "Fina", "Fiona", "Fionna", "Fionnula", "Fiorenze", "Fleur", "Fleurette", "Flo", "Flor", "Flora", "Florance", "Flore", "Florella", "Florence", "Florencia", "Florentia", "Florenza", "Florette", "Flori", "Floria", "Florida", "Florie", "Florina", "Florinda", "Floris", "Florri", "Florrie", "Florry", "Flory", "Flossi", "Flossie", "Flossy", "Flss", "Fran", "Francene", "Frances", "Francesca", "Francine", "Francisca", "Franciska", "Francoise", "Francyne", "Frank", "Frankie", "Franky", "Franni", "Frannie", "Franny", "Frayda", "Fred", "Freda", "Freddi", "Freddie", "Freddy", "Fredelia", "Frederica", "Fredericka", "Frederique", "Fredi", "Fredia", "Fredra", "Fredrika", "Freida", "Frieda", "Friederike", "Fulvia", "Gabbey", "Gabbi", "Gabbie", "Gabey", "Gabi", "Gabie", "Gabriel", "Gabriela", "Gabriell", "Gabriella", "Gabrielle", "Gabriellia", "Gabrila", "Gaby", "Gae", "Gael", "Gail", "Gale", "Gale", "Galina", "Garland", "Garnet", "Garnette", "Gates", "Gavra", "Gavrielle", "Gay", "Gaye", "Gayel", "Gayla", "Gayle", "Gayleen", "Gaylene", "Gaynor", "Gelya", "Gena", "Gene", "Geneva", "Genevieve", "Genevra", "Genia", "Genna", "Genni", "Gennie", "Gennifer", "Genny", "Genovera", "Genvieve", "George", "Georgeanna", "Georgeanne", "Georgena", "Georgeta", "Georgetta", "Georgette", "Georgia", "Georgiana", "Georgianna", "Georgianne", "Georgie", "Georgina", "Georgine", "Geralda", "Geraldine", "Gerda", "Gerhardine", "Geri", "Gerianna", "Gerianne", "Gerladina", "Germain", "Germaine", "Germana", "Gerri", "Gerrie", "Gerrilee", "Gerry", "Gert", "Gerta", "Gerti", "Gertie", "Gertrud", "Gertruda", "Gertrude", "Gertrudis", "Gerty", "Giacinta", "Giana", "Gianina", "Gianna", "Gigi", "Gilberta", "Gilberte", "Gilbertina", "Gilbertine", "Gilda", "Gilemette", "Gill", "Gillan", "Gilli", "Gillian", "Gillie", "Gilligan", "Gilly", "Gina", "Ginelle", "Ginevra", "Ginger", "Ginni", "Ginnie", "Ginnifer", "Ginny", "Giorgia", "Giovanna", "Gipsy", "Giralda", "Gisela", "Gisele", "Gisella", "Giselle", "Giuditta", "Giulia", "Giulietta", "Giustina", "Gizela", "Glad", "Gladi", "Gladys", "Gleda", "Glen", "Glenda", "Glenine", "Glenn", "Glenna", "Glennie", "Glennis", "Glori", "Gloria", "Gloriana", "Gloriane", "Glory", "Glyn", "Glynda", "Glynis", "Glynnis", "Gnni", "Godiva", "Golda", "Goldarina", "Goldi", "Goldia", "Goldie", "Goldina", "Goldy", "Grace", "Gracia", "Gracie", "Grata", "Gratia", "Gratiana", "Gray", "Grayce", "Grazia", "Greer", "Greta", "Gretal", "Gretchen", "Grete", "Gretel", "Grethel", "Gretna", "Gretta", "Grier", "Griselda", "Grissel", "Guendolen", "Guenevere", "Guenna", "Guglielma", "Gui", "Guillema", "Guillemette", "Guinevere", "Guinna", "Gunilla", "Gus", "Gusella", "Gussi", "Gussie", "Gussy", "Gusta", "Gusti", "Gustie", "Gusty", "Gwen", "Gwendolen", "Gwendolin", "Gwendolyn", "Gweneth", "Gwenette", "Gwenneth", "Gwenni", "Gwennie", "Gwenny", "Gwenora", "Gwenore", "Gwyn", "Gwyneth", "Gwynne", "Gypsy", "Hadria", "Hailee", "Haily", "Haleigh", "Halette", "Haley", "Hali", "Halie", "Halimeda", "Halley", "Halli", "Hallie", "Hally", "Hana", "Hanna", "Hannah", "Hanni", "Hannie", "Hannis", "Hanny", "Happy", "Harlene", "Harley", "Harli", "Harlie", "Harmonia", "Harmonie", "Harmony", "Harri", "Harrie", "Harriet", "Harriett", "Harrietta", "Harriette", "Harriot", "Harriott", "Hatti", "Hattie", "Hatty", "Hayley", "Hazel", "Heath", "Heather", "Heda", "Hedda", "Heddi", "Heddie", "Hedi", "Hedvig", "Hedvige", "Hedwig", "Hedwiga", "Hedy", "Heida", "Heidi", "Heidie", "Helaina", "Helaine", "Helen", "Helen-Elizabeth", "Helena", "Helene", "Helenka", "Helga", "Helge", "Helli", "Heloise", "Helsa", "Helyn", "Hendrika", "Henka", "Henrie", "Henrieta", "Henrietta", "Henriette", "Henryetta", "Hephzibah", "Hermia", "Hermina", "Hermine", "Herminia", "Hermione", "Herta", "Hertha", "Hester", "Hesther", "Hestia", "Hetti", "Hettie", "Hetty", "Hilary", "Hilda", "Hildagard", "Hildagarde", "Hilde", "Hildegaard", "Hildegarde", "Hildy", "Hillary", "Hilliary", "Hinda", "Holli", "Hollie", "Holly", "Holly-Anne", "Hollyanne", "Honey", "Honor", "Honoria", "Hope", "Horatia", "Hortense", "Hortensia", "Hulda", "Hyacinth", "Hyacintha", "Hyacinthe", "Hyacinthia", "Hyacinthie", "Hynda", "Ianthe", "Ibbie", "Ibby", "Ida", "Idalia", "Idalina", "Idaline", "Idell", "Idelle", "Idette", "Ileana", "Ileane", "Ilene", "Ilise", "Ilka", "Illa", "Ilsa", "Ilse", "Ilysa", "Ilyse", "Ilyssa", "Imelda", "Imogen", "Imogene", "Imojean", "Ina", "Indira", "Ines", "Inesita", "Inessa", "Inez", "Inga", "Ingaberg", "Ingaborg", "Inge", "Ingeberg", "Ingeborg", "Inger", "Ingrid", "Ingunna", "Inna", "Iolande", "Iolanthe", "Iona", "Iormina", "Ira", "Irena", "Irene", "Irina", "Iris", "Irita", "Irma", "Isa", "Isabel", "Isabelita", "Isabella", "Isabelle", "Isadora", "Isahella", "Iseabal", "Isidora", "Isis", "Isobel", "Issi", "Issie", "Issy", "Ivett", "Ivette", "Ivie", "Ivonne", "Ivory", "Ivy", "Izabel", "Jacenta", "Jacinda", "Jacinta", "Jacintha", "Jacinthe", "Jackelyn", "Jacki", "Jackie", "Jacklin", "Jacklyn", "Jackquelin", "Jackqueline", "Jacky", "Jaclin", "Jaclyn", "Jacquelin", "Jacqueline", "Jacquelyn", "Jacquelynn", "Jacquenetta", "Jacquenette", "Jacquetta", "Jacquette", "Jacqui", "Jacquie", "Jacynth", "Jada", "Jade", "Jaime", "Jaimie", "Jaine", "Jami", "Jamie", "Jamima", "Jammie", "Jan", "Jana", "Janaya", "Janaye", "Jandy", "Jane", "Janean", "Janeczka", "Janeen", "Janel", "Janela", "Janella", "Janelle", "Janene", "Janenna", "Janessa", "Janet", "Janeta", "Janetta", "Janette", "Janeva", "Janey", "Jania", "Janice", "Janie", "Janifer", "Janina", "Janine", "Janis", "Janith", "Janka", "Janna", "Jannel", "Jannelle", "Janot", "Jany", "Jaquelin", "Jaquelyn", "Jaquenetta", "Jaquenette", "Jaquith", "Jasmin", "Jasmina", "Jasmine", "Jayme", "Jaymee", "Jayne", "Jaynell", "Jazmin", "Jean", "Jeana", "Jeane", "Jeanelle", "Jeanette", "Jeanie", "Jeanine", "Jeanna", "Jeanne", "Jeannette", "Jeannie", "Jeannine", "Jehanna", "Jelene", "Jemie", "Jemima", "Jemimah", "Jemmie", "Jemmy", "Jen", "Jena", "Jenda", "Jenelle", "Jeni", "Jenica", "Jeniece", "Jenifer", "Jeniffer", "Jenilee", "Jenine", "Jenn", "Jenna", "Jennee", "Jennette", "Jenni", "Jennica", "Jennie", "Jennifer", "Jennilee", "Jennine", "Jenny", "Jeralee", "Jere", "Jeri", "Jermaine", "Jerrie", "Jerrilee", "Jerrilyn", "Jerrine", "Jerry", "Jerrylee", "Jess", "Jessa", "Jessalin", "Jessalyn", "Jessamine", "Jessamyn", "Jesse", "Jesselyn", "Jessi", "Jessica", "Jessie", "Jessika", "Jessy", "Jewel", "Jewell", "Jewelle", "Jill", "Jillana", "Jillane", "Jillayne", "Jilleen", "Jillene", "Jilli", "Jillian", "Jillie", "Jilly", "Jinny", "Jo", "Jo Ann", "Jo-Ann", "Jo-Anne", "Joan", "Joana", "Joane", "Joanie", "Joann", "Joanna", "Joanne", "Joannes", "Jobey", "Jobi", "Jobie", "Jobina", "Joby", "Jobye", "Jobyna", "Jocelin", "Joceline", "Jocelyn", "Jocelyne", "Jodee", "Jodi", "Jodie", "Jody", "Joeann", "Joela", "Joelie", "Joell", "Joella", "Joelle", "Joellen", "Joelly", "Joellyn", "Joelynn", "Joete", "Joey", "Johanna", "Johannah", "Johna", "Johnath", "Johnette", "Johnna", "Joice", "Jojo", "Jolee", "Joleen", "Jolene", "Joletta", "Joli", "Jolie", "Joline", "Joly", "Jolyn", "Jolynn", "Jonell", "Joni", "Jonie", "Jonis", "Jordain", "Jordan", "Jordana", "Jordanna", "Jorey", "Jori", "Jorie", "Jorrie", "Jorry", "Joscelin", "Josee", "Josefa", "Josefina", "Josepha", "Josephina", "Josephine", "Josey", "Josi", "Josie", "Josselyn", "Josy", "Jourdan", "Joy", "Joya", "Joyan", "Joyann", "Joyce", "Joycelin", "Joye", "Jsandye", "Juana", "Juanita", "Judi", "Judie", "Judith", "Juditha", "Judy", "Judye", "Juieta", "Julee", "Juli", "Julia", "Juliana", "Juliane", "Juliann", "Julianna", "Julianne", "Julie", "Julienne", "Juliet", "Julieta", "Julietta", "Juliette", "Julina", "Juline", "Julissa", "Julita", "June", "Junette", "Junia", "Junie", "Junina", "Justina", "Justine", "Justinn", "Jyoti", "Kacey", "Kacie", "Kacy", "Kaela", "Kai", "Kaia", "Kaila", "Kaile", "Kailey", "Kaitlin", "Kaitlyn", "Kaitlynn", "Kaja", "Kakalina", "Kala", "Kaleena", "Kali", "Kalie", "Kalila", "Kalina", "Kalinda", "Kalindi", "Kalli", "Kally", "Kameko", "Kamila", "Kamilah", "Kamillah", "Kandace", "Kandy", "Kania", "Kanya", "Kara", "Kara-Lynn", "Karalee", "Karalynn", "Kare", "Karee", "Karel", "Karen", "Karena", "Kari", "Karia", "Karie", "Karil", "Karilynn", "Karin", "Karina", "Karine", "Kariotta", "Karisa", "Karissa", "Karita", "Karla", "Karlee", "Karleen", "Karlen", "Karlene", "Karlie", "Karlotta", "Karlotte", "Karly", "Karlyn", "Karmen", "Karna", "Karol", "Karola", "Karole", "Karolina", "Karoline", "Karoly", "Karon", "Karrah", "Karrie", "Karry", "Kary", "Karyl", "Karylin", "Karyn", "Kasey", "Kass", "Kassandra", "Kassey", "Kassi", "Kassia", "Kassie", "Kat", "Kata", "Katalin", "Kate", "Katee", "Katerina", "Katerine", "Katey", "Kath", "Katha", "Katharina", "Katharine", "Katharyn", "Kathe", "Katherina", "Katherine", "Katheryn", "Kathi", "Kathie", "Kathleen", "Kathlin", "Kathrine", "Kathryn", "Kathryne", "Kathy", "Kathye", "Kati", "Katie", "Katina", "Katine", "Katinka", "Katleen", "Katlin", "Katrina", "Katrine", "Katrinka", "Katti", "Kattie", "Katuscha", "Katusha", "Katy", "Katya", "Kay", "Kaycee", "Kaye", "Kayla", "Kayle", "Kaylee", "Kayley", "Kaylil", "Kaylyn", "Keeley", "Keelia", "Keely", "Kelcey", "Kelci", "Kelcie", "Kelcy", "Kelila", "Kellen", "Kelley", "Kelli", "Kellia", "Kellie", "Kellina", "Kellsie", "Kelly", "Kellyann", "Kelsey", "Kelsi", "Kelsy", "Kendra", "Kendre", "Kenna", "Keri", "Keriann", "Kerianne", "Kerri", "Kerrie", "Kerrill", "Kerrin", "Kerry", "Kerstin", "Kesley", "Keslie", "Kessia", "Kessiah", "Ketti", "Kettie", "Ketty", "Kevina", "Kevyn", "Ki", "Kiah", "Kial", "Kiele", "Kiersten", "Kikelia", "Kiley", "Kim", "Kimberlee", "Kimberley", "Kimberli", "Kimberly", "Kimberlyn", "Kimbra", "Kimmi", "Kimmie", "Kimmy", "Kinna", "Kip", "Kipp", "Kippie", "Kippy", "Kira", "Kirbee", "Kirbie", "Kirby", "Kiri", "Kirsten", "Kirsteni", "Kirsti", "Kirstin", "Kirstyn", "Kissee", "Kissiah", "Kissie", "Kit", "Kitti", "Kittie", "Kitty", "Kizzee", "Kizzie", "Klara", "Klarika", "Klarrisa", "Konstance", "Konstanze", "Koo", "Kora", "Koral", "Koralle", "Kordula", "Kore", "Korella", "Koren", "Koressa", "Kori", "Korie", "Korney", "Korrie", "Korry", "Kris", "Krissie", "Krissy", "Krista", "Kristal", "Kristan", "Kriste", "Kristel", "Kristen", "Kristi", "Kristien", "Kristin", "Kristina", "Kristine", "Kristy", "Kristyn", "Krysta", "Krystal", "Krystalle", "Krystle", "Krystyna", "Kyla", "Kyle", "Kylen", "Kylie", "Kylila", "Kylynn", "Kym", "Kynthia", "Kyrstin", "La Verne", "Lacee", "Lacey", "Lacie", "Lacy", "Ladonna", "Laetitia", "Laina", "Lainey", "Lana", "Lanae", "Lane", "Lanette", "Laney", "Lani", "Lanie", "Lanita", "Lanna", "Lanni", "Lanny", "Lara", "Laraine", "Lari", "Larina", "Larine", "Larisa", "Larissa", "Lark", "Laryssa", "Latashia", "Latia", "Latisha", "Latrena", "Latrina", "Laura", "Lauraine", "Laural", "Lauralee", "Laure", "Lauree", "Laureen", "Laurel", "Laurella", "Lauren", "Laurena", "Laurene", "Lauretta", "Laurette", "Lauri", "Laurianne", "Laurice", "Laurie", "Lauryn", "Lavena", "Laverna", "Laverne", "Lavina", "Lavinia", "Lavinie", "Layla", "Layne", "Layney", "Lea", "Leah", "Leandra", "Leann", "Leanna", "Leanor", "Leanora", "Lebbie", "Leda", "Lee", "Leeann", "Leeanne", "Leela", "Leelah", "Leena", "Leesa", "Leese", "Legra", "Leia", "Leigh", "Leigha", "Leila", "Leilah", "Leisha", "Lela", "Lelah", "Leland", "Lelia", "Lena", "Lenee", "Lenette", "Lenka", "Lenna", "Lenora", "Lenore", "Leodora", "Leoine", "Leola", "Leoline", "Leona", "Leonanie", "Leone", "Leonelle", "Leonie", "Leonora", "Leonore", "Leontine", "Leontyne", "Leora", "Leshia", "Lesley", "Lesli", "Leslie", "Lesly", "Lesya", "Leta", "Lethia", "Leticia", "Letisha", "Letitia", "Letizia", "Letta", "Letti", "Lettie", "Letty", "Lexi", "Lexie", "Lexine", "Lexis", "Lexy", "Leyla", "Lezlie", "Lia", "Lian", "Liana", "Liane", "Lianna", "Lianne", "Lib", "Libbey", "Libbi", "Libbie", "Libby", "Licha", "Lida", "Lidia", "Liesa", "Lil", "Lila", "Lilah", "Lilas", "Lilia", "Lilian", "Liliane", "Lilias", "Lilith", "Lilla", "Lilli", "Lillian", "Lillis", "Lilllie", "Lilly", "Lily", "Lilyan", "Lin", "Lina", "Lind", "Linda", "Lindi", "Lindie", "Lindsay", "Lindsey", "Lindsy", "Lindy", "Linea", "Linell", "Linet", "Linette", "Linn", "Linnea", "Linnell", "Linnet", "Linnie", "Linzy", "Lira", "Lisa", "Lisabeth", "Lisbeth", "Lise", "Lisetta", "Lisette", "Lisha", "Lishe", "Lissa", "Lissi", "Lissie", "Lissy", "Lita", "Liuka", "Liv", "Liva", "Livia", "Livvie", "Livvy", "Livvyy", "Livy", "Liz", "Liza", "Lizabeth", "Lizbeth", "Lizette", "Lizzie", "Lizzy", "Loella", "Lois", "Loise", "Lola", "Loleta", "Lolita", "Lolly", "Lona", "Lonee", "Loni", "Lonna", "Lonni", "Lonnie", "Lora", "Lorain", "Loraine", "Loralee", "Loralie", "Loralyn", "Loree", "Loreen", "Lorelei", "Lorelle", "Loren", "Lorena", "Lorene", "Lorenza", "Loretta", "Lorette", "Lori", "Loria", "Lorianna", "Lorianne", "Lorie", "Lorilee", "Lorilyn", "Lorinda", "Lorine", "Lorita", "Lorna", "Lorne", "Lorraine", "Lorrayne", "Lorri", "Lorrie", "Lorrin", "Lorry", "Lory", "Lotta", "Lotte", "Lotti", "Lottie", "Lotty", "Lou", "Louella", "Louisa", "Louise", "Louisette", "Loutitia", "Lu", "Luce", "Luci", "Lucia", "Luciana", "Lucie", "Lucienne", "Lucila", "Lucilia", "Lucille", "Lucina", "Lucinda", "Lucine", "Lucita", "Lucky", "Lucretia", "Lucy", "Ludovika", "Luella", "Luelle", "Luisa", "Luise", "Lula", "Lulita", "Lulu", "Lura", "Lurette", "Lurleen", "Lurlene", "Lurline", "Lusa", "Luz", "Lyda", "Lydia", "Lydie", "Lyn", "Lynda", "Lynde", "Lyndel", "Lyndell", "Lyndsay", "Lyndsey", "Lyndsie", "Lyndy", "Lynea", "Lynelle", "Lynett", "Lynette", "Lynn", "Lynna", "Lynne", "Lynnea", "Lynnell", "Lynnelle", "Lynnet", "Lynnett", "Lynnette", "Lynsey", "Lyssa", "Mab", "Mabel", "Mabelle", "Mable", "Mada", "Madalena", "Madalyn", "Maddalena", "Maddi", "Maddie", "Maddy", "Madel", "Madelaine", "Madeleine", "Madelena", "Madelene", "Madelin", "Madelina", "Madeline", "Madella", "Madelle", "Madelon", "Madelyn", "Madge", "Madlen", "Madlin", "Madonna", "Mady", "Mae", "Maegan", "Mag", "Magda", "Magdaia", "Magdalen", "Magdalena", "Magdalene", "Maggee", "Maggi", "Maggie", "Maggy", "Mahala", "Mahalia", "Maia", "Maible", "Maiga", "Maighdiln", "Mair", "Maire", "Maisey", "Maisie", "Maitilde", "Mala", "Malanie", "Malena", "Malia", "Malina", "Malinda", "Malinde", "Malissa", "Malissia", "Mallissa", "Mallorie", "Mallory", "Malorie", "Malory", "Malva", "Malvina", "Malynda", "Mame", "Mamie", "Manda", "Mandi", "Mandie", "Mandy", "Manon", "Manya", "Mara", "Marabel", "Marcela", "Marcelia", "Marcella", "Marcelle", "Marcellina", "Marcelline", "Marchelle", "Marci", "Marcia", "Marcie", "Marcile", "Marcille", "Marcy", "Mareah", "Maren", "Marena", "Maressa", "Marga", "Margalit", "Margalo", "Margaret", "Margareta", "Margarete", "Margaretha", "Margarethe", "Margaretta", "Margarette", "Margarita", "Margaux", "Marge", "Margeaux", "Margery", "Marget", "Margette", "Margi", "Margie", "Margit", "Margo", "Margot", "Margret", "Marguerite", "Margy", "Mari", "Maria", "Mariam", "Marian", "Mariana", "Mariann", "Marianna", "Marianne", "Maribel", "Maribelle", "Maribeth", "Marice", "Maridel", "Marie", "Marie-Ann", "Marie-Jeanne", "Marieann", "Mariejeanne", "Mariel", "Mariele", "Marielle", "Mariellen", "Marietta", "Mariette", "Marigold", "Marijo", "Marika", "Marilee", "Marilin", "Marillin", "Marilyn", "Marin", "Marina", "Marinna", "Marion", "Mariquilla", "Maris", "Marisa", "Mariska", "Marissa", "Marita", "Maritsa", "Mariya", "Marj", "Marja", "Marje", "Marji", "Marjie", "Marjorie", "Marjory", "Marjy", "Marketa", "Marla", "Marlane", "Marleah", "Marlee", "Marleen", "Marlena", "Marlene", "Marley", "Marlie", "Marline", "Marlo", "Marlyn", "Marna", "Marne", "Marney", "Marni", "Marnia", "Marnie", "Marquita", "Marrilee", "Marris", "Marrissa", "Marsha", "Marsiella", "Marta", "Martelle", "Martguerita", "Martha", "Marthe", "Marthena", "Marti", "Martica", "Martie", "Martina", "Martita", "Marty", "Martynne", "Mary", "Marya", "Maryann", "Maryanna", "Maryanne", "Marybelle", "Marybeth", "Maryellen", "Maryjane", "Maryjo", "Maryl", "Marylee", "Marylin", "Marylinda", "Marylou", "Marylynne", "Maryrose", "Marys", "Marysa", "Masha", "Matelda", "Mathilda", "Mathilde", "Matilda", "Matilde", "Matti", "Mattie", "Matty", "Maud", "Maude", "Maudie", "Maura", "Maure", "Maureen", "Maureene", "Maurene", "Maurine", "Maurise", "Maurita", "Maurizia", "Mavis", "Mavra", "Max", "Maxi", "Maxie", "Maxine", "Maxy", "May", "Maybelle", "Maye", "Mead", "Meade", "Meagan", "Meaghan", "Meara", "Mechelle", "Meg", "Megan", "Megen", "Meggi", "Meggie", "Meggy", "Meghan", "Meghann", "Mehetabel", "Mei", "Mel", "Mela", "Melamie", "Melania", "Melanie", "Melantha", "Melany", "Melba", "Melesa", "Melessa", "Melicent", "Melina", "Melinda", "Melinde", "Melisa", "Melisande", "Melisandra", "Melisenda", "Melisent", "Melissa", "Melisse", "Melita", "Melitta", "Mella", "Melli", "Mellicent", "Mellie", "Mellisa", "Mellisent", "Melloney", "Melly", "Melodee", "Melodie", "Melody", "Melonie", "Melony", "Melosa", "Melva", "Mercedes", "Merci", "Mercie", "Mercy", "Meredith", "Meredithe", "Meridel", "Meridith", "Meriel", "Merilee", "Merilyn", "Meris", "Merissa", "Merl", "Merla", "Merle", "Merlina", "Merline", "Merna", "Merola", "Merralee", "Merridie", "Merrie", "Merrielle", "Merrile", "Merrilee", "Merrili", "Merrill", "Merrily", "Merry", "Mersey", "Meryl", "Meta", "Mia", "Micaela", "Michaela", "Michaelina", "Michaeline", "Michaella", "Michal", "Michel", "Michele", "Michelina", "Micheline", "Michell", "Michelle", "Micki", "Mickie", "Micky", "Midge", "Mignon", "Mignonne", "Miguela", "Miguelita", "Mikaela", "Mil", "Mildred", "Mildrid", "Milena", "Milicent", "Milissent", "Milka", "Milli", "Millicent", "Millie", "Millisent", "Milly", "Milzie", "Mimi", "Min", "Mina", "Minda", "Mindy", "Minerva", "Minetta", "Minette", "Minna", "Minnaminnie", "Minne", "Minni", "Minnie", "Minnnie", "Minny", "Minta", "Miof Mela", "Miquela", "Mira", "Mirabel", "Mirabella", "Mirabelle", "Miran", "Miranda", "Mireielle", "Mireille", "Mirella", "Mirelle", "Miriam", "Mirilla", "Mirna", "Misha", "Missie", "Missy", "Misti", "Misty", "Mitzi", "Modesta", "Modestia", "Modestine", "Modesty", "Moina", "Moira", "Moll", "Mollee", "Molli", "Mollie", "Molly", "Mommy", "Mona", "Monah", "Monica", "Monika", "Monique", "Mora", "Moreen", "Morena", "Morgan", "Morgana", "Morganica", "Morganne", "Morgen", "Moria", "Morissa", "Morna", "Moselle", "Moyna", "Moyra", "Mozelle", "Muffin", "Mufi", "Mufinella", "Muire", "Mureil", "Murial", "Muriel", "Murielle", "Myra", "Myrah", "Myranda", "Myriam", "Myrilla", "Myrle", "Myrlene", "Myrna", "Myrta", "Myrtia", "Myrtice", "Myrtie", "Myrtle", "Nada", "Nadean", "Nadeen", "Nadia", "Nadine", "Nadiya", "Nady", "Nadya", "Nalani", "Nan", "Nana", "Nananne", "Nance", "Nancee", "Nancey", "Nanci", "Nancie", "Nancy", "Nanete", "Nanette", "Nani", "Nanice", "Nanine", "Nannette", "Nanni", "Nannie", "Nanny", "Nanon", "Naoma", "Naomi", "Nara", "Nari", "Nariko", "Nat", "Nata", "Natala", "Natalee", "Natalie", "Natalina", "Nataline", "Natalya", "Natasha", "Natassia", "Nathalia", "Nathalie", "Natividad", "Natka", "Natty", "Neala", "Neda", "Nedda", "Nedi", "Neely", "Neila", "Neile", "Neilla", "Neille", "Nelia", "Nelie", "Nell", "Nelle", "Nelli", "Nellie", "Nelly", "Nerissa", "Nerita", "Nert", "Nerta", "Nerte", "Nerti", "Nertie", "Nerty", "Nessa", "Nessi", "Nessie", "Nessy", "Nesta", "Netta", "Netti", "Nettie", "Nettle", "Netty", "Nevsa", "Neysa", "Nichol", "Nichole", "Nicholle", "Nicki", "Nickie", "Nicky", "Nicol", "Nicola", "Nicole", "Nicolea", "Nicolette", "Nicoli", "Nicolina", "Nicoline", "Nicolle", "Nikaniki", "Nike", "Niki", "Nikki", "Nikkie", "Nikoletta", "Nikolia", "Nina", "Ninetta", "Ninette", "Ninnetta", "Ninnette", "Ninon", "Nissa", "Nisse", "Nissie", "Nissy", "Nita", "Nixie", "Noami", "Noel", "Noelani", "Noell", "Noella", "Noelle", "Noellyn", "Noelyn", "Noemi", "Nola", "Nolana", "Nolie", "Nollie", "Nomi", "Nona", "Nonah", "Noni", "Nonie", "Nonna", "Nonnah", "Nora", "Norah", "Norean", "Noreen", "Norene", "Norina", "Norine", "Norma", "Norri", "Norrie", "Norry", "Novelia", "Nydia", "Nyssa", "Octavia", "Odele", "Odelia", "Odelinda", "Odella", "Odelle", "Odessa", "Odetta", "Odette", "Odilia", "Odille", "Ofelia", "Ofella", "Ofilia", "Ola", "Olenka", "Olga", "Olia", "Olimpia", "Olive", "Olivette", "Olivia", "Olivie", "Oliy", "Ollie", "Olly", "Olva", "Olwen", "Olympe", "Olympia", "Olympie", "Ondrea", "Oneida", "Onida", "Oona", "Opal", "Opalina", "Opaline", "Ophelia", "Ophelie", "Ora", "Oralee", "Oralia", "Oralie", "Oralla", "Oralle", "Orel", "Orelee", "Orelia", "Orelie", "Orella", "Orelle", "Oriana", "Orly", "Orsa", "Orsola", "Ortensia", "Otha", "Othelia", "Othella", "Othilia", "Othilie", "Ottilie", "Page", "Paige", "Paloma", "Pam", "Pamela", "Pamelina", "Pamella", "Pammi", "Pammie", "Pammy", "Pandora", "Pansie", "Pansy", "Paola", "Paolina", "Papagena", "Pat", "Patience", "Patrica", "Patrice", "Patricia", "Patrizia", "Patsy", "Patti", "Pattie", "Patty", "Paula", "Paule", "Pauletta", "Paulette", "Pauli", "Paulie", "Paulina", "Pauline", "Paulita", "Pauly", "Pavia", "Pavla", "Pearl", "Pearla", "Pearle", "Pearline", "Peg", "Pegeen", "Peggi", "Peggie", "Peggy", "Pen", "Penelopa", "Penelope", "Penni", "Pennie", "Penny", "Pepi", "Pepita", "Peri", "Peria", "Perl", "Perla", "Perle", "Perri", "Perrine", "Perry", "Persis", "Pet", "Peta", "Petra", "Petrina", "Petronella", "Petronia", "Petronilla", "Petronille", "Petunia", "Phaedra", "Phaidra", "Phebe", "Phedra", "Phelia", "Phil", "Philipa", "Philippa", "Philippe", "Philippine", "Philis", "Phillida", "Phillie", "Phillis", "Philly", "Philomena", "Phoebe", "Phylis", "Phyllida", "Phyllis", "Phyllys", "Phylys", "Pia", "Pier", "Pierette", "Pierrette", "Pietra", "Piper", "Pippa", "Pippy", "Polly", "Pollyanna", "Pooh", "Poppy", "Portia", "Pris", "Prisca", "Priscella", "Priscilla", "Prissie", "Pru", "Prudence", "Prudi", "Prudy", "Prue", "Queenie", "Quentin", "Querida", "Quinn", "Quinta", "Quintana", "Quintilla", "Quintina", "Rachael", "Rachel", "Rachele", "Rachelle", "Rae", "Raeann", "Raf", "Rafa", "Rafaela", "Rafaelia", "Rafaelita", "Rahal", "Rahel", "Raina", "Raine", "Rakel", "Ralina", "Ramona", "Ramonda", "Rana", "Randa", "Randee", "Randene", "Randi", "Randie", "Randy", "Ranee", "Rani", "Rania", "Ranice", "Ranique", "Ranna", "Raphaela", "Raquel", "Raquela", "Rasia", "Rasla", "Raven", "Ray", "Raychel", "Raye", "Rayna", "Raynell", "Rayshell", "Rea", "Reba", "Rebbecca", "Rebe", "Rebeca", "Rebecca", "Rebecka", "Rebeka", "Rebekah", "Rebekkah", "Ree", "Reeba", "Reena", "Reeta", "Reeva", "Regan", "Reggi", "Reggie", "Regina", "Regine", "Reiko", "Reina", "Reine", "Remy", "Rena", "Renae", "Renata", "Renate", "Rene", "Renee", "Renell", "Renelle", "Renie", "Rennie", "Reta", "Retha", "Revkah", "Rey", "Reyna", "Rhea", "Rheba", "Rheta", "Rhetta", "Rhiamon", "Rhianna", "Rhianon", "Rhoda", "Rhodia", "Rhodie", "Rhody", "Rhona", "Rhonda", "Riane", "Riannon", "Rianon", "Rica", "Ricca", "Rici", "Ricki", "Rickie", "Ricky", "Riki", "Rikki", "Rina", "Risa", "Rita", "Riva", "Rivalee", "Rivi", "Rivkah", "Rivy", "Roana", "Roanna", "Roanne", "Robbi", "Robbie", "Robbin", "Robby", "Robbyn", "Robena", "Robenia", "Roberta", "Robin", "Robina", "Robinet", "Robinett", "Robinetta", "Robinette", "Robinia", "Roby", "Robyn", "Roch", "Rochell", "Rochella", "Rochelle", "Rochette", "Roda", "Rodi", "Rodie", "Rodina", "Rois", "Romola", "Romona", "Romonda", "Romy", "Rona", "Ronalda", "Ronda", "Ronica", "Ronna", "Ronni", "Ronnica", "Ronnie", "Ronny", "Roobbie", "Rora", "Rori", "Rorie", "Rory", "Ros", "Rosa", "Rosabel", "Rosabella", "Rosabelle", "Rosaleen", "Rosalia", "Rosalie", "Rosalind", "Rosalinda", "Rosalinde", "Rosaline", "Rosalyn", "Rosalynd", "Rosamond", "Rosamund", "Rosana", "Rosanna", "Rosanne", "Rose", "Roseann", "Roseanna", "Roseanne", "Roselia", "Roselin", "Roseline", "Rosella", "Roselle", "Rosemaria", "Rosemarie", "Rosemary", "Rosemonde", "Rosene", "Rosetta", "Rosette", "Roshelle", "Rosie", "Rosina", "Rosita", "Roslyn", "Rosmunda", "Rosy", "Row", "Rowe", "Rowena", "Roxana", "Roxane", "Roxanna", "Roxanne", "Roxi", "Roxie", "Roxine", "Roxy", "Roz", "Rozalie", "Rozalin", "Rozamond", "Rozanna", "Rozanne", "Roze", "Rozele", "Rozella", "Rozelle", "Rozina", "Rubetta", "Rubi", "Rubia", "Rubie", "Rubina", "Ruby", "Ruperta", "Ruth", "Ruthann", "Ruthanne", "Ruthe", "Ruthi", "Ruthie", "Ruthy", "Ryann", "Rycca", "Saba", "Sabina", "Sabine", "Sabra", "Sabrina", "Sacha", "Sada", "Sadella", "Sadie", "Sadye", "Saidee", "Sal", "Salaidh", "Sallee", "Salli", "Sallie", "Sally", "Sallyann", "Sallyanne", "Saloma", "Salome", "Salomi", "Sam", "Samantha", "Samara", "Samaria", "Sammy", "Sande", "Sandi", "Sandie", "Sandra", "Sandy", "Sandye", "Sapphira", "Sapphire", "Sara", "Sara-Ann", "Saraann", "Sarah", "Sarajane", "Saree", "Sarena", "Sarene", "Sarette", "Sari", "Sarina", "Sarine", "Sarita", "Sascha", "Sasha", "Sashenka", "Saudra", "Saundra", "Savina", "Sayre", "Scarlet", "Scarlett", "Sean", "Seana", "Seka", "Sela", "Selena", "Selene", "Selestina", "Selia", "Selie", "Selina", "Selinda", "Seline", "Sella", "Selle", "Selma", "Sena", "Sephira", "Serena", "Serene", "Shae", "Shaina", "Shaine", "Shalna", "Shalne", "Shana", "Shanda", "Shandee", "Shandeigh", "Shandie", "Shandra", "Shandy", "Shane", "Shani", "Shanie", "Shanna", "Shannah", "Shannen", "Shannon", "Shanon", "Shanta", "Shantee", "Shara", "Sharai", "Shari", "Sharia", "Sharity", "Sharl", "Sharla", "Sharleen", "Sharlene", "Sharline", "Sharon", "Sharona", "Sharron", "Sharyl", "Shaun", "Shauna", "Shawn", "Shawna", "Shawnee", "Shay", "Shayla", "Shaylah", "Shaylyn", "Shaylynn", "Shayna", "Shayne", "Shea", "Sheba", "Sheela", "Sheelagh", "Sheelah", "Sheena", "Sheeree", "Sheila", "Sheila-Kathryn", "Sheilah", "Shel", "Shela", "Shelagh", "Shelba", "Shelbi", "Shelby", "Shelia", "Shell", "Shelley", "Shelli", "Shellie", "Shelly", "Shena", "Sher", "Sheree", "Sheri", "Sherie", "Sherill", "Sherilyn", "Sherline", "Sherri", "Sherrie", "Sherry", "Sherye", "Sheryl", "Shina", "Shir", "Shirl", "Shirlee", "Shirleen", "Shirlene", "Shirley", "Shirline", "Shoshana", "Shoshanna", "Siana", "Sianna", "Sib", "Sibbie", "Sibby", "Sibeal", "Sibel", "Sibella", "Sibelle", "Sibilla", "Sibley", "Sibyl", "Sibylla", "Sibylle", "Sidoney", "Sidonia", "Sidonnie", "Sigrid", "Sile", "Sileas", "Silva", "Silvana", "Silvia", "Silvie", "Simona", "Simone", "Simonette", "Simonne", "Sindee", "Siobhan", "Sioux", "Siouxie", "Sisely", "Sisile", "Sissie", "Sissy", "Siusan", "Sofia", "Sofie", "Sondra", "Sonia", "Sonja", "Sonni", "Sonnie", "Sonnnie", "Sonny", "Sonya", "Sophey", "Sophi", "Sophia", "Sophie", "Sophronia", "Sorcha", "Sosanna", "Stace", "Stacee", "Stacey", "Staci", "Stacia", "Stacie", "Stacy", "Stafani", "Star", "Starla", "Starlene", "Starlin", "Starr", "Stefa", "Stefania", "Stefanie", "Steffane", "Steffi", "Steffie", "Stella", "Stepha", "Stephana", "Stephani", "Stephanie", "Stephannie", "Stephenie", "Stephi", "Stephie", "Stephine", "Stesha", "Stevana", "Stevena", "Stoddard", "Storm", "Stormi", "Stormie", "Stormy", "Sue", "Suellen", "Sukey", "Suki", "Sula", "Sunny", "Sunshine", "Susan", "Susana", "Susanetta", "Susann", "Susanna", "Susannah", "Susanne", "Susette", "Susi", "Susie", "Susy", "Suzann", "Suzanna", "Suzanne", "Suzette", "Suzi", "Suzie", "Suzy", "Sybil", "Sybila", "Sybilla", "Sybille", "Sybyl", "Sydel", "Sydelle", "Sydney", "Sylvia", "Tabatha", "Tabbatha", "Tabbi", "Tabbie", "Tabbitha", "Tabby", "Tabina", "Tabitha", "Taffy", "Talia", "Tallia", "Tallie", "Tallou", "Tallulah", "Tally", "Talya", "Talyah", "Tamar", "Tamara", "Tamarah", "Tamarra", "Tamera", "Tami", "Tamiko", "Tamma", "Tammara", "Tammi", "Tammie", "Tammy", "Tamqrah", "Tamra", "Tana", "Tandi", "Tandie", "Tandy", "Tanhya", "Tani", "Tania", "Tanitansy", "Tansy", "Tanya", "Tara", "Tarah", "Tarra", "Tarrah", "Taryn", "Tasha", "Tasia", "Tate", "Tatiana", "Tatiania", "Tatum", "Tawnya", "Tawsha", "Ted", "Tedda", "Teddi", "Teddie", "Teddy", "Tedi", "Tedra", "Teena", "TEirtza", "Teodora", "Tera", "Teresa", "Terese", "Teresina", "Teresita", "Teressa", "Teri", "Teriann", "Terra", "Terri", "Terrie", "Terrijo", "Terry", "Terrye", "Tersina", "Terza", "Tess", "Tessa", "Tessi", "Tessie", "Tessy", "Thalia", "Thea", "Theadora", "Theda", "Thekla", "Thelma", "Theo", "Theodora", "Theodosia", "Theresa", "Therese", "Theresina", "Theresita", "Theressa", "Therine", "Thia", "Thomasa", "Thomasin", "Thomasina", "Thomasine", "Tiena", "Tierney", "Tiertza", "Tiff", "Tiffani", "Tiffanie", "Tiffany", "Tiffi", "Tiffie", "Tiffy", "Tilda", "Tildi", "Tildie", "Tildy", "Tillie", "Tilly", "Tim", "Timi", "Timmi", "Timmie", "Timmy", "Timothea", "Tina", "Tine", "Tiphani", "Tiphanie", "Tiphany", "Tish", "Tisha", "Tobe", "Tobey", "Tobi", "Toby", "Tobye", "Toinette", "Toma", "Tomasina", "Tomasine", "Tomi", "Tommi", "Tommie", "Tommy", "Toni", "Tonia", "Tonie", "Tony", "Tonya", "Tonye", "Tootsie", "Torey", "Tori", "Torie", "Torrie", "Tory", "Tova", "Tove", "Tracee", "Tracey", "Traci", "Tracie", "Tracy", "Trenna", "Tresa", "Trescha", "Tressa", "Tricia", "Trina", "Trish", "Trisha", "Trista", "Trix", "Trixi", "Trixie", "Trixy", "Truda", "Trude", "Trudey", "Trudi", "Trudie", "Trudy", "Trula", "Tuesday", "Twila", "Twyla", "Tybi", "Tybie", "Tyne", "Ula", "Ulla", "Ulrica", "Ulrika", "Ulrikaumeko", "Ulrike", "Umeko", "Una", "Ursa", "Ursala", "Ursola", "Ursula", "Ursulina", "Ursuline", "Uta", "Val", "Valaree", "Valaria", "Vale", "Valeda", "Valencia", "Valene", "Valenka", "Valentia", "Valentina", "Valentine", "Valera", "Valeria", "Valerie", "Valery", "Valerye", "Valida", "Valina", "Valli", "Vallie", "Vally", "Valma", "Valry", "Van", "Vanda", "Vanessa", "Vania", "Vanna", "Vanni", "Vannie", "Vanny", "Vanya", "Veda", "Velma", "Velvet", "Venita", "Venus", "Vera", "Veradis", "Vere", "Verena", "Verene", "Veriee", "Verile", "Verina", "Verine", "Verla", "Verna", "Vernice", "Veronica", "Veronika", "Veronike", "Veronique", "Vevay", "Vi", "Vicki", "Vickie", "Vicky", "Victoria", "Vida", "Viki", "Vikki", "Vikky", "Vilhelmina", "Vilma", "Vin", "Vina", "Vinita", "Vinni", "Vinnie", "Vinny", "Viola", "Violante", "Viole", "Violet", "Violetta", "Violette", "Virgie", "Virgina", "Virginia", "Virginie", "Vita", "Vitia", "Vitoria", "Vittoria", "Viv", "Viva", "Vivi", "Vivia", "Vivian", "Viviana", "Vivianna", "Vivianne", "Vivie", "Vivien", "Viviene", "Vivienne", "Viviyan", "Vivyan", "Vivyanne", "Vonni", "Vonnie", "Vonny", "Vyky", "Wallie", "Wallis", "Walliw", "Wally", "Waly", "Wanda", "Wandie", "Wandis", "Waneta", "Wanids", "Wenda", "Wendeline", "Wendi", "Wendie", "Wendy", "Wendye", "Wenona", "Wenonah", "Whitney", "Wileen", "Wilhelmina", "Wilhelmine", "Wilie", "Willa", "Willabella", "Willamina", "Willetta", "Willette", "Willi", "Willie", "Willow", "Willy", "Willyt", "Wilma", "Wilmette", "Wilona", "Wilone", "Wilow", "Windy", "Wini", "Winifred", "Winna", "Winnah", "Winne", "Winni", "Winnie", "Winnifred", "Winny", "Winona", "Winonah", "Wren", "Wrennie", "Wylma", "Wynn", "Wynne", "Wynnie", "Wynny", "Xaviera", "Xena", "Xenia", "Xylia", "Xylina", "Yalonda", "Yasmeen", "Yasmin", "Yelena", "Yetta", "Yettie", "Yetty", "Yevette", "Ynes", "Ynez", "Yoko", "Yolanda", "Yolande", "Yolane", "Yolanthe", "Yoshi", "Yoshiko", "Yovonnda", "Ysabel", "Yvette", "Yvonne", "Zabrina", "Zahara", "Zandra", "Zaneta", "Zara", "Zarah", "Zaria", "Zarla", "Zea", "Zelda", "Zelma", "Zena", "Zenia", "Zia", "Zilvia", "Zita", "Zitella", "Zoe", "Zola", "Zonda", "Zondra", "Zonnya", "Zora", "Zorah", "Zorana", "Zorina", "Zorine", "Zsa Zsa", "Zsazsa", "Zulema", "Zuzana"}
	GenKoreaName    = []string{"(지연) Ji-yeon", "(해원) Hae-won", "(민지) Min-ji", "(수경) Soo-kyung", "(미연) Mi-yeon", "(은지) Eun-ji", "(연주) Yeon-joo", "(지혜) Ji-hye", "(혜원) Hye-won", "(나리) Na-ri", "(민석) Min-seok", "(지현) Ji-hyun", "(재원) Jae-won", "(은수) Eun-su", "(영희) Young-hee", "(태준) Tae-jun", "(유정) Yoo-jung", "(현수) Hyun-su", "(서영) Seo-young", "(민경) Min-kyung", "(선영) Seon-young", "(정수) Jung-soo", "(영수) Young-su", "(현지) Hyun-ji", "(재영) Jae-young", "(하린) Ha-rin", "(태우) Tae-woo", "(지원) Ji-won", "(세정) Se-jung", "(현우) Hyun-woo", "(은서) Eun-seo", "(민서) Min-seo", "(선우) Sun-woo", "(유미) Yoo-mi", "(경수) Kyung-su", "(지수) Ji-soo", "(준영) Jun-young", "(희경) Hee-kyung", "(주원) Ju-won", "(연수) Yeon-su", "(진우) Jin-woo", "(정민) Jung-min", "(소영) So-young", "(세은) Se-eun", "(효진) Hyo-jin", "(다현) Da-hyun", "(영진) Young-jin", "(민영) Min-young", "(성호) Sung-ho", "(석현) Seok-hyun", "(성민) Sung-min", "(우빈) Woo-bin", "(민재) Min-jae", "(승우) Seung-woo", "(수빈) Su-bin", "(혜린) Hye-rin", "(민선) Min-seon", "(은경) Eun-kyung", "(영미) Young-mi", "(태석) Tae-seok", "(현아) Hyun-a", "(지한) Ji-han", "(하은) Ha-eun", "(도현) Do-hyun", "(하은) Ha-eun", "(태현) Tae-hyun", "(지안) Ji-an", "(소희) So-hee", "(재민) Jae-min", "(혜인) Hye-in", "(재연) Jae-yeon", "(예린) Ye-rin", "(다온) Da-on", "(은영) Eun-young", "(주희) Ju-hee", "(민지) Min-ji", "(하은) Ha-eun", "(은아) Eun-a", "(지민) Ji-min", "(지은) Ji-eun", "(태경) Tae-kyung", "(소현) So-hyun", "(은주) Eun-ju", "(유나) Yu-na", "(민규) Min-gyu", "(세아) Se-a", "(민우) Min-woo", "(수진) Su-jin", "(진혁) Jin-hyuk", "(채원) Chae-won", "(재윤) Jae-yoon", "(현지) Hyun-ji", "(다원) Da-won", "(민호) Min-ho", "(수아) Su-a", "(예은) Ye-eun", "(민수) Min-su", "(재화) Jae-hwa", "(나리) Na-ri", "(재민) Jae-min", "(하인) Ha-in", "(민재) Min-jae", "(지윤) Ji-yoon", "(현지) Hyun-ji", "(상훈) Sang-hoon", "(지예) Ji-ye", "(은우) Eun-woo", "(서현) Seo-hyun", "(재영) Jae-young", "(유리) Yoo-ri", "(진호) Jin-ho", "(가영) Ga-young", "(민석) Min-seok", "(지아) Ji-a", "(승연) Seung-yeon", "(유정) Yoo-jung", "(해경) Hae-kyung", "(재욱) Jae-wook", "(연진) Yeon-jin", "(동하) Dong-ha"}
	GenJapanName    = []string{"Yamada Taro", "Suzuki Ichiro", "Sato Jiro", "Takahashi Saburo", "Tanaka Shiro", "Ito Goro", "Watanabe Rokuro", "Yamaguchi Shichiro", "Nakamura Hachiro", "Kobayashi Kurou", "Kato Juro", "Kimura Juichiro", "Hayashi Juniro", "Saito Juusaburo", "Shimizu Juushiro", "Yamazaki Juugoro", "Mori Juuro", "Abe Juushichiro", "Ishikawa Juuhachiro", "Hashimoto Juukyuro", "Yamashita Hatsuro", "Matsumoto Nijuichiro", "Inoue Nijunihiro", "Okada Nijuusanro", "Tamura Nijuushiro", "Nakajima Nijuugoro", "Ogawa Nijuuro", "Aoki Nijuushichiro", "Fujita Nijuuhachiro", "Murata Nijuukyuro", "Sasaki Sanjuuro", "Kato Sanjuichiro", "Takahashi Sanjuniro", "Ito Sanjusaburo", "Watanabe Sanjuushiro", "Yamaguchi Sanjuugoro", "Nakamura Sanjuuroku", "Kobayashi Sanjuushichiro", "Tanaka Sanjuuhachiro", "Suzuki Sanjuukyuro", "Yamada Yonjuuro", "Sato Yonjuichiro", "Takahashi Yonjuniro", "Tanaka Yonjusaburo", "Ito Yonjuushiro", "Watanabe Yonjuugoro", "Yamaguchi Yonjuuroku", "Nakamura Yonjuushichiro", "Kobayashi Yonjuuhachiro", "Tanaka Yonjuukyuro", "Kato Gojuuro", "Yamada Gojuichiro", "Suzuki Gojuniro", "Sato Gojusaburo", "Takahashi Gojushiro", "Tanaka Gojuugoro", "Ito Gojuuro", "Watanabe Gojushichiro", "Yamaguchi Gojuuhachiro", "Nakamura Gojuukyuro", "Kobayashi Rokujuuro", "Tanaka Rokujuichiro", "Yamada Rokujuniro", "Suzuki Rokujusaburo", "Sato Rokujushiro", "Takahashi Rokujuugoro", "Ito Rokujuuro", "Watanabe Rokujuushichiro", "Yamaguchi Rokujuuhachiro", "Nakamura Rokujuukyuro", "Kobayashi Nanajuuro", "Tanaka Nanajuichiro", "Yamada Nanajuniro", "Suzuki Nanajusaburo", "Sato Nanajushiro", "Takahashi Nanajuugoro", "Ito Nanajuuro", "Watanabe Nanajuushichiro", "Yamaguchi Nanjuuhachiro", "Nakamura Nanjuukyuro", "Kobayashi Hachijuuro", "Tanaka Hachijuichiro", "Yamada Hachijuniro", "Suzuki Hachijusaburo", "Sato Hachijushiro", "Takahashi Hachijuugoro", "Ito Hachijuuro", "Watanabe Hachijuushichiro", "Yamaguchi Hachijuuhachiro", "Nakamura Hachijuukyuro", "Kobayashi Kyujuuro", "Tanaka Kyujuichiro", "Yamada Kyujuniro", "Suzuki Kyujusaburo", "Sato Kyujushiro", "Takahashi Kyujuugoro", "Ito Kyujuuro", "Watanabe Kyujuushichiro", "Yamaguchi Kyujuuhachiro", "Nakamura Kyujuukyuro", "Kobayashi Hyakuuro", "Tanaka Hyakuichiro", "Yamada Hyakujuniro", "Suzuki Hyakujusaburo", "Sato Hyakujushiro", "Takahashi Hyakujuugoro", "Ito Hyakujuuro", "Watanabe Hyakujuushichiro", "Yamaguchi Hyakujuuhachiro", "Nakamura Hyakujuukyuro", "Kobayashi Senjuuro", "Tanaka Senjuichiro", "Yamada Senjuniro", "Suzuki Senjusaburo", "Sato Senjushiro", "Takahashi Senjuugoro", "Ito Senjuuro", "Watanabe Senjuushichiro", "Yamaguchi Senjuuhachiro", "Nakamura Senjuukyuro", "Kobayashi Ichijuuro", "Tanaka Ichijuichiro", "Yamada Ichijuniro", "Suzuki Ichijusaburo", "Sato Ichijushiro", "Takahashi Ichijuugoro", "Ito Ichijuuro", "Watanabe Ichijuushichiro", "Yamaguchi Ichijuuhachiro", "Nakamura Ichijuukyuro", "Kobayashi Juuichirou", "Tanaka Juuichirou", "Yamada Juuichirou", "Suzuki Juuichirou", "Sato Juuichirou", "Takahashi Juuichirou", "Ito Juuichirou", "Watanabe Juuichirou", "Yamaguchi Juuichirou", "Nakamura Juuichirou", "Kobayashi Juunichirou", "Tanaka Juunichirou", "Yamada Juunichirou", "Suzuki Juunichirou", "Sato Juunichirou", "Takahashi Juunichirou", "Ito Juunichirou", "Watanabe Juunichirou", "Yamaguchi Juunichirou", "Nakamura Juunichirou", "Kobayashi Juusanjirou", "Tanaka Juusanjirou", "Yamada Juusanjirou", "Suzuki Juusanjirou", "Sato Juusanjirou", "Takahashi Juusanjirou", "Ito Juusanjirou", "Watanabe Juusanjirou", "Yamaguchi Juusanjirou", "Nakamura Juusanjirou", "Kobayashi Juuyonjirou", "Tanaka Juuyonjirou", "Yamada Juuyonjirou", "Suzuki Juuyonjirou", "Sato Juuyonjirou", "Takahashi Juuyonjirou", "Ito Juuyonjirou", "Watanabe Juuyonjirou", "Yamaguchi Juuyonjirou", "Nakamura Juuyonjirou", "Kobayashi Juugojirou", "Tanaka Juugojirou", "Yamada Juugojirou", "Suzuki Juugojirou", "Sato Juugojirou", "Takahashi Juugojirou", "Ito Juugojirou", "Watanabe Juugojirou", "Yamaguchi Juugojirou", "Nakamura Juugojirou", "Kobayashi Juurokujirou", "Tanaka Juurokujirou", "Yamada Juurokujirou", "Suzuki Juurokujirou", "Sato Juurokujirou", "Takahashi Juurokujirou", "Ito Juurokujirou", "Watanabe Juurokujirou", "Yamaguchi Juurokujirou", "Nakamura Juurokujirou", "Kobayashi Juushichirou", "Tanaka Juushichirou", "Yamada Juushichirou", "Suzuki Juushichirou", "Sato Juushichirou", "Takahashi Juushichirou", "Ito Juushichirou", "Watanabe Juushichirou", "Yamaguchi Juushichirou", "Nakamura Juushichirou", "Kobayashi Juuhachirou", "Tanaka Juuhachirou", "Yamada Juuhachirou", "Suzuki Juuhachirou", "Sato Juuhachirou", "Takahashi Juuhachirou", "Ito Juuhachirou", "Watanabe Juuhachirou", "Yamaguchi Juuhachirou", "Nakamura Juuhachirou", "Kobayashi Juukyuuji", "Tanaka Juukyuuji", "Yamada Juukyuuji", "Suzuki Juukyuuji", "Sato Juukyuuji", "Takahashi Juukyuuji", "Ito Juukyuuji", "Watanabe Juukyuuji", "Yamaguchi Juukyuuji", "Nakamura Juukyuuji", "Kobayashi Nijuui", "Tanaka Nijuui", "Yamada Nijuui", "Suzuki Nijuui", "Sato Nijuui", "Takahashi Nijuui", "Ito Nijuui", "Watanabe Nijuui", "Yamaguchi Nijuui", "Nakamura Nijuui", "Kobayashi Nijuuichi", "Tanaka Nijuuichi", "Yamada Nijuuichi", "Suzuki Nijuuichi", "Sato Nijuuichi", "Takahashi Nijuuichi", "Ito Nijuuichi", "Watanabe Nijuuichi", "Yamaguchi Nijuuichi", "Nakamura Nijuuichi", "Kobayashi Nijuuni", "Tanaka Nijuuni", "Yamada Nijuuni", "Suzuki Nijuuni", "Sato Nijuuni", "Takahashi Nijuuni", "Ito Nijuuni", "Watanabe Nijuuni", "Yamaguchi Nijuuni", "Nakamura Nijuuni", "Kobayashi Nijuusan", "Tanaka Nijuusan", "Yamada Nijuusan", "Suzuki Nijuusan", "Sato Nijuusan", "Takahashi Nijuusan", "Ito Nijuusan", "Watanabe Nijuusan", "Yamaguchi Nijuusan", "Nakamura Nijuusan", "Kobayashi Nijuuyon", "Tanaka Nijuuyon", "Yamada Nijuuyon", "Suzuki Nijuuyon", "Sato Nijuuyon", "Takahashi Nijuuyon", "Ito Nijuuyon", "Watanabe Nijuuyon", "Yamaguchi Nijuuyon", "Nakamura Nijuuyon", "Kobayashi Nijuugo", "Tanaka Nijuugo", "Yamada Nijuugo", "Suzuki Nijuugo", "Sato Nijuugo", "Takahashi Nijuugo", "Ito Nijuugo", "Watanabe Nijuugo", "Yamaguchi Nijuugo", "Nakamura Nijuugo", "Kobayashi Nijuuroku", "Tanaka Nijuuroku", "Yamada Nijuuroku", "Suzuki Nijuuroku", "Sato Nijuuroku", "Takahashi Nijuuroku", "Ito Nijuuroku", "Watanabe Nijuuroku", "Yamaguchi Nijuuroku", "Nakamura Nijuuroku", "Kobayashi Nijuushichi", "Tanaka Nijuushichi", "Yamada Nijuushichi", "Suzuki Nijuushichi", "Sato Nijuushichi", "Takahashi Nijuushichi", "Ito Nijuushichi", "Watanabe Nijuushichi", "Yamaguchi Nijuushichi", "Nakamura Nijuushichi", "Kobayashi Nijuuhachi", "Tanaka Nijuuhachi", "Yamada Nijuuhachi", "Suzuki Nijuuhachi", "Sato Nijuuhachi", "Takahashi Nijuuhachi", "Ito Nijuuhachi", "Watanabe Nijuuhachi", "Yamaguchi Nijuuhachi", "Nakamura Nijuuhachi", "Kobayashi Sanjuui", "Tanaka Sanjuui", "Yamada Sanjuui", "Suzuki Sanjuui", "Sato Sanjuui", "Takahashi Sanjuui", "Ito Sanjuui", "Watanabe Sanjuui", "Yamaguchi Sanjuui", "Nakamura Sanjuui", "Kobayashi Sanjuuichi", "Tanaka Sanjuuichi", "Yamada Sanjuuichi", "Suzuki Sanjuuichi", "Sato Sanjuuichi", "Takahashi Sanjuuichi", "Ito Sanjuuichi", "Watanabe Sanjuuichi", "Yamaguchi Sanjuuichi", "Nakamura Sanjuuichi", "Kobayashi Sanjuuuni", "Tanaka Sanjuuuni", "Yamada Sanjuuuni", "Suzuki Sanjuuuni", "Sato Sanjuuuni", "Takahashi Sanjuuuni", "Ito Sanjuuuni", "Watanabe Sanjuuuni", "Yamaguchi Sanjuuuni", "Nakamura Sanjuuuni", "Kobayashi Sanjuuusan", "Tanaka Sanjuuusan", "Yamada Sanjuuusan", "Suzuki Sanjuuusan", "Sato Sanjuuusan", "Takahashi Sanjuuusan", "Ito Sanjuuusan", "Watanabe Sanjuuusan", "Yamaguchi Sanjuuusan", "Nakamura Sanjuuusan", "Kobayashi Sanjuuuyon", "Tanaka Sanjuuuyon", "Yamada Sanjuuuyon", "Suzuki Sanjuuuyon", "Sato Sanjuuuyon", "Takahashi Sanjuuuyon", "Ito Sanjuuuyon", "Watanabe Sanjuuuyon", "Yamaguchi Sanjuuuyon", "Nakamura Sanjuuuyon", "Kobayashi Sanjuuugo", "Tanaka Sanjuuugo", "Yamada Sanjuuugo", "Suzuki Sanjuuugo", "Sato Sanjuuugo", "Takahashi Sanjuuugo", "Ito Sanjuuugo", "Watanabe Sanjuuugo", "Yamaguchi Sanjuuugo", "Nakamura Sanjuuugo", "Kobayashi Sanjuuroku", "Tanaka Sanjuuroku", "Yamada Sanjuuroku", "Suzuki Sanjuuroku", "Sato Sanjuuroku", "Takahashi Sanjuuroku", "Ito Sanjuuroku", "Watanabe Sanjuuroku", "Yamaguchi Sanjuuroku", "Nakamura Sanjuuroku", "Kobayashi Sanjuushichi", "Tanaka Sanjuushichi", "Yamada Sanjuushichi", "Suzuki Sanjuushichi", "Sato Sanjuushichi", "Takahashi Sanjuushichi", "Ito Sanjuushichi", "Watanabe Sanjuushichi", "Yamaguchi Sanjuushichi", "Nakamura Sanjuushichi", "Kobayashi Sanjuuhachi", "Tanaka Sanjuuhachi", "Yamada Sanjuuhachi", "Suzuki Sanjuuhachi", "Sato Sanjuuhachi", "Takahashi Sanjuuhachi", "Ito Sanjuuhachi", "Watanabe Sanjuuhachi", "Yamaguchi Sanjuuhachi", "Nakamura Sanjuuhachi", "Kobayashi Sanjuukyuu", "Tanaka Sanjuukyuu", "Yamada Sanjuukyuu", "Suzuki Sanjuukyuu", "Sato Sanjuukyuu", "Takahashi Sanjuukyuu", "Ito Sanjuukyuu", "Watanabe Sanjuukyuu", "Yamaguchi Sanjuukyuu", "Nakamura Sanjuukyuu", "Kobayashi Yojui", "Tanaka Yojui", "Yamada Yojui", "Suzuki Yojui", "Sato Yojui", "Takahashi Yojui", "Ito Yojui", "Watanabe Yojui", "Yamaguchi Yojui", "Nakamura Yojui", "Kobayashi Yojuiichi", "Tanaka Yojuiichi", "Yamada Yojuiichi", "Suzuki Yojuiichi", "Sato Yojuiichi", "Takahashi Yojuiichi", "Ito Yojuiichi", "Watanabe Yojuiichi", "Yamaguchi Yojuiichi", "Nakamura Yojuiichi", "Kobayashi Yojuiuni", "Tanaka Yojuiuni", "Yamada Yojuiuni", "Suzuki Yojuiuni", "Sato Yojuiuni", "Takahashi Yojuiuni", "Ito Yojuiuni", "Watanabe Yojuiuni", "Yamaguchi Yojuiuni", "Nakamura Yojuiuni", "Kobayashi Yojuiusan", "Tanaka Yojuiusan", "Yamada Yojuiusan", "Suzuki Yojuiusan", "Sato Yojuiusan", "Takahashi Yojuiusan", "Ito Yojuiusan", "Watanabe Yojuiusan", "Yamaguchi Yojuiusan", "Nakamura Yojuiusan", "Kobayashi Yojuiuyon", "Tanaka Yojuiuyon", "Yamada Yojuiuyon", "Suzuki Yojuiuyon", "Sato Yojuiuyon", "Takahashi Yojuiuyon", "Ito Yojuiuyon", "Watanabe Yojuiuyon", "Yamaguchi Yojuiuyon", "Nakamura Yojuiuyon", "Kobayashi Yojuiugo", "Tanaka Yojuiugo", "Yamada Yojuiugo", "Suzuki Yojuiugo", "Sato Yojuiugo", "Takahashi Yojuiugo", "Ito Yojuiugo", "Watanabe Yojuiugo", "Yamaguchi Yojuiugo", "Nakamura Yojuiugo", "Kobayashi Yojuiuroku", "Tanaka Yojuiuroku", "Yamada Yojuiuroku", "Suzuki Yojuiuroku", "Sato Yojuiuroku", "Takahashi Yojuiuroku", "Ito Yojuiuroku", "Watanabe Yojuiuroku", "Yamaguchi Yojuiuroku", "Nakamura Yojuiuroku", "Kobayashi Yojuishichi", "Tanaka Yojuishichi", "Yamada Yojuishichi", "Suzuki Yojuishichi", "Sato Yojuishichi", "Takahashi Yojuishichi", "Ito Yojuishichi", "Watanabe Yojuishichi", "Yamaguchi Yojuishichi", "Nakamura Yojuishichi", "Kobayashi Yojuihachi", "Tanaka Yojuihachi", "Yamada Yojuihachi", "Suzuki Yojuihachi", "Sato Yojuihachi", "Takahashi Yojuihachi", "Ito Yojuihachi", "Watanabe Yojuihachi", "Yamaguchi Yojuihachi", "Nakamura Yojuihachi", "Kobayashi Yojuijuu", "Tanaka Yojuijuu", "Yamada Yojuijuu", "Suzuki Yojuijuu", "Sato Yojuijuu", "Takahashi Yojuijuu", "Ito Yojuijuu", "Watanabe Yojuijuu", "Yamaguchi Yojuijuu", "Nakamura Yojuijuu", "Kobayashi Nijuiichi", "Tanaka Nijuiichi", "Yamada Nijuiichi", "Suzuki Nijuiichi", "Sato Nijuiichi", "Takahashi Nijuiichi", "Ito Nijuiichi", "Watanabe Nijuiichi", "Yamaguchi Nijuiichi", "Nakamura Nijuiichi", "Kobayashi Nijuiuni", "Tanaka Nijuiuni", "Yamada Nijuiuni", "Suzuki Nijuiuni", "Sato Nijuiuni", "Takahashi Nijuiuni", "Ito Nijuiuni", "Watanabe Nijuiuni", "Yamaguchi Nijuiuni", "Nakamura Nijuiuni", "Kobayashi Nijuiusan", "Tanaka Nijuiusan", "Yamada Nijuiusan", "Suzuki Nijuiusan", "Sato Nijuiusan", "Takahashi Nijuiusan", "Ito Nijuiusan", "Watanabe Nijuiusan", "Yamaguchi Nijuiusan", "Nakamura Nijuiusan", "Kobayashi Nijuiuyon", "Tanaka Nijuiuyon", "Yamada Nijuiuyon", "Suzuki Nijuiuyon", "Sato Nijuiuyon", "Takahashi Nijuiuyon", "Ito Nijuiuyon", "Watanabe Nijuiuyon", "Yamaguchi Nijuiuyon", "Nakamura Nijuiuyon", "Kobayashi Nijuiugo", "Tanaka Nijuiugo", "Yamada Nijuiugo", "Suzuki Nijuiugo", "Sato Nijuiugo", "Takahashi Nijuiugo", "Ito Nijuiugo", "Watanabe Nijuiugo", "Yamaguchi Nijuiugo", "Nakamura Nijuiugo", "Kobayashi Nijuiuroku", "Tanaka Nijuiuroku", "Yamada Nijuiuroku", "Suzuki Nijuiuroku", "Sato Nijuiuroku", "Takahashi Nijuiuroku", "Ito Nijuiuroku", "Watanabe Nijuiuroku", "Yamaguchi Nijuiuroku", "Nakamura Nijuiuroku", "Kobayashi Nijuishichi", "Tanaka Nijuishichi", "Yamada Nijuishichi", "Suzuki Nijuishichi", "Sato Nijuishichi", "Takahashi Nijuishichi", "Ito Nijuishichi", "Watanabe Nijuishichi", "Yamaguchi Nijuishichi", "Nakamura Nijuishichi", "Kobayashi Nijuuhachi", "Tanaka Nijuuhachi", "Yamada Nijuuhachi", "Suzuki Nijuuhachi", "Sato Nijuuhachi", "Takahashi Nijuuhachi", "Ito Nijuuhachi", "Watanabe Nijuuhachi", "Yamaguchi Nijuuhachi", "Nakamura Nijuuhachi", "Kobayashi Nijuukyuu", "Tanaka Nijuukyuu", "Yamada Nijuukyuu", "Suzuki Nijuukyuu", "Sato Nijuukyuu", "Takahashi Nijuukyuu", "Ito Nijuukyuu", "Watanabe Nijuukyuu", "Yamaguchi Nijuukyuu", "Nakamura Nijuukyuu", "Kobayashi Sanjuui", "Tanaka Sanjuui", "Yamada Sanjuui", "Suzuki Sanjuui", "Sato Sanjuui", "Takahashi Sanjuui", "Ito Sanjuui", "Watanabe Sanjuui", "Yamaguchi Sanjuui", "Nakamura Sanjuui", "Kobayashi Sanjuuichi", "Tanaka Sanjuuichi", "Yamada Sanjuuichi", "Suzuki Sanjuuichi", "Sato Sanjuuichi", "Takahashi Sanjuuichi", "Ito Sanjuuichi", "Watanabe Sanjuuichi", "Yamaguchi Sanjuuichi", "Nakamura Sanjuuichi", "Kobayashi Sanjuuuni", "Tanaka Sanjuuuni", "Yamada Sanjuuuni", "Suzuki Sanjuuuni", "Sato Sanjuuuni", "Takahashi Sanjuuuni", "Ito Sanjuuuni", "Watanabe Sanjuuuni", "Yamaguchi Sanjuuuni", "Nakamura Sanjuuuni", "Kobayashi Sanjuuusan", "Tanaka Sanjuuusan", "Yamada Sanjuuusan", "Suzuki Sanjuuusan", "Sato Sanjuuusan", "Takahashi Sanjuuusan", "Ito Sanjuuusan", "Watanabe Sanjuuusan", "Yamaguchi Sanjuuusan", "Nakamura Sanjuuusan", "Kobayashi Sanjuuuyon", "Tanaka Sanjuuuyon", "Yamada Sanjuuuyon", "Suzuki Sanjuuuyon", "Sato Sanjuuuyon", "Takahashi Sanjuuuyon", "Ito Sanjuuuyon", "Watanabe Sanjuuuyon", "Yamaguchi Sanjuuuyon", "Nakamura Sanjuuuyon", "Kobayashi Sanjuuugo", "Tanaka Sanjuuugo", "Yamada Sanjuuugo", "Suzuki Sanjuuugo", "Sato Sanjuuugo", "Takahashi Sanjuuugo", "Ito Sanjuuugo", "Watanabe Sanjuuugo", "Yamaguchi Sanjuuugo", "Nakamura Sanjuuugo", "Kobayashi Sanjuuroku", "Tanaka Sanjuuroku", "Yamada Sanjuuroku", "Suzuki Sanjuuroku", "Sato Sanjuuroku", "Takahashi Sanjuuroku", "Ito Sanjuuroku", "Watanabe Sanjuuroku", "Yamaguchi Sanjuuroku", "Nakamura Sanjuuroku", "Kobayashi Sanjuushichi", "Tanaka Sanjuushichi", "Yamada Sanjuushichi", "Suzuki Sanjuushichi", "Sato Sanjuushichi", "Takahashi Sanjuushichi", "Ito Sanjuushichi", "Watanabe Sanjuushichi", "Yamaguchi Sanjuushichi", "Nakamura Sanjuushichi", "Kobayashi Sanjuuhachi", "Tanaka Sanjuuhachi", "Yamada Sanjuuhachi", "Suzuki Sanjuuhachi", "Sato Sanjuuhachi", "Takahashi Sanjuuhachi", "Ito Sanjuuhachi", "Watanabe Sanjuuhachi", "Yamaguchi Sanjuuhachi", "Nakamura Sanjuuhachi", "Kobayashi Sanjuukyuu", "Tanaka Sanjuukyuu", "Yamada Sanjuukyuu", "Suzuki Sanjuukyuu", "Sato Sanjuukyuu", "Takahashi Sanjuukyuu", "Ito Sanjuukyuu", "Watanabe Sanjuukyuu", "Yamaguchi Sanjuukyuu", "Nakamura Sanjuukyuu", "Kobayashi Yojui", "Tanaka Yojui", "Yamada Yojui", "Suzuki Yojui", "Sato Yojui", "Takahashi Yojui", "Ito Yojui", "Watanabe Yojui", "Yamaguchi Yojui", "Nakamura Yojui", "Kobayashi Yojuiichi", "Tanaka Yojuiichi"}
	GenThaiName     = []string{"Somchai Sombat", "Chaiyo Chai", "Niramit Nimit", "Sakda Sangsom", "Prasit Prasong", "Santi Sukhum", "Chalermchai Chanchai", "Kamol Kanchana", "Sutin Supaporn", "Adirek Anong", "Saman Sangdao", "Vichai Udon", "Chatree Chaidee", "Viroj Sombat", "Winai Wanthana", "Somchai Sombat", "Chaiyo Chai", "Niramit Nimit", "Sakda Sangsom", "Prasit Prasong", "Santi Sukhum", "Chalermchai Chanchai", "Kamol Kanchana", "Sutin Supaporn", "Adirek Anong", "Saman Sangdao", "Vichai Udon", "Chatree Chaidee", "Viroj Sombat", "Winai Wanthana", "Somchai Sombat", "Chaiyo Chai", "Niramit Nimit", "Sakda Sangsom", "Prasit Prasong", "Santi Sukhum", "Chalermchai Chanchai", "Kamol Kanchana", "Sutin Supaporn", "Adirek Anong", "Saman Sangdao", "Vichai Udon", "Chatree Chaidee", "Viroj Sombat", "Winai Wanthana", "Somchai Sombat", "Chaiyo Chai", "Niramit Nimit", "Sakda Sangsom", "Prasit Prasong", "Santi Sukhum", "Chalermchai Chanchai", "Kamol Kanchana", "Sutin Supaporn", "Adirek Anong", "Saman Sangdao", "Vichai Udon", "Chatree Chaidee", "Viroj Sombat", "Winai Wanthana", "Somchai Sombat", "Chaiyo Chai", "Niramit Nimit", "Sakda Sangsom", "Prasit Prasong", "Santi Sukhum", "Chalermchai Chanchai", "Kamol Kanchana", "Sutin Supaporn", "Adirek Anong", "Saman Sangdao", "Vichai Udon", "Chatree Chaidee", "Viroj Sombat", "Winai Wanthana", "Somchai Sombat", "Chaiyo Chai", "Niramit Nimit", "Sakda Sangsom", "Prasit Prasong", "Santi Sukhum", "Chalermchai Chanchai", "Kamol Kanchana", "Sutin Supaporn", "Adirek Anong", "Saman Sangdao", "Vichai Udon", "Chatree Chaidee", "Viroj Sombat", "Winai Wanthana", "Somchai Sombat", "Chaiyo Chai", "Niramit Nimit", "Sakda Sangsom", "Prasit Prasong", "Santi Sukhum", "Chalermchai Chanchai", "Kamol Kanchana", "Sutin Supaporn", "Adirek Anong", "Saman Sangdao", "Vichai Udon", "Chatree Chaidee", "Viroj Sombat", "Winai Wanthana", "Somchai Sombat", "Chaiyo Chai", "Niramit Nimit", "Sakda Sangsom", "Prasit Prasong", "Santi Sukhum", "Chalermchai Chanchai", "Kamol Kanchana", "Sutin Supaporn", "Adirek Anong", "Saman Sangdao", "Vichai Udon", "Chatree Chaidee", "Viroj Sombat", "Winai Wanthana", "Somchai Sombat", "Chaiyo Chai", "Niramit Nimit", "Sakda Sangsom", "Prasit Prasong", "Santi Sukhum", "Chalermchai Chanchai", "Kamol Kanchana", "Sutin Supaporn", "Adirek Anong", "Saman Sangdao", "Vichai Udon", "Chatree Chaidee", "Viroj Sombat", "Winai Wanthana", "Somchai Sombat", "Chaiyo Chai", "Niramit Nimit", "Sakda Sangsom", "Prasit Prasong", "Santi Sukhum", "Chalermchai Chanchai", "Kamol Kanchana", "Sutin Supaporn", "Adirek Anong", "Saman Sangdao", "Vichai Udon", "Chatree Chaidee", "Viroj Sombat", "Winai Wanthana"}
	PictRand        = []string{"vha.jpg", "vhb.jpg", "vhc.jpg", "vhd.jph", "vhe.jpg", "vhf.jpg", "vhg.jpg", "vhh.jpg", "vhi.jpg", "vhj.jpg", "vhk.jpg"}
	TextSave        = []string{}
	TextSaveMention = []string{}
	ChangePicture   = make(map[string]int)
	Squad           = []string{}
	Tcore           = map[string][]string{}
	Tclient         = make(map[string]string)
	Umat            = []string{}
	Kosong          = []string{}
	Creator         = []string{"ue65b440cb8f6acde3065f83830d81188"}
	Banned          = &LineBanned{}
	SquadRoom       = []*LineRoom{}
	ChatAccess      = []*GAccess{}
	Blacklist       = []string{}
	Hostage         = []string{}
	Killmode        = ""
	Detectjoin      = &SaveJoin{}
	Nukejoin        bool
	Forceqr         bool
	Takeover        bool
	Purge           = true
	LockSet         bool
	GoBatas         = 2
	Batasan         = 3
	Kicker         = 3
	Inviter         = 3
    Canceler         = 3
	Ginvite         = 2
	Mode            = "invite"
	Random          = false
	AllowBan        = true
	Staynuke        = false
	Forcejoin       = false
	Attacking       = true
	ShortFight      = false
	WarPro          = false
	Sflag           = "SelfTcr"
	LockPoint       = time.Now()
	Greeting        = &hashmap.HashMap{}
	Resel           = []string{}
	Owner           = []string{}
	Bot             = []string{}
	Admin           = []string{}
	GlobalStaff     = []string{}
	Staymid         = []string{}
	Whitelist       = []string{}
	Protected       = []string{}
	ProInvite       = []string{}
	ProQr           = []string{}
	ProKick         = []string{}
	ProName         = []string{}
	ProCancel       = []string{}
	ProJoin         = []string{}
	ProStay         = []string{}
	Waitadd         = []*LineClient{}
	TimeBackup      time.Time
	TimeReboot      time.Time
	KickBans        = []*LineClient{}
	GetBlock        = &hashmap.HashMap{}
	GetBlockAdd     = &hashmap.HashMap{}
	Sider           = map[string][]string{}
	SiderV2         = map[string]bool{}
	MsgRespon       string
	MsgSider        string
	TypoDetect      bool
	suggestword     = []string{}
	Prefix          = ""
	Rname           = ""
	Prefixsb        = ""
	ProPicture      = []string{}
	ProFile         = []string{}
	ProAlbum        = []string{}
	Notifadd        = true
	ProNote         = []string{}
	ProFlex         = []string{}
	ProLinkGroup    = []string{}
	ProContact      = []string{}
	ProCall         = []string{}
	Notiproall      = "Protect"
	Lurk            = "Hi, @! \nCome here."
	Sname           = ""
	Silents         = false
	Antitag         = true
	Autocban        = true
	JoinTicket      = true
	Wordban         = []string{}
	sugest1         = []string{}
	sugest2         = []string{}
	sugest3         = []string{}
	sugest4         = []string{}
	sugest5         = []string{}
	DueDate         time.Time
	Staylist        = []int{}
	Suggest         = 0
	Invitelist      = map[string][]string{}
	Mute            = []string{}
	ColorReset      = "\033[0m"
	ColorRed        = "\033[31m"
	ColorGreen      = "\033[32m"
	ColorYellow     = "\033[33m"
	ColorBlue       = "\033[34m"
	ColorPurple     = "\033[35m"
	ColorCyan       = "\033[36m"
	ColorWhite      = "\033[37m"
	LineHost        = []string{
		"https://gf.line.naver.jp",
		"https://legy-jp.line.naver.jp",
		"https://ga2.line.naver.jp",
		"https://gd2.line.naver.jp",
		"https://gs.line.naver.jp",
		"https://gp.line.naver.jp",
		"https://gm.line.naver.jp",
		"https://gm2.line.naver.jp",
		"https://gi.line.naver.jp",
		"https://gfp.line.naver.jp",
		"https://gb.line.naver.jp",
		"https://ga.line.naver.jp",
		"https://gmp.line.naver.jp",
		"https://legy-jp-short.line.naver.jp",
		"https://legy-jp-long.line.naver.jp",
		"https://legy-gslb.line.naver.jp",
		"https://legy-jp-addr.line.naver.jp",
		"https://legy-jp-addr-short.line.naver.jp",
		"https://legy-jp-addr-long.line.naver.jp",
		"https://legy-gslb.line.naver.jp",
	}

	LineHostW = []string{
		"gf.line.naver.jp",
		"legy-jp.line.naver.jp",
		"ga2.line.naver.jp",
		"gd2.line.naver.jp",
		"gs.line.naver.jp",
		"gp.line.naver.jp",
		"gm.line.naver.jp",
		"gm2.line.naver.jp",
		"gi.line.naver.jp",
		"gfp.line.naver.jp",
		"gb.line.naver.jp",
		"ga.line.naver.jp",
		"gmp.line.naver.jp",
		"legy-jp-short.line.naver.jp",
		"legy-jp-long.line.naver.jp",
		"legy-gslb.line.naver.jp",
		"legy-jp-addr.line.naver.jp",
		"legy-jp-addr-short.line.naver.jp",
		"legy-jp-addr-long.line.naver.jp",
		"legy-gslb.line.naver.jp",
	}

	SelfHost = []string{
		"https://legy-gslb.line.naver.jp",
	}

	SelfHed = []string{
		"IOSIPAD\t13.18.1\tiOS\t16.7.2",
	}

	PinElement addFuncInt = func(data []string, element string) int {
		for k, v := range data {
			if element == v {
				return k
			}
		}
		return -1
	}
	OverLook addFuncArStr = func(s []string, element string) []string {
		defer func() {
			if recover() != nil {
				fmt.Println("array index out of bounds")
			}
		}()
		i := PinElement(s, element)
		s[i] = s[len(s)-1]
		return s[:len(s)-1]
	}
)

type SaveJoin struct {
	User []string
	Time []int64
}

type LineRoom struct {
	Name     string
	Id       string
	Lurk     bool
	Lqr      bool
	Ispro    bool
	Seen     []string
	Exe      *LineClient
	Bot      []string
	Staff    []string
	GoMid    []string
	Client   []*LineClient
	Ava      []*Ava
	GoClient []*LineClient
	Present  []string
	Actor    []*LineClient
	Invite   int
	Kick     int
	Cancel   int
	Fight    time.Time
	Leave    time.Time
	Kicked   []string
	Hostage  []string
	Qr       bool
	Nuke     bool
	Purge    bool
	Danger   bool
	Attack   bool
	Bajingan []string
	Tclient  string
	Tcore    []string
	Link     string
	Mparam2  string
}

type Ava struct {
	Client *LineClient
	Exist  bool
	Mid    string
}

type LineBanned struct {
	Group []string
	User  [][]string
}

type GAccess struct {
	Id        string
	Owner     []string
	Admin     []string
	Staff     []string
	Mute      []string
	Blacklist []string
	Bot       []string
}

type Wellcome struct {
	Msg   string
	State bool
}

type (
	mentionMsg struct {
		MENTIONEES []struct {
			S string `json:"S"`
			E string `json:"E"`
			M string `json:"M"`
		} `json:"MENTIONEES"`
	}
)

type (
	mention struct {
		S string `json:"S"`
		E string `json:"E"`
		M string `json:"M"`
	}
)
type clustering struct {
	mem string
	tm  int64
	fr  []string
}

func getVnum() int {
	nm := 0
	for _, v := range os.Args {
		if strings.Contains(v, "num=") {
			u := strings.Split(v, "num=")
			an := u[1]
			aa, err := strconv.Atoi(an)
			if err == nil {
				nm = aa
			}
		}
	}
	for _, v := range os.Args {
		if strings.Contains(v, "enc=") {
			u := strings.Split(v, "enc=")
			an := u[1]
			if an == "true" {
				EncMetode = true
			}
		}
	}
	return nm
}
func IsMidban(mids string) bool {
	return Contains(Creator, mids)
}
func InArrayInt(arr []int, str int) bool {
	for _, tar := range arr {
		if tar == str {
			return true
		}
	}
	return false
}

func Archimed(s string, list []string) []string {
	ln := len(list)
	ls := []int{}
	ind := []int{}
	hasil := []string{}
	if strings.Contains(s, ",") {
		logics := strings.Split(s, ",")
		for _, logic := range logics {
			if strings.Contains(logic, ">") {
				su := strings.TrimPrefix(logic, ">")
				si, _ := strconv.Atoi(su)
				si -= 1
				for i := (si + 1); i > si && i <= ln; i++ {
					ls = append(ls, i)
				}
			} else if strings.Contains(logic, "<") {
				su := strings.TrimPrefix(logic, "<")
				si, _ := strconv.Atoi(su)
				si -= 1
				for i := 0; i <= si; i++ {
					ls = append(ls, i)
				}
			} else if strings.Contains(logic, "-") {
				las := strings.Split(logic, "-")
				si := las[0]
				siu, _ := strconv.Atoi(si)
				siu -= 1
				sa := las[1]
				sau, _ := strconv.Atoi(sa)
				sau -= 1
				for i := (siu); i >= siu && i <= sau; i++ {
					ls = append(ls, i)
				}
			} else {
				sau, _ := strconv.Atoi(logic)
				sau -= 1
				ls = append(ls, sau)
			}
		}
	} else {
		logic := s
		if strings.Contains(logic, ">") {
			su := strings.TrimPrefix(logic, ">")
			si, _ := strconv.Atoi(su)
			si -= 1
			for i := (si + 1); i > si && i <= ln; i++ {
				ls = append(ls, i)
			}
		} else if strings.Contains(logic, "<") {
			su := strings.TrimPrefix(logic, "<")
			si, _ := strconv.Atoi(su)
			si -= 1
			for i := 0; i <= si; i++ {
				ls = append(ls, i)
			}
		} else if strings.Contains(logic, "-") {
			las := strings.Split(logic, "-")
			si := las[0]
			siu, _ := strconv.Atoi(si)
			siu -= 1
			sa := las[1]
			sau, _ := strconv.Atoi(sa)
			sau -= 1
			for i := (siu); i >= siu && i <= sau; i++ {
				ls = append(ls, i)
			}
		} else {
			sau, _ := strconv.Atoi(logic)
			sau -= 1
			ls = append(ls, sau)
		}
	}
	for _, do := range ls {
		if !InArrayInt(ind, do) && do < ln {
			jo := list[do]
			ind = append(ind, do)
			hasil = append(hasil, jo)
		}
	}
	return hasil
}
