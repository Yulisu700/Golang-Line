package engine

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
	"bytes"
	"context"
	"crypto/rand"
	"crypto/rsa"
	//"crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"strings"
	"sync"
	"time"
	"../LineThrift"
	thrift "../thrift"
	g2 "github.com/dgrr/http2"
	"github.com/fckveza/VHtearCryptoutil"
	"github.com/valyala/fasthttp"
	//"golang.org/x/net/http2"
)

type LineClient struct {
	sync.Mutex
	Enc          string
	PublicKeyPEM []byte
	Key          *rsa.PublicKey
	EncryptKey   []byte
	EncEncKeyV3  string
	IV           []byte
	Le           string
	Ctx          context.Context
	Ctimeline    *LineThrift.ChannelToken
	//qrLogin                             LoginRequest
	Header                              http.Header
	Transport     *http.Transport
	HttpClient                          *http.Client
	HttpClientPoll                      *fasthttp.HostClient
	FastHost                            *fasthttp.HostClient
	Freq                                *fasthttp.HostClient
	CacheFast                           *fasthttp.Request
	CacheGroup                          *fasthttp.Request
	Connection                          *http.Client
	E2EEKey         *LineThrift.E2EEKey `json:"e2eeKey"`
	PrivateKEY            []byte
	PublicKEY             []byte
	ConnectionType                      string
	Main_host                           string
	Second_host                         string
	AuthToken                           string
	Mid                                 string
	Name                                string
	AppName                             string
	UserAgent                           string
	SeqMessage                          int32
	Rname                               string
	Proxy								string
	Sname                               string
	LINE_COMPACT_E2EE_MESSAGE_ENDPOINT  string
	LINE_COMPACT_PLAIN_MESSAGE_ENDPOINT string
	OBS_DOMAIN                          string
	TALK_S3                             string
	TALK_S4                             string
	TALK_S5                             string
	SYNC4                               string
	SYNC5                               string
	ApiUrlS                             string
	ApiUrlS5                            string
	PollUrlS                            string
	Faddr                               string
	AccGroup                            string
	PreGroup                            string
	Revision                            int64
	GlobalRev                           int64
	IndividualRev                       int64
	KickCount                           int
	CancelCount                         int
	InvCount                            int
	TempKick                            int
	TempInv                             int
	KickPoint                           int
	CustomPoint                         int
	Limiter                             bool
	Limitadd                            bool
	Limitqr                             bool
	Kicked                              bool
	Add                                 int
	Num                                 int
	Cpoll                               int
	TimeBan                             time.Time
	ResetTime                           time.Time
	CountDay                            int
	Ready                               bool
	Timeadd                             time.Time
	Timeqr                              time.Time
	Lastadd                             time.Time
	Lastkick                            time.Time
	Lastinvite                          time.Time
	TmpI                                int
	Lastcancel                          time.Time
	AdditionHeader                      map[string]string
	Ops                                 []*LineThrift.Operation
	Backup    []string
	fast_connection *fasthttp.Client
	timeLineHeader  map[string]string
	KeyID                 int
	Version               int
}

func SettingConnection(Host string, AuthToken string, Headers string, num int) *LineClient {
	UA := strings.Split(Headers, "\t")
	s := new(LineClient)
	publicKeyPEM := []byte(`-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0LRokSkGDo8G5ObFfyKiIdPAU5iOpj+UT+A3AcDxLuePyDt8IVp9HpOsJlf8uVk3Wr9fs+8y7cnF3WiY6Ro526hy3fbWR4HiD0FaIRCOTbgRlsoGNC2rthp2uxYad5up78krSDXNKBab8t1PteCmOq84TpDCRmainaZQN9QxzaSvYWUICVv27Kk97y2j3LS3H64NCqjS88XacAieivELfMr6rT2GutRshKeNSZOUR3YROV4THa77USBQwRI7ZZTe6GUFazpocTN58QY8jFYODzfhdyoiym6rXJNNnUKatiSC/hmzdpX8/h4Y98KaGAZaatLAgPMRCe582q4JwHg7rwIDAQAB
-----END PUBLIC KEY-----`)
	block, _ := pem.Decode(publicKeyPEM)
	if block == nil {
		fmt.Println("Failed to parse PEM block containing the public key")
		os.Exit(1)
	}
	pubKey, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		fmt.Println("Failed to parse public key:", err)
		os.Exit(1)
	}
	rsaPubKey, ok := pubKey.(*rsa.PublicKey)
	if !ok {
		fmt.Println("The public key is not an RSA key")
		os.Exit(1)
	}
	encryptKey := make([]byte, 16)
	s.AdditionHeader = make(map[string]string)
	_, err = rand.Read(encryptKey)
	if err != nil {
		fmt.Println("Failed to generate random data for encryptKey:", err)
		os.Exit(1)
	}
	s.Le = "18"
	s.IV = []byte{78, 9, 72, 62, 56, 245, 255, 114, 128, 18, 123, 158, 251, 92, 45, 51}
	s.Key = rsaPubKey
	s.EncryptKey = encryptKey
	s.EncEncKeyV3 = VHtearCryptoutil.EncEncKey(s.Key, s.EncryptKey)
	s.Ctx = context.Background()
	s.OBS_DOMAIN = "http://obs.line-apps.com"
	s.Main_host = Host
	//s.Second_host = LineHost[Vnum+1]
	parsedURLC, _ := url.Parse(Host + "/S5")
	parsedapi, _ := url.Parse(Host + "/S4")
	parsedpoll, _ := url.Parse(Host + "/SYNC4")
	s.ApiUrlS5 = parsedURLC.String()
	s.ApiUrlS = parsedapi.String()
	s.PollUrlS = parsedpoll.String()
	s.Enc = "/enc"
	s.TALK_S3 = "/S3"
	s.TALK_S4 = "/S4"
	s.TALK_S5 = "/S5"
	s.SYNC4 = "/SYNC4"
	s.SYNC5 = "/SYNC5"
	s.Num = num
	s.CustomPoint = 10 + num
	s.TmpI = 0
	s.Cpoll = 0
	s.Kicked = false
	s.LINE_COMPACT_E2EE_MESSAGE_ENDPOINT = "/ECA5"
	s.LINE_COMPACT_PLAIN_MESSAGE_ENDPOINT = "/CA5"
	s.AppName = Headers
	s.UserAgent = fmt.Sprintf("Line/%s", UA[1]) //fmt.Sprintf("Mozilla/5.0 (compatible; Yahoo! Slurp; http://help.yahoo.com/help/us/ysearch/slurp)")
	s.AuthToken = AuthToken
	s.Revision = -1
	s.GlobalRev = 0
	s.IndividualRev = 0
	s.TempInv = 0
	s.TempKick = 0
	s.KickPoint = 0
	s.Add = 0
	s.AccGroup = ""
	s.PreGroup = ""
	s.Lastkick = time.Now()
	s.Lastcancel = time.Now()
	s.Lastinvite = time.Now()
	s.TimeBan = time.Now()
	s.Lastadd = time.Now()
	s.Limiter = true
	s.Ready = true
	s.Limitadd = true
	s.Limitqr = true
	s.Header = s.SettingUpHeader()
	s.Transport = GetNewTransport()
	s.HttpClient = setHC()
	if AuthToken != "" {
		s.Revision = s.GetLastOpRevision()
		//s.LoginChannel()
	}
	s.FastHost = &fasthttp.HostClient{
		Addr: LineHostW[Vnum] + ":443",
	}
	if err := g2.ConfigureClient(s.FastHost, g2.ClientOpts{}); err != nil {
		fmt.Printf("%s doesn't support http/2\n", s.FastHost.Addr)
	}
	s.Faddr = s.Main_host + "/S5"
	s.HttpClientPoll = &fasthttp.HostClient{
		Addr:                LineHostW[Vnum] + ":443",
		MaxIdleConnDuration: 10 * time.Hour,
	}
	if err := g2.ConfigureClient(s.HttpClientPoll, g2.ClientOpts{MaxResponseTime: 1 * time.Hour}); err != nil {
		fmt.Printf("%s doesn't support http/2\n", s.HttpClientPoll.Addr)
	}
	s.Freq = &fasthttp.HostClient{
		Addr:                LineHostW[Vnum] + ":443",
		MaxIdleConnDuration: 10 * time.Hour,
	}
	if err := g2.ConfigureClient(s.Freq, g2.ClientOpts{MaxResponseTime: 1 * time.Hour}); err != nil {
		fmt.Printf("%s doesn't support http/2\n", s.Freq.Addr)
	}

	return s
}

func (cl *LineClient) SettingUpHeader() http.Header {
	Header := http.Header{"content-type": {"application/x-thrift"}}
	Header.Add("user-agent", cl.UserAgent)
	Header.Add("x-line-application", cl.AppName)
	Header.Add("x-line-access", cl.AuthToken)
	Header.Add("x-lal", "en_US")
	Header.Add("x-lpv", "1")
	Header.Add("accept", "application/x-thrift")
	Header.Add("accept-encoding", "gzip")
	Header.Add("x-las", "F")
	Header.Add("x-lam", "W")
	Header.Add("x-lac", "46692")
	return Header
}

func (cl *LineClient) SetFastReq() *fasthttp.Request {
	req := fasthttp.AcquireRequest()
	req.Header.SetMethod("POST")
	req.Header.Set("x-line-application", cl.AppName)
	req.Header.Set("x-line-access", cl.AuthToken)
	req.Header.Set("user-agent", cl.UserAgent)
	req.Header.Set("Content-Type", "application/x-thrift; protocol=TCOMPACT")
	req.Header.Set("x-lal", "en_US")
	req.Header.Set("x-lpv", "1")
	req.Header.Set("x-lhm", "POST")
	req.Header.Set("Accept", "application/x-thrift")
	req.Header.Set("Accept-Encoding", "gzip, deflate")
	return req
}

func (cl *LineClient) ConnectLiff() *LineThrift.LiffServiceClient {
	HTTP, _ := thrift.NewTHttpClient("https://legy-jp.line-apps.com/LIFF1")
	transport := HTTP.(*thrift.THttpClient)
	transport.SetHeader("X-Line-Access", cl.AuthToken)
	transport.SetHeader("User-Agent", cl.UserAgent)
	transport.SetHeader("X-Line-Application", cl.AppName)
	setProtocol := thrift.NewTCompactProtocolFactory()
	protocol := setProtocol.GetProtocol(transport)
	return LineThrift.NewLiffServiceClientProtocol(transport, protocol, protocol)
}

func setHC() *http.Client {
	return &http.Client{
		Transport: &http.Transport{},
	}
}

func (ss *LineClient) SerializeOri(bits []byte) []byte {
	req, _ := http.NewRequest("POST", ss.ApiUrlS5, bytes.NewBuffer(bits))
	req.Header = ss.Header
	response, err := ss.HttpClient.Do(req)
	if err != nil {
		fmt.Println(err)
		return nil
	} else if response.Body != nil {
		defer response.Body.Close()
		responseBody, err := io.ReadAll(response.Body)
		if err != nil {
			fmt.Println("Error reading response body:", err)
		}
		return responseBody
	}
	return nil
}
