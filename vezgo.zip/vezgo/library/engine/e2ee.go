package engine

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
  "bytes"
  "crypto/aes"
  "crypto/cipher"
  "crypto/hmac"
  "crypto/rand"
  "crypto/sha256"
  "encoding/base64"
  "encoding/json"
  "fmt"
  "golang.org/x/crypto/curve25519"
  "golang.org/x/crypto/hkdf"
  "io"
  "encoding/binary"
  "../LineThrift"
  "../TalkService"
  "maps"
  "os"
  "strings"
  "net/url"
  "io/ioutil"
  "github.com/tidwall/gjson"
  "github.com/valyala/fasthttp"
)

func (p *LineClient) TimelineRequestsOLD(url string, method string, extraHeader map[string]string, data interface{}) (res string, err error) {
	if p.timeLineHeader == nil || p.timeLineHeader["X-Line-ChannelToken"] == "" {
		if err = p.SetTimelineHeaders(); err != nil {
			return "", err
		}
	}
	if p.fast_connection == nil {
		p.setDefaultHttpClient()
	}
	request := fasthttp.AcquireRequest()
	response := fasthttp.AcquireResponse()
	request.SetRequestURI(url)
	request.Header.SetMethod(method)
	for key, value := range p.timeLineHeader {
		request.Header.Set(key, value)
	}
	for key, value := range extraHeader {
		request.Header.Set(key, value)
	}
	if method == "POST" {
		if bData, ok := data.([]byte); ok {
			request.SetBody(bData)
		} else {
			byteData, _ := json.Marshal(data)
			request.SetBody(byteData)
		}
	}
	err = p.fast_connection.Do(request, response)
	if err != nil {
		return "", err
	}
	return string(response.Body()), nil
}

func (p *LineClient) GetKeeps(revision, limit string) (string, error) {
	params := url.Values{}
	params.Add("revision", revision)
	params.Add("limit", limit)
	url := LINE_HOST_DOMAIN + "/kp/api/v27/keep/sync.json?" + params.Encode()
	r, err := p.TimelineRequestsOLD(url, "GET", nil, "")
	if gjson.Get(r, "code").Int() != 0 {
		return "", fmt.Errorf(gjson.Get(r, "message").String())
	}
	return r, err
}

func (p *LineClient) GetE2EEPublicKeys() (r []*LineThrift.E2EEPublicKey, err error) {
	return p.TalkService().GetE2EEPublicKeys(p.Ctx)
}

func (self *LineClient) GetLastE2EEGroupSharedKey(to string) *TalkService.E2EEGroupSharedKey {
	res, err := self.LINETalkService().GetLastE2EEGroupSharedKey(self.Ctx, 2, to)
	if err != nil {
		return nil
	}
	return res
}

func (self *LineClient) NegotiateE2EEPublicKey(mid string) (*TalkService.E2EENegotiationResult_, error) {
	res, err := self.LINETalkService().NegotiateE2EEPublicKey(self.Ctx, mid)
	return res, err
}

func (self *LineClient) RegisterE2EEPublicKey(keyId int32, keyData []byte) *TalkService.E2EEPublicKey {
	publicKey := TalkService.NewE2EEPublicKey()
	publicKey.KeyId = keyId
	publicKey.KeyData = keyData
	publicKey.Version = int32(1)
	res, err := self.LINETalkService().RegisterE2EEPublicKey(self.Ctx, 0, publicKey)
	if err != nil {
		return nil
	}
	return res
}


func (self *LineClient) DecryptedFileMessage(message *TalkService.Message) *TalkService.Message {
    if message.ToType == 2 {
        chunks := message.Chunks
        if len(chunks) != 0 {
            e2ee := self.GetLastE2EEGroupSharedKey(message.To)
            if e2ee == nil {
                return message
            }
            creatorKey, _ := self.NegotiateE2EEPublicKey(e2ee.Creator)
            encryptedSharedKey := e2ee.EncryptedSharedKey
            aesKey := GenerateSharedSecret(self.PrivateKEY, creatorKey.PublicKey.KeyData)
            aesIV := Xor(GetSHA256Sum(append(aesKey, []byte("IV")...)))
            aesKey = GetSHA256Sum(append(aesKey, []byte("Key")...))

              block, err := aes.NewCipher(aesKey)
              if err != nil {
                fmt.Println("Error creating AES cipher:", err)
              }
              decrypted := make([]byte, len(encryptedSharedKey))
              mode := cipher.NewCBCDecrypter(block, aesIV)
            mode.CryptBlocks(decrypted, encryptedSharedKey)
              var pubk []byte
            if message.From_ == self.Mid {
                pubk = self.PublicKEY
            } else {
                erm, _ := self.NegotiateE2EEPublicKey(message.From_)
                pubk = erm.PublicKey.KeyData
            }
              aad := self.GenerateAAD(message.To, message.From_, Byte2int(chunks[3]), Byte2int(chunks[4]), 2, int(message.ContentType))
            var result map[string]interface{}
            switch {
              case message.ContentMetadata["e2eeVersion"] == "1":
                result = self.DecryptedE2EEMessageV1(chunks, decrypted[:32], pubk)
              default:
                result = self.DecryptedE2EEMessageV2(chunks, decrypted[:32], pubk, aad)
            }
            rrr := result["REPLACE"]
            metadata := make(map[string]string)
            if rrr != nil {
                rep := result["REPLACE"].(map[string]interface{})
                for k, _ := range rep {
                    metadata["REPLACE"] = fmt.Sprintf(`{"sticon": %s}`, ToJSON(rep[k]))
                }
            }
            location := result["location"]
            keyMaterial := result["keyMaterial"]
            if keyMaterial != nil {
                message.Text = result["keyMaterial"].(string)
            }
            if location != nil {
                message.Text = result["location"].(map[string]interface{})["address"].(string)
            }
            if result["text"] != nil {
                message.Text = result["text"].(string)
            }
            message.ContentMetadata = self.updateMap(message.ContentMetadata, metadata)
        }
        return message
    }
    chunks := message.Chunks

    if len(chunks) != 0 {
        var e2eeFriend *TalkService.E2EENegotiationResult_

        if message.From_ != self.Mid {
            e2eeFriend, _ = self.NegotiateE2EEPublicKey(message.From_)
        } else {
            e2eeFriend, _ = self.NegotiateE2EEPublicKey(message.To)
        }
        receiverKeyId := Byte2int(chunks[4])
        senderKeyId   := Byte2int(chunks[3])

        var aad []byte
        if message.From_ != self.Mid {
            aad = self.GenerateAAD(self.Mid, message.From_, senderKeyId, receiverKeyId, 2, int(message.ContentType))
        } else {
            aad = self.GenerateAAD(message.To, self.Mid, senderKeyId, receiverKeyId, 2, int(message.ContentType))
        }
        var result map[string]interface{}
        switch {
          case message.ContentMetadata["e2eeVersion"] == "1":
            result = self.DecryptedE2EEMessageV1(chunks, self.PrivateKEY, e2eeFriend.PublicKey.KeyData)
          default:
            result = self.DecryptedE2EEMessageV2(chunks, self.PrivateKEY, e2eeFriend.PublicKey.KeyData, aad)
        }
        rrr := result["REPLACE"]
        location := result["location"]
        keyMaterial := result["keyMaterial"]
        metadata := make(map[string]string)
        if rrr != nil {
            rep := result["REPLACE"].(map[string]interface{})
            for k, _ := range rep {
                metadata["REPLACE"] = fmt.Sprintf(`{"sticon": %s}`, ToJSON(rep[k]))
            }
        }
        if location != nil {
            message.Text = result["location"].(map[string]interface{})["address"].(string)
        }
        if keyMaterial != nil {
            message.Text = result["keyMaterial"].(string)
        }
        if result["text"] != nil {
            message.Text = result["text"].(string)
        }
        message.ContentMetadata = self.updateMap(message.ContentMetadata, metadata)
    }
    return message
}

func (self *LineClient) LoadPrimaryE2EEKeys() {
    _, err := os.Stat(fmt.Sprintf("./database/e2ee/%s.json", self.Mid))
    if err != nil {
        pri, pub := GenerateKey()
        keyid, _ := self.NegotiateE2EEPublicKey(self.Mid)
        if keyid.SpecVersion == -1 {
            return
        }
        keyId := keyid.PublicKey.KeyId
        res := self.RegisterE2EEPublicKey(keyId, pub[:])
        data := map[string]interface{}{
            "publicKey": self.Base64Encoding(pub[:]),
            "privateKey": self.Base64Encoding(pri[:]),
            "keyId": int(res.KeyId),
            "version": 1,
        }
        jsonData, err := json.MarshalIndent(data, "", "    ")
        if err != nil {
            fmt.Printf("could not marshal json: %s\n", err)
            return
          }
        os.WriteFile(fmt.Sprintf("./database/e2ee/%s.json", self.Mid), jsonData, 0644)
        self.PrivateKEY = pri[:]
        self.PublicKEY = pub[:]
        self.KeyID = int(res.KeyId)
        self.Version = 1
    } else {
        jFile, _ := os.Open(fmt.Sprintf("./database/e2ee/%s.json", self.Mid))
        defer jFile.Close()
        val, _ := io.ReadAll(jFile)
        var res map[string]interface{}
        json.Unmarshal(val, &res)
        self.PrivateKEY = self.Base64Decoding(res["privateKey"].(string))
        self.PublicKEY = self.Base64Decoding(res["publicKey"].(string))
        self.KeyID = int(res["keyId"].(float64))
        self.Version = int(res["version"].(float64))
    }
    return
}

func (self *LineClient) LoadE2EEKeys() {
    E2EEPublicKEY, _ := self.NegotiateE2EEPublicKey(self.Mid)
    if E2EEPublicKEY.SpecVersion == -1 {
        return
    }
    var e2ee map[string]interface{}
    jj, _ := os.Open(fmt.Sprintf("./database/e2ee/%s.json", self.Mid))
    defer jj.Close()
    value, _ := ioutil.ReadAll(jj)
    json.Unmarshal([]byte(value), &e2ee)
    e2ee = e2ee["e2ee"].(map[string]interface{})
    if e2ee[self.Mid] != nil {
        data := e2ee[self.Mid].(map[string]interface{})
        self.PrivateKEY = self.Base64Decoding(data["privateKey"].(string))
        self.PublicKEY = self.Base64Decoding(data["publicKey"].(string))
        switch data["keyId"].(type) {
          case float64:
              self.KeyID = int(data["keyId"].(float64))
          default:
              self.KeyID = data["keyId"].(int)
        }
    }
}

func encryptAESCTR(aesKey []byte, nonce []byte, data []byte) ([]byte, error) {
    block, err := aes.NewCipher(aesKey)
    if err != nil {
        return nil, err
    }

    arg := make([]byte, 4)
    nonce = append(nonce, arg...)
    ciphertext := make([]byte, len(data))
    stream := cipher.NewCTR(block, nonce)
    stream.XORKeyStream(ciphertext, data)

    return ciphertext, nil
}

func signData(data []byte, key []byte) []byte {
    h := hmac.New(sha256.New, key)
    h.Write(data)
    return h.Sum(nil)
}

func deriveKeyMaterial(keyMaterial []byte) map[string][]byte {
    derived := make([]byte, 76)
    hkdf := hkdf.New(sha256.New, keyMaterial, nil, []byte("FileEncryption"))
    hkdf.Read(derived)

    return map[string][]byte{
        "encKey": derived[:32],
        "macKey": derived[32:64],
        "nonce":  derived[64:],
    }
}

func ConstructIV(nonce []byte, blockSize int) []byte {
    padding := make([]byte, blockSize-len(nonce))
    iv := append(nonce, padding...)
    return iv
}

func DecryptAESCTR(encryptionKey, nonce, ciphertext []byte) []byte {
    block, _ := aes.NewCipher(encryptionKey)
    stream := cipher.NewCTR(block, nonce)
    plaintext := make([]byte, len(ciphertext))
    stream.XORKeyStream(plaintext, ciphertext)
    return plaintext
}

func (self *LineClient) EncryptedKeyMaterial(rawData, keyMaterial []byte) (string, []byte) {
    if len(keyMaterial) == 0 {
        keyMaterial = GenerateRandom32Bytes()
    }

    keys := deriveKeyMaterial(keyMaterial)

    encData, _ := encryptAESCTR(keys["encKey"], keys["nonce"], rawData)
    sign := signData(encData, keys["macKey"])
    encData = append(encData, sign...)
    return self.Base64Encoding(keyMaterial), encData
}

func (self *LineClient) DecryptedVIAFMessage(keyMaterial, responseContent []byte) []byte {
    keys := deriveKeyMaterial(keyMaterial)
    return DecryptAESCTR(keys["encKey"], ConstructIV(keys["nonce"], aes.BlockSize), responseContent)
}

func (self *LineClient) RemoveFile(path string) {
    _, err := os.Stat(path)
    if err == nil {
        os.Remove(path)
    }
}

func ToJSON(data interface{}) string {
    bytess, _ := json.Marshal(data)
    return string(bytess)
}

func (self *LineClient) Base64Encoding(input []byte) (string) {
    return base64.StdEncoding.EncodeToString(input)
}

func (self *LineClient) Base64Decoding(input string)([]byte) {
    data, err := base64.StdEncoding.DecodeString(input)
    if err != nil {
        panic(err)
    }
    return data
}

func GenerateKey() (pri, pub *[32]byte) {
    pri, pub = new([32]byte), new([32]byte)
    if _, err := rand.Read(pri[:]); err != nil {
        panic(err.Error())
    }
    curve25519.ScalarBaseMult(pub, pri)
    return
}

func GenerateRandom16Bytes() ([]byte) {
  iv := make([]byte, 16)
    if _, err := io.ReadFull(rand.Reader, iv); err != nil {
      panic(err.Error())
    }
  return iv
}

func GenerateRandom12Bytes() ([]byte) {
  iv := make([]byte, 12)
    if _, err := io.ReadFull(rand.Reader, iv); err != nil {
      panic(err.Error())
    }
  return iv
}

func GenerateRandom32Bytes() ([]byte) {
    token := make([]byte, 32)
    if _, err := io.ReadFull(rand.Reader, token); err != nil {
        panic(err.Error())
    }
    return token
}

func GenerateSharedSecret(privateKey, keyDate []byte) []byte {
    sharedSecret, _ := curve25519.X25519(privateKey, keyDate)
    return sharedSecret
}

func GetSHA256Sum(data ...[]byte) (r []byte) {
    sha := sha256.New()
    for _, update := range data {
        sha.Write(update)
    }
    r = sha.Sum(nil)
    return
}

func Xor(buf []byte) []byte {
    bufLength := len(buf) / 2
    buf2 := make([]byte, bufLength)
    for i := 0; i < bufLength; i++ {
        buf2[i] = buf[i] ^ buf[bufLength+i]
    }
    return buf2
}

func Byte2int(t []byte) int {
    e := 0
    s := len(t)
    for i := 0; i < s; i++ {
        e = 256*e + int(t[i])
    }
    return e
}

func (self *LineClient) GenerateAAD(a, b string, c, d, e, f int) []byte {
    var aad []byte
    aad = append(aad, []byte(a)...)
    aad = append(aad, []byte(b)...)
    aad = append(aad, self.GetIntBytes(c, 4, false)...)
    aad = append(aad, self.GetIntBytes(d, 4, false)...)
    aad = append(aad, self.GetIntBytes(e, 4, false)...)
    aad = append(aad, self.GetIntBytes(f, 4, false)...)
    return aad
}

func (self *LineClient) updateMap(arg, args map[string]string) map[string]string {
    maps.Copy(args, arg)
    return args
}

func (self *LineClient) DecryptedE2EEMessageV1(chunks [][]byte, privK, pubK []byte) map[string]interface{} {
    aesKey := GenerateSharedSecret(privK, pubK)
    aesIV := Xor(GetSHA256Sum(aesKey, chunks[0], []byte("IV")))
    aesKey = GetSHA256Sum(aesKey, chunks[0], []byte("Key"))
    block, err := aes.NewCipher(aesKey)
    if err != nil {
        panic(err.Error())
    }
    message := chunks[1]
    mode := cipher.NewCBCDecrypter(block, aesIV)
    mode.CryptBlocks(message, message)
    var result map[string]interface{}
    json.NewDecoder(bytes.NewReader([]byte(string(message)))).Decode(&result)
    return result
}

func (self *LineClient) DecryptedE2EEMessageV2(chunks [][]byte, privK, pubK, aad []byte) map[string]interface{} {
    aesKey := GenerateSharedSecret(privK, pubK)
    gcmKey := GetSHA256Sum(aesKey, chunks[0], []byte("Key"))
    block, err := aes.NewCipher(gcmKey)
    if err != nil {
        panic(err.Error())
    }
    aesgcm, err := cipher.NewGCM(block)
    if err != nil {
        panic(err.Error())
    }
    plaintext, err := aesgcm.Open(nil, chunks[2][:12], chunks[1], aad)
    var result map[string]interface{}
    if err != nil {
        return result
    }
    json.Unmarshal(plaintext, &result)
    return result
}

func (self *LineClient) DecryptedMessage(message *LineThrift.Message) (string, map[string]string) {
    if message.ToType == 2 {
        chunks := message.Chunks
        e2ee := self.GetLastE2EEGroupSharedKey(message.To)
        if e2ee == nil {
            return "", map[string]string{}
        }
        creatorKey, _ := self.NegotiateE2EEPublicKey(e2ee.Creator)

        encryptedSharedKey := e2ee.EncryptedSharedKey
        aesKey := GenerateSharedSecret(self.PrivateKEY, creatorKey.PublicKey.KeyData)
          aesIV := Xor(GetSHA256Sum(append(aesKey, []byte("IV")...)))
          aesKey = GetSHA256Sum(append(aesKey, []byte("Key")...))

          block, err := aes.NewCipher(aesKey)
          if err != nil {
            fmt.Println("Error creating AES cipher:", err)
          }
          decrypted := make([]byte, len(encryptedSharedKey))
          mode := cipher.NewCBCDecrypter(block, aesIV)
        mode.CryptBlocks(decrypted, encryptedSharedKey)
          var pubk []byte
        if message.From_ == self.Mid {
            pubk = self.PublicKEY
        } else {
            erm, _ := self.NegotiateE2EEPublicKey(message.From_)
            if erm == nil {
                return "", map[string]string{}
            }
            pubk = erm.PublicKey.KeyData
        }
        var result map[string]interface{}
          aad := self.GenerateAAD(message.To, message.From_, Byte2int(chunks[3]), Byte2int(chunks[4]), 2, int(message.ContentType))
        switch {
          case message.ContentMetadata["e2eeVersion"] == "1":
            result = self.DecryptedE2EEMessageV1(chunks, decrypted[:32], pubk)
          default:
            result = self.DecryptedE2EEMessageV2(chunks, decrypted[:32], pubk, aad)
        }
        rrr := result["REPLACE"]
        metadata := make(map[string]string)
        if rrr != nil {
            rep := result["REPLACE"].(map[string]interface{})
            for k, _ := range rep {
                metadata["REPLACE"] = fmt.Sprintf(`{"sticon": %s}`, ToJSON(rep[k]))
            }
        }
        location := result["location"]
        keyMaterial := result["keyMaterial"]
        if keyMaterial != nil {
            return result["keyMaterial"].(string), metadata
        }
        if location != nil {
            return result["location"].(map[string]interface{})["address"].(string), metadata
        }
        if result["text"] != nil {
            return result["text"].(string), metadata
        }
        return "", metadata
    }
    chunks := message.Chunks

    var (
      e2eeFriend *TalkService.E2EENegotiationResult_
      err error
    )

    if message.From_ != self.Mid {
        e2eeFriend, err = self.NegotiateE2EEPublicKey(message.From_)
        if err != nil {
            return "", map[string]string{}
        }
    } else {
        e2eeFriend, err = self.NegotiateE2EEPublicKey(message.To)
        if err != nil {
            return "", map[string]string{}
        }
    }
    receiverKeyId := Byte2int(chunks[4])
    senderKeyId := Byte2int(chunks[3])

    var aad []byte
    if message.From_ != self.Mid {
        aad = self.GenerateAAD(self.Mid, message.From_, senderKeyId, receiverKeyId, 2, int(message.ContentType))
    } else {
        aad = self.GenerateAAD(message.To, self.Mid, senderKeyId, receiverKeyId, 2, int(message.ContentType))
    }
    var result map[string]interface{}
    switch {
      case message.ContentMetadata["e2eeVersion"] == "1":
        result = self.DecryptedE2EEMessageV1(chunks, self.PrivateKEY, e2eeFriend.PublicKey.KeyData)
      default:
        result = self.DecryptedE2EEMessageV2(chunks, self.PrivateKEY, e2eeFriend.PublicKey.KeyData, aad)
    }
    if result == nil  {
       return "", map[string]string{}
    }
    rrr := result["REPLACE"]
    location := result["location"]
    keyMaterial := result["keyMaterial"]
    metadata := make(map[string]string)
    if rrr != nil {
        rep := result["REPLACE"].(map[string]interface{})
        for k, _ := range rep {
            metadata["REPLACE"] = fmt.Sprintf(`{"sticon": %s}`, ToJSON(rep[k]))
        }
    }
    if location != nil {
        return result["location"].(map[string]interface{})["address"].(string), metadata
    }
    if keyMaterial != nil {
        return result["keyMaterial"].(string), metadata
    }
    if result["text"] != nil {
        return result["text"].(string), metadata
    }
    return "", metadata
}

func (self *LineClient) DecryptE2EEMessage(msg *LineThrift.Message) *LineThrift.Message {
    if msg.Chunks != nil {
        var meta map[string]string
        msg.Text, meta = self.DecryptedMessage(msg)
        maps.Copy(msg.ContentMetadata, meta)
        return msg
    }
    return msg
}

func (self *LineClient) EncryptedMessage(to, text string) [][]byte {
    if strings.HasPrefix(to, "c") {
        e2ee := self.GetLastE2EEGroupSharedKey(to)
        if e2ee == nil {
            return [][]byte{}
        }
        creatorKey, _ := self.NegotiateE2EEPublicKey(e2ee.Creator)
        encryptedSharedKey := e2ee.EncryptedSharedKey
        aesKey := GenerateSharedSecret(self.PrivateKEY, creatorKey.PublicKey.KeyData)
          aesIV := Xor(GetSHA256Sum(append(aesKey, []byte("IV")...)))
          aesKey = GetSHA256Sum(append(aesKey, []byte("Key")...))

          block, err := aes.NewCipher(aesKey)
          if err != nil {
            fmt.Println("Error creating AES cipher:", err)
          }

          decrypted := make([]byte, len(encryptedSharedKey))
          mode := cipher.NewCBCDecrypter(block, aesIV)
          mode.CryptBlocks(decrypted, encryptedSharedKey)

          keyData := GenerateSharedSecret(decrypted[:32], self.PublicKEY)

        salt := GenerateRandom16Bytes()
        gcmKey := GetSHA256Sum(keyData, salt, []byte("Key"))

        aad := self.GenerateAAD(to, self.Mid, self.KeyID, int(e2ee.GroupKeyId), 2, 0)

        data := map[string]interface{}{
            "text": text,
        }
          plaintext, err := json.Marshal(data)
          if err != nil {
            panic(err.Error())
          }

          bb, err := aes.NewCipher(gcmKey)
          if err != nil {
            panic(err.Error())
          }

          aesgcm, err := cipher.NewGCM(bb)
          if err != nil {
            panic(err.Error())
          }

          nonce := GenerateRandom12Bytes()

          encData := aesgcm.Seal(nil, nonce, plaintext, aad)

        chunks := [][]byte{salt, encData, nonce, self.GetIntBytes(self.KeyID, 4, false), self.GetIntBytes(int(e2ee.GroupKeyId), 4, false)}
        return chunks
    }
    e2eeFriend, _ := self.NegotiateE2EEPublicKey(to)
    receiverKeyId := int(e2eeFriend.PublicKey.KeyId)
    keyData := e2eeFriend.PublicKey.KeyData

    aesKey := GenerateSharedSecret(self.PrivateKEY, keyData)

    salt := GenerateRandom16Bytes()

    gcmKey := GetSHA256Sum(aesKey, salt, []byte("Key"))

    aad := self.GenerateAAD(to, self.Mid, self.KeyID, int(receiverKeyId), 2, 0)

    data := map[string]interface{}{
        "text": text,
    }
    plaintext, err := json.Marshal(data)
    if err != nil {
        panic(err.Error())
    }

    block, err := aes.NewCipher(gcmKey)
    if err != nil {
        panic(err.Error())
    }
    aesgcm, err := cipher.NewGCM(block)
    if err != nil {
        panic(err.Error())
    }
    nonce := GenerateRandom12Bytes()
    encData := aesgcm.Seal(nil, nonce, plaintext, aad)

    chunks := [][]byte{salt, encData, nonce, self.GetIntBytes(self.KeyID, 4, false), self.GetIntBytes(receiverKeyId, 4, false)}
    return chunks
}

func (self *LineClient) DecodeE2EESBKeyV1 (pri, pub, enc []byte, kid int) ([]byte, []byte, int) {
    shared_key := GenerateSharedSecret(pri, pub)
    aesIV := Xor(GetSHA256Sum(append(shared_key, []byte("IV")...)))
    aesKey := GetSHA256Sum(append(shared_key, []byte("Key")...))
    block, err := aes.NewCipher(aesKey)
    if err != nil {
        fmt.Println("Error creating AES cipher:", err)
    }
    decrypted := make([]byte, len(enc))

    mode := cipher.NewCBCDecrypter(block, aesIV)
    mode.CryptBlocks(decrypted, enc)
    tc := NewTCompactProtocol()
    res := tc.DecodeKey(decrypted)
    for _, k := range res {
        erm := k.([]interface{})
        keyId := erm[1].([]interface{})[0].(int)
        if kid == keyId {
            publicKey := erm[2].([]interface{})[0].([]byte)
            privateKey := erm[3].([]interface{})[0].([]byte)
            return privateKey, publicKey, keyId
        }
    }
    return []byte{}, []byte{}, 0
}

func (self *LineClient) GetIntBytes(i, j int, isCompact bool) []byte {
    var res []byte
    if isCompact {
        var a int
        if j*j == 16 {
            a = self.MakeZigZag(i, 32)
        } else {
            a = self.MakeZigZag(i, 64)
        }
        res = self.WriteVarint(a)
        return res
    }
    if j*j == 16 {
        buf := make([]byte, 4)
        binary.BigEndian.PutUint32(buf, uint32(i))
        res = buf
    } else {
        buf := make([]byte, 8)
        binary.BigEndian.PutUint64(buf, uint64(i))
        res = buf
    }
    return res
}