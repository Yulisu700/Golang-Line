package engine

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
	"bytes"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"time"

	"github.com/fckveza/VHtearCryptoutil"
	"github.com/valyala/fasthttp"
)

func (cl *LineClient) WhatWeUse(fckV []byte, path string, addOnHeader map[string]string) []byte {
	if EncMetode {
		b := cl.MakeFastHTTPEncH2(cl.Main_host+"/enc", fckV, path, addOnHeader)
		return b[4:]
	} else {
		return cl.MakeHTTPDec(cl.Main_host+path, fckV, addOnHeader)
	}
}

func (cl *LineClient) MakeHTTPEnc(uri string, fckV []byte, path string, addOnHeader map[string]string) []byte {
	data := fckV
	var _headers = map[string]string{}
	if cl.AuthToken != "" {
		asw := map[string]string{"x-lt": cl.AuthToken, "x-lpqs": path}
		_headers = asw
	} else {
		asw := map[string]string{"x-lpqs": path}
		_headers = asw
	}
	a := VHtearCryptoutil.EncHeaders(_headers)
	var _data = []byte{}
	_data = append(a, data...)
	le, _ := strconv.Atoi(cl.Le)
	if (le & 4) == 4 {
		asw := append([]byte{byte(le)}, _data...)
		_data = asw
	}
	if (le & 2) != 2 {
		asw, _ := cl.EncData(_data)
		data = asw
	} else {
		asw, _ := cl.EncData(_data)
		data = asw
		celeng := VHtearCryptoutil.CalculateChecksumAndTransform(cl.EncryptKey, data)
		data = append(data, celeng...)
	}
	req := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(req)
	for key, value := range addOnHeader {
		req.Header.Set(key, value)
	}
	req.Header.SetMethod("POST")
	req.Header.Set("x-line-application", cl.AppName)
	req.Header.Set("x-le", cl.Le)
	req.Header.Set("x-lap", "5")
	req.Header.Set("x-lpv", "1")
	req.Header.Set("x-lcs", cl.EncEncKeyV3)
	req.Header.Set("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36")
	req.Header.Set("content-type", "application/x-thrift; protocol=TCOMPACT")
	req.Header.Set("x-lal", "en_US")
	req.Header.Set("x-lhm", "POST")
	req.Header.Set("accept", "application/x-thrift")
	req.Header.Set("accept-encoding", "gzip, deflate")
	req.SetRequestURI(uri)
	req.SetBody(data)
	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)
	if err := fasthttp.Do(req, resp); err != nil {
		fmt.Println("DoMakeFastHTTPReq", err)
		return nil
	}
	responseBody := resp.Body()
	w, err := cl.DecData(responseBody)
	if err != nil {
		fmt.Println("DecDataMakeFastHTTPReq", err)
		return nil
	}
	return w
}

func (cl *LineClient) MakeFastHTTPEncH2(uri string, data []byte, path string, addOnHeader map[string]string) []byte {
	//client := &http.Client{}
	var _headers = map[string]string{}
	if cl.AuthToken != "" {
		asw := map[string]string{"x-lt": cl.AuthToken, "x-lpqs": path}
		_headers = asw
	} else {
		asw := map[string]string{"x-lpqs": path}
		_headers = asw
	}
	a := VHtearCryptoutil.EncHeaders(_headers)
	var _data = []byte{}
	_data = append(a, data...)
	le, _ := strconv.Atoi(cl.Le)
	if (le & 4) == 4 {
		asw := append([]byte{byte(le)}, _data...)
		_data = asw
	}
	if (le & 2) != 2 {
		asw, _ := cl.EncData(_data)
		data = asw
	} else {
		asw, _ := cl.EncData(_data)
		data = asw
		celeng := VHtearCryptoutil.CalculateChecksumAndTransform(cl.EncryptKey, data)
		data = append(data, celeng...)
	}
	req, err := http.NewRequest("POST", uri, bytes.NewBuffer(data))
	if err != nil {
		fmt.Println("Error creating request:", err)
	}
	for key, value := range addOnHeader {
		req.Header.Set(key, value)
	}
	req.Header.Set("x-line-application", cl.AppName)
	req.Header.Set("x-le", cl.Le)
	req.Header.Set("x-lap", "5")
	req.Header.Set("x-lpv", "1")
	req.Header.Set("x-lcs", cl.EncEncKeyV3)
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36")
	req.Header.Set("Content-Type", "application/x-thrift; protocol=TCOMPACT")
	req.Header.Set("x-lal", "en_US")
	req.Header.Set("x-lhm", "POST")
	req.Header.Set("Accept", "application/x-thrift")
	req.Header.Set("Accept-Encoding", "gzip, deflate")
	resp, err := cl.HttpClient.Do(req)
	if err != nil {
		fmt.Println("HTTP request error:", err)
	}
	defer resp.Body.Close()

	responseBody, err := io.ReadAll(resp.Body)
	if err != nil {
		fmt.Println("Error reading response body:", err)
	}

	w, err := cl.DecData(responseBody) // Assuming cl.DecData is a valid function
	if err != nil {
		fmt.Println("Error decoding response:", err)
	}
	return w
}

func (cl *LineClient) MakeHTTPDec(uri string, fckV []byte, addOnHeader map[string]string) []byte {
	req, _ := http.NewRequest("POST", uri, bytes.NewBuffer(fckV))
	req.Header = cl.Header
	for key, value := range addOnHeader {
		req.Header.Set(key, value)
	}
	resp, err := cl.HttpClient.Do(req)
	if err != nil {
		return nil
	}
	defer resp.Body.Close()
	responseBody, _ := io.ReadAll(resp.Body)
	/*if err != nil {
		fmt.Println("Error reading response body:", err)
	}*/
	return responseBody
}

func (cl *LineClient) MakeHTTPDec2(fckV []byte, path string) []byte {
	/*resp, err := cl.HttpClientPoll.R().
		SetHeader("user-agent", cl.UserAgent).
		SetHeader("x-line-application", cl.AppName).
		SetHeader("x-line-access", cl.AuthToken).
		SetHeader("x-lal", "en_US").
		SetHeader("x-lpv", "1").
		SetHeader("content-type", "application/x-thrift").
		SetHeader("accept", "application/x-thrift").
		SetHeader("accept-encoding", "gzip").
		SetHeader("x-las", "F").
		SetHeader("x-lam", "W").
		SetHeader("x-lac", "46692").
		SetBody(bytes.NewBuffer(fckV)).
		Post(cl.Main_host + path)
	if err != nil {
		fmt.Println(err)
		return nil
	}
	defer resp.Body.Close()
	responseBody, _ := io.ReadAll(resp.Body)
	return responseBody*/
	return nil
}

func (cl *LineClient) MakeHTTPDecFast(path string, fckV []byte, addOnHeader map[string]string) []byte {
	req := cl.SetFastReq()
	for key, value := range addOnHeader {
		req.Header.Set(key, value)
	}

	req.URI().Update(cl.Main_host + path)
	req.SetBody(fckV)
	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)
	if err := cl.FastHost.Do(req, resp); err != nil {
		if path != "/SYNC5" {
			fmt.Println("DoMakeFastHTTPReq", err)
		}
		return nil
	}
	responseBody := resp.Body()
	return responseBody
}

func (cl *LineClient) DirectFast2(fckV []byte, path string) []byte {
	uri := cl.Main_host + path
	req := cl.SetFastReq()
	req.URI().Update(uri)
	req.SetBody(fckV)
	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)
	if err := cl.HttpClientPoll.Do(req, resp); err != nil {
		return nil
	}
	responseBody := resp.Body()
	return responseBody
}
func (cl *LineClient) DirectGc() []byte {
	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)
	if err := cl.HttpClientPoll.Do(cl.CacheGroup, resp); err != nil {
		return nil
	}
	responseBody := resp.Body()
	return responseBody
}

func (cl *LineClient) DirectFastGC(fckV []byte, path string) []byte {
	req := cl.SetFastReq()
	req.URI().Update(cl.Faddr)
	req.SetBody(fckV)
	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)
	if err := cl.HttpClientPoll.Do(req, resp); err != nil {
		cl.CacheGroup = req
		return nil
	}
	cl.CacheGroup = req
	responseBody := resp.Body()
	return responseBody
}

func (cl *LineClient) DirectFastTalk(fckV []byte, path string) []byte {
	//uri := cl.Main_host + path
	req := cl.SetFastReq()
	req.URI().Update(cl.Faddr)
	req.SetBody(fckV)
	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)
	if err := cl.Freq.Do(req, resp); err != nil {
		return nil
	}
	cl.CacheFast = req
	responseBody := resp.Body()
	return responseBody
}

func (cl *LineClient) DirectFastTalkNone(fckV []byte, path string) []byte {
	req := cl.SetFastReq()
	req.URI().Update(cl.Faddr)
	req.SetBody(fckV)
	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)
	if err := cl.Freq.Do(req, resp); err != nil {
		return nil
	}
	responseBody := resp.Body()
	return responseBody
}

func (cl *LineClient) DirectAcc() []byte {
	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)
	if err := cl.Freq.Do(cl.CacheFast, resp); err != nil {
		return nil
	}
	responseBody := resp.Body()
	return responseBody
}

func (cl *LineClient) DirectFast(fckV []byte, path string) []byte {
	uri := cl.Main_host + path
	req := cl.SetFastReq()
	req.URI().Update(uri)
	req.SetBody(fckV)
	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)
	if err := cl.FastHost.DoTimeout(req, resp, 500*time.Millisecond); err != nil {
		return nil
	}
	responseBody := resp.Body()
	return responseBody
}
