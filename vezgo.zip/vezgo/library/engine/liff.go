package engine

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
	"bytes"
	"context"
	"fmt"
	"strconv"

	ls "../LineThrift"

	//"io/ioutil"
	"net/http"
)

var liffID = "1655063343-oxyzbOrK"

func (cl *LineClient) AllowLiff() error {
	url := "https://access.line.me/dialog/api/permissions"
	var jsonStr = []byte(`{"on":["P","CM","OC"],"off":[]}`)
	req, _ := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	req.Header.Set("X-Line-Access", cl.AuthToken)
	req.Header.Set("X-Line-Application", cl.AppName)
	req.Header.Set("X-Line-ChannelId", "1655063343")
	req.Header.Set("Content-Type", "application/json")
	req.ContentLength = int64(len(jsonStr))
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	//fmt.Println(string(ColorGreen) + "\nAllowing liff success")
	return nil
}

func (p *LineClient) IssueLiff(to string) (*ls.LiffViewResponse, error) {
	cm := ls.NewLiffChatContext()
	cm.ChatMid = to

	lc := ls.NewLiffContext()
	lc.Chat = cm

	lv := ls.NewLiffViewRequest()
	lv.LiffId = liffID
	lv.Context = lc

	return p.LiffService().IssueLiffView(context.TODO(), lv)
}

func (p *LineClient) SendLiff(to, jsn string) error {
	token, err := p.IssueLiff(to)
	if liffexcption, ok := err.(*ls.LiffException); ok && int64(liffexcption.Code) == 3 {
		p.AllowLiff()
	}
	if token != nil {
		msg := fmt.Sprintf(`{"messages": [%s]}`, jsn)
		data := []byte(msg)
		req, _ := http.NewRequest("POST", "https://api.line.me/message/v3/share", bytes.NewBuffer(data))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("User-Agent", "Line/11.5.0")
		req.Header.Set("Authorization", fmt.Sprintf("Bearer %s", token.AccessToken))
		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			return err
		}
		defer resp.Body.Close()
		return nil
	} else {
		return err
	}
}

func (p *LineClient) VHsendFlex(to, datane string) error {
	token, err := p.IssueLiff(to)
	if liffexcption, ok := err.(*ls.LiffException); ok && int64(liffexcption.Code) == 3 {
		p.AllowLiff()
	}
	if token != nil {
		msg := fmt.Sprintf(`{"messages":[{"type":"flex","altText":"`+TeamName+`","contents":%s}]}`, datane)
		data := []byte(msg)
		req, _ := http.NewRequest("POST", "https://api.line.me/message/v3/share", bytes.NewBuffer(data))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("User-Agent", "Line/11.5.0")
		req.Header.Set("Authorization", fmt.Sprintf("Bearer %s", token.AccessToken))
		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			return err
		}
		defer resp.Body.Close()
		return nil
	} else {
		return err
	}
}

func (self *LineClient) SendTextWithLiff(to, textnya string) {
	jsn := `{"type":"text","text":` + strconv.Quote(textnya) + `,"sentBy":{"label":"` + TeamName + `","iconUrl":"` + TeamIcon + `","linkUrl":"` + TeamUrl + `"}}`
	self.SendLiff(to, jsn)
}

func (cl *LineClient) SendImageWithLiff(to string, url string) {
	datane := `{"type":"image","originalContentUrl":"` + url + `","previewImageUrl":"` + url + `","animated":true,"extension":"png"}`
	cl.SendLiff(to, datane)
}

func (cl *LineClient) SendImageWithLiffFooter(to string, url string) {
	datane := `{"type":"image","originalContentUrl":"` + url + `","previewImageUrl":"` + url + `","animated":true,"extension":"png","sentBy":{"label":"  ` + TeamName + `","iconUrl":"` + TeamIcon + `","linkUrl":"` + TeamUrl + `"}}`
	cl.SendLiff(to, datane)
}

func (cl *LineClient) SendAudioWithLiff(to string, url string) {
	datane := `{"type":"audio","originalContentUrl":"` + url + `","duration":60000}`
	cl.SendLiff(to, datane)
}

func (cl *LineClient) SendVideoLiff(to, video string) {
	jsn := `{"type": "video", "originalContentUrl": "` + video + `", "previewImageUrl": "` + TeamIcon + `"}`
	cl.SendLiff(to, jsn)
}

func (self *LineClient) SendFlex1(to, text string) {
	data := `{"type": "bubble","size": "micro","header": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co.com/fkQMVgq/ezgif-com-gif-to-apng-converter.png","size": "full","aspectRatio": "500:100","aspectMode": "cover", "animated": true},{"type": "box","layout": "vertical","contents": [{"type": "text","text": ".","color": "#0066FF", "size": "1px"}],"position": "absolute","width": "145px","height": "20px","offsetTop": "0px","offsetStart": "0px","justifyContent": "center","alignItems": "center"}],"paddingAll": "0px"},"hero": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [],"backgroundColor": "#00FF00","width": "2px"},{"type": "box","layout": "vertical","contents": [],"width": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": ` + strconv.Quote(text) + `,"color": "#000000","size": "xxs","wrap": true}]}],"paddingAll": "2px","backgroundColor": "#00FF00","cornerRadius": "2px"}],"paddingAll": "2px"},"body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co.com/1sncBrm/20240805-172055.png","size": "full","aspectRatio": "500:100","aspectMode": "cover","animated": true},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/k5T4VWY/ezgif-com-resize-5.png","size": "full","aspectMode": "cover","animated": true},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "` + TeamIcon + `","size": "full","aspectMode": "cover"}],"position": "absolute","width": "26px","height": "26px","offsetTop": "1px","offsetStart": "1px","cornerRadius": "100px"}],"width": "28px","height": "28px","position": "absolute","offsetBottom": "3px","offsetEnd": "3px","cornerRadius": "100px","backgroundColor": "#000000"}],"paddingAll": "0px"},"styles": {"header": {"backgroundColor": "#000000"},"hero": {"backgroundColor": "#000000"},"body": {"backgroundColor": "#000000"}}}`
	jsn := ` {"type": "flex","altText": "` + TeamName + `","contents": ` + data + `}`
	self.SendLiff(to, jsn)
}

func (self *LineClient) SendFlex2(to, text string) {
	data := `{"type": "bubble","size": "micro","header": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co.com/Q8Sn1yv/1723798978845.png","size": "full","aspectRatio": "500:100","aspectMode": "cover", "animated": true},{"type": "box","layout": "vertical","contents": [{"type": "text","text": ".","color": "#000000", "size": "1px"}],"position": "absolute","width": "145px","height": "20px","offsetTop": "0px","offsetStart": "0px","justifyContent": "center","alignItems": "center"}],"paddingAll": "0px"},"hero": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [],"backgroundColor": "#000000","width": "2px"},{"type": "box","layout": "vertical","contents": [],"width": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": ` + strconv.Quote(text) + `,"color": "#FFFFFF","size": "xxs","wrap": true}]}],"paddingAll": "2px","backgroundColor": "#000000","cornerRadius": "2px"}],"paddingAll": "2px"},"body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co.com/hWDf6hM/1723799964249.png","size": "full","aspectRatio": "500:100","aspectMode": "cover","animated": true},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/k5T4VWY/ezgif-com-resize-5.png","size": "full","aspectMode": "cover","animated": true},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "` + TeamIcon + `","size": "full","aspectMode": "cover"}],"position": "absolute","width": "26px","height": "26px","offsetTop": "1px","offsetStart": "1px","cornerRadius": "100px"}],"width": "28px","height": "28px","position": "absolute","offsetBottom": "3px","offsetEnd": "3px","cornerRadius": "100px","backgroundColor": "#000000"}],"paddingAll": "0px"},"styles": {"header": {"backgroundColor": "#000000"},"hero": {"backgroundColor": "#000000"},"body": {"backgroundColor": "#000000"}}}`
	jsn := ` {"type": "flex","altText": "` + TeamName + `","contents": ` + data + `}`
	self.SendLiff(to, jsn)
}
