package engine

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
	"github.com/tidwall/gjson"
	"fmt"
	"io/ioutil"
	"io"
	"encoding/json"
	"net/http"
	"regexp"
	"strings"
)



func (self *LineClient) AutoDownloader(to, text, from string) bool {
    re := regexp.MustCompile(`http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+`)
    URLS := re.FindAllString(text, -1)
	state := false
    for _, URL := range URLS {
        if strings.Contains(URL, "youtu") {
            self.YoutubeDL(to, URL)
			state = true
        } else if strings.Contains(URL, "smule.com") {
            self.SmuleDL(to, URL)
			state = true
        } else if strings.Contains(URL, "tiktok.com") {
            self.TiktoDL(to, URL)
			state = true
        }
	}
	return state
}

func (client *LineClient) TiktoDL(to string, urlx string) {
	url := fmt.Sprintf("https://jvrestapi.site/tiktokdl=%s", urlx)
	req, _ := http.NewRequest("GET",url, nil)
	req.Header.Set("Apikey", "ANGGA203")
	req.Header.Set("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) Chrome/51.0.2704.106")
	clhn := &http.Client{}
	resp, _ := clhn.Do(req)
	defer resp.Body.Close()
	data, _ := ioutil.ReadAll(resp.Body)
	username := gjson.Get(string(data), "result.username").String()
	fullname := gjson.Get(string(data), "result.fullname").String()
	duration := gjson.Get(string(data), "result.duration").String()
	created := gjson.Get(string(data), "result.created").String()
	vid_nowatermark := gjson.Get(string(data), "result.vid_nowatermark").String()
	tcr := "Tiktok Downloader\n\n"
	tcr += "Fullname : "+fullname
	tcr += "\nUsername : "+username
	tcr += "\nDuration : "+duration
	tcr += "\nCreated : "+created
	client.SendMessage(to,tcr)
	client.SendVideoWithURL(to, vid_nowatermark)
}

type Track struct {
	TrackName     string `json:"Track Name"`
	Artist        string `json:"Artist"`
	Album         string `json:"Album"`
	ReleaseDate   string `json:"Release Date"`
	Popularity    int    `json:"Popularity"`
	AudioURL      string `json:"Audio URL"`
	AlbumCoverURL string `json:"Album Cover URL"`
}

type ResponseData struct {
	Results []Track `json:"results"`
}


func (client *LineClient) SpotifyDL(to string, name string) {
	url := fmt.Sprintf("https://jvrestapi.site/spotifyplaylist=%s", name)
	req, _ := http.NewRequest("GET",url, nil)
	req.Header.Set("Apikey", "ANGGA203")
	req.Header.Set("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) Chrome/51.0.2704.106")
	clhn := &http.Client{}
	resp, _ := clhn.Do(req)
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusOK {
		body, err := ioutil.ReadAll(resp.Body)
		if err != nil {
			fmt.Printf("Error reading response: %v\n", err)
			return
		}

		var data ResponseData
		if err := json.Unmarshal(body, &data); err != nil {
			fmt.Println("Invalid JSON response")
			fmt.Printf("Error: %v\n", err)
			return
		}
		if len(data.Results) > 0 {
			for _, item := range data.Results {
				tcr := "Spotify Downloader\n\n"
				tcr += "Track Name : "+item.TrackName
				tcr += "\nArtist : "+item.Artist
				tcr += "\nAlbum : "+item.Album
				tcr += "\nRelease Date : "+item.ReleaseDate
				tcr += fmt.Sprintf("\nPopularity: %d", item.Popularity)
				client.SendMessage(to,tcr)
				client.SendImageWithURL(to, item.AlbumCoverURL)
				client.SendAudioWithURL(to, item.AudioURL)
			}
		}
	}
}

func (client *LineClient) YoutubeDL(to string, urlx string) {
	url := fmt.Sprintf("https://jvrestapi.site/youtubedl=%s", urlx)
	req, _ := http.NewRequest("GET",url, nil)
	req.Header.Set("Apikey", "ANGGA203")
	req.Header.Set("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) Chrome/51.0.2704.106")
	clhn := &http.Client{}
	resp, _ := clhn.Do(req)
	defer resp.Body.Close()
	data, _ := ioutil.ReadAll(resp.Body)
	title := gjson.Get(string(data), "result.title").String()
	author := gjson.Get(string(data), "result.author").String()
	duration := gjson.Get(string(data), "result.duration").String()
	videoUrl := gjson.Get(string(data), "result.videoUrl").String()
	audioUrl := gjson.Get(string(data), "result.audioUrl").String()
	tcr := "Youtube Downloader\n\n"
	tcr += "Title : "+title
	tcr += "\nAuthor : "+author
	tcr += "\nDuration : "+duration
	client.SendMessage(to,tcr)
	client.SendVideoWithURL(to, videoUrl)
	client.SendAudioWithURL(to, audioUrl)
}

func (client *LineClient) SmuleDL(to string, urlx string) {
	url := fmt.Sprintf("https://jvrestapi.site/smuledl=%s", urlx)
	req, _ := http.NewRequest("GET",url, nil)
	req.Header.Set("Apikey", "ANGGA203")
	req.Header.Set("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) Chrome/51.0.2704.106")
	clhn := &http.Client{}
	resp, _ := clhn.Do(req)
	defer resp.Body.Close()
	data, _ := ioutil.ReadAll(resp.Body)
	title := gjson.Get(string(data), "result.title").String()
	username := gjson.Get(string(data), "result.username").String()
	duration := gjson.Get(string(data), "result.duration").String()
	created := gjson.Get(string(data), "result.created").String()
	picture := gjson.Get(string(data), "result.picture").String()
	mp4Url := gjson.Get(string(data), "result.mp4Url").String()
	mp3Url := gjson.Get(string(data), "result.mp3Url").String()
	typex := gjson.Get(string(data), "result.type").String()
	tcr := "Smule Downloader\n\n"
	tcr += "Title : "+title
	tcr += "\nUsername : "+username
	tcr += "\nDuration : "+duration
	tcr += "\nCreated : "+created
	tcr += "\nType : "+typex
	client.SendMessage(to,tcr)
	client.SendImageWithURL(to,picture)
	if typex == "video" {
		client.SendVideoWithURL(to, mp4Url)
	} else {
		client.SendAudioWithURL(to, mp3Url)
	}
}

func (client *LineClient) MigrateToken(to string, tokenx string) {
	var data = strings.NewReader(`{"authtoken": tokenx}`)
	req, _ := http.NewRequest("POST", "https://api.vhtear.com/api/get_qr_transfer", data)
	req.Header.Set("accept", "application/json")
	req.Header.Set("api-key", "519edbdf0c4df9291b3e93cd98dab8f85c34d9d86a27bfef66cab6b01d415422")
	req.Header.Set("Content-Type", "application/json")
	clhn := &http.Client{}
	resp, _ := clhn.Do(req)
	defer resp.Body.Close()
	datax, _ := io.ReadAll(resp.Body)
	fmt.Printf("%s\n", datax)
	//title := gjson.Get(string(data), "result.url").String()
}