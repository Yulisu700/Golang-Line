package engine

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
	"context"
	"slices"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"
	"crypto/aes"
	"crypto/cipher"
	"../LineThrift"
	LINERelation "../RelationService"
	TalkService "../TalkService"
	thrift "../thrift"
	mcp "../vhTearCP"
	"github.com/danielgtaylor/unistyle"
	"github.com/lynn9388/supsub"
	"github.com/fckveza/VHtearCryptoutil"
	"github.com/tidwall/gjson"
	"os/exec"
	"golang.org/x/text/cases"
	"golang.org/x/text/language"
	"math/rand"
	curve "github.com/miguelsandro/curve25519-go/axlsign"
	"net/url"
	LineV2 "../linetcr/line" //TALKSERVICE S5/P5
	modcompact "../linetcr/modcompact"
	thrift2 "../linetcr/thrift"
	//"io"
	//"crypto/hmac"
	//"golang.org/x/crypto/hkdf"
	//"golang.org/x/crypto/curve25519"
	//rant "crypto/rand"
	//"bytes"
	//"maps"
	//"encoding/binary"
)

var (
	ModeFont1   = false
	ModeFont2   = false
	ModeFont3   = false
	ModeFont4   = false
	ModeFont5   = false
	ModeFont6   = false
	ModeFont7   = false
	FooterLINE   = false
	FlexMode1  	= false
	FlexMode2  	= false
)

type (
	tagdata struct {
		S string `json:"S"`
		E string `json:"E"`
		M string `json:"M"`
	}
)

func (cl *LineClient) GetCurrReqId() int32 {
	defer func() {
		UpdateSetInt("SeqMessage."+cl.Mid, int(cl.SeqMessage))
	}()
	if cl.SeqMessage == 0 {
		csk := gjson.Get(Settings, "SeqMessage."+cl.Mid)
		if csk.Exists() {
			cl.SeqMessage = int32(csk.Int())
		}
	}
	cl.SeqMessage += 1
	return cl.SeqMessage
}

func (self *LineClient) RemoveMessage(to string) {
	self.TalkService().RemoveAllMessages(context.TODO(), 1, to)
}

func (p *LineClient) SendMusicMessage(to, sender string) (*LineThrift.Message, error) {
	c, _ := p.GetContact(sender)
	M := &LineThrift.Message{
		To:          to,
		Text:        "Profile:",
		ContentType: 19,
		ContentMetadata: map[string]string{
			"text":          "Profile:",
			"subText":       c.DisplayName,
			"a-installUrl":  "https://line.me/R/ti/p/2-SvMLzhwE",
			"i-installUrl":  "https://line.me/R/ti/p/2-SvMLzhwE",
			"a-linkUri":     "https://line.me/R/ti/p/2-SvMLzhwE",
			"i-linkUri":     "https://line.me/R/ti/p/2-SvMLzhwE",
			"linkUri":       "https://line.me/R/ti/p/2-SvMLzhwE",
			"previewUrl":    "https://profile.line-scdn.net/"+c.PictureStatus,
			"type":          "mt",
			"a-packageName": "com.spotify.music",
			"countryCode":   "JP",
			"id":            "mt000000000a6b79f9",
		},
		RelatedMessageId: "0", // to be honest, i don't know what this is for, and if i don't throw something it wouldn't send the message
	}
	res, err := p.TalkService().SendMessage(p.Ctx, int32(0), M)
	return res, err
}

func (self *LineClient) GetChatListMem(groupId string) (mem []string) {
	res, _ := self.TalkService().GetChats(self.Ctx, &LineThrift.GetChatsRequest{
		ChatMids:     []string{groupId},
		WithInvitees: true,
		WithMembers:  true,
	})
	if len(res.Chats) != 0 {
		ch := res.Chats[0]
		for a, _ := range ch.Extra.GroupExtra.MemberMids {
			mem = append(mem, a)
		}
		return mem
	}
	return []string{}
}

func (self *LineClient) GetChatListinv(groupId string) (inv []string) {
	res, _ := self.TalkService().GetChats(self.Ctx, &LineThrift.GetChatsRequest{
		ChatMids:     []string{groupId},
		WithInvitees: true,
		WithMembers:  true,
	})
	if len(res.Chats) != 0 {
		ch := res.Chats[0]
		for a, _ := range ch.Extra.GroupExtra.InviteeMids {
			inv = append(inv, a)
		}
		return inv
	}
	return []string{}
}

func AddCount(user *LineClient, t string) {
	if t == "kick" {
		user.KickCount += 1
		user.TempKick += 1
		user.KickPoint += 1
		user.Lastkick = time.Now()
		/*if user.TempKick >= 40 {
			if !InArrayCl(KickBans, user) {
				KickBans = append(KickBans, user)
				user.TimeBan = time.Now()
			}
			user.Limiter = false
		}*/
	} else if t == "c" {
		user.CancelCount += 1
		user.Lastcancel = time.Now()

	} else {
		user.InvCount += 1
		user.TempInv += 1
		user.KickPoint += 1
		user.Lastinvite = time.Now()
		/*if user.TempInv >= 40 {
			if !InArrayCl(KickBans, user) {
				KickBans = append(KickBans, user)
				user.TimeBan = time.Now()
			}
			user.Limiter = false
		}*/
	}
	if Random {
		Random = false
	} else {
		Random = true
	}
}

func (self *LineRoom) Fights(tipe string) {
	if tipe == "k" {
		self.Kick += 1
	} else if tipe == "i" {
		self.Invite += 1
	} else {
		self.Cancel += 1
	}
	self.Fight = time.Now()
}

func (self *LineClient) SyncRevision(val int64) int64 {
 	defer VHrecover("SyncRevision")
 	self.Revision = val
 	return self.Revision
}

func (cl *LineClient) Sync(count int32) (r []*LineThrift.Operation, err error) {
	res, err := cl.SyncService().Sync(context.TODO(), &LineThrift.SyncRequest{LastRevision: cl.Revision, Count: count, LastGlobalRevision: cl.GlobalRev, LastIndividualRevision: cl.IndividualRev})
	if err == nil && res != nil {
		operationResponse := res.OperationResponse
		fullSyncResponse := res.FullSyncResponse
		if operationResponse != nil {
			ops := operationResponse.Operations
			globalEvents := operationResponse.GlobalEvents
			individualEvents := operationResponse.IndividualEvents
			if globalEvents != nil {
				lastRevision := globalEvents.LastRevision
				cl.GlobalRev = lastRevision
			}
			if individualEvents != nil {
				lastRevision := individualEvents.LastRevision
				cl.IndividualRev = lastRevision
			}
			return ops, nil
		} else if fullSyncResponse != nil {
			cl.Revision = fullSyncResponse.NextRevision - 1
			return r, nil
		}
	}
	return nil, err
}

func (self *LineClient) SyncOps(count int32) (op []*LineThrift.Operation, err error){
 	TS := self.SyncService()
 	res, err := TS.Sync(self.Ctx, &LineThrift.SyncRequest {
 	 	LastRevision:           self.Revision,
 	 	Count:                  count,
 	 	LastGlobalRevision:     self.GlobalRev,
 	 	LastIndividualRevision: self.IndividualRev,
 	 	FullSyncRequestReason:  -1,
 	 	LastPartialFullSyncs:   make(map[LineThrift.SyncType]int64),
 	})
 	if err == nil && res != nil {
 	 	operationResponse := res.OperationResponse
 	 	fullSyncResponse := res.FullSyncResponse
 	 	if operationResponse != nil {
 	 	 	op = operationResponse.Operations
 	 	 	globalEvents := operationResponse.GlobalEvents
 	 	 	individualEvents := operationResponse.IndividualEvents
 	 	 	if globalEvents != nil {
 	 	 	 	lastRevision := globalEvents.LastRevision
 	 	 	 	self.GlobalRev = lastRevision
 	 	 	} 
 	 	 	if individualEvents != nil {
 	 	 	 	lastRevision := individualEvents.LastRevision
 	 	 	 	self.IndividualRev = lastRevision
 	 	 	}
 	 	} else if fullSyncResponse != nil {
 	 	 	self.Revision = fullSyncResponse.NextRevision
 	 	 	return self.SyncOps(count)
 	 	}
 	}
 	return op, err
}

func (cl *LineClient) SyncS() (r []*LineThrift.Operation, err error) {
	res, err := cl.SyncService().Sync(context.TODO(), &LineThrift.SyncRequest{LastRevision: int64(cl.Revision), Count: 100, LastGlobalRevision: int64(cl.GlobalRev), LastIndividualRevision: int64(cl.IndividualRev)})
	// fmt.Println(err)
	// fmt.Println(res)
	if err == nil {
		operationResponse := res.OperationResponse
		fullSyncResponse := res.FullSyncResponse
		if operationResponse != nil {
			ops := operationResponse.Operations
			globalEvents := operationResponse.GlobalEvents
			individualEvents := operationResponse.IndividualEvents
			if globalEvents != nil {
				lastRevision := globalEvents.LastRevision
				cl.GlobalRev = lastRevision
			}
			if individualEvents != nil {
				lastRevision := individualEvents.LastRevision
				cl.IndividualRev = lastRevision
			}
			return ops, nil
		} else if fullSyncResponse != nil {
			cl.Revision = fullSyncResponse.NextRevision
			return r, nil
		}
	} else {
		ee := err.Error()
		if strings.Contains(ee, "context deadline") {
			cl.Revision = -1 //cl.GetLastOpRevision()
		} else if strings.Contains(ee, "suspend") {
			fmt.Printf("%v ", "freeze")
			time.Sleep(70 * time.Minute)
			cl.Revision = -1 //cl.GetLastOpRevision()
		}
		return cl.SyncS()
	}
	return nil, err
}

func (cl *LineClient) Sync5(count int32) (res []*LineThrift.Operation, err *mcp.ExceptionMod) {
	defer VHrecover(cl.Name)
	var LINE = []byte{130, 33, 0, 4, 115, 121, 110, 99, 28, 22}
	LINE = append(LINE, GetIntBytes(int(cl.Revision))...) //revision
	LINE = append(LINE, 21)
	LINE = append(LINE, GetIntBytes(int(count))...)
	LINE = append(LINE, 22)
	LINE = append(LINE, GetIntBytes(int(cl.GlobalRev))...)
	LINE = append(LINE, 22)
	LINE = append(LINE, GetIntBytes(int(cl.IndividualRev))...)
	LINE = append(LINE, []byte{0, 0}...)
	b := cl.MakeHTTPDec(cl.Main_host+cl.SYNC5, LINE, map[string]string{})
	//b := cl.DirectFast2(LINE, cl.SYNC5)
	if b == nil {
		return cl.Sync5(count)
	}
	fckG := mcp.TMoreShoot(b)
	asu, err := fckG.GetSync5Response()
	operationResponse := asu.OperationResponse
	fullSyncResponse := asu.FullSyncResponse
	if operationResponse != nil {
		ops := operationResponse.Operations
		globalEvents := operationResponse.GlobalEvents
		individualEvents := operationResponse.IndividualEvents
		if globalEvents != nil {
			lastRevision := globalEvents.LastRevision
			cl.GlobalRev = lastRevision
		}
		if individualEvents != nil {
			lastRevision := individualEvents.LastRevision
			cl.IndividualRev = lastRevision
		}
		return ops, nil
	} else if fullSyncResponse != nil {
		cl.Revision = fullSyncResponse.NextRevision - 1
		return cl.Sync5(count)
	}
	return res, err
}

func (cl *LineClient) SendText(to string, text string) {
	LINE := []byte{130, 33, 0, 11, 115, 101, 110, 100, 77, 101, 115, 115, 97, 103, 101, 21}
	LINE = append(LINE, GetIntBytes(int(cl.GetCurrReqId()))...)
	LINE = append(LINE, []byte{28, 40, 33}...)
	LINE = append(LINE, GetStringBytes(to, false)...)
	LINE = append(LINE, []byte{54, 0, 22, 0, 130, 21}...)
	LINE = append(LINE, mcp.WriteMetaData(map[string]string{}, 0)...)
	LINE = append(LINE, []byte{19, 0, 8, 20}...)
	LINE = append(LINE, GetStringBytes(text, true)...)
	LINE = append(LINE, []byte{0, 0}...)
	p := cl.MakeHTTPDec(LINE_HOST_DOMAIN+cl.TALK_S5, LINE, map[string]string{})
	fckG := mcp.TMoreShoot(p)
	fckG.GetMessageResponse()
}

func (self *LineClient) SendMessageLINE(to, text string, contentMetadata map[string]string, contentType int32, chunks [][]byte, relatedMessageId string) (*TalkService.Message, *TalkService.TalkException) {
	msg := &TalkService.Message{
		To:              to,
		ContentMetadata: contentMetadata,
		ContentType:     contentType,
	}
	msg.Text = text
	if len(chunks) != 0 {
		msg.Chunks = chunks
	}
	if relatedMessageId != "" {
		var ss int32 = 3
		msg.RelatedMessageId = relatedMessageId
		msg.MessageRelationType = &ss
		msg.RelatedMessageServiceCode = 1
	}
	res, err := self.LINETalkService().SendMessage(self.Ctx, int32(0), msg)
	if err != nil {
		serr, _ := err.(*TalkService.TalkException)
		return nil, serr
	}
	return res, nil
}

func (self *LineClient) SendTextLINE(to string, ttx any, meta map[string]string, mids []string, msgid string) *TalkService.Message {
	text := fmt.Sprintf("%v", ttx)
	re := regexp.MustCompile(`\(==[^\(S+\)]*==\)`)
	if strings.Contains(text, "@MENTION") {
		text = strings.Replace(text, "@MENTION", "@!", -1)
	}
	if strings.Contains(text, "@mention") {
		text = strings.Replace(text, "@mention", "@!", -1)
	}
	contentMetadata := make(map[string]string)
	if strings.Contains(text, "@!") {
		txt := strings.Split(text, "@!")
		textr := ""
		mentionees := []map[string]string{}
		for no, mid := range mids {
			textr += txt[no]
			uni := strconv.QuoteToASCII(textr)
			textt := utf8.RuneCountInString(textr)
			if strings.Contains(uni, "U0") {
				textt += strings.Count(uni, "U0")
			}
			if strings.Contains(textr, "(==") && strings.Contains(textr, "==)") {
				textt = textt - strings.Count(textr, "=")
			}
			if mid == "1" {
				mentionees = append(mentionees, map[string]string{
					"S": fmt.Sprintf("%d", textt),
					"E": fmt.Sprintf("%d", textt+4),
					"A": mid,
				})
				textr += "@All"
			} else {
				c, err := self.GetContact(mid)
				if err == nil {
					unic := strconv.QuoteToASCII(c.DisplayName)
					kk := utf8.RuneCountInString(c.DisplayName)
					if strings.Contains(unic, "U0") {
						kk += strings.Count(unic, "U0")
					}
					textr += fmt.Sprintf("@%s", c.DisplayName)
					metaDatas := map[string]string{
						"S": fmt.Sprintf("%d", textt),
						"E": fmt.Sprintf("%d", textt+kk+1),
						"M": mid,
					}
					mentionees = append(mentionees, metaDatas)
				} else {
					textr += "@Unknown"
					metaDatas := map[string]string{
						"S": fmt.Sprintf("%d", textt),
						"E": fmt.Sprintf("%d", textt+8),
						"M": mid,
					}
					mentionees = append(mentionees, metaDatas)
				}
			}
		}
		textr += txt[len(mentionees)]
		text = textr
		contentMetadata = map[string]string{
			"MENTION": fmt.Sprintf(`{"MENTIONEES":%s}`, ToJSON(mentionees)),
		}
	}
	var replaces map[string]interface{}
	if meta["REPLACE"] != "" {
		json.Unmarshal([]byte(meta["REPLACE"]), &replaces)
	}
	if replaces != nil {
		re = regexp.MustCompile(`\(==[^\(S+\)]*==\)`)
		replace := replaces["sticon"].(map[string]interface{})["resources"].([]interface{})
		resources := []map[string]string{}
		productIds := []string{}
		txtss := re.FindAllString(text, -1)
		txt_ := re.Split(text, -1)
		txt := make([]string, 0)
		for _, f := range txtss {
			f = strings.Replace(f, "(==", "(", 1)
			f = strings.Replace(f, "==)", ")", 1)
			txt = append(txt, f)
		}
		textr := ""
		for no, resource := range replace {
			textr += txt_[no]
			res := resource.(map[string]interface{})
			if !slices.Contains(productIds, res["productId"].(string)) {
				productIds = append(productIds, res["productId"].(string))
			}
			uni := strconv.QuoteToASCII(textr)
			textt := utf8.RuneCountInString(textr)
			if strings.Contains(uni, "U0") {
				textt += strings.Count(uni, "U0")
			}
			var version string
			ver := res["version"]
			switch ver.(type) {
			case float64:
				version = fmt.Sprintf("%d", int(res["version"].(float64)))
			case string:
				version = ver.(string)
			default:
				version = fmt.Sprintf("%d", res["version"].(int))
			}
			resources = append(resources, map[string]string{
				"S":            fmt.Sprintf("%d", textt),
				"E":            fmt.Sprintf("%d", textt+len(txt[no])),
				"sticonId":     res["sticonId"].(string),
				"productId":    res["productId"].(string),
				"resourceType": res["resourceType"].(string),
				"version":      version,
			})
			textr += txt[no]
		}
		textr += txt_[len(replace)]
		contentMetadata["REPLACE"] = fmt.Sprintf(`{"sticon": {"resources": %s}}`, ToJSON(resources))
		contentMetadata["STICON_OWNERSHIP"] = fmt.Sprintf(`%s`, ToJSON(productIds))
		text = textr
	}
	res, err := self.SendMessageLINE(to, text, contentMetadata, 0, [][]byte{}, msgid)
	if err != nil {
		if err.Code == TalkService.TalkErrorCode_ILLEGAL_ARGUMENT {
			self.SendTextLINE(to, mids, map[string]string{}, []string{}, "")
			self.SendTextLINE(to, err.Reason, map[string]string{}, []string{}, "")
			return nil
		} else if err.Code == TalkService.TalkErrorCode_USER_NOT_STICON_OWNER {
			self.SendTextLINE(to, "Give me that emoji, then i'll mention for you.", map[string]string{}, []string{}, "")
			return nil
		}
		contentMetadata["e2eeVersion"] = "2"
		for i := 0;i < len(text);i += 10000 {
            end := i + 10000
            if end > len(text) {
                end = len(text)
            }
            txt := text[i:end]
			chunks := self.EncryptedMessage(to, txt)
			res, _ := self.SendMessageLINE(to, "", contentMetadata, 0, chunks, msgid)
			return res
		}
	}
	return res
}

func (cl *LineClient) SendText2(to string, text string) {
	LINE := []byte{130, 33, 0, 11, 115, 101, 110, 100, 77, 101, 115, 115, 97, 103, 101, 21}
	LINE = append(LINE, GetIntBytes(int(cl.GetCurrReqId()))...)
	LINE = append(LINE, []byte{28, 40, 33}...)
	LINE = append(LINE, GetStringBytes(to, false)...)
	LINE = append(LINE, []byte{54, 0, 22, 0, 130, 21}...)
	LINE = append(LINE, mcp.WriteMetaData(map[string]string{}, 0)...)
	LINE = append(LINE, []byte{19, 0, 8, 20}...)
	LINE = append(LINE, GetStringBytes(text, true)...)
	LINE = append(LINE, []byte{0, 0}...)
	p := cl.DirectFast(LINE, cl.TALK_S5)
	fckG := mcp.TMoreShoot(p)
	fckG.GetMessageResponse()
}

func (cl *LineClient) SendText3(to string, text string) {
	LINE := []byte{130, 33, 0, 11, 115, 101, 110, 100, 77, 101, 115, 115, 97, 103, 101, 21}
	LINE = append(LINE, GetIntBytes(int(cl.GetCurrReqId()))...)
	LINE = append(LINE, []byte{28, 40, 33}...)
	LINE = append(LINE, GetStringBytes(to, false)...)
	LINE = append(LINE, []byte{54, 0, 22, 0, 130, 21}...)
	LINE = append(LINE, mcp.WriteMetaData(map[string]string{}, 0)...)
	LINE = append(LINE, []byte{19, 0, 8, 20}...)
	LINE = append(LINE, GetStringBytes(text, true)...)
	LINE = append(LINE, []byte{0, 0}...)
	p := cl.DirectFastTalkNone(LINE, cl.TALK_S5)
	fckG := mcp.TMoreShoot(p)
	fckG.GetMessageResponse()
}

func (cl *LineClient) Sendnewmsg(to string, text string) (*LineThrift.Message, error) {
	M := &LineThrift.Message{
		To:               to,
		ContentType:      0,
		Text:             text,
		RelatedMessageId: "0",
	}
	res, err := cl.TalkService().SendMessage(cl.Ctx, 0, M)
	if err != nil {
		fmt.Printf("error")
	}
	return res, err
}

/*func (cl *LineClient) SendMessagePM(to, text string) {
	_from := cl.Mid
	selfKeyData := cl.GetE2EESelfKeyData(_from)
	if len(to) == 0 || GetToType(to) != 0 {
		fmt.Println("Invalid mid")
	}
	senderKeyId := selfKeyData.KeyId
	private_key, _ := base64.StdEncoding.DecodeString(selfKeyData.PrivKey)
	receiver_key_data, err := cl.NegotiateE2EEPublicKey(to)
	if err != nil {
		fmt.Println("NegotiateE2EEPublicKeyErr", err)
	}
	receiverKeyId := receiver_key_data.KeyId
	keyData, _ := VHtearCryptoutil.GenerateSharedSecret(private_key, receiver_key_data.KeyData)
	specVersion := int32(2)
	ContentType := 0
	encData := EncryptE2EETextMessage(senderKeyId, receiverKeyId, keyData, specVersion, text, to, _from, false)
	cl.SendMessageE2EE(to, map[string]string{"e2eeVersion": "2", "contentType": "0", "e2eeMark": "2"}, ContentType, encData)
}*/

func (self *LineClient) FindGroupByTicket(ticketId string) (r *LineThrift.Chat, err error) {
	req := LineThrift.NewFindChatByTicketRequest()
	req.TicketId = ticketId
	res, err := self.TalkService().FindChatByTicket(context.TODO(), req)
	return res.Chat, err
}

func (self *LineClient) GetGroupIdsInvited() (r []string, err error) {
	req := &LineThrift.GetAllChatMidsRequest{
		WithInvitedChats: true,
		WithMemberChats:  false,
	}
	rs, err := self.TalkService().GetAllChatMids(context.TODO(), req, *thrift.Int32Ptr(0))
	return rs.InvitedChatMids, err
}

func (cl *LineClient) SendCompactMessage(to, text string, chunks [][]byte) (res *mcp.MesssageMod, err *mcp.ExceptionMod) {
	cType := -1
	path := cl.LINE_COMPACT_PLAIN_MESSAGE_ENDPOINT
	if text != "" {
		cType = 2
	} else {
		cType = 5
		path = cl.LINE_COMPACT_E2EE_MESSAGE_ENDPOINT
	}
	cok := byte(cType)
	sqrd := []byte{cok}
	midType := string(to[0])
	switch midType {
	case "u":
		sqrd = append(sqrd, byte(0))
	case "r":
		sqrd = append(sqrd, byte(1))
	case "c":
		sqrd = append(sqrd, byte(2))
	default:
		fmt.Printf("unknown midType: %s", midType)
	}
	_reqId := cl.GetCurrReqId()
	asws := GetIntBytes(int(_reqId))
	sqrd = append(sqrd, asws...)
	coks := GetMagicStringBytes(to[1:], false)
	sqrd = append(sqrd, coks...)
	if cType == 2 {
		textBytes := GetStringBytes(text, true)
		sqrd = append(sqrd, textBytes...)
		sqrd = append(sqrd, byte(2))
	} else if cType == 5 {
		sqrd = append(sqrd, 2)
		for _, _ck := range chunks[:3] {
			chunkBytes2 := GetStringBytes(string(_ck), true)
			sqrd = append(sqrd, chunkBytes2...)
		}
		for _, _ck := range chunks[3:5] {
			sqrd = append(sqrd, _ck...)
		}
	}
	cl.AdditionHeader["x-lai"] = fmt.Sprintf("%v", _reqId)
	cokz := cl.WhatWeUse(sqrd, path, cl.AdditionHeader)
	res, asw := mcp.MessageResponse(cokz)
	if asw != nil {
		if asw.Code == 82 || asw.Code == 99 {
			cl.SeqMessage--
			return cl.SendCompactE2EEMessage(to, text)
		}
	}
	return res, err
}

func (cl *LineClient) SendCompactE2EEMessage(to, text string) (res *mcp.MesssageMod, err *mcp.ExceptionMod) {
	chunks := cl.EncryptedMessage(to, text)
	return cl.SendCompactMessage(to, "", chunks)
}

func (cl *LineClient) SendMessageE2EE(to string, metaData map[string]string, ContentType int, chunk [][]byte) (res *LineThrift.Message, err *mcp.ExceptionMod) {
	LINE := []byte{130, 33, 0, 11, 115, 101, 110, 100, 77, 101, 115, 115, 97, 103, 101, 21}
	LINE = append(LINE, GetIntBytes(int(cl.GetCurrReqId()))...)
	LINE = append(LINE, []byte{28, 40, 33}...)
	LINE = append(LINE, GetStringBytes(to, false)...)
	LINE = append(LINE, []byte{54, 0, 22, 0, 130, 21}...)
	LINE = append(LINE, mcp.WriteMetaData(metaData, ContentType)...)
	LINE = append(LINE, []byte{19, 0, 25, 88}...)
	chunkBytes1 := GetStringBytes(string(chunk[0]), true)
	LINE = append(LINE, chunkBytes1...)
	chunkBytes2 := GetStringBytes(string(chunk[1]), true)
	LINE = append(LINE, chunkBytes2...)
	chunkBytes3 := GetStringBytes(string(chunk[2]), true)
	LINE = append(LINE, chunkBytes3...)
	LINE = append(LINE, []byte{4}...)
	LINE = append(LINE, chunk[3]...)
	LINE = append(LINE, []byte{4}...)
	LINE = append(LINE, chunk[4]...)
	LINE = append(LINE, []byte{0, 0}...)
	p := cl.WhatWeUse(LINE, cl.TALK_S5, nil)
	if len(p) == 0 {
		return res, err
	}
	fckG := mcp.TMoreShoot(p)
	return fckG.GetMessageResponse()
}

func (cl *LineClient) SendMessageWithoutE2ee(to string, metaData map[string]string, ContentType int, text string) (res *LineThrift.Message, err *mcp.ExceptionMod) {
	LINE := []byte{130, 33, 0, 11, 115, 101, 110, 100, 77, 101, 115, 115, 97, 103, 101, 21}
	LINE = append(LINE, GetIntBytes(int(cl.GetCurrReqId()))...)
	LINE = append(LINE, []byte{28, 40, 33}...)
	LINE = append(LINE, GetStringBytes(to, false)...)
	LINE = append(LINE, []byte{54, 0, 22, 0, 130, 21}...)
	LINE = append(LINE, mcp.WriteMetaData(metaData, ContentType)...)
	LINE = append(LINE, []byte{19, 0, 8, 20}...)
	LINE = append(LINE, GetStringBytes(text, true)...)
	LINE = append(LINE, []byte{0, 0}...)
	p := cl.WhatWeUse(LINE, cl.TALK_S5, nil)
	if len(p) == 0 {
		return res, err
	}
	fckG := mcp.TMoreShoot(p)
	return fckG.GetMessageResponse()
}

func (self *LineClient) SendMessageV3(to, text string, contentMetadata map[string]string, contentType int32, chunks [][]byte, relatedMessageId string) (*LineThrift.Message, *LineThrift.TalkException) {
	msg := &LineThrift.Message{
		To:              to,
		ContentMetadata: contentMetadata,
		ContentType:     0,
	}
	msg.Text = text
	if len(chunks) != 0 {
		msg.Chunks = chunks
	}
	if relatedMessageId != "" {
		//var ss int32 = 3
		msg.RelatedMessageId = relatedMessageId
		msg.MessageRelationType = 3
		msg.RelatedMessageServiceCode = 1
	}
	res, err := self.TalkService().SendMessage(self.Ctx, int32(0), msg)
	if err != nil {
		serr, _ := err.(*LineThrift.TalkException)
		return nil, serr
	}
	return res, nil
}

func (cl *LineClient) SendMessageWithE2EE(to, text string, ContentType int) {
	chunk := cl.EncryptedMessage(to, text)
	metadata := map[string]string{"e2eeVersion": "2", "contentType": "0", "e2eeMark": "2"}
	cl.SendMessageV3(to, "", metadata, 0, chunk, "")
}

func (cl *LineClient) SendMentionWithE2EE(to, text, arrData string) {
	chunk := cl.EncryptedMessage(to, text)
	Metadata := map[string]string{
		"MENTION":     "{\"MENTIONEES\":" + string(arrData) + "}",
		"e2eeVersion": "2",
		"contentType": "0",
		"e2eeMark":    "2",
	}
	cl.SendMessageE2EE(to, Metadata, 0, chunk)
}

func (cl *LineClient) SendMessageX1(to string, text string) (res *LineThrift.Message, err *mcp.ExceptionMod) {
	res, err = cl.SendMessageWithoutE2ee(to, map[string]string{}, 0, text)
	if err != nil {
		cl.SendMessageWithE2EE(to, text, 0)
	}
	return res, err
}

func removeEndNewLine(input string) string {
	if len(input) == 0 {
		return input
	}
	if input[len(input)-1:] == "\n" {

		return input[:len(input)-1]
	}
	return input
}

func (s *LineClient) SendMessage(to string, newsend string) {
	tcrtext := ""
	if FlexMode1 {
		if ModeFont1 {
			s.SendFlex1(to, unistyle.Fraktur(newsend))
		} else if ModeFont2 {
			s.SendFlex1(to, unistyle.BoldSans(newsend))
		} else if ModeFont3 {
			s.SendFlex1(to, unistyle.BoldSerif(newsend))
		} else if ModeFont4 {
			s.SendFlex1(to, unistyle.ItalicSans(newsend))
		} else if ModeFont5 {
			s.SendFlex1(to, unistyle.BoldItalicSans(newsend))
		} else if ModeFont6 {
			s.SendFlex1(to, unistyle.Cursive(newsend))
		} else if ModeFont7 {
			s.SendFlex1(to, supsub.ToSup(newsend))
		} else {
			s.SendFlex1(to, newsend)
		}
	} else if FlexMode2 {
		if ModeFont1 {
			s.SendFlex2(to, unistyle.Fraktur(newsend))
		} else if ModeFont2 {
			s.SendFlex2(to, unistyle.BoldSans(newsend))
		} else if ModeFont3 {
			s.SendFlex2(to, unistyle.BoldSerif(newsend))
		} else if ModeFont4 {
			s.SendFlex2(to, unistyle.ItalicSans(newsend))
		} else if ModeFont5 {
			s.SendFlex2(to, unistyle.BoldItalicSans(newsend))
		} else if ModeFont6 {
			s.SendFlex2(to, unistyle.Cursive(newsend))
		} else if ModeFont7 {
			s.SendFlex2(to, supsub.ToSup(newsend))
		} else {
			s.SendFlex2(to, newsend)
		}
	} else if FooterLINE {
		if ModeFont1 {
			s.SendTextWithLiff(to, unistyle.Fraktur(newsend))
		} else if ModeFont2 {
			s.SendTextWithLiff(to, unistyle.BoldSans(newsend))
		} else if ModeFont3 {
			s.SendTextWithLiff(to, unistyle.BoldSerif(newsend))
		} else if ModeFont4 {
			s.SendTextWithLiff(to, unistyle.ItalicSans(newsend))
		} else if ModeFont5 {
			s.SendTextWithLiff(to, unistyle.BoldItalicSans(newsend))
		} else if ModeFont6 {
			s.SendTextWithLiff(to, unistyle.Cursive(newsend))
		} else if ModeFont7 {
			s.SendTextWithLiff(to, supsub.ToSup(newsend))
		} else {
			s.SendTextWithLiff(to, newsend)
		}
	} else {
		if ModeFont1 {
			tcrtext += unistyle.Fraktur(newsend)
		} else if ModeFont2 {
			tcrtext += unistyle.BoldSans(newsend)
		} else if ModeFont3 {
			tcrtext += unistyle.BoldSerif(newsend)
		} else if ModeFont4 {
			tcrtext += unistyle.ItalicSans(newsend)
		} else if ModeFont5 {
			tcrtext += unistyle.BoldItalicSans(newsend)
		} else if ModeFont6 {
			tcrtext += unistyle.Cursive(newsend)
		} else if ModeFont7 {
			tcrtext += supsub.ToSup(newsend)
		} else {
			tcrtext += newsend
		}
		//s.SendMessageX1(to, removeEndNewLine(tcrtext))
		s.SendTextLINE(to, tcrtext, map[string]string{}, []string{}, "")
	}
}

func (s *LineClient) SendMentionReply(to string, ids string, text string, mids []string) (*LineThrift.Message, error) {
	arr := []*mention{}
	mentionee := "@LINEBot-2024  "
	texts := strings.Split(text, "@!")
	if len(mids) == 0 || len(texts) < len(mids) {
		return &LineThrift.Message{}, fmt.Errorf("Invalid mids.")
	}
	textx := ""
	for i := 0; i < len(mids); i++ {
		textx += texts[i]
		arr = append(arr, &mention{S: strconv.Itoa(utf8.RuneCountInString(textx)), E: strconv.Itoa(utf8.RuneCountInString(textx) + 14), M: mids[i]})
		textx += mentionee
	}
	textx += texts[len(texts)-1]
	arrData, _ := json.Marshal(arr)
	M := &LineThrift.Message{
		From_:                     s.Mid,
		To:                        to,
		Text:                      textx,
		ContentType:               0,
		RelatedMessageId:          ids,
		RelatedMessageServiceCode: 1,
		MessageRelationType:       3,
		ContentMetadata:           map[string]string{"MENTION": "{\"MENTIONEES\":" + string(arrData) + "}"},
	}
	mes, err := s.TalkService().SendMessage(context.TODO(), int32(0), M)
	return mes, err
}

func (s *LineClient) SendMentionLINE(toID string, msgText string, mids []string) {
	client := s.TalkService()
	arr := []*tagdata{}
	mentionee := "@Eltcr  "
	texts := strings.Split(msgText, "@!")
	textx := ""
	for i := 0; i < len(mids); i++ {
		textx += texts[i]
		arr = append(arr, &tagdata{S: strconv.Itoa(len(textx)), E: strconv.Itoa(len(textx) + 6), M: mids[i]})
		textx += mentionee
	}
	textx += texts[len(texts)-1]
	allData, _ := json.MarshalIndent(arr, "", " ")
	msg := LineThrift.NewMessage()
	msg.ContentType = 0
	msg.To = toID
	msg.Text = textx
	msg.ContentMetadata = map[string]string{"MENTION": "{\"MENTIONEES\":" + string(allData) + "}"}
	msg.RelatedMessageId = "0"
	client.SendMessage(s.Ctx, s.SeqMessage, msg)
}

/*func (s *Account) SendMention(toID string, msgText string, mids []string) {
	defer PanicOnly()
	client := s.Talk()
	arr := []*tagdata{}
	mentionee := "@Eltcr"
	texts := strings.Split(msgText, "@!")
	textx := ""
	for i := 0; i < len(mids); i++ {
		textx += texts[i]
		arr = append(arr, &tagdata{S: strconv.Itoa(len(textx)), E: strconv.Itoa(len(textx) + 6), M: mids[i]})
		textx += mentionee
	}
	textx += texts[len(texts)-1]
	allData, _ := json.MarshalIndent(arr, "", " ")
	msg := TalkService.NewMessage()
	msg.ContentType = 0
	msg.To = toID
	msg.Text = textx
	msg.ContentMetadata = map[string]string{"MENTION": "{\"MENTIONEES\":" + string(allData) + "}"}
	msg.RelatedMessageId = "0"
	_, e := client.SendMessage(s.Ctx, s.Seq, msg)
	deBug("SendMention", e)
}*/

func (cl *LineClient) SendMention(to string, text string, mids []string) (res *LineThrift.Message, err *mcp.ExceptionMod) {
	arr := []*mention{}
	mentionee := "@LINEBot-2023  "
	texts := strings.Split(text, "@!")
	if len(mids) == 0 || len(texts) < len(mids) {
		fmt.Println("Invalid mids.")
		return &LineThrift.Message{}, err
	}
	textx := ""
	for i := 0; i < len(mids); i++ {
		textx += texts[i]
		arr = append(arr, &mention{S: strconv.Itoa(utf8.RuneCountInString(textx)), E: strconv.Itoa(utf8.RuneCountInString(textx) + 14), M: mids[i]})
		textx += mentionee
	}
	textx += texts[len(texts)-1]

	arrData, _ := json.Marshal(arr)
	res, err = cl.SendMessageWithoutE2ee(to, map[string]string{
		"MENTION": "{\"MENTIONEES\":" + string(arrData) + "}",
	}, 0, textx)

	if err != nil {
		cl.SendMentionWithE2EE(to, textx, string(arrData))
	}
	return res, err
}

func (cl *LineClient) SendContact(to string, mid string) {
	regex, _ := regexp.Compile(`u\w{32}`)
	links := regex.FindAllString(mid, -1)
	for _, a := range links {
		if len(a) == 33 {
			oh := map[string]string{"mid": a}
			cl.SendMessageWithoutE2ee(to, oh, 13, "")
		}
	}
}

func (cl *LineClient) ReissueChatTicketOLD(groupId string) (tiket string) {
	req := &LineThrift.ReissueChatTicketRequest{
		GroupMid: groupId,
		ReqSeq:   0,
	}
	res, err := cl.TalkService().ReissueChatTicket(context.TODO(), req)
	if err != nil {
		return ""
	}
	return res.TicketId
}

func (cl *LineClient) ReissueChatTicket(to string) string {
	LINE := []byte{130, 33, 1, 17, 114, 101, 105, 115, 115, 117, 101, 67, 104, 97, 116, 84, 105, 99, 107, 101, 116, 28, 21, 130, 250, 1, 24, 33}
	LINE = append(LINE, GetStringBytes(to, false)...)
	LINE = append(LINE, []byte{0, 0}...)
	p := cl.MakeHTTPDec(cl.Main_host+cl.TALK_S5, LINE, map[string]string{})
	fckG := mcp.TMoreShoot(p)
	a, err := fckG.GetReissueChatTicket()
	if err == nil {
		return a.TicketId
	}
	return ""
}

func (p *LineClient) AcceptChatInvitation(to string) (err error) {
	err = p.TalkService().AcceptChatInvitation(p.Ctx, &LineThrift.AcceptChatInvitationRequest{ReqSeq: p.SeqMessage, ChatMid: to})
	p.SeqMessage++
	return err
}

func (p *LineClient) InviteIntoChats(to string, targetUserMids []string) (err error) {
	err = p.TalkService().InviteIntoChat(p.Ctx, &LineThrift.InviteIntoChatRequest{ReqSeq: p.SeqMessage, ChatMid: to, TargetUserMids: targetUserMids})
	p.SeqMessage++
	AddCount(p, "invite")
	GetRoom(to).Fights("i")
	return err
}

func (p *LineClient) AcceptGroupInvitationByTicket(to string, ticketId string) (err error) {
	err = p.TalkService().AcceptChatInvitationByTicket(p.Ctx, &LineThrift.AcceptChatInvitationByTicketRequest{ReqSeq: p.SeqMessage, ChatMid: to, TicketId: ticketId})
	p.SeqMessage++
	if err != nil {
		p.GetError(err, "Acc ticket")
	}
	return err
}

func (cl *LineClient) InviteIntoChatCheck(groupId string, contactIds []string, sender string, id string) (err error) {
	cl.LINEAddFriendShareContact(groupId, contactIds[0], sender, id)
	err = cl.TalkService().InviteIntoChat(context.TODO(), &LineThrift.InviteIntoChatRequest{
		ChatMid:        groupId,
		ReqSeq:         1,
		TargetUserMids: contactIds,
	})
	AddCount(cl, "invite")
	GetRoom(groupId).Fights("i")
	return err
}

func (cl *LineClient) InviteIntoChatCheckV2(groupId string, contactIds []string, sender string, id string) (err error) {
	err = cl.TalkService().InviteIntoChat(context.TODO(), &LineThrift.InviteIntoChatRequest{
		ChatMid:        groupId,
		ReqSeq:         1,
		TargetUserMids: contactIds,
	})
	AddCount(cl, "invite")
	GetRoom(groupId).Fights("i")
	return err
}

func WriteVarint(data int) []byte {
	var out []byte

	for {
		if data&^0x7f == 0 {
			out = append(out, byte(data))
			break
		} else {
			out = append(out, byte((data&0xff)|0x80))
			data = data >> 7
		}
	}

	return out
}

func GetStringBytes1(str string, isCompact bool) []byte {
	var va []byte
	if isCompact {
		fck := WriteVarint(len(str))
		va = append(va, fck...)
	}
	va = append(va, []byte(str)...)
	return va
}

func (cl *LineClient) DeleteOtherFromChat(to string, mid string) (err *mcp.ExceptionMod) {
	fckV := []byte{130, 33, 1, 19, 100, 101, 108, 101, 116, 101, 79, 116, 104, 101, 114, 70, 114, 111, 109, 67, 104, 97, 116, 28, 21, 0, 24, 33}
	fckV = append(fckV, []byte(to)...)
	fckV = append(fckV, []byte{26, 24, 33}...)
	fckV = append(fckV, []byte(mid)...)
	fckV = append(fckV, []byte{0, 0}...)
	p := cl.MakeHTTPDec(LINE_HOST_DOMAIN+cl.TALK_S5, fckV, map[string]string{})
	cl.SeqMessage++
	if len(p) == 0 {
		return err
	}
	fckG := mcp.TMoreShoot(p)
	err = fckG.ResponseDeleteOtherFromChat()
	AddCount(cl, "kick")
	GetRoom(to).Fights("k")
	return err
}

func (p *LineClient) CancelChatInvitation(to string, targetUserMid string) (err error) {
	err = p.TalkService().CancelChatInvitation(p.Ctx, &LineThrift.CancelChatInvitationRequest{ReqSeq: p.SeqMessage, ChatMid: to, TargetUserMids: []string{targetUserMid}})
	p.SeqMessage++
	AddCount(p, "c")
	GetRoom(to).Fights("c")
	return err
}

func (p *LineClient) GetAllChatIds() ([]string, []string, error) {
	res, err := p.TalkService().GetAllChatMids(p.Ctx, &LineThrift.GetAllChatMidsRequest{WithMemberChats: true, WithInvitedChats: true}, 4)
	if err != nil {
		return []string{}, []string{}, err
	}
	return res.MemberChatMids, res.InvitedChatMids, nil
}

func (self *LineClient) RejectChatInvitation(chatMid string) error {
	req := LineThrift.NewRejectChatInvitationRequest()
	req.ReqSeq = self.SeqMessage
	self.SeqMessage++
	req.ChatMid = chatMid
	err := self.TalkService().RejectChatInvitation(self.Ctx, req)
	return err
}

func (self *LineClient) CreateChatV2(chatMid []string) (*TalkService.CreateChatResponse, error) {
	time.Sleep(20 * time.Second)
	tcr := &TalkService.CreateChatRequest{
		ReqSeq: self.SeqMessage,
		Type: 1,
		TargetUserMids: chatMid,
	}
	self.SeqMessage++
	return self.LINETalkService().CreateChat(context.TODO(), tcr)
}

func (self *LineClient) tcrGetChats(chatMids string) ([]*LineThrift.Chat, *LineThrift.TalkException) {
    req := LineThrift.NewGetChatsRequest()
    req.ChatMids     = []string{chatMids}
    req.WithMembers  = true
    req.WithInvitees = true
    chats, err      := self.TalkService().GetChats(self.Ctx, req)
    if err          != nil {
        error, ok   := err.(*LineThrift.TalkException)
        if !ok {
            return nil, &LineThrift.TalkException{}
        }
        return nil, error
    }
    return chats.Chats, nil
}

func (self *LineClient) GetGroupMembers(groupId string) (error, string, map[string]int64) {
	res, err := self.TalkService().GetChats(self.Ctx, &LineThrift.GetChatsRequest{
		ChatMids:     []string{groupId},
		WithInvitees: false,
		WithMembers:  true,
	})
	if err != nil {
		return err, "", map[string]int64{}
	}
	if len(res.Chats) != 0 {
		ch := res.Chats[0]
		mem := ch.Extra.GroupExtra.MemberMids
		return err, ch.ChatName, mem
	}
	return err, "", map[string]int64{}
}

func (self *LineClient) GetGroupLINE(groupId string) (r *LineThrift.Chat, err error) {
	res, err := self.TalkService().GetChats(self.Ctx, &LineThrift.GetChatsRequest{
		ChatMids:     []string{groupId},
		WithInvitees: true,
		WithMembers:  true,
	})
	return res.Chats[0], err
}

func (p *LineClient) GetChats(to string) (res *LineThrift.GetChatsResponse, err error) {
	if res, err := p.TalkService().GetChats(p.Ctx, &LineThrift.GetChatsRequest{ChatMids: []string{to}, WithMembers: true, WithInvitees: true}); err == nil && len(res.Chats) > 0 {
		if res.Chats[0].Extra != nil {
			return res, nil
		} else {
			return nil, fmt.Errorf("null chat")
		}
	} else {
		return nil, fmt.Errorf("GetChat: %v", err)
	}
}

func (cl *LineClient) GetChats2(to string) (res *LineThrift.GetChatsResponse, err *mcp.ExceptionMod) {
	res, _ = cl.TalkService().GetChats(context.TODO(), &LineThrift.GetChatsRequest{
		ChatMids:     []string{to},
		WithInvitees: true,
		WithMembers:  true,
	})
	return res, err
}

func (p *LineClient) GetContact(id string) (r *LineThrift.Contact, err error) {
	res, err := p.TalkService().GetContact(p.Ctx, id)
	return res, err
}

func (p *LineClient) FindContactByUserTicket(id string) (r *TalkService.Contact, err error) {
	res, err := p.LINETalkService().FindContactByUserTicket(p.Ctx, id)
	if err != nil {
        fmt.Println("Error:", err)
        return nil, err
    }
	fmt.Println("Result:", res)
	return res, err
}

func (self *LineClient) GetContacts(id []string) (r []*LineThrift.Contact, err error) {
	res, err := self.TalkService().GetContacts(self.Ctx, id)
	return res, err
}

func (self *LineClient) Getcontactuser(id string) (err error) {
	client := self.TalkService()
	_, err = client.GetContact(self.Ctx, id)
	if err != nil {
		return err
	}
	return err
}

func (p *LineClient) GetSettings() (r *LineThrift.Settings, err error) {
	res, err := p.SettingService().GetSettings(p.Ctx)
	return res, err
}

func (p *LineClient) GetConfigurations(country string) (r *LineThrift.Configurations, err error) {
	res, err := p.TalkService().GetConfigurations(p.Ctx, 0, "TW", country, "TW", "46692")
	return res, err
}

func (p *LineClient) UpdateSettingsAttributes2(settings *LineThrift.Settings, attrs []LineThrift.SettingsAttribute) (err error) {
	_, err = p.TalkService().UpdateSettingsAttributes2(p.Ctx, int32(1000), settings, attrs)
	return err
}

func (p *LineClient) UpdateProfileAttribute(attr LineThrift.ProfileAttribute, value string) (err error) {
	err = p.TalkService().UpdateProfileAttribute(p.Ctx, int32(0), attr, value)
	return err
}

func (p *LineClient) UpdateProfileAttributes(attrs map[int32]*LineThrift.ProfileContent) (err error) {
	// err = p.TalkService().UpdateProfileAttributes(p.ctx, int32(0), &LineThrift.UpdateProfileAttributesRequest{ProfileAttributes: attrs})
	for attr, value := range attrs {
		p.UpdateProfileAttribute(LineThrift.ProfileAttribute(attr), value.Value)
	}
	return err
}

func (cl *LineClient) UpdateChatQrByte(chatId string, typevar bool) {
	var x string
	if typevar {
		x = "!"
	}
	LINE := []byte("\x82!\x00\nupdateChat\x1c\x15\x00\x1c(!" + chatId + "l\x1c" + x + "\x00\x00\x00\x15\x08\x00\x00")
	cl.MakeHTTPDec(cl.Main_host+cl.TALK_S5, LINE, map[string]string{})
}

func (cl *LineClient) LINEAddByTicket(mid string) {
	var x string
	x = `{"screen":"urlScheme:internal","spec":"native"}`
	LINE := []byte("\x82!\x01\x0eaddFriendByMid\x1c\x15\xa4\x1f\x18!" + mid + "\x1c\x18/" + x + ",\xac\x00\x00\x00\x00\x00")
	cl.MakeHTTPDec("https://legy.line-apps.com/RE4", LINE, map[string]string{})
}

func (cl *LineClient) FindandAddUrl(mid string) {
	//LINE := []byte("�!  addFriendByMid  �> !"+ mid +"  /{"screen":"urlScheme:internal","spec":"native"},�")
	//cl.MakeHTTPDec(LINE_HOST_DOMAIN+"/RE4", LINE, map[string]string{})
}

func (self *LineClient) UpdateProfileName(name string) error {
	profile_B := self.GetProfile()
	profile_B.DisplayName = name
	self.UpdateProfile(profile_B)
	return nil
}

func (self *LineClient) UpdateProfileBio(bio string) error {
	profile_B := self.GetProfile()
	profile_B.StatusMessage = bio
	self.UpdateProfile(profile_B)
	return nil
}
func (cl *LineClient) GetRecentMessagesV2(toId string) (r []*LineThrift.Message, err error) {
	return cl.TalkService().GetRecentMessagesV2(context.TODO(), toId, int32(100000000))
}

func (cl *LineClient) UnsendAllChat(toId string) (err error) {
	Nganu, _ := cl.TalkService().GetRecentMessagesV2(context.TODO(), toId, int32(100000000))
	Mid := []string{}
	for _, chat := range Nganu {
		if chat.From_ == cl.Mid {
			Mid = append(Mid, chat.ID)
		}
	}
	for i := 0; i < len(Mid); i++ {
		err = cl.TalkService().UnsendMessage(context.TODO(), cl.GetCurrReqId(), Mid[i])
	}
	return err
}

func (cl *LineClient) UnsendLastChat(toId string) (err error) {
	Nganu, _ := cl.TalkService().GetRecentMessagesV2(context.TODO(), toId, int32(1))
	Mid := []string{}
	for _, chat := range Nganu {
		if chat.From_ == cl.Mid {
			Mid = append(Mid, chat.ID)
		}
	}
	err = cl.TalkService().UnsendMessage(context.TODO(), cl.GetCurrReqId(), Mid[0])
	return err
}

func (cl *LineClient) UnsendMessage(msgID string) (err error) {
	err = cl.TalkService().UnsendMessage(context.TODO(), cl.GetCurrReqId(), msgID)
	return err
}

func (s *LineClient) UnsendChatnume(toId string, text string) (err error) {
	client := s.TalkService()
	err = client.UnsendMessage(s.Ctx, int32(0), text)
	return err
}

func (self *LineClient) GetGroups(groupId []string) (r []*LineThrift.Chat, err error) {
	tux := [][]string{}
	if len(groupId) > 100 {
		for {
			if len(groupId) > 0 {
				if len(groupId) < 99 {
					tux = append(tux, groupId)
					groupId = []string{}
				} else {
					tux = append(tux, groupId[:99])
					groupId = groupId[99:]
				}
			} else {
				break
			}
		}
	} else {
		tux = append(tux, groupId)
	}
	for _, lis := range tux {
		res, err := self.TalkService().GetChats(context.TODO(), &LineThrift.GetChatsRequest{
			ChatMids:     lis,
			WithInvitees: true,
			WithMembers:  true,
		})
		if err != nil {
			P(fmt.Sprintf("GetChatsFCK %v", err))
		}
		r = append(r, res.Chats...)
	}
	return r, err
}

func (self *LineClient) GetGroupMemberLINE(groupId string) (string, map[string]int64) {
	res, err := self.TalkService().GetChats(context.TODO(), &LineThrift.GetChatsRequest{
		ChatMids:     []string{groupId},
		WithInvitees: false,
		WithMembers:  true,
	})
	if err != nil {
		P(fmt.Sprintf("GetChatsFCK %v", err))
		return "", map[string]int64{}
	}
	if len(res.Chats) != 0 {
		ch := res.Chats[0]
		mem := ch.Extra.GroupExtra.MemberMids
		return ch.ChatName, mem
	}
	return "", map[string]int64{}
}

func (cl *LineClient) CorrectRevision(op *LineThrift.Operation, local bool, global bool, individual bool) {
	if global {
		if op.Revision == -1 && op.Param2 != "" {
			s := strings.Split(op.Param2, "\x1e")
			cl.GlobalRev, _ = strconv.ParseInt(s[0], 10, 64)
		}
	}
	if individual {
		if op.Revision == -1 && op.Param1 != "" {
			s := strings.Split(op.Param1, "\x1e")
			cl.IndividualRev, _ = strconv.ParseInt(s[0], 10, 64)
		}
	}
	if local {
		if op.Revision > cl.Revision {
			cl.Revision = op.Revision
		}
	}
}

func (cl *LineClient) DeleteSelfFromChat(to string) {
	LINE := []byte{130, 33, 1, 18, 100, 101, 108, 101, 116, 101, 83, 101, 108, 102, 70, 114, 111, 109, 67, 104, 97, 116, 28, 21, 0, 24, 33}
	LINE = append(LINE, GetStringBytes(to, false)...)
	LINE = append(LINE, []byte{0, 0}...)
	cl.WhatWeUse(LINE, cl.TALK_S5, nil)
}

func (self *LineClient) GetGroupIdsJoined() ([]string, error) {
	req := &LineThrift.GetAllChatMidsRequest{
		WithInvitedChats: false,
		WithMemberChats:  true,
	}
	res, err := self.TalkService().GetAllChatMids(context.TODO(), req, *thrift.Int32Ptr(0))
	return res.MemberChatMids, err
}

func (self *LineClient) UnFriend(mid string) {
	self.TalkService().UpdateContactSetting(context.TODO(), self.SeqMessage, mid, 16, "True")
}


func (cl *LineClient) GetAllContactIds() (res []string) {
	LINE := []byte{130, 33, 1, 16, 103, 101, 116, 65, 108, 108, 67, 111, 110, 116, 97, 99, 116, 73, 100, 115, 21, 4, 0}
	p := cl.WhatWeUse(LINE, cl.TALK_S5, nil)
	fckG := mcp.TMoreShoot(p)
	return fckG.GetAllContactResponse()
}

func (cl *LineClient) GetLastOpRevision() int64 {
	Vezhan, _ := cl.TalkService().GetLastOpRevision(context.TODO())
	return Vezhan
}

// func (cl *LineClient) GetProfile() (res *LineThrift.Profile) {
// 	res, _ = cl.TalkService().GetProfile(context.TODO(), 2)
// 	return res
// }
func (cl *LineClient) GetProfile() (res *LineThrift.Profile) {
	defer VHrecover("GetProfile")
	data := []byte{130, 33, 0, 10, 103, 101, 116, 80, 114, 111, 102, 105, 108, 101, 0}
	p := cl.MakeHTTPDec(LINE_HOST_DOMAIN+cl.TALK_S5, data, map[string]string{})
	fckG := mcp.TMoreShoot(p)
	res = fckG.GetProfileResponse()
	cl.SeqMessage++
	return res
}

func (cl *LineClient) GetProfileT() (r *LineThrift.Profile, err error) {
	return cl.TalkService().GetProfile(context.TODO(), 2)
}

func (cl *LineClient) SendTagAll(to string) (res *LineThrift.Message) {
	textx := "@All"
	ContentMetadata := map[string]string{"MENTION": "{\"MENTIONEES\":[{\"A\":\"1\",\"S\":\"0\",\"E\":\"4\"}]}"} //map[string]string{}
	_, err := cl.SendMessageWithoutE2ee(to, ContentMetadata, 0, textx)
	if err != nil {
		chunk := cl.EncryptedMessage(to, textx)
		Metadata := ContentMetadata
		cl.SendMessageE2EE(to, Metadata, 0, chunk)
	}
	return res
}

func (cl *LineClient) UpdateProfile(profile *LineThrift.Profile) {
	cl.TalkService().UpdateProfile(context.TODO(), 123, profile)
}

func (self *LineClient) GetChattcr(chatMids string) ([]*LineThrift.Chat, *LineThrift.TalkException) {
	req := LineThrift.NewGetChatsRequest()
	req.ChatMids = []string{chatMids}
	req.WithMembers = true
	req.WithInvitees = true
	chats, err := self.TalkService().GetChats(self.Ctx, req)
	if err != nil {
		error, ok := err.(*LineThrift.TalkException)
		if !ok {
			return nil, &LineThrift.TalkException{}
		}
		return nil, error
	}
	return chats.Chats, nil
}

func (cl *LineClient) FCKGetMember(to string) (memb []string, pend []string, peek bool) {
	defer VHrecover("FCKGetMember: " + cl.Name)
	var ab []string
	var ac []string
	p11, err := cl.GetChats(to)
	if err != nil {
		p11, err = cl.GetChats(to)
		if err != nil {
			P(fmt.Sprintf("GetChatsFCK %v", err))
			return memb, pend, peek
		}
	}
	p13 := p11.Chats[0]
	mb := p13.Extra.GroupExtra.MemberMids
	inv := p13.Extra.GroupExtra.InviteeMids
	cv := p13.Extra.GroupExtra.PreventedJoinByTicket
	for f := range mb {
		ab = append(ab, f)
	}
	for g := range inv {
		ac = append(ac, g)
	}
	return ab, ac, cv
}

func (cl *LineClient) SendChatChecked(consumer string, lastMessageId string) {
	cl.TalkService().SendChatChecked(context.TODO(), cl.GetCurrReqId(), consumer, lastMessageId, 6)
}

func (cl *LineClient) SendMsg(to, id, path, tipe, text string, metadata map[string]string) error {
	msg := LineThrift.NewMessage()
	msg.To = to
	msg.From_ = cl.Mid
	msg.ContentMetadata = metadata
	if id != "" {
		msg.RelatedMessageId = id
		msg.RelatedMessageServiceCode = 1
		msg.MessageRelationType = 3
	} else {
		msg.RelatedMessageId = "0"
	}
	switch tipe {
	case "none":
		msg.ContentType = 0
		if text != "" {
			msg.Text = text
		} else {
			return errors.New("invalid msg! text must not be nil")
		}
	case "image", "gif":
		msg.ContentType = 1
	case "video":
		msg.ContentType = 2
	case "audio":
		msg.ContentType = 3
	case "file":
		msg.ContentType = 14
	case "gift":
		msg.ContentType = 9
	case "contact":
		msg.ContentType = 13
	case "sticker":
		msg.ContentType = 7
	default:
		return errors.New("invalid ContentType")
	}
	res, err := cl.TalkService().SendMessage(context.TODO(), cl.GetCurrReqId(), msg)
	//fmt.Println("SendMsg res", res)
	if err != nil {
		fmt.Println("SendMsg", err)
		return err
	}
	if Contains([]string{"image", "gif", "video", "audio", "file"}, tipe) {
		err = cl.UploadObjTalk(res.ID, path, tipe)
		if err != nil {
			fmt.Println(err)
			return err
		}
		os.Remove(path)
	}
	return nil
}

func (cl *LineClient) FetchpanicHandle(s string) {
	if r := recover(); r != nil {
		ret_ := "Error Handling\n"
		ret_ += "\nType : " + s
		ret_ += fmt.Sprintf("\n%v\n%v", s, r)
		fmt.Println(ret_)
	}
}

func (cl *LineClient) GetGroupName(to string) (string, map[string]int64) {
	Chaty, _ := cl.GetChats(to)
	if Chaty == nil {
		return "Nothing", nil
	}
	p13 := Chaty.Chats[0]
	mb := p13.Extra.GroupExtra.MemberMids
	nm := p13.ChatName
	return nm, mb
}

func MentionList(op *LineThrift.Operation) []string {
	msg := op.Message
	str := fmt.Sprintf("%v", msg.ContentMetadata["MENTION"])
	taglist := GetMentionData(str)
	return taglist
}

func (cl *LineClient) AddedText(msg string, babi string, prefix string) string {
	su := babi
	names := cl.GetProfile().DisplayName
	jj := fmt.Sprintf("@%v", names)
	caser := cases.Title(language.English)
	rname := caser.String(prefix)
	str0 := strings.Replace(msg, rname+su+"", "", 1)
	str1 := strings.Replace(str0, prefix+su+"", "", 1)
	str2 := strings.Replace(str1, prefix+" "+su+" ", "", 1)
	str3 := strings.Replace(str2, rname+su+" ", "", 1)
	str4 := strings.Replace(str3, prefix+su+" ", "", 1)
	str5 := strings.Replace(str4, jj+" "+su+" ", "", 1)
	str6 := strings.Replace(str5, su+" ", "", 1)
	str7 := strings.Replace(str6, " "+su+" ", "", 1)
	str8 := strings.Replace(str7, su, "", 1)
	if len(str8) != 0 {
		if str8[0:1] == " " {
			runes := []rune(str8)
			runes = append(runes[:0], runes[1:]...)
			str8 = string(runes)
		}
	}
	return str8
}

func (cl *LineClient) Checkban(to string) bool {
	a := cl.DeleteOtherFromChat(to, "u3b07c57b6239e5216aa4c7a02687c86d")
	if strings.Contains(a.Reason, "request blocked") {
		if !InArrayCl(KickBans, cl) {
			KickBans = append(KickBans, cl)
			cl.Ready = false
			cl.Limiter = false
		}
		return false
	} else {
		if InArrayCl(KickBans, cl) {
			KickBans = RemoveCl(KickBans, cl)
			cl.Ready = true
			cl.Limiter = true
		}
		return true
	}
}

func (cl *LineClient) GetError(jos error, tipe string) {
	if strings.Contains(jos.Error(), "request blocked") {
		if InArrayCl(Client, cl) {
			if !InArrayCl(KickBans, cl) {
				KickBans = append(KickBans, cl)
				cl.TimeBan = time.Now()
			}
			cl.Limiter = false
		}
	} else {
		fmt.Println(cl.Name, tipe, jos.Error())
	}
}

type TCompactProtocol struct {
    lastFid  int
    lastPos  int
    data     []byte
}

func NewTCompactProtocol() *TCompactProtocol {
    return &TCompactProtocol{
        lastFid: 0,
        lastPos: 0,
    }
}

func (self *TCompactProtocol) DecodeKey(buff []byte) []interface{} {
    A := new(TCompactProtocol)
    A.data = buff
    ee := A.x()
    return ee
}

func (self *LineClient) MakeZigZag(n, bits int) int {
    return (n << 1) ^ (n >> (bits - 1))
}

func (self *LineClient) WriteVarint(data int) []byte {
    var out []byte

    for {
        if data&^0x7f == 0 {
            out = append(out, byte(data))
            break
        } else {
            out = append(out, byte(data&0x7f|0x80))
            data >>= 7
        }
    }
    return out
}

func (cl *LineClient) EncData(data []byte) ([]byte, error) {
	block, err := aes.NewCipher(cl.EncryptKey)
	if err != nil {
		return nil, err
	}
	paddedData := VHtearCryptoutil.Pad(data, aes.BlockSize)
	encryptedData := make([]byte, len(paddedData))
	mode := cipher.NewCBCEncrypter(block, cl.IV)
	mode.CryptBlocks(encryptedData, paddedData)
	return encryptedData, nil
}

func (cl *LineClient) DecData(data []byte) ([]byte, error) {
	dat := VHtearCryptoutil.Pad(data, aes.BlockSize)
	block, err := aes.NewCipher(cl.EncryptKey)
	if err != nil {
		fmt.Println("NewCipher", err)
	}

	mode := cipher.NewCBCDecrypter(block, cl.IV)
	decrypted := make([]byte, len(dat))
	mode.CryptBlocks(decrypted, dat)
	decrypted = decrypted[:len(decrypted)-16]
	return decrypted, nil
}

func (p *TCompactProtocol) x() []interface{} {
    ftype, fid, offset := p.readFieldBegin(p.data[p.lastPos:])
    p.lastPos += offset
    return p.z(ftype, fid)
}

func (p *TCompactProtocol) readFieldBegin(data []byte) (int, int, int) {
    offset := 1
    _type := int(data[0])
    if _type&0x0f == 0x00 {
        return 0, 0, offset
    }
    delta := _type >> 4
    p.lastFid += delta
    _type = _type & 0x0f
    return _type, p.lastFid, offset
}

func (p *TCompactProtocol) z(ftype int, fid int) []interface{} {
    var (
        datas []interface{}
        offset = 0
    )
    if ftype == 5 {
        pp, ppp := p.readZigZag(p.data[p.lastPos:])
        datas, offset = append(datas, pp), ppp
        p.lastPos += offset
    } else if ftype == 6 {
        pp, ppp := p.readZigZag(p.data[p.lastPos:])
        datas, offset = append(datas, pp), ppp
        p.lastPos += offset
    } else if ftype == 8 {
        pp, ppp := p.readBinary(p.data[p.lastPos:])
        datas, offset = append(datas, pp), ppp
        p.lastPos += offset
    } else if ftype == 9 || ftype == 10 {
        datas = make([]interface{}, 0)
        vtype, vsize, vlen := p.readCollectionBegin(p.data[p.lastPos:])
        p.lastPos += vlen
        for _i := 0; _i < vsize; _i++ {
            _data := p.z(vtype, 0)
            datas = append(datas, _data)
        }
    } else if ftype == 12 {
        datas = make([]interface{}, 0)
        _dec := NewTCompactProtocol()
        for {
            _ftype, _fid, offset := _dec.readFieldBegin(p.data[p.lastPos:])
            p.lastPos += offset
            if _ftype == 0 {
                break
            }
            pp := p.z(_ftype, _fid)
            datas = append(datas, pp)
        }
    }
    return datas
}
func (p *TCompactProtocol) readZigZag(data []byte) (int, int) {
    res := p.readVarint(data)
    return p.fromZigZag(int(res[0])), res[1]
}

func (p *TCompactProtocol) readBinary(data []byte) ([]byte, int) {
    res := p.readVarint(data)
    result := data[res[1] : res[0]+res[1]]
    return []byte(result), int(res[0]+res[1])
}

func (p *TCompactProtocol) readVarint(data []byte) []int {
    result, shift, i := 0, 0, 0
    for {
        mb := data[i]
        i++
        result |= (int(mb) & 0x7f) << shift
        if mb >> 7 == 0 {
            return []int{result, i}
        }
        shift += 7
    }
}

func mentions(client *LineClient, to string, jenis string, memlist []string) {
	ta := false
	tx := ""
	tag := []string{}
	z := len(memlist) / 20
	y := z + 1
	for i := 0; i < y; i++ {
		if !ta {
			tx += fmt.Sprintf("%s:\n", jenis)
			ta = true
		}
		if i == z {
			tag = memlist[i*20:]
			no := i * 20
			no += 1
			for i := 0; i < len(tag); i++ {
				iki := no + i
				tx += fmt.Sprintf("\n%v. @!", iki)
			}
		} else {
			tag = memlist[i*20 : (i+1)*20]
			no := i * 20
			no += 1
			for i := 0; i < len(tag); i++ {
				iki := no + i
				if iki < 10 {
					tx += fmt.Sprintf("\n%v.  @!", iki)
				} else {
					tx += fmt.Sprintf("\n%v. @!", iki)
				}

			}
		}
		if len(tag) != 0 {
			tx += "\n\n" + TeamName
			client.SendMentionLINE(to, tx, tag)
		}
		tx = ""
	}
}

func (p *TCompactProtocol) readCollectionBegin(data []byte) (int, int, int) {
    sizeType := data[0]
    size := int(sizeType >> 4)
    _type := int(sizeType & 0x0f)
    _len := 0
    if size == 15 {
        res := p.readVarint(data[1:])
        size, _len = res[0], res[1]
    }
    return _type, size, _len + 1
}

func (p *TCompactProtocol) fromZigZag(n int) int {
    return (n >> 1) ^ -(n & 1)
}

type SelfKey struct {
	Version int
	KeyId   int
	PubKey  string
	PrivKey string
}

func SaveE2EESelfKeyData(mid string, pubK string, privK string, keyID int, e2eeVersion int) (e2 *SelfKey) {
	if mid != "" {
		UpdateSetInt("dataE2EE."+mid+".keyId", keyID)
		UpdateSetInt("dataE2EE."+mid+".e2eeVersion", e2eeVersion)
		UpdateSetString("dataE2EE."+mid+".privKey", privK)
		UpdateSetString("dataE2EE."+mid+".pubKey", pubK)
	}
	sk := fmt.Sprintf("%v", mid)
	UpdateSetInt("dataE2EE."+sk+".keyId", keyID)
	UpdateSetInt("dataE2EE."+sk+".e2eeVersion", e2eeVersion)
	UpdateSetString("dataE2EE."+sk+".privKey", privK)
	UpdateSetString("dataE2EE."+sk+".pubKey", pubK)
	return &SelfKey{
		Version: e2eeVersion,
		KeyId:   keyID,
		PrivKey: privK,
		PubKey:  pubK,
	}
}

func (cl *LineClient) GetGroupCall(to string) (*LineThrift.GroupCall, error) {
	return cl.CallService().GetGroupCall(cl.Ctx, to)
}

func (cl *LineClient) InviteIntoGroupCall(to string, mids []string) (error) {
	return cl.CallService().InviteIntoGroupCall(cl.Ctx, to, mids, 1)
}

func (self *LineClient) LINEAddFriendGroupMember(to, mid string) error {
	req := LINERelation.NewAddFriendByMidRequest()
	req.UserMid = mid
	req.Tracking = LINERelation.NewAddFriendTracking()
	req.Tracking.Reference = ToJSON(map[string]string{
		"screen": "groupMemberList",
		"spec":   "native",
	})
	req.Tracking.TrackingMeta = LINERelation.NewAddFriendTrackingMeta()
	req.Tracking.TrackingMeta.GroupMemberList = LINERelation.NewAddMetaGroupMemberList()
	req.Tracking.TrackingMeta.GroupMemberList.ChatMid = to
	_, err := self.LINERelationService().AddFriendByMid(self.Ctx, req)
	return err
}

func (self *LineClient) LINEAddFriendShareContact(to, mid, sender, id string) error {
	time.Sleep(3 * time.Second)
	req := LINERelation.NewAddFriendByMidRequest()
	req.UserMid = mid
	req.Tracking = LINERelation.NewAddFriendTracking()
	req.Tracking.Reference = ToJSON(map[string]string{
		"screen": "talkroom:message",
		"spec":   "native",
	})
	req.Tracking.TrackingMeta = LINERelation.NewAddFriendTrackingMeta()
	req.Tracking.TrackingMeta.ShareContact = LINERelation.NewAddMetaShareContact()
	req.Tracking.TrackingMeta.ShareContact.MessageId = id
	req.Tracking.TrackingMeta.ShareContact.ChatMid = to
	req.Tracking.TrackingMeta.ShareContact.SenderMid = sender
	time.Sleep(3 * time.Second)
	_, err := self.LINERelationService().AddFriendByMid(self.Ctx, req)
	return err
}

func (self *LineClient) LINEAddFriendUrl(mid string) error {
	time.Sleep(3 * time.Second)
	req := LINERelation.NewAddFriendByMidRequest()
	req.UserMid = mid
	req.Tracking = LINERelation.NewAddFriendTracking()
	req.Tracking.Reference = ToJSON(map[string]string{
		"screen": "urlScheme:internal",
		"spec":   "native",
	})
	req.Tracking.TrackingMeta = LINERelation.NewAddFriendTrackingMeta()
	req.Tracking.TrackingMeta.UrlScheme = LINERelation.NewAddMetaUrlScheme()
	time.Sleep(3 * time.Second)
	_, err := self.LINERelationService().AddFriendByMid(self.Ctx, req)
	return err
}

func (self *LineClient) AddFriendByTicketV2(ticket string) (err error) {
	tcr,_ := self.FindContactByUserTicket(ticket)
       //fmt.Println(tcr)
	self.LINEAddByTicket(tcr.Mid)
	return err
}

func (self *LineClient) AddFriendByTicket(ticket string) error {
	tcr,_ := self.FindContactByUserTicket(ticket)
	fmt.Println(tcr)
    req := LINERelation.NewAddFriendByMidRequest()
    req.UserMid = tcr.Mid
    req.Tracking = LINERelation.NewAddFriendTracking()
    req.Tracking.Reference = ToJSON(map[string]string{
        "screen": "urlScheme:internal",
        "spec": "native",
    })
    req.Tracking.TrackingMeta = LINERelation.NewAddFriendTrackingMeta()
    req.Tracking.TrackingMeta.UrlScheme = LINERelation.NewAddMetaUrlScheme()
    _, err := self.LINERelationService().AddFriendByMid(self.Ctx, req)
    return err
}

func (s *LineClient) SendTextMentionByListLINE(to string, msgText string, targets []string) {
	listMid := targets
	listMid2 := []string{}
	listChar := msgText+"\n"
	listNum := 0
	loopny := len(listMid)/20 + 1
	limiter := 0
	limiter2 := 20
	for a := 0; a < loopny; a++ {
		for c := limiter; c < len(listMid); c++ {
			if c < limiter2 {
				listNum = int(listNum) + 1
				listChar += "\n" + strconv.Itoa(listNum) + ". @!"
				listMid2 = append(listMid2, listMid[c])
				limiter = limiter + 1
			} else {
				limiter2 = limiter + 20
				break
			}
		}
		listChar += "\n\n" + TeamName
		s.SendMentionLINE(to, listChar, listMid2)
		listChar = ""
		listMid2 = []string{}
	}
}

/*func (cl *LineClient) NewAcceptLINE(to string) error {
	fckV := []byte{130, 33, 1, 20, 97, 99, 99, 101, 112, 116, 67, 104, 97, 116, 73, 110, 118, 105, 116, 97, 116, 105, 111, 110, 28, 21, 0, 24, 33}
	fckV = append(fckV, GetStringBytes(to, false)...)
	fckV = append(fckV, []byte{0, 0}...)
	_, err := cl.ConnectMoreCompact(fckV, cl.TALK_S5)
	return err
}*/

func (s *LineClient) NewAcceptLINE(groupId string) error {
	client := s.TalkService()
	v := LineThrift.NewAcceptChatInvitationRequest()
	v.ReqSeq = s.SeqMessage
	v.ChatMid = groupId
	err := client.AcceptChatInvitation(context.TODO(), v)
	return err
}

/*func (cl *LineClient) NewKickLINE(to string, mid string) error {
	defer cl.GetCurrReqId()
	fckV := []byte{130, 33, 1, 19, 100, 101, 108, 101, 116, 101, 79, 116, 104, 101, 114, 70, 114, 111, 109, 67, 104, 97, 116, 28, 21, 0, 24, 33}
	fckV = append(fckV, GetStringBytes(to, false)...)
	fckV = append(fckV, []byte{26, 24, 33}...)
	fckV = append(fckV, GetStringBytes(mid, false)...)
	fckV = append(fckV, []byte{0, 0}...)
	_, err := cl.ConnectMoreCompact(fckV, cl.TALK_S5)
	return err
}*/

func (s *LineClient) NewKickLINE(groupId string, contactIds string) error {
	client := s.TalkService()
	fst := LineThrift.NewDeleteOtherFromChatRequest()
	fst.ReqSeq = s.SeqMessage
	fst.ChatMid = groupId
	fst.TargetUserMids = []string{contactIds}
	err := client.DeleteOtherFromChat(context.TODO(), fst)
	return err
}

/*func (cl *LineClient) NewCancelLINE(to string, mid string) error {
	fckV := []byte{130, 33, 1, 20, 99, 97, 110, 99, 101, 108, 67, 104, 97, 116, 73, 110, 118, 105, 116, 97, 116, 105, 111, 110, 28, 21, 0, 24, 33}
	fckV = append(fckV, GetStringBytes(to, false)...)
	fckV = append(fckV, []byte{26, 24, 33}...)
	fckV = append(fckV, GetStringBytes(mid, false)...)
	fckV = append(fckV, []byte{0, 0}...)
	_, err := cl.ConnectMoreCompact(fckV, cl.TALK_S5)
	return err
}*/

func (s *LineClient) NewCancelLINE(groupId string, contactIds string) error {
	client := s.TalkService()
	fst := LineThrift.NewCancelChatInvitationRequest()
	fst.ReqSeq = s.SeqMessage
	fst.ChatMid = groupId
	fst.TargetUserMids = []string{contactIds}
	err  := client.CancelChatInvitation(context.TODO(), fst)
	return err
}

/*func (cl *LineClient) NewInviteLINE(to string, mid []string) error {
	fckV := []byte{130, 33, 1, 14, 105, 110, 118, 105, 116, 101, 73, 110, 116, 111, 67, 104, 97, 116, 28, 21, 0, 24, 33}
	fckV = append(fckV, GetStringBytes(to, false)...)
	fckV = append(fckV, []byte{26}...)
	byteCount := 8
	for range mid {
		byteCount += 16
	}
	fckV = append(fckV, GetLenStrBytes(byteCount)...)
	for _, mids := range mid {
		fckV = append(fckV, []byte{33}...)
		fckV = append(fckV, GetStringBytes(mids, false)...)
	}
	fckV = append(fckV, []byte{0, 0}...)
	_, err := cl.ConnectMoreCompact(fckV, cl.TALK_S5)
	return err
}*/

func (s *LineClient) NewInviteLINE(groupId string, contactIds []string) error {
	client := s.TalkService()
	fst := LineThrift.NewInviteIntoChatRequest()
	fst.ReqSeq = s.SeqMessage
	fst.ChatMid = groupId
	fst.TargetUserMids = contactIds
	err := client.InviteIntoChat(context.TODO(), fst)
	return err
}

func (cl *LineClient) NewCreateChat(mid []string, name string) error {
	HTTP, _ := thrift.NewTHttpClient(LINE_HOST_DOMAIN + "/S5")
	transport := HTTP.(*thrift.THttpClient)
	transport.SetHeader("user-agent", cl.UserAgent)
	transport.SetHeader("x-line-application", cl.AppName)
	transport.SetHeader("x-line-access", cl.AuthToken)
	transport.SetHeader("x-lal", "en_US")
	transport.SetHeader("x-lpv", "1")
	transport.SetHeader("content-type", "application/x-thrift")
	transport.SetHeader("accept", "application/x-thrift")
	transport.SetHeader("accept-encoding", "gzip")
	transport.SetHeader("X-Forwarded-For", "203.0.113.7")
	transport.SetMoreCompact(true)
	gatel := ""
	for _, babi := range mid {
		gatel += fmt.Sprintf("!%v", babi)
	}
	celeng := []byte("\x82!\x01\r\ncreateChat\x1c\x15\xd8\xea\x01\x15\x02\x18\t" + name + "\x1a8" + gatel + "\x18\x00\x00\x00")
	transport.Write(celeng)
	//fmt.Println(celeng, gatel)
	return transport.Flush(cl.Ctx)

}

func (self *LineClient) LINEAddFriendByMid(to string, rep string) {
	contacts := self.GetAllContactIds()
	if strings.HasPrefix(rep, "u") && len(rep) == 33 {
        c, err := self.GetContact(rep)
        if err == nil {
            if !slices.Contains(contacts, c.Mid) && self.Mid != rep {
				time.Sleep(5 * time.Second)
                self.AddFriendByte(to, c.Mid)
				time.Sleep(2 * time.Second)
				self.SendMessage(to, c.DisplayName+" added to friendlist.")
            } else {
                self.SendMessage(to, c.DisplayName+" is a friendlist.")
            }
            return
        }
	}
}

func (self *LineClient) LINEAddFriendByMidV2(to string, rep string,sender string,id string) {
	contacts := self.GetAllContactIds()
	if strings.HasPrefix(rep, "u") && len(rep) == 33 {
        c, err := self.GetContact(rep)
        if err == nil {
            if !slices.Contains(contacts, c.Mid) {
				time.Sleep(5 * time.Second)
                self.LINEAddFriendShareContact(to,c.Mid,sender,id)
				time.Sleep(2 * time.Second)
				self.SendMessage(to, c.DisplayName+" added to friendlist.")
            } else {
                self.SendMessage(to, c.DisplayName+" is a friendlist.")
            }
            return
        }
	}
}

func (cl *LineClient) AddFriendByMid(mid string) (res map[string]*LineThrift.Contact, err error) {
	var httpClient thrift.TTransport
	fOB := []byte{130, 33, 0, 14, 97, 100, 100, 70, 114, 105, 101, 110, 100, 66, 121, 77, 105, 100, 28, 21, 0, 24, 33}
	fOB = append(fOB, GetStringBytes(mid, false)...)
	fOB = append(fOB, []byte{28, 24, 48, 123, 34, 115, 99, 114, 101, 101, 110, 34, 58, 34, 102, 114, 105, 101, 110, 100, 65, 100, 100, 58, 114, 101, 99, 111, 109, 109, 101, 110, 100, 34, 44, 34, 115, 112, 101, 99, 34, 58, 34, 110, 97, 116, 105, 118, 101, 34, 125, 28, 172, 0, 0, 0, 0, 0}...)
	httpClient, _ = thrift.NewTHttpClientWithOptions(LINE_HOST_DOMAIN+"/RE4", thrift.THttpClientOptions{
		Client: cl.HttpClient,
	})
	transport := httpClient.(*thrift.THttpClient)
	transport.SetHeader("user-agent", cl.UserAgent)
	transport.SetHeader("x-line-application", cl.AppName)
	transport.SetHeader("x-line-access", cl.AuthToken)
	transport.SetHeader("x-lal", "id_ID")
	transport.SetHeader("x-lpv", "1")
	transport.Write(fOB)
	r := transport.Flush(cl.Ctx)
	str_bytes := fmt.Sprintf("%v", r)
	final_byte, e := exec.Command("bash", "-c", fmt.Sprintf("python3 AddFriendResult.py '%s'", str_bytes)).Output()
	fmt.Println(final_byte)
	final := string(final_byte)
	if e != nil {return res, e}
	if final != "Success" { return res, fmt.Errorf(final) }
	return res, nil
}

func randomBytes(size int) []uint8 {
	rand.Seed(time.Now().UTC().UnixNano())
	var High int = 255
	var seed = make([]uint8, size)
	for i := 0; i < len(seed); i++ {
		seed[i] = uint8(rand.Int() % (High + 1))
	}
	return seed
}

func GenerateAsymmetricKeypair() curve.Keys {
	seed := randomBytes(32)
	return curve.GenerateKeyPair(seed)
}

func (p *LineClient) StartMigration(to string) error {
	service := p.PrimaryQRMigrationPreService()
	session, err := service.CreateQRMigrationSession(p.Ctx, &LineThrift.CreateSessionRequest{})
	if err != nil {
		return err
	}
	nonce := randomBytes(32)
	keypair := GenerateAsymmetricKeypair()
	qrmap := map[string]string{
		"si": session.SessionId,
		"qi": fmt.Sprintf("%X", nonce),
		"pk": fmt.Sprintf("%X", keypair.PublicKey),
	}
	fmt.Println(session.SessionId, fmt.Sprintf("%X", nonce), fmt.Sprintf("%X", keypair.PublicKey), fmt.Sprintf("%X", keypair.PrivateKey))
	bData, err := json.Marshal(qrmap)
	fmt.Println(bData)
	fmt.Println("https://chart.googleapis.com/chart?chs=500x500&cht=qr&chl=" + url.QueryEscape(string(bData)))
	p.SendMessage(to, "https://chart.googleapis.com/chart?chs=500x500&cht=qr&chl=" + url.QueryEscape(string(bData)))
	//qrterminal.Generate(string(bData), qrterminal.L, os.Stdout)
	// go p.TryMigration(qrmap)
	fmt.Println("按Enter鍵繼續...")
	os.Stdin.Read(make([]byte, 10))
	time.Sleep(2 * time.Second)
	service.SendEncryptedE2EEKey(p.Ctx, &LineThrift.SendEncryptedE2EEKeyRequest{
		SessionId: session.SessionId,
		EncryptedSecureChannelPayload: &LineThrift.EncryptedBinary{
			RecoveryKey:       []byte{146, 1, 196, 16, 9, 231, 32, 118, 225, 45, 12, 22, 26, 217, 192, 116, 198, 36, 121, 74},
			BackupBlobPayload: []byte{147, 1, 146, 146, 1, 206, 0, 60, 0, 37, 145, 2, 196, 239, 81, 173, 78, 182, 210, 207, 157, 196, 91, 218, 171, 171, 70, 64, 153, 100, 235, 1, 120, 95, 212, 153, 64, 62, 56, 140, 114, 38, 57, 36, 64, 227, 12, 10, 55, 48, 76, 185, 211, 36, 231, 144, 78, 230, 35, 59, 180, 84, 170, 52, 3, 34, 94, 89, 189, 13, 240, 207, 128, 37, 116, 140, 190, 198, 162, 82, 77, 44, 72, 4, 56, 6, 145, 205, 8, 57, 180, 98, 88, 85, 17, 247, 34, 128, 166, 115, 11, 101, 34, 49, 146, 176, 250, 48, 12, 220, 229, 232, 184, 113, 209, 201, 38, 204, 209, 113, 218, 159, 208, 61, 16, 191, 63, 125, 122, 181, 31, 186, 55, 155, 213, 111, 78, 77, 46, 80, 95, 199, 104, 101, 169, 204, 99, 237, 52, 223, 75, 193, 159, 86, 238, 117, 132, 244, 204, 102, 241, 90, 118, 124, 153, 161, 160, 215, 178, 50, 221, 16, 136, 187, 165, 17, 132, 247, 116, 24, 157, 253, 21, 133, 115, 127, 84, 242, 175, 17, 63, 145, 224, 73, 235, 200, 18, 44, 115, 191, 108, 107, 247, 89, 82, 238, 106, 87, 253, 181, 101, 171, 175, 33, 176, 32, 227, 92, 190, 107, 99, 108, 160, 251, 50, 167, 232, 160, 26, 211, 221, 54, 156, 51, 217, 125, 223, 23, 187, 210, 154, 147, 22, 225, 17, 119, 39, 103, 15, 98, 151, 58, 92},
		},
	})
	return nil
}

//NEW FUNC BYTE
func (cl *LineClient) NewLINEAcceptChat(to string) {
	LINE := []byte("\x82!\x01\x14acceptChatInvitation\x1c\x15\xc8>\x18!"+to+"\x00\x00")
	cl.MakeHTTPDec("https://legy.line-apps.com/S5", LINE, map[string]string{})
}

func (cl *LineClient) NewLINEKickChat(to string, target string) {
	    LINE := []byte("\x82!\x01\x13deleteOtherFromChat\x1c\x15\x82/\x18!"+to+"\x1a\x18!"+target+"\x00\x00")
	    cl.MakeHTTPDec("https://legy.line-apps.com/S5", LINE, map[string]string{})
}

func (cl *LineClient) NewLINECancelChat(to string, target string) {
	    LINE := []byte("\x82!\x01\x14cancelChatInvitation\x1c\x15\x80/\x18!"+to+"\x1a\x18!"+target+"\x00\x00")
	    cl.MakeHTTPDec("https://legy.line-apps.com/S5", LINE, map[string]string{})
}

func (cl *LineClient) AcceptGroupInvitationByTicketV2(to string,ticket string) {
	LINE := []byte("\xef\xbf\xbd!\x01\x1cacceptChatInvitationByTicket\x1c\x15\xef\xbf\xbd>\x18!"+to+"\x18\r\n"+ticket+"\x00\x00")
	cl.MakeHTTPDec("https://legy.line-apps.com/S5", LINE, map[string]string{})
}

func (self *LineClient) AddFriendByte(to string, mid string) {
	LINE := []byte("\x82!\x01\x0eaddFriendByMid\x1c\x15\xe2\x0f\x18!" + mid + "\x1c\x18,{\"screen\":\"groupMemberList\",\"spec\":\"native\"},L\x18!" + to + "\x00\x00\x00\x00\x00")
	self.MakeHTTPDec("https://legy.line-apps.com/RE4", LINE, map[string]string{})
}

func (cl *LineClient) GetChatsByte(to string) (res *LineV2.GetChatsResponse) {
	LINE := []byte{130, 33, 0, 8, 103, 101, 116, 67, 104, 97, 116, 115, 28, 25, 24, 33}
	LINE = append(LINE, GetStringBytes(to,false)...)
	LINE = append(LINE, []byte{17, 17, 0, 0}...)
	HTTP, _ := thrift2.NewTHttpClient(cl.Main_host + "/S5")
	transport := HTTP.(*thrift2.THttpClient)
	transport.SetHeader("user-agent", cl.UserAgent)
	transport.SetHeader("x-line-application", cl.AppName)
	transport.SetHeader("x-line-access", cl.AuthToken)
	transport.SetHeader("x-lal", "en_US")
	transport.SetHeader("x-lpv", "1")
	transport.SetHeader("content-type", "application/x-thrift")
	transport.SetHeader("accept", "application/x-thrift")
	transport.SetHeader("accept-encoding", "gzip")
	transport.SetHeader("X-Forwarded-For", "203.0.113.7")
	transport.SetMoreCompact(true)
	transport.Write(LINE)
	transport.Flush(context.TODO())
	b := transport.GetBody()
	if len(b) > 0 {
		tmcp := modcompact.TMoreCompactProtocolGoods(b)
		return tmcp.GetChatsResponse()
	}
	return res
}