package engine

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
	"bufio"
	"bytes"
	b64 "encoding/base64"
	"encoding/json"
	"fmt"
	"io"

	"math/rand"
	"net/http"
	"net/url"
	"os"

	//"os/exec"
	"crypto/md5"
	"encoding/hex"
	"errors"
	"path/filepath"
	"strconv"
	"strings"
	"time"
	"github.com/valyala/fasthttp"
	"github.com/tidwall/gjson"
)

var timelineAPI = "https://legy-backup.line-apps.com/hm/api"
var LINE_OBS_DOMAIN = "https://obs-sg.line-apps.com"

func DownloadFileURL(URL, fileName string) string {
	//defer vh.VHpanicHandle("DownloadFileURL")
	if URL != "" {
		response, err := http.Get(URL)
		fmt.Println(response.StatusCode)
		if err != nil {
			fmt.Println(err)
			return ""
		} else {
			defer response.Body.Close()
			if response.StatusCode != 200 {
				fmt.Println("Received non 200 response code")
				return ""
			}
			file, _ := os.Create(fileName)
			defer file.Close()
			_, _ = io.Copy(file, response.Body)
			return fileName
		}
	}
	return ""
}

func (p *LineClient) SetTimelineHeaders() error {
	channel, err := p.ChannelService().ApproveChannelAndIssueChannelToken(p.Ctx, TIMELINE_CHANNEL_ID)
	if err != nil {
		return err
	}
	p.timeLineHeader = map[string]string{
		"Content-Type":        "application/json",
		"X-LAP":               "5",
		"X-LPV":               "1",
		"X-Line-ChannelToken": channel.ChannelAccessToken,
		"X-Line-Application":  p.AppName,
		"User-Agent":          p.UserAgent,
		"X-Line-Mid":          p.Mid,
	}
	// fmt.Println("ChannelToken: ", channel.ChannelAccessToken)
	return nil
}

func (p *LineClient) TimelineRequests(url string, method string, extraHeader map[string]string, data interface{}) (res string, err error) {
	if p.timeLineHeader == nil || p.timeLineHeader["X-Line-ChannelToken"] == "" {
		if err = p.SetTimelineHeaders(); err != nil {
			return "", err
		}
	}
	if p.fast_connection == nil {
		p.setDefaultHttpClient()
	}
	request := fasthttp.AcquireRequest()
	response := fasthttp.AcquireResponse()
	request.SetRequestURI(url)
	request.Header.SetMethod(method)
	for key, value := range p.timeLineHeader {
		request.Header.Set(key, value)
	}
	for key, value := range extraHeader {
		request.Header.Set(key, value)
	}
	if method == "POST" {
		if bData, ok := data.([]byte); ok {
			request.SetBody(bData)
		} else {
			byteData, _ := json.Marshal(data)
			request.SetBody(byteData)
		}
	}
	err = p.fast_connection.Do(request, response)
	if err != nil {
		return "", err
	}
	return string(response.Body()), nil
}

func (p *LineClient) CreateKeep(keepID, content string) (string, error) {
	if keepID == "" {
		keepID = fmt.Sprintf("%d", time.Now().UnixNano())
	}
	var data interface{}
	strdata := fmt.Sprintf(`{"clientId": "ad_kp|%s", "contentData": [{"size": 1, "text": "%s", "type": "TEXT", "urlList": [], "bgColor": "COLOR_04"}], "source": {"id": "ub7a12eba4acc71bd47e749ea46d8a09b", "type": "KEEP"}, "tagInfos": [], "collectionInfos": [], "pinInfo": {"pinned": false}, "serviceType": 0}`, keepID, content)
	json.Unmarshal([]byte(strdata), &data)
	r, err := p.TimelineRequests(LINE_HOST_DOMAIN+"/kp/api/v27/keep/create.json", "POST", nil, data)
	if gjson.Get(r, "code").Int() != 0 {
		return "", fmt.Errorf(gjson.Get(r, "message").String())
	}
	return r, err
}

func ChangeRandomPict(to string) {
	rand.Seed(time.Now().UnixNano())
	max := len(Squad)
	jeh := rand.Intn(155)
	rand.Seed(time.Now().Unix())
	fmt.Println(jeh)
	url := fmt.Sprintf("https://picsum.photos/v2/list?page=%v&limit=%v", jeh, max)
	res, err := http.Get(url)
	if err != nil {
		return
	} else {
		defer res.Body.Close()
		body, _ := io.ReadAll(res.Body)
		ijf := gjson.Get(string(body), "#.download_url").Array()
		for no, a := range ijf {
			b := strings.Replace(a.String(), "https://picsum.photos/id/", "", 1)
			c := strings.Split(b, "/")
			Path := DownloadFileURL(a.String(), "./tmp/"+c[0]+".png")
			Client[no].UpdatePictureProfile(Path, "p")
			Client[no].SendMessage(to, "Success update picture..")
			os.Remove(Path)
		}
	}
}

func ChangeRandomCover(to string) {
	rand.Seed(time.Now().UnixNano())
	max := len(Squad)
	jeh := rand.Intn(155)
	rand.Seed(time.Now().Unix())
	fmt.Println(jeh)
	url := fmt.Sprintf("https://picsum.photos/v2/list?page=%v&limit=%v", jeh, max)
	res, err := http.Get(url)
	if err != nil {
		return
	} else {
		defer res.Body.Close()
		body, _ := io.ReadAll(res.Body)
		ijf := gjson.Get(string(body), "#.download_url").Array()
		for no, a := range ijf {
			fmt.Println(a)
			b := strings.Replace(a.String(), "https://picsum.photos/id/", "", 1)
			c := strings.Split(b, "/")
			Path := DownloadFileURL(a.String(), "./tmp/"+c[0]+".png")
			Client[no].UpdateCover(Path)
			Client[no].SendMessage(to, "Success update Cover..")
			os.Remove(Path)
		}
	}
}

func RandomGroupPict(to string) {
	path := RandomString(PictRand)
	Client[0].ChangeGroupPicture(to, "./database/image/"+path)
}

func GetMD5Hash(text string) string {
	hash := md5.Sum([]byte(text))
	return hex.EncodeToString(hash[:])
}

func (cl *LineClient) DefaultTimelineHeader(req *http.Request) {
	channel, _ := cl.ChannelService().ApproveChannelAndIssueChannelToken(cl.Ctx, TIMELINE_CHANNEL_ID)
	mp := map[string]string{
		`Content-Type`:        `application/json`,
		`User-Agent`:          cl.UserAgent,
		`X-Line-Mid`:          cl.Mid,
		`X-Line-Carrier`:      "51089, 1-0",
		`X-Line-Application`:  "ANDROID 14.3.1 Android OS 12.0",
		`X-Line-ChannelToken`: channel.ChannelAccessToken,
	}
	hed(req, mp)
}

func hed(r *http.Request, heder map[string]string) {
	for k, v := range heder {
		r.Header.Set(k, v)
	}
}

var CoverVideo string


func (cl *LineClient) TimeLineGet(url string) (string, error) {
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return "", err
	}
	cl.DefaultTimelineHeader(req)
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	cvt, _ := io.ReadAll(resp.Body)
	return string(cvt), err
}

func AddParam(urls string, param map[string]string) string {
	p := url.Values{}
	for k, v := range param {
		p.Add(k, v)
	}
	return urls + p.Encode()
}

func InArray2(ArrList []string, rstr string) bool {
	for _, x := range ArrList {
		if x == rstr {
			return true
		}
	}
	return false
}

func (cl *LineClient) GetHomeProfileV2(mid string) string{
  url := AddParam(timelineAPI+"/v1/home/socialprofile/postWithAd.json?", map[string]string{
    "homeId": mid,
    "withSocialHomeInfo": "true",
    "storyVersion": "v10",
    "timelineVersion": "v57",
  })
  rs, _ := cl.TimeLineGet(url)
  return rs
}

func (cl *LineClient) GetHomeProfile(mid, postLimit, commentLimit, likeLimit string) string{
  url := AddParam(timelineAPI+"/v45/post/list.json?", map[string]string{
    "homeId": mid,
    "postLimit": postLimit,
    "commentLimit": commentLimit,
    "likeLimit": likeLimit,
    "sourceType": "LINE_PROFILE_COVER",
  })
  rs, _ := cl.TimeLineGet(url)
  return rs
}


func (cl *LineClient) GetProfileCoverURL(mid string) string {
	home := cl.GetProfileDetail(mid)
	woy := gjson.Get(string(home), "result.objectId").String()
	url := LINE_OBS_DOMAIN + "/myhome/c/download.nhn?userid=" + mid + "&oid=" + woy
	return url
}

func (cl *LineClient) GetProfileDetail(mid string) string {
	url := AddParam(timelineAPI+"/v1/userpopup/getDetail.json?", map[string]string{
		"userMid": mid,
	})
	tr, _ := cl.TimeLineGet(url)
	return tr
}

func (cl *LineClient) GetFeed(postLimit, commentLimit, likeLimit, order string) (err error) {
	if order == "" {
		order = "TIME"
	}
	url := AddParam("https://gxx.line.naver.jp/mh/api/v45/feed/list.json?", map[string]string{
		"postLimit":    postLimit,
		"commentLimit": commentLimit,
		"likeLimit":    likeLimit,
		"order":        order,
	})
	_, err = cl.TimeLineGet(url)
	return
}

func (cl *LineClient) UpdateCoverById(objId, tipe string) error {

	var js []byte
	if tipe == "p" {
		js, _ = json.Marshal(map[string]interface{}{
			"homeId":        cl.Mid,
			"coverObjectId": objId,
			"storyShare":    false,
			"meta":          map[string]string{},
		})
	} else if tipe == "v" {
		js, _ = json.Marshal(map[string]interface{}{
			"homeId":             cl.Mid,
			"coverObjectId":      objId,
			"storyShare":         false,
			"meta":               map[string]string{},
			"videoCoverObjectId": CoverVideo,
		})
		//dataa = fmt.Sprintf(`{"homeId": %s, "coverObjectId": %s, "storyShare": "false", "meta":{}, :"%s", "videoCoverObjectId":%s%}`,cl.Mid,objId,objId)
	} else {
		js, _ = json.Marshal(map[string]interface{}{
			"homeId":        tipe,
			"coverObjectId": objId,
			"storyShare":    false,
			"meta":          map[string]string{},
		})
		req, err := http.NewRequest("POST", "https://gxx.line.naver.jp/hm/api/v1/home/groupprofile/defaultimages.json", bytes.NewBuffer(js))
		if err != nil {
			return err
		}

		cl.DefaultTimelineHeader(req)
		asu := &http.Client{}
		resp, err := asu.Do(req)
		if err != nil {
			return err
		}
		defer resp.Body.Close()
		return nil
	}

	req, err := http.NewRequest("POST", "https://gxx.line.naver.jp/hm/api/v1/home/cover.json", bytes.NewBuffer(js))
	if err != nil {
		return err
	}

	cl.DefaultTimelineHeader(req)

	asu := &http.Client{}
	resp, err := asu.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	return nil
}

func RandomStringV2(n int) string {
	rand.Seed(time.Now().UTC().UnixNano())
	st := "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	b := make([]byte, n)
	for i := range b {
		b[i] = st[rand.Intn(len(st))]
	}
	return string(b)
}

func (y *LineClient) UpdateCoverVideo(path string) error {
	objId := RandomStringV2(32)
	fl, err := os.Open(path)
	if err != nil {
		return err
	}
	defer fl.Close()
	of, err := fl.Stat()
	if err != nil {
		return err
	}
	var size int64 = of.Size()
	bytess := make([]byte, size)
	buffer := bufio.NewReader(fl)
	_, err = buffer.Read(bytess)
	if err != nil {
		return err
	}
	nama := filepath.Base(path)
	dataa := fmt.Sprintf(`
    {
      "name": "%s",
      "oid": "%s",
      "type": "video",
      "userid": "%s",
      "ver": "2.0"
    }`, nama, objId, y.Mid)
	sDec := b64.StdEncoding.EncodeToString([]byte(dataa))
	client := &http.Client{}
	req, _ := http.NewRequest("POST", "https://ga2.line.naver.jp/hm/api/v1/home/cover.json", bytes.NewBuffer(bytess))
	y.DefaultTimelineHeader(req)
	req.Header.Set("x-obs-params", string(sDec))
	req.Header.Set("X-Line-PostShare", "true")
	req.Header.Set("X-Line-StoryShare", "true")
	req.Header.Set("coverObjectId", objId)
	req.Header.Set("videoCoverObjectId", objId)
	req.Header.Set("x-line-signup-region", "ID")
	req.Header.Set("content-type", "video/mp4")
	req.ContentLength = int64(len(bytess))

	res, err := client.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	CoverVideo = objId
	return nil
}

func (y *LineClient) UpdateCoverWithVideo(path string) error {
	objId := RandomStringV2(32)
	fl, err := os.Open(path)
	if err != nil {
		return err
	}
	defer fl.Close()
	of, err := fl.Stat()
	if err != nil {
		return err
	}
	var size int64 = of.Size()
	bytess := make([]byte, size)
	buffer := bufio.NewReader(fl)
	_, err = buffer.Read(bytess)
	if err != nil {
		return err
	}
	nama := filepath.Base(path)
	dataa := fmt.Sprintf(`
    {
      "name": "%s",
      "oid": "%s",
      "type": "image",
      "userid": "%s",
      "ver": "2.0"
    }`, nama, objId, y.Mid)
	sDec := b64.StdEncoding.EncodeToString([]byte(dataa))

	client := &http.Client{}
	req, _ := http.NewRequest("POST", "https://obs-sg.line-apps.com/r/myhome/c/"+objId, bytes.NewBuffer(bytess))
	y.DefaultTimelineHeader(req)
	req.Header.Set("x-obs-params", string(sDec))
	req.Header.Set("X-Line-PostShare", "true")
	req.Header.Set("X-Line-StoryShare", "true")
	req.Header.Set("x-line-signup-region", "ID")
	req.Header.Set("content-type", "image/png")
	req.ContentLength = int64(len(bytess))

	res, err := client.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	return y.UpdateCoverById(objId, "v")
}

func (y *LineClient) UpdateCoverGroup(to, path string) error {
	objId := RandomStringV2(32)
	fl, err := os.Open(path)
	if err != nil {
		return err
	}
	defer fl.Close()
	of, err := fl.Stat()
	if err != nil {
		return err
	}
	var size int64 = of.Size()
	bytess := make([]byte, size)
	buffer := bufio.NewReader(fl)
	_, err = buffer.Read(bytess)
	if err != nil {
		return err
	}
	nama := filepath.Base(path)
	dataa := fmt.Sprintf(`
    {
      "name": "%s",
      "oid": "%s",
      "type": "image",
      "userid": "%s",
      "ver": "2.0"
    }`, nama, objId, y.Mid)
	sDec := b64.StdEncoding.EncodeToString([]byte(dataa))

	client := &http.Client{}
	req, _ := http.NewRequest("POST", "https://obs-sg.line-apps.com/r/myhome/c/"+objId, bytes.NewBuffer(bytess))
	y.DefaultTimelineHeader(req)
	req.Header.Set("x-obs-params", string(sDec))
	req.Header.Set("X-Line-PostShare", "false")
	req.Header.Set("X-Line-StoryShare", "false")
	req.Header.Set("x-line-signup-region", "ID")
	req.Header.Set("content-type", "image/png")
	req.ContentLength = int64(len(bytess))

	res, err := client.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	return y.UpdateCoverById(objId, to)
}

func (y *LineClient) UpdateCover(path string) error {
	objId := RandomStringV2(32)
	fl, err := os.Open(path)
	if err != nil {
		return err
	}
	defer fl.Close()
	of, err := fl.Stat()
	if err != nil {
		return err
	}
	var size int64 = of.Size()
	bytess := make([]byte, size)
	buffer := bufio.NewReader(fl)
	_, err = buffer.Read(bytess)
	if err != nil {
		return err
	}
	nama := filepath.Base(path)
	dataa := fmt.Sprintf(`
    {
      "name": "%s",
      "oid": "%s",
      "type": "image",
      "userid": "%s",
      "ver": "2.0"
    }`, nama, objId, y.Mid)
	sDec := b64.StdEncoding.EncodeToString([]byte(dataa))

	client := &http.Client{}
	req, _ := http.NewRequest("POST", "https://obs-sg.line-apps.com/r/myhome/c/"+objId, bytes.NewBuffer(bytess))
	y.DefaultTimelineHeader(req)
	req.Header.Set("x-obs-params", string(sDec))
	req.Header.Set("X-Line-PostShare", "true")
	req.Header.Set("X-Line-StoryShare", "true")
	req.Header.Set("x-line-signup-region", "ID")
	req.Header.Set("content-type", "image/png")
	req.ContentLength = int64(len(bytess))

	res, err := client.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	return y.UpdateCoverById(objId, "p")
}

func (p *LineClient) DownloadObjectMsg(msgid string, tipe string) (string, error) {
	client := &http.Client{}
	req, err := http.NewRequest("GET", "https://obs-sg.line-apps.com/talk/m/download.nhn?oid="+msgid, nil)
	if err != nil {
		return "", err
	}
	req.Header.Set("User-Agent", p.UserAgent)
	req.Header.Set("X-Line-Application", p.AppName)
	req.Header.Set("X-Line-Access", p.AuthToken)

	res, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer res.Body.Close()

	directory := "./tmp/"
	_, su := os.Stat(directory)
	if os.IsNotExist(su) {
		errDir := os.MkdirAll("./tmp/", 0755)
		if errDir != nil {
			return "", errDir
		}
	}

	file, err := os.Create("tmp/" + msgid + "." + tipe)
	if err != nil {
		return "", err
	}
	defer file.Close()

	_, err = io.Copy(file, res.Body)
	if err != nil {
		return "", err
	}

	return file.Name(), nil
}

func (y *LineClient) UpdatePictureProfileOLD(path, tipe string) error {
	fl, err := os.Open(path)
	if err != nil {
		return err
	}
	defer fl.Close()
	of, err := fl.Stat()
	if err != nil {
		return err
	}
	var size int64 = of.Size()
	bytess := make([]byte, size)
	buffer := bufio.NewReader(fl)
	_, err = buffer.Read(bytess)
	if err != nil {
		return err
	}
	nama := filepath.Base(path)
	dataa := fmt.Sprintf(`{"name": "%s", "oid": "%s", "type": "image"`, nama, y.Mid)
	if tipe == "v" {
		dataa += `, "ver": "2.0", "cat": "vp.mp4"}`
	} else {
		dataa += `, "ver": "1.0"}`
	}
	sDec := b64.StdEncoding.EncodeToString([]byte(dataa))

	client := &http.Client{}
	req, _ := http.NewRequest("POST", "https://obs-sg.line-apps.com/talk/p/upload.nhn", bytes.NewBuffer(bytess))
	y.DefaultLineHeader(req)
	req.Header.Set("x-obs-params", string(sDec))
	req.ContentLength = int64(len(bytess))

	res, err := client.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	return nil
}

func (cl *LineClient) DefaultLineHeader(req *http.Request) {
	req.Header.Set("user-agent", cl.UserAgent)
	req.Header.Set("x-line-application", cl.AppName)
	req.Header.Set("x-line-access", cl.AuthToken)
	req.Header.Set("x-lal", "en_US")
}

func (y *LineClient) UpdatePictureProfile(path, tipe string) error {
	fl, err := os.Open(path)
	if err != nil {
		return err
	}
	defer fl.Close()
	of, err := fl.Stat()
	if err != nil {
		return err
	}
	var size int64 = of.Size()
	bytess := make([]byte, size)
	buffer := bufio.NewReader(fl)
	_, err = buffer.Read(bytess)
	if err != nil {
		return err
	}
	tim := fmt.Sprintf("%s%d", filepath.Base(path), time.Now().UnixNano()/1000)
	nama := GetMD5Hash(tim)

	dataa := fmt.Sprintf(`{"name": "%s", "quality": "100", "type": "image"`, nama)
	if tipe == "v" {
		dataa += `, "ver": "2.0", "cat": "vp.mp4"}`
	} else {
		dataa += `, "ver": "2.0"}`
	}
	sDec := b64.StdEncoding.EncodeToString([]byte(dataa))

	client := &http.Client{}
	req, _ := http.NewRequest("POST", "https://legy.line-apps.com/oa/r/talk/p/"+y.Mid, bytes.NewBuffer(bytess))
	y.DefaultLineHeader(req)
	req.Header.Set("x-obs-params", string(sDec))
	req.ContentLength = int64(len(bytess))

	res, err := client.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	return nil
}

func (y *LineClient) UpdateVideoProfile(vid string) error {
	fl, err := os.Open(vid)
	if err != nil {
		return err
	}
	defer fl.Close()
	of, err := fl.Stat()
	if err != nil {
		return err
	}
	var size int64 = of.Size()
	bytess := make([]byte, size)
	buffer := bufio.NewReader(fl)
	_, err = buffer.Read(bytess)
	if err != nil {
		return err
	}

	tim := fmt.Sprintf("%s%d", filepath.Base(vid), time.Now().UnixNano()/1000)

	nama := GetMD5Hash(tim)

	dataa := fmt.Sprintf(`{"name": "%s", "ver": "2.0", "type": "video", "cat": "vp.mp4"}`, nama)
	sDec := b64.StdEncoding.EncodeToString([]byte(dataa))

	client := &http.Client{}
	req, _ := http.NewRequest("POST", "https://legy.line-apps.com/oa/r/talk/vp/"+y.Mid, bytes.NewBuffer(bytess))
	y.DefaultLineHeader(req)
	req.Header.Set("x-obs-params", string(sDec))
	req.ContentLength = int64(len(bytess))

	res, err := client.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	return nil
}

func (cl *LineClient) ChangeGroupPicture(groupId, path string) error {
	fl, err := os.Open(path)
	if err != nil {
		return err
	}
	defer fl.Close()
	of, err := fl.Stat()
	if err != nil {
		return err
	}
	var size int64 = of.Size()
	bytess := make([]byte, size)
	buffer := bufio.NewReader(fl)
	_, err = buffer.Read(bytess)
	if err != nil {
		return err
	}

	//dataa := fmt.Sprintf(`{"oid": "%s", "type": "image"}`, groupId)

	client := &http.Client{}
	req, _ := http.NewRequest("POST", "https://obs.line-apps.com/os/g/"+groupId, bytes.NewBuffer(bytess))
	cl.DefaultLineHeader(req)
	//req.Header.Set("x-obs-params", b64.StdEncoding.EncodeToString([]byte(dataa)))
	req.Header.Set("Content-Type", "image/jpg")
	req.ContentLength = int64(len(bytess))
	res, err := client.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	//resp, _ := ioutil.ReadAll(res.Body)
	if res.StatusCode != 201 {
		return errors.New("upload obj failed")
	}
	defer res.Body.Close()
	//return os.Remove(path)
	return err
}

func (p *LineClient) UploadObjTalk(msgid, path, tipe string) (err error) {
	fl, err := os.Open(path)
	if err != nil {
		return err
	}
	defer fl.Close()
	of, err := fl.Stat()
	if err != nil {
		return err
	}
	var size int64 = of.Size()
	bytess := make([]byte, size)
	buffer := bufio.NewReader(fl)
	_, err = buffer.Read(bytess)
	if err != nil {
		return err
	}
	nama := time.Now().Unix()

	dataa := fmt.Sprintf(`{"name": "%d", "size": "%d", "oid": "%s", "type": "%s", "ver": "1.0"}`, nama, of.Size(), msgid, tipe)
	if tipe == "gif" {
		dataa = fmt.Sprintf(`{"name": "%d", "size": "%d", "oid": "%s", "type": "image", "cat": "original", "ver": "1.0"}`, nama, of.Size(), msgid)
	}
	client := &http.Client{}
	req, _ := http.NewRequest("POST", "https://obs-sg.line-apps.com/talk/m/upload.nhn", bytes.NewBuffer(bytess))
	p.DefaultLineHeader(req)
	req.Header.Set("x-obs-params", b64.StdEncoding.EncodeToString([]byte(dataa)))
	req.ContentLength = int64(len(bytess))
	res, err := client.Do(req)
	if err != nil {
		return err
	}
	if res.StatusCode != 201 {
		return err
	}
	defer res.Body.Close()
	//return os.Remove(path)
	return err
}

func SetMention(mids []string) string {
	arr := []*mention{}
	mentionee := "@VHtear"
	textx := ""
	for _, mid := range mids {
		arr = append(arr, &mention{S: strconv.Itoa(len(textx)), E: strconv.Itoa(len(textx) + len(mentionee)), M: mid})
		textx += mentionee + " "
	}
	arrData, _ := json.Marshal(arr)
	return string(arrData)
}

func (cl *LineClient) SendReplyContact(to, id, mid string) error {
	return cl.SendMsg(to, id, "", "contact", "", map[string]string{"mid": mid})
}

func (cl *LineClient) SendReplyGIF(to, id, path string) error {
	fl, err := os.Open(path)
	if err != nil {
		return err
	}
	defer fl.Close()
	of, err := fl.Stat()
	if err != nil {
		return err
	}
	jsonC, err := json.Marshal(map[string]interface{}{
		"category":  "original",
		"extension": "gif",
		"animated":  true,
		"fileSize":  fmt.Sprintf("%d", of.Size()),
	})
	if err != nil {
		return err
	}
	cmt := map[string]string{
		"OBS_CONTENT_INFO": string(jsonC),
	}
	return cl.SendMsg(to, id, path, "image", "", cmt)
}

func (cl *LineClient) SendReplyImage(to, id, path string) error {
	return cl.SendMsg(to, id, path, "image", "", nil)
}
func (cl *LineClient) SendImageWithURL(to, url string) (err error) {
	path, err := cl.downloadFile(url)
	if err != nil {
		return
	}

	err = cl.SendImage(to, path)
	return
}
func (cl *LineClient) SendReplyAudio(to, id, path string) error {
	return cl.SendMsg(to, id, path, "audio", "", nil)
}
func (cl *LineClient) SendReplyImageWithURL(to, id, url string) (err error) {
	path, err := cl.downloadFile(url)
	if err != nil {
		return
	}

	err = cl.SendReplyImage(to, id, path)
	return
}

func (cl *LineClient) SendVideoWithURL(to, url string) (err error) {
	path, err := cl.downloadFile(url)
	if err != nil {
		return
	}

	err = cl.SendVideo(to, path)
	return
}

func (cl *LineClient) SendReplyVideoWithURL(to, id, url string) (err error) {
	path, err := cl.downloadFile(url)
	if err != nil {
		return
	}

	err = cl.SendReplyVideo(to, id, path)
	return
}

func (cl *LineClient) SendAudioWithURL(to, url string) (err error) {
	path, err := cl.downloadFile(url)
	if err != nil {
		return
	}

	err = cl.SendAudio(to, path)
	return
}

func (cl *LineClient) SendReplyAudioWithURL(to, id, url string) (err error) {
	path, err := cl.downloadFile(url)
	if err != nil {
		return
	}

	err = cl.SendReplyAudio(to, id, path)
	return
}

func (cl *LineClient) SendGIFWithURL(to, url string) (err error) {
	path, err := cl.downloadFile(url)
	if err != nil {
		return
	}

	err = cl.SendGIF(to, path)
	return
}

func (cl *LineClient) SendImage(to, path string) error {
	return cl.SendMsg(to, "", path, "image", "", nil)
}
func (cl *LineClient) SendVideo(to, path string) error {
	cmt := map[string]string{
		"VIDLEN":   "6000",
		"DURATION": "6000",
		//"PREVIEW_URL": "https://cdn3.iconfinder.com/data/icons/unicons-vector-icons-pack/32/youtube-512.png",
	}
	return cl.SendMsg(to, "", path, "video", "", cmt)
}
func (cl *LineClient) SendAudio(to, path string) error {
	return cl.SendMsg(to, "", path, "audio", "", nil)
}

func (cl *LineClient) SendGift(to, productId, productType string) error {
	if productType != "theme" && productType != "sticker" {
		return errors.New("invalid product type")
	}
	pid := "STKPKGID"
	if productType == "theme" {
		pid = "PRDID"
	}
	cmt := map[string]string{
		"MSGTPL":  strconv.Itoa(rand.Intn(12)),
		"PRDTYPE": strings.ToUpper(productType),
		pid:       productId,
	}
	return cl.SendMsg(to, "", "", "gift", "", cmt)
}

func (cl *LineClient) SendGIF(to, path string) error {
	fl, err := os.Open(path)
	if err != nil {
		return err
	}
	defer fl.Close()
	of, err := fl.Stat()
	if err != nil {
		return err
	}
	jsonC, err := json.Marshal(map[string]interface{}{
		"category":  "original",
		"extension": "gif",
		"animated":  true,
		"fileSize":  fmt.Sprintf("%d", of.Size()),
	})
	if err != nil {
		return err
	}
	cmt := map[string]string{
		"OBS_CONTENT_INFO": string(jsonC),
	}
	return cl.SendMsg(to, "", path, "image", "", cmt)
}
func (cl *LineClient) SendReplyGift(to, id, productId, productType string) error {
	if productType != "theme" && productType != "sticker" {
		return errors.New("invalid product type")
	}
	pid := "STKPKGID"
	if productType == "theme" {
		pid = "PRDID"
	}
	cmt := map[string]string{
		"MSGTPL":  strconv.Itoa(rand.Intn(12)),
		"PRDTYPE": strings.ToUpper(productType),
		pid:       productId,
	}
	return cl.SendMsg(to, id, "", "gift", "", cmt)
}

func (cl *LineClient) SendReplyGIFWithURL(to, id, url string) (err error) {
	path, err := cl.downloadFile(url)
	if err != nil {
		return
	}

	err = cl.SendReplyGIF(to, id, path)
	return
}
func (cl *LineClient) SendFile(to, path string) error {
	fl, err := os.Open(path)
	if err != nil {
		return err
	}
	defer fl.Close()
	of, err := fl.Stat()
	if err != nil {
		return err
	}
	cmt := map[string]string{
		"FILE_SIZE": fmt.Sprintf("%d", of.Size()),
		"FILE_NAME": filepath.Base(path),
	}
	return cl.SendMsg(to, "", path, "file", "", cmt)
}

func (cl *LineClient) SendReplyFile(to, id, path string) error {
	fl, err := os.Open(path)
	if err != nil {
		return err
	}
	defer fl.Close()
	of, err := fl.Stat()
	if err != nil {
		return err
	}
	cmt := map[string]string{
		"FILE_SIZE": fmt.Sprintf("%d", of.Size()),
		"FILE_NAME": filepath.Base(path),
	}
	return cl.SendMsg(to, id, path, "file", "", cmt)
}

func (cl *LineClient) SendReplyVideo(to, id, path string) error {
	cmt := map[string]string{
		"VIDLEN":      "6000",
		"DURATION":    "6000",
		"PREVIEW_URL": "https://cdn3.iconfinder.com/data/icons/unicons-vector-icons-pack/32/youtube-512.png",
	}
	return cl.SendMsg(to, id, path, "video", "", cmt)
}

func (cl *LineClient) SendFileWithURL(to, url string) (err error) {
	path, err := cl.downloadFile(url)
	if err != nil {
		return
	}

	err = cl.SendFile(to, path)
	return
}

func (cl *LineClient) SendReplyFileWithURL(to, id, url string) (err error) {
	path, err := cl.downloadFile(url)
	if err != nil {
		return
	}

	err = cl.SendReplyFile(to, id, path)
	return
}

func SetHeader(z *http.Request) {
	z.Header.Set("user-agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36")
	z.Header.Set("authority", "scrapeme.live")
	z.Header.Set("upgrade-insecure-requests", "1")
	z.Header.Set("dnt", "1")
	z.Header.Set("accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9")
	z.Header.Set("sec-fetch-mode", "navigate")
	z.Header.Set("sec-fetch-user", "?1")
	z.Header.Set("sec-fetch-dest", "document")
	z.Header.Set("accept-language", "en-GB,en-US;q=0.9,en;q=0.8")
}

func (p *LineClient) downloadFile(url string) (string, error) {
	asu := fmt.Sprintf("%v", time.Now().Nanosecond())
	res, err := http.Get(url)
	if err != nil {
		fmt.Println(err)
	}
	defer res.Body.Close()
	var tp string
	if strings.Contains(res.Header.Get("Content-Type"), "image") {
		tp = "png"
	} else if strings.Contains(res.Header.Get("Content-Type"), "video") {
		tp = "mp4"
	} else if strings.Contains(res.Header.Get("Content-Type"), "audio") {
		tp = "mp3"
	} else {
		tp = "bin"
	}
	directory := "./tmp/"
	_, su := os.Stat(directory)
	if os.IsNotExist(su) {
		errDir := os.MkdirAll("./tmp/", 0755)
		if errDir != nil {
			fmt.Println(su)
		}
	}
	file, err := os.Create("tmp/" + asu + "." + tp)
	if err != nil {
		return "", err
	}
	io.Copy(file, res.Body)
	file.Close()
	return file.Name(), nil
}

func (p *LineClient) DownloadFileASU(url string) (string, error) {
	asu := fmt.Sprintf("%v", time.Now().Nanosecond())
	req, _ := http.NewRequest("GET", url, nil)
	SetHeader(req)
	y := &http.Client{}
	res, err := y.Do(req)
	if err != nil {
		return "", err
	}
	defer res.Body.Close()
	var tp string
	if strings.Contains(res.Header.Get("Content-Type"), "image") {
		tp = "png"
	} else if strings.Contains(res.Header.Get("Content-Type"), "video") {
		tp = "mp4"
	} else if strings.Contains(res.Header.Get("Content-Type"), "audio") {
		tp = "mp3"
	} else {
		tp = "bin"
	}
	directory := "./tmp/"
	_, su := os.Stat(directory)
	if os.IsNotExist(su) {
		errDir := os.MkdirAll("./tmp/", 0755)
		if errDir != nil {
			fmt.Println(su)
		}
	}
	file, err := os.Create("tmp/" + asu + "." + tp)
	if err != nil {
		return "", err
	}
	io.Copy(file, res.Body)
	file.Close()
	return file.Name(), nil
}
