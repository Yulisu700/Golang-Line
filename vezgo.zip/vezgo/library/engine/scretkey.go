package engine

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"net/url"
	"crypto/hmac"
	"crypto/sha1"
	"strings"
	"time"
	"golang.org/x/crypto/curve25519"
)

func parseAuthKey(key string) (string, string) {
	splited := strings.Split(key, ":")
	return splited[0], splited[1]
}

func SignHmacSha1(key, msg []byte) []byte {
	mac := hmac.New(sha1.New, key)
	mac.Write(msg)
	return mac.Sum(nil)
}

func generateIOSToken(authKey string) string {
	mid, key := parseAuthKey(authKey)
	iat := base64.StdEncoding.EncodeToString([]byte(fmt.Sprintf("iat: %v\n", time.Now().Unix()*60))) + "."
	keyEnc, _ := base64.StdEncoding.DecodeString(key)
	return mid + ":" + iat + "." + base64.StdEncoding.EncodeToString(SignHmacSha1(keyEnc, []byte(iat)))
}

func generatePrivateKey() (*[32]byte, error) {
	privateKey := new([32]byte)
	_, err := rand.Read(privateKey[:])
	if err != nil {
		return nil, err
	}
	return privateKey, nil
}

func generatePublicKey(privateKey *[32]byte) (*[32]byte, error) {
	var publicKey [32]byte
	curve25519.ScalarBaseMult(&publicKey, privateKey)
	return &publicKey, nil
}

func createSqrSecret(base64Only bool) (*[32]byte, string, error) {
	privateKey, err := generatePrivateKey()
	if err != nil {
		return nil, "", err
	}

	publicKey, err := generatePublicKey(privateKey)
	if err != nil {
		return nil, "", err
	}

	encodedPublicKey := base64.StdEncoding.EncodeToString(publicKey[:])
	encodedPublicKeyURL := url.QueryEscape(encodedPublicKey)

	version := 1

	if base64Only {
		return privateKey, encodedPublicKey, nil
	}

	secretURL := fmt.Sprintf("?secret=%s&e2eeVersion=%d", encodedPublicKeyURL, version)
	return privateKey, secretURL, nil
}

func CreateSqrSecret() string {
	_, secretURL, err := createSqrSecret(false)
	if err != nil {
		fmt.Println("Error:", err)
		return ""
	}
	// 	fmt.Printf("Private Key: %x\n", privateKey)
	// 	fmt.Printf("Secret URL: %s\n", secretURL)
	return secretURL
}

func CreateSecretKeys() ([]byte, []byte, error) {
	var privateKey [32]byte
	_, err := rand.Read(privateKey[:])
	if err != nil {
		return nil, nil, err
	}

	var publicKey [32]byte
	curve25519.ScalarBaseMult(&publicKey, &privateKey)

	return privateKey[:], publicKey[:], nil
}

func ConvertStringByte(hexString string) []byte {
	byteData, _ := hex.DecodeString(hexString)
	return byteData
}
