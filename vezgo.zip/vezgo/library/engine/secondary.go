package engine

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"../LineThrift"
	"github.com/slayer/autorestart"
	"github.com/tidwall/gjson"
	"io/ioutil"
	"os"
)

var (
	baseurl = "https://secondaryv3.vhtear.com"
	baseurlJV = "https://jvrestapi.site"
)

type SecondaryMetaData struct {
	E2EEVersion       string `json:"e2eeVersion"`
	EncryptedKeyChain string `json:"encryptedKeyChain"`
	ErrorCode         string `json:"errorCode"`
	HashKeyChain      string `json:"hashKeyChain"`
	KeyID             string `json:"keyId"`
	PublicKey         string `json:"publicKey"`
}

type LoginRequest struct {
	Login1     *LineThrift.SecondaryQrCodeLoginServiceClient
	LoginCheck *LineThrift.SecondaryQrCodeLoginServiceClient
	SessionID  string
}

func (cl *LineClient) WaitForQrCodeVerified() {

}

func (cl *LineClient) VerifyCertificate(certificate string) (*LineThrift.VerifyCertificateResponse, error) {
	// req := LineThrift.NewVerifyCertificateRequest()
	// req.Certificate = certificate
	// req.AuthSessionId = cl.QrLogin.SessionID
	// res, err := cl.QrLogin.Login1.VerifyCertificate(context.TODO(), req)
	return nil, nil
}

func (cl *LineClient) CreatePinCode() (string, error) {
	return "", nil
}

func (cl *LineClient) WaitForInputPinCode() {
}

func (cl *LineClient) QrCodeLoginV2ForSecure(SysName, Nonce string) (res *LineThrift.QrCodeLoginV2Response, err error) {
	//qrCodeLoginV2ForSecure
	// req := LineThrift.NewQrCodeLoginV2ForSecureRequest()
	// req.AuthSessionId = cl.QrLogin.SessionID
	// req.SystemName = SysName
	// req.Nonce = Nonce
	// req.ModelName = "VHTEAR-2024"
	// req.AutoLoginIsRequired = true
	// callback, err := cl.QrLogin.Login1.QrCodeLoginV2ForSecure(context.TODO(), req)
	return res, err
}

// func (cl *LineClient) CreateQrCode() (string, string, *[32]byte, error) {
// 	req := LineThrift.NewCreateQrCodeForSecureRequest()
// 	req.AuthSessionId = cl.qrLogin.sessionID
// 	res, err := cl.qrLogin.login1.CreateQrCodeForSecure(context.TODO(), req)
// 	// FIXME return res.CallbackUrl + createSecret(), err
// 	scret, pre := CreateSqrSecret()
// 	return res.CallbackUrl + pre, res.Nonce, scret, err
// }

// TOKEN VERSION 3 API
func (client *LineClient) LoginVersionV2(to, sender string) {
	refreshToken := ""
	accessToken := ""
	cert := ""
	pubKey := ""
	privKey := ""
	keyId := int64(1)
	e2eeVersion := ""
	cert = gjson.Get(Settings, "Selfbot.CertificateLogin."+sender).String()
	data := map[string]interface{}{
		"appname": SECONDARY_DEVICE3,
		"cert":    cert,
	}
	fullurl := baseurl + "/api/loginqr"
	resp, _ := RequestApi("POST", fullurl, data)
	barcode := gjson.Get(string(resp), "result.barcode").String()
	//url := gjson.Get(string(resp), "result.url").String()
	session := gjson.Get(string(resp), "result.session").String()
	client.SendImageWithURL(to, barcode)
	fmt.Println(barcode)
	client.SendMention(to, "Hey @! Scan this QR code on your LINE for smartphone in 2 minutes. \n􀔃􀄎ข้อความ􏿿 https://line.me/R/au/lgn/sq/scan", []string{sender})
	if cert == "" {
		data = map[string]interface{}{
			"session": session,
		}
		fullurl = baseurl + "/api/getpincode"
		resp, _ = RequestApi("POST", fullurl, data)
		pinmessage := gjson.Get(string(resp), "result.pinmessage").String()
		fmt.Println(pinmessage)
		client.SendText(to, pinmessage)
		data = map[string]interface{}{
			"session": session,
		}
		fullurl = baseurl + "/api/gettokenv3"
		resp, _ = RequestApi("POST", fullurl, data)
		refreshToken = gjson.Get(string(resp), "result.refreshToken").String()
		accessToken = gjson.Get(string(resp), "result.accessToken").String()
		cert = gjson.Get(string(resp), "result.cert").String()
		pubKey = gjson.Get(string(resp), "result.e2eeKeyInfo.pubKey").String()
		privKey = gjson.Get(string(resp), "result.e2eeKeyInfo.privKey").String()
		keyId = gjson.Get(string(resp), "result.e2eeKeyInfo.keyId").Int()
		e2eeVersion = gjson.Get(string(resp), "result.e2eeKeyInfo.e2eeVersion").String()
	} else {
		data = map[string]interface{}{
			"session": session,
		}
		fullurl = baseurl + "/api/gettokenv3"
		resp, _ = RequestApi("POST", fullurl, data)
		refreshToken = gjson.Get(string(resp), "result.refreshToken").String()
		accessToken = gjson.Get(string(resp), "result.accessToken").String()
		cert = gjson.Get(string(resp), "result.cert").String()
		pubKey = gjson.Get(string(resp), "result.e2eeKeyInfo.pubKey").String()
		privKey = gjson.Get(string(resp), "result.e2eeKeyInfo.privKey").String()
		keyId = gjson.Get(string(resp), "result.e2eeKeyInfo.keyId").Int()
		e2eeVersion = gjson.Get(string(resp), "result.e2eeKeyInfo.e2eeVersion").String()
	}
	version, _ := strconv.Atoi(e2eeVersion)
	UpdateSetString("Selfbot.RefreshToken."+sender, refreshToken)
	UpdateSetString("Selfbot.CertificateLogin."+sender, cert)
	UpdateSetString("Selfbot.AuthToken."+sender, accessToken)
	UpdateSetString("Selfbot.Mid."+sender, sender)
	SaveE2EESelfKeyData(sender, pubKey, privKey, int(keyId), version)
	vez := SettingConnection(LINE_HOST_DOMAIN, accessToken, SECONDARY_DEVICE3, 0)
	vez.AllowLiff()
	client.SendMessage(to, "Login with QRcode allowed\n\nHeader: "+vez.AppName)
	autorestart.RestartByExec()
}


func RequestApi(metode string, url string, data map[string]interface{}) (string, string) {
	payload, err := json.Marshal(data)
	if err != nil {
		fmt.Println("Error:", err)
	}
	req, err := http.NewRequest(metode, url, bytes.NewBuffer(payload))
	if err != nil {
		fmt.Println("Error:", err)
	}
	req.Header.Set("Content-Type", "application/json")
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		fmt.Println("Error:", err)
	}
	defer resp.Body.Close()
	body := new(bytes.Buffer)
	_, err = body.ReadFrom(resp.Body)
	if err != nil {
		fmt.Println("Error:", err)
	}
	fmt.Println("Response:", resp.Status)
	return body.String(), resp.Status
}

func (client *LineClient) LoginEmailV2(to, sender string) {
	emailx := gjson.Get(Settings, "Selfbot.Email."+sender).String()
	passx := gjson.Get(Settings, "Selfbot.Password."+sender).String()
	data1 := map[string]interface{}{
		"appname": SECONDARY_DEVICE3,
		"sysname": "WINDOWS",
		"apikey": "ANGGA203",
		"email": emailx,
		"passwd": passx,
	}
	fullurl1 := baseurlJV + "/lineemailV2"
	resp1, _ := RequestApi("POST", fullurl1, data1)
	pinCode := gjson.Get(string(resp1), "result.pin").String()
	client.SendMention(to, "Hey @! Pincode: "+pinCode, []string{sender})
	data2 := map[string]interface{}{
		"apikey": "ANGGA203",
	}
	fullurl2 := baseurlJV + "/etokenV2"
	resp2, _ := RequestApi("POST", fullurl2, data2)
	accessToken := gjson.Get(string(resp2), "result.authToken").String()
	cert := gjson.Get(string(resp2), "result.cert").String()
	UpdateSetString("Selfbot.AuthToken."+sender, accessToken)
	UpdateSetString("Selfbot.Mid."+sender, sender)
	UpdateSetString("Selfbot.CertificateLogin."+sender, cert)
	fox := SettingConnection(LINE_HOST_DOMAIN, accessToken, SECONDARY_DEVICE3, 0)
	fox.AllowLiff()
	client.SendMessage(to, "Login with Email success\n\nHeader: "+fox.AppName)
}

const (
	baseURL   = "https://jvrestapi.site"
	sysname   = "LINEBOT"
	apikey    = "ANGGA203"
	cert      = "" 
	proxy     = ""
	logemail  = "/lineemailV3"
	etoken    = "/etokenV3"
	e2eeloc   = "asu"
)

type Response struct {
	Status int `json:"status"`
	Result struct {
		AuthToken    string `json:"authToken"`
		Cert         string `json:"cert"`
		Pin          string `json:"pin"`
		KeyId        string `json:"keyId"`
		PrivKey      string `json:"privKey"`
		PubKey       string `json:"pubKey"`
		E2eeVersion  string `json:"e2eeVersion"`
		RefreshToken string `json:"refreshToken"`
	} `json:"result"`
}

func (client *LineClient) LoginEmailV3(to, sender string) {
	email     := gjson.Get(Settings, "Selfbot.Email."+sender).String()
	passwd    := gjson.Get(Settings, "Selfbot.Password."+sender).String()
	if cert != "" {
		params := map[string]string{
			"appname": SECONDARY_DEVICE3, "sysname": sysname, "apikey": apikey,
			"cert": cert, "proxy": proxy, "email": email, "passwd": passwd,
		}
		reqtoken, err := sendPostRequest(baseURL+logemail, params)
		if err != nil {
			fmt.Println("Error:", err)
			return
		}
		if reqtoken.Status == 200 {
			authToken := reqtoken.Result.AuthToken
			certificate := reqtoken.Result.Cert
			err = ioutil.WriteFile(fmt.Sprintf("%s.crt", email), []byte(certificate), 0644)
			if err != nil {
				fmt.Println("Error writing certificate:", err)
				return
			}
			fmt.Printf("Auth Token: %s//nCertificate: %s//n", authToken, certificate)
		}
	} else {
		params1 := map[string]string{
			"appname": SECONDARY_DEVICE3, "sysname": sysname, "apikey": apikey,
			"cert": cert, "proxy": proxy, "email": email, "passwd": passwd,
		}
		reqpin, err := sendPostRequest(baseURL+logemail, params1)
		if err != nil {
			fmt.Println("Error:", err)
			return
		}
		if reqpin.Status == 200 {
			pin := reqpin.Result.Pin
			client.SendMention(to, "Hey @! Pincode: "+pin, []string{sender})
			fmt.Printf("Input this PIN code '%s' on your LINE for smartphone in 2 minutes.//n", pin)
			params2 := map[string]string{"apikey": apikey}
			reqtoken, err := sendPostRequest(baseURL+etoken, params2)
			if err != nil {
				fmt.Println("Error:", err)
				return
			}
			if reqtoken.Status == 200 {
				authToken := reqtoken.Result.AuthToken
				refreshToken := reqtoken.Result.RefreshToken
				certificate := reqtoken.Result.Cert
				err = ioutil.WriteFile(fmt.Sprintf("%s.crt", email), []byte(certificate), 0644)
				if err != nil {
					fmt.Println("Error writing certificate:", err)
					return
				}
				ret := ""
				if reqtoken.Result.KeyId != "" {
					keyId := reqtoken.Result.KeyId
					privKey := reqtoken.Result.PrivKey
					pubKey := reqtoken.Result.PubKey
					e2eeVer := reqtoken.Result.E2eeVersion
					ret += fmt.Sprintf("\n Private ID: %s", keyId)
					ret += fmt.Sprintf("\n Private Key: %s", privKey)
					ret += fmt.Sprintf("\n Public Key: %s", pubKey)
					ret += fmt.Sprintf("\n E2EE VER: %s", e2eeVer)
					keyidx, _ := strconv.Atoi(keyId)
					versix, _ := strconv.Atoi(e2eeVer)
					_, err := os.Stat(fmt.Sprintf("./database/e2ee/%s.json", client.Mid))
                   if err != nil {
                       data := map[string]interface{}{
                           "publicKey": pubKey,
                           "privateKey": privKey,
                           "keyId": keyId,
                           "version": 1,
                        }
                        jsonData, err := json.MarshalIndent(data, "", "    ")
                        if err != nil {
                            fmt.Printf("could not marshal json: %s\n", err)
                            return
                         }
                         os.WriteFile(fmt.Sprintf("./database/e2ee/%s.json", client.Mid), jsonData, 0644)
                     }
					 SaveE2EESelfKeyData(sender, pubKey, privKey, keyidx, versix)
				}
				res := fmt.Sprintf("\n Auth Token: %s\nRefreshToken: %s\nCertificate: %s", authToken, refreshToken, certificate)
				res += ret
				fmt.Println(res)
				UpdateSetString("Selfbot.AuthToken."+sender, authToken)
				UpdateSetString("Selfbot.Mid."+sender, sender)
				UpdateSetString("Selfbot.CertificateLogin."+sender, certificate)
				fox := SettingConnection(LINE_HOST_DOMAIN, authToken, SECONDARY_DEVICE3, 0)
				fox.AllowLiff()
				client.SendMessage(to, "Login with Email success\n\nHeader: "+fox.AppName)
				autorestart.RestartByExec()
			}
		}
	}
}

func sendPostRequest(url string, params map[string]string) (Response, error) {
	client := &http.Client{}
	req, err := http.NewRequest("POST", url, nil)
	if err != nil {
		return Response{}, err
	}
	q := req.URL.Query()
	for key, value := range params {
		q.Add(key, value)
	}
	req.URL.RawQuery = q.Encode()
	resp, err := client.Do(req)
	if err != nil {
		return Response{}, err
	}
	defer resp.Body.Close()
	var response Response
	err = json.NewDecoder(resp.Body).Decode(&response)
	if err != nil {
		return Response{}, err
	}
	return response, nil
}	