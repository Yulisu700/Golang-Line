package engine


/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/



import (
	//"bytes"
	"fmt"
	//"io/ioutil"
	//"net/http"
	"os"
	"os/exec"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
	"../LineThrift"
	//"../hashmap"
	"runtime"
	"github.com/shirou/gopsutil/mem"
	"github.com/shirou/gopsutil/host"
	"github.com/opalmer/check-go-version/api"
	"github.com/pmezard/go-difflib/difflib"
	"github.com/slayer/autorestart"
	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
	"math/rand"
	"slices"
	//"golang.org/x/crypto/ssh"
)

func LINEmsg(client *LineClient, op *LineThrift.Operation, MentionMsg []string) {
	defer VHrecover("Message  Crash")
	var Mid = client.Mid
	var cmds = []string{}
	op.Message = client.DecryptE2EEMessage(op.Message)
	msg := op.Message
	sender := msg.From_
	var to string
	var Print = fmt.Println
	Nosuggest = false
	grades := Grade(to, msg.From_)
	var room *LineRoom
	var bks = []*LineClient{}
	if _, ok := Commandss.Get(op.CreatedTime); ok {
		return
	} else {
		Commandss.Set(op.CreatedTime, client)
	}
	if time.Now().Sub(timeabort) >= 60*time.Second {
		abort()
	}

	if msg.ToType == 0 {
		if sender != Mid {
			to = sender
		} else {
			to = msg.To
		}
		room = nil
	} else if msg.ToType == 1 {
		to = msg.To
		room = nil
	} else if msg.ToType == 2 {
		to = msg.To
		room = GetRoom(to)
		bks = room.Client
		if len(bks) == 0 {
			GetSquad(client, to)
			room = GetRoom(to)
			bks = room.Client
		}
		sort.Slice(room.Ava, func(i, j int) bool {
			return room.Ava[i].Client.KickPoint < room.Ava[j].Client.KickPoint
		})
	}
	caca := []int{}

	for _, x := range bks {
		caca = append(caca, x.Num)
	}
	sort.Ints(caca)
	bk := []*LineClient{}
	for _, n := range caca {
		bk = append(bk, Client[n])
	}
	if Antitag && MemUser(to, msg.From_) {
		n := 0
		for _, c := range MentionMsg {
			if Contains(Squad, c) {
				n++
			}
		}
		if n >= 5 {
			if client.Limiter {
				client.DeleteOtherFromChat(to, msg.From_)
			} else {
				for _, cl := range bk {
					if cl.Limiter {
						cl.DeleteOtherFromChat(to, msg.From_)
						break
					}
				}
			}
		}
	}
	if msg.RelatedMessageId != "" {
		MentionMsg = getreply(op)
	}
	if upimage && len(MentionMsg) != 0 && grades < 2 {
		changepic = []*LineClient{}
		for _, ym := range MentionMsg {
			if Contains(Squad, ym) {
				idx := IndexOf(Squad, ym)
				changepic = append(changepic, Client[idx])
			}
		}
		if len(changepic) != 0 {
			client.SendMessage(to, "Send your image.")
		}
		cpic = true
		upimage = false
		timeabort = time.Now()
	}
	if upcover && len(MentionMsg) != 0 && grades < 2 {
		changepic = []*LineClient{}
		for _, ym := range MentionMsg {
			if Contains(Squad, ym) {
				idx := IndexOf(Squad, ym)
				changepic = append(changepic, Client[idx])
			}
		}
		if len(changepic) != 0 {
			client.SendMessage(to, "Send your image.")
		}
		ccover = true
		upcover = false
		timeabort = time.Now()
	}
	if len(changename) != 0 && upname && len(MentionMsg) != 0 && grades < 2 {
		for _, ym := range MentionMsg {
			if Contains(Squad, ym) {
				idx := IndexOf(Squad, ym)
				cl := Client[idx]
				cl.UpdateProfileName(changename)
				cl.Name = changename
				cl.SendMessage(to, "Displayname updated to "+changename)
			}
		}
		upname = false
		changename = ""
	}
	zx := msg.ContentMetadata
	vok, cook := zx["REPLACE"]
	if Contains(Blacklist, msg.From_) {
		for _, cl := range bk {
			if room.Act(cl) && cl.Ready {
				cl.DeleteOtherFromChat(to, msg.From_)
				return
			}
		}
	}

	if msg.ContentType == 7 || cook {
		var ids []string
		var pids []string
		if grades < 4 {
			if cook {
				ress := gjson.Get(vok, "sticon")
				mp := ress.Map()
				yo := mp["resources"]
				vls := yo.Array()
				for _, vl := range vls {
					mm := vl.Map()
					pids = append(pids, mm["productId"].String())
					ids = append(ids, mm["sticonId"].String())
				}
			} else {
				ids = []string{zx["STKID"]}
				pids = []string{zx["STKPKGID"]}
			}
			if ustk {
				UpStk(pids[0], ids[0])
				ustk = false
				client.SendMessage(to, fmt.Sprintf("Sticker command %s saved.", cstk))
			} else {
				tk := GetStk(ids, pids)
				if tk != "" {
					msg.Text = Rname + tk
					msg.ContentType = 0
				}
			}
		}
	}
	if msg.ContentType == 0 {
		var sname = "."
		var rname = "/"
		var txt string
		silent = false
		Default = false
		var pesan = strings.ToLower(msg.Text)
		pesan = StripPrefix(pesan)
		if pesan == "rabu" {
			client.SendMessage(to, "Assalamulaikum,,jangan lupa hari ini pke seragam y,,,makasih kekompakan y🙏🙏🙏")
			client.SendImageWithLiff(to, "https://i.ibb.co.com/R6pDKw5/1726716547616.jpg")
		}
		if pesan == "jumat" {
			client.SendMessage(to, "Assalamulaikum...jangan lupa malam ini yasinan terimakasih 🙏🙏🙏")
			client.SendImageWithLiff(to, "https://i.ibb.co.com/RChhvfV/1726716258958.jpg")
		}
		if Media == true {
			client.AutoDownloader(to, msg.Text, "")
		}
		/*if len(op.Message.Chunks) != 0 {
			vezza := client.DecryptE2EEMessage(op.Message)
			fmt.Println(vezza)
			pesan = StripPrefix(vezza)
			msg.Text = vezza
		}*/
		var Tcm = []string{}
		grades := Grade(to, msg.From_)
		if crashconfirm && grades < 2 {
			anu := StripOut(pesan)
			if Contains([]string{"yes", "y", "ok"}, anu) {
				var wg sync.WaitGroup
				var ts = ""
				for _, target := range crashtarget {
					prs, _ := client.GetContact(target)
					name := prs.DisplayName
					ts += fmt.Sprintf("\n  %s", name)
					no := 0
					for _, cl := range Client {
						if no >= 4 {
							no = 0
						}
						tx := crash[no]
						wg.Add(1)
						go func(cl *LineClient, tx string, tar string) {
							i := 0
							for ; i < counter; i++ {
								cl.SendMessage(tar, tx)
								time.Sleep(delayed)
							}
							wg.Done()
						}(cl, tx, target)
						no++
					}
				}
				tss := fmt.Sprintf("Sending %v crash message to target:\n", counter)
				client.SendMessage(to, tss+ts)
				logAccess(client, to, msg.From_, "crash", crashtarget, int32(int32(msg.ToType)))
				crashconfirm = false
				crashtarget = []string{}
				crashwait = true
				wg.Wait()
				crashwait = false
				tss = fmt.Sprintf("crash message has been sent to:\n")
				client.SendMessage(to, tss+ts)
				return
			} else if Contains([]string{"no", "n", "abort"}, anu) {
				crashconfirm = false
				crashtarget = []string{}
				client.SendMessage(to, "Crash aborted.")
			}
		}

		go checkWb(to, pesan, msg.From_)
		if strings.Contains(pesan, "/ti/g") {
			if grades < 3 && JoinTicket {
				regex, _ := regexp.Compile(`(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?`)
				links := regex.FindAllString(msg.Text, -1)
				tickets := []string{}
				gids, _ := client.GetGroupIdsJoined()
				for _, link := range links {
					if !Contains(tickets, link) {
						tickets = append(tickets, link)
					}
				}
				for _, tick := range tickets {
					tuk := strings.Split(tick, "/")
					ntk := len(tuk) - 1
					ticket := tuk[ntk]
					acc, err := client.FindGroupByTicket(ticket)
					if err != nil {
						Print(err)
						continue
					} else {
						ids := acc.ChatMid
						if Contains(gids, ids) {
							continue
						} else {
							et := client.AcceptGroupInvitationByTicket(ids, ticket)
							if et != nil {
								Print(et)
							}
						}
					}
				}
			}
		}
		if strings.HasPrefix(pesan, rname) || strings.HasPrefix(pesan, sname) {
			if grades < 3 {
				if strings.Contains(msg.Text, "r:") {
					msg.Text = strings.Replace(msg.Text, rname, "", 1)
					msg.Text = strings.Replace(msg.Text, sname, "", 1)
					msg.Text = strings.TrimPrefix(msg.Text, " ")
					msg.Text = strings.Replace(msg.Text, "r:", "", 1)
					nums := strings.Split(msg.Text, " ")
					st := nums[0]
					msg.Text = strings.Replace(msg.Text, st, "", 1)
					msg.Text = rname + msg.Text
					pesan = strings.ToLower(msg.Text)
					numb, _ := strconv.Atoi(st)
					numb = numb - 1
					var gr []string
					if len(tempgroup) == 0 {
						gr, _ = client.GetGroupIdsJoined()
					} else {
						gr = tempgroup
					}
					to = gr[numb]
					room = GetRoom(to)
					bks = room.Client
					if len(bks) == 0 {
						GetSquad(client, to)
						room = GetRoom(to)
						bks = room.Client
					}
					caca = []int{}

					for _, x := range bks {
						caca = append(caca, x.Num)
					}
					sort.Ints(caca)
					bk = []*LineClient{}
					for _, n := range caca {
						bk = append(bk, Client[n])
					}
					com := gettxt(pesan, rname, sname, Mid, MentionMsg)
					cmds = getcmd(com)
					name, _ := client.GetGroupName(to)
					as := fmt.Sprintf("Command %s sendto group '%s'", com, name)
					client.SendMessage(msg.To, as)
				}
			}
		}
		if grades < 4 {
			ccc, ditag := squadMention(MentionMsg)
			if ccc != nil {
				client = ccc
			}
			if pesan == "rname" {
				var ca string
				if rname != "" {
					ca = rname
				} else {
					ca = "not defined"
				}
				client.SendMessage(to, ca)
			} else if pesan == "moci" {
					bt, _ := client.GetChats(to)
					memlist := bt.Chats[0].Extra.GroupExtra.MemberMids
					i := 1
					ta := false
					no := 1
					tx := ""
					tag := []string{}
					for v := range memlist {
						cancel := string(v)
						if !ta {
							tx += "Tag All Member:\n"
							ta = true
						}
						if i < 20 {
							if no == 21 || no == 41 || no == 61 || no == 81 || no == 101 || no == 121 || no == 141 || no == 161 || no == 181 || no == 201 || no == 221 || no == 241 || no == 261 {
								tx += fmt.Sprintf("%v. @!", no)
							} else {
								tx += fmt.Sprintf("\n%v. @!", no)
							}
							no += 1
							i += 1
							tag = append(tag, cancel)
						} else {
							tag = append(tag, cancel)
							tx += fmt.Sprintf("\n%v. @!", no)
							client.SendMention(to, tx, tag)
							tag = []string{}
							tx = ""
							i = 1
							no += 1
						}
					}
					if len(tag) != 0 {
						tx += "\n\n" + TeamName
						client.SendMention(to, tx, tag)
					}
			} else if pesan == "sname" {
				if sname != "" {
					client.SendMessage(to, sname)
				} else {
					client.SendMessage(to, "not defined")
				}
			} else if pesan == rname || pesan == sname {
				client.SendMessage(to, MsgRespon)
			} else if strings.HasPrefix(pesan, rname) || strings.HasPrefix(pesan, sname) || ditag {
				cmds = getcmd(gettxt(pesan, rname, sname, Mid, MentionMsg))
			}
			suggestword = cmds
			if Suggest == 2 {
				pesan, cmds = autoCorrect(gettxt(pesan, rname, sname, Mid, MentionMsg), cmds)
			}
			for _, mcom := range cmds {
				txt = mcom
				/*master command*/
				if Contains(Creator, msg.From_) || Contains(Resel, msg.From_) {
					Pangkat = "creator"
					if strings.HasPrefix(txt, GetCommand(grades, "bring")) {
						nums := strings.Split(txt, GetCommand(grades, "bring"))
						st := nums[1]
						st = StripOut(st)
						numb, _ := strconv.Atoi(st)
						client.GetSquad(to)
						all := []string{}
						room := GetRoom(to)
						cuk := room.Client
						for _, x := range Client {
							if len(all) < numb {
								if !InArrayCl(cuk, x) && !InArrayCl(KickBans, x) && !InArrayCl(room.GoClient, x) {
									all = append(all, x.Mid)
								}
							} else {
								break
							}
						}
						if client.Limiter {
							//no := 0
							for _, mid := range all {
								go client.InviteIntoChats(to, []string{mid})
							}
							//client.InviteIntoChats(to, all)
							time.Sleep(1 * time.Second)
							client.GetSquad(to)
						} else {
							client.SendMessage(to, "Cannot invite squad, please try with another bots.")
						}
					}
					if strings.HasPrefix(txt, GetCommand(grades, "buyer")) && txt != GetCommand(grades, "buyers") {
						if MentionMsg != nil {
							addc := []string{}
							for _, target := range MentionMsg {
								if !Contains(Resel, target) {
									Resel = append(Resel, target)
									Upset("status", "resel", target)
									addc = append(addc, target)
								}
							}
							if len(addc) != 0 {
								client.SendTextMentionByListLINE(to, "Promoted as Buyer", addc)
							} else {
								client.SendMessage(to, "The user has a higher grade or is listed in the main list.")
							}

						} else {
							ha := strings.Split(txt, GetCommand(grades, "buyer"))
							hi := StripOut(ha[1])
							_, MentionMsga := gCon(client, to, hi, grades)
							if len(MentionMsga) != 0 {
								addc := []string{}
								for _, target := range MentionMsga {
									if !Contains(Resel, target) {
										Resel = append(Resel, target)
										Upset("status", "resel", target)
										addc = append(addc, target)
									}
								}
								if len(addc) != 0 {
									client.SendTextMentionByListLINE(to, "Promoted as Buyer", addc)
									logAccess(client, to, msg.From_, "Buyer List", addc, int32(msg.ToType))
								} else {
									client.SendMessage(to, "The user has a higher grade or is listed in the main list.")
								}
							} else {
								Addresel = true
								timeabort = time.Now()
								client.SendMessage(to, "Please send contact that I want to add")
							}
						}
					} else if strings.HasPrefix(txt, GetCommand(grades, "delbuyer")) {
						ha := strings.Split(msg.Text, GetCommand(grades, "delbuyer")+" ")
						haj := ha[1]
						_, wongs := gCon(client, to, haj, grades)
						if len(wongs) == 0 {
							hapuss := Archimed(haj, Resel)
							lisa := []string{}
							for _, wong := range hapuss {
								Resel = Remove(Resel, wong)
								Delset("status", "resel", wong)
								lisa = append(lisa, wong)
							}
							if len(lisa) != 0 {
								client.SendTextMentionByListLINE(to, "Evicted from buyer", lisa)
								logAccess(client, to, msg.From_, "delbuyer", lisa, int32(msg.ToType))
							}

						} else {
							lisa := []string{}
							for _, wong := range wongs {
								Resel = Remove(Resel, wong)
								Delset("status", "resel", wong)
								lisa = append(lisa, wong)
							}
							if len(lisa) != 0 {
								client.SendTextMentionByListLINE(to, "Evicted from buyer", lisa)
								logAccess(client, to, msg.From_, "delbuyer", lisa, int32(msg.ToType))
							} else {
								Tcm = append(Tcm, "The user is not in the buyer list.")
							}

						}
					} else if txt == GetCommand(grades, "appname") {
						for _, cl := range bk {
							cl.SendMessage(to, cl.AppName)
						}
					} else if txt == GetCommand(grades, "tokens") {
						for _, cl := range bk {
							cl.SendMessage(to, cl.AuthToken)
						}
					} else if txt == GetCommand(grades, "clearfriends") {
						client.SendMessage(to, "Waiting for clear all friends")
						clearCon()
						client.SendMessage(to, "All bots success clear all friends")
					} else if txt == GetCommand(grades, "clearallfriends") {
						client.SendMessage(to, "Waiting for clear all friends")
						clearConV2(to)
						client.SendMessage(to, "All bots success clear all friends")
					} else if txt == GetCommand(grades, "clearbuyer") {
						jus := Resel
						for _, vv := range Resel {
							Delset("status", "resel", vv)
						}
						Resel = []string{}
						str := fmt.Sprintf("The list of %v buyer's has been cleared.", len(jus))

						client.SendMessage(to, str)
						logAccess(client, to, msg.From_, "clearbuyer", jus, int32(msg.ToType))
					} else if txt == GetCommand(grades, "creators") {
						var str = "Creator list"
						if len(Creator) != 0 {
							client.SendTextMentionByListLINE(to, str, Creator)
						} else {
							client.SendMessage(to, "The creator list is empty.")
						}
					} else if txt == GetCommand(grades, "login selfbot") {
						client.LoginVersionV2(to, sender)
					} else if txt == GetCommand(grades, "login email") {
						//client.LoginEmailV2(to, sender)
						client.LoginEmailV3(to, sender)
					} else if strings.HasPrefix(txt, GetCommand(grades, "getmail")) {
						cuk := strings.Split(txt, " ")
						email := cuk[1]
						passwrod := cuk[2]
						UpdateSetString("Selfbot.Email."+sender, email)
						UpdateSetString("Selfbot.Password."+sender, passwrod)
						client.SendMessage(to, "Success Add Email")
					} else if txt == GetCommand(grades, "restart") {
						client.SendMessage(to, "Please wait..")
						UpdateSetString("mid_restart", to)
						autorestart.RestartByExec()
					} else if txt == GetCommand(grades, "screen -ls") || txt == "screen" {
						if IsMaster(sender) {
							cmd := exec.Command("bash", "-c", "sudo screen -ls")
							stdoutStderr, err := cmd.CombinedOutput()
							if err != nil {
								fmt.Println(err)
								return
							}
							output := string(stdoutStderr)
							client.SendMessage(to, output)
						}
					} else if strings.HasPrefix(txt, GetCommand(grades, "running")) {
						if IsMaster(sender) {
							mm := GetCommand(grades, "running")
							Konstol := client.AddedText(msg.Text, mm, Prefix)
							if Konstol != "" {
								exec.Command("bash", "-c", "screen -S "+Konstol+" -X kill").Output()
								exec.Command("bash", "-c", "screen -S "+Konstol+" -dm ./vh.sh "+Konstol).Output()
								client.SendMessage(to, "Running bot: "+Konstol)
							}
						}
					} else if strings.HasPrefix(txt, GetCommand(grades, "kill")) {
						if IsMaster(sender) {
							mm := GetCommand(grades, "kill")
							Konstol := client.AddedText(msg.Text, mm, Prefix)
							if Konstol != "" {
								exec.Command("bash", "-c", "screen -S "+Konstol+" -X kill").Output()
								client.SendMessage(to, "Kill bot: "+Konstol)
							}
						}
					} else if strings.HasPrefix(txt, GetCommand(grades, "setdelay")) {
						nums := strings.Split(txt, GetCommand(grades, "setdelay"))
						st := nums[1]
						st = StripOut(st)
						numb, err := strconv.Atoi(st)
						if err != nil {
							client.SendMessage(to, "Please input the right number.")
						} else {
							delayed = time.Duration(numb) * time.Second
							client.SendMessage(to, "Spam delay set to "+st+" second's")
						}
					} else if txt == GetCommand(grades, "addallsquads") {
						client.SendMessage(to, "Please wait..")
						addCon(to, Squad, sender, msg.ID)
						client.SendMessage(to, "Done.")
					} else if txt == GetCommand(grades, "checkallfriend") {
						for _, p := range bk {
							ls := []string{}
							fl := p.GetAllContactIds()
							for _, mi := range Squad {
								if !Contains(fl, mi) && mi != p.Mid {
									ls = append(ls, mi)
								}
							}
							if len(ls) != 0 {
								mentions(p, to, "Not added", ls)
							} else {
								p.SendMessage(to, "All teams added")
							}
						}
					}
				}
				Pangkat = "buyer"
				if strings.HasPrefix(txt, GetCommand(grades, "media")) {
					ha := strings.Split(txt, GetCommand(grades, "media"))
					hi := StripOut(ha[1])
					if hi == "on" {
						Media = true
					}
					if hi == "off" {
						Media = false
					}
					Tcm = append(Tcm, fmt.Sprintf("Media mode set: %s.", hi))
				}
				if strings.HasPrefix(txt, GetCommand(grades, "owner")) && txt != GetCommand(grades, "owners") {
					if MentionMsg != nil {
						addc := []string{}
						for _, target := range MentionMsg {
							geta := GradeKick(to, target)
							if geta < 2 {
								continue
							} else if !Contains(Owner, target) {
								Owner = append(Owner, target)
								Upset("status", "owner", target)
								addc = append(addc, target)
							}
						}
						if len(addc) != 0 {
							client.SendTextMentionByListLINE(to, "Promote to owner", addc)
							logAccess(client, to, msg.From_, "owner", addc, int32(msg.ToType))
						} else {
							client.SendMessage(to, "The user has a higher grade or is listed in the owner list.")
						}

					} else {
						ha := strings.Split(txt, GetCommand(grades, "owner"))
						hi := StripOut(ha[1])
						_, targets := gCon(client, to, hi, grades)
						if len(targets) != 0 {
							addc := []string{}
							for _, target := range targets {
								geta := GradeKick(to, target)
								if geta < 2 {
									continue
								} else if !Contains(Owner, target) {
									Owner = append(Owner, target)
									Upset("status", "owner", target)
									addc = append(addc, target)
								}
							}
							if len(addc) != 0 {
								client.SendTextMentionByListLINE(to, "Promote to owner", addc)
								logAccess(client, to, msg.From_, "owner", addc, int32(msg.ToType))
							} else {
								client.SendMessage(to, "The user has a higher grade or is listed in the owner list.")
							}
						} else {
							Addowner = true
							timeabort = time.Now()
							client.SendMessage(to, "Please send contact that I want to add")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "encmode")) {
					ha := strings.Split(txt, GetCommand(grades, "encmode"))
					hi := StripOut(ha[1])
					kmo := []string{"true", "false"}
					if Contains(kmo, hi) {
						if hi == "true" {
							EncMetode = true
							value, _ := sjson.Set(Settings, "settings.encmode", true)
							Settings = value
							JsonDump(true, JsonFile, Settings)
						} else {
							EncMetode = false
							value, _ := sjson.Set(Settings, "settings.encmode", false)
							Settings = value
							JsonDump(true, JsonFile, Settings)
						}
						Tcm = append(Tcm, fmt.Sprintf("Enc mode set: %s.", hi))
					}
				} else if txt == GetCommand(grades, "speed") {
						mss := "Speed\n"
						for n, tp := range bk {
							//hi := time.Now().UnixNano() / int64(time.Millisecond)
							//t := hi - op.CreatedTime
							//spg := fmt.Sprintf("%v", t)
							start := time.Now()
							tp.GetProfile()
							elapsed := time.Since(start)
							sp := fmt.Sprintf("%v", elapsed)
							sp = sp[:3]
							sps := fmt.Sprintf("\nBot %v: %vms", n+1, sp)
							mss += sps
						}
						Tcm = append(Tcm, mss)
				} else if strings.HasPrefix(txt, GetCommand(grades, "delowner")) {
					ha := strings.Split(msg.Text, GetCommand(grades, "delowner")+" ")
					haj := ha[1]
					_, wongs := gCon(client, to, haj, grades)
					if len(wongs) == 0 {
						hapuss := Archimed(haj, Owner)
						lisa := []string{}
						for _, wong := range hapuss {
							Owner = Remove(Owner, wong)
							Delset("status", "owner", wong)
							lisa = append(lisa, wong)
						}
						if len(lisa) != 0 {
							client.SendTextMentionByListLINE(to, "Expeled from Owner", lisa)
							logAccess(client, to, msg.From_, "delowner", lisa, int32(msg.ToType))
						}

					} else {
						lisa := []string{}
						for _, wong := range wongs {
							Owner = Remove(Owner, wong)
							Delset("status", "owner", wong)
							lisa = append(lisa, wong)
						}
						if len(lisa) != 0 {
							client.SendTextMentionByListLINE(to, "Fired from owner", lisa)
							logAccess(client, to, msg.From_, "delowner", lisa, int32(msg.ToType))
						} else {
							Tcm = append(Tcm, "The user is not in the owner list.")
						}

					}
				} else if txt == GetCommand(grades, "clearowner") {
					jum := Owner
					for _, vv := range Owner {
						Delset("status", "owner", vv)
					}
					Owner = []string{}
					str := fmt.Sprintf("Cleared %v Owner.", len(jum))

					client.SendMessage(to, str)
					logAccess(client, to, msg.From_, "clearaccess", jum, int32(msg.ToType))
				} else if strings.HasPrefix(txt, GetCommand(grades, "perm")) {
					ha := strings.Split(msg.Text, GetCommand(grades, "perm")+" ")
					fmt.Println(ha[1])
					co := strings.Split(ha[1], " ")
					v := co[0]
					p := co[1]
					if p == "perm" {
						if v == "buyer" || v == "0" {
							Ginvite = 0
							value, _ := sjson.Set(Settings, "settings.gradeinvite", Ginvite)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							client.SendMessage(to, "Invite bot's permission set to buyer and higher grade.")
						} else if v == "owner" || v == "1" {
							Ginvite = 1
							value, _ := sjson.Set(Settings, "settings.gradeinvite", Ginvite)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							client.SendMessage(to, "Invite permission set to owner and higher grade.")
						} else if v == "master" || v == "2" {
							Ginvite = 2
							value, _ := sjson.Set(Settings, "settings.gradeinvite", Ginvite)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							client.SendMessage(to, "Invite permission set to master and higher grade.")
						} else if v == "admin" || v == "3" {
							Ginvite = 3
							value, _ := sjson.Set(Settings, "settings.gradeinvite", Ginvite)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							client.SendMessage(to, "Invite permission set to admin and higher grade.")
						}
					} else {
						kk := CekSetCMD(p)
						if kk {
							a := UpPermit(p, v)
							if a {
								client.SendMessage(to, "Command rank "+p+" set to "+v)
							} else {
								client.SendMessage(to, "Permission is not valid\nUse 0-3 or buyer/owner/master/admin")
							}

						} else {
							client.SendMessage(to, "Command not found")
						}
					}
				} else if txt == GetCommand(grades, "lockedcmd") {
					tst := "Locked Command:\n"
					num := 1
					for _, v := range helper {
						k := getKey(v)
						anu := cekLock(k)
						if anu {
							var jo string
							if num < 10 {
								jo = fmt.Sprintf("\n %v.   %s\n     %s ", num, k, v)
							} else {
								jo = fmt.Sprintf("\n %v. %s\n     %s ", num, k, v)
							}
							tst += strings.Title(jo)
							num += 1
						}
					}
					if num != 1 {
						client.SendMessage(to, tst)
					} else {
						client.SendMessage(to, "All command's is enable.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "setcmd")) {
					ha := strings.Split(txt, " ")
					v := ha[1]
					p := ha[2]
					kk := CekSetCMD(p)
					if kk {
						var j bool
						var ps string
						if v == "lock" || v == "disable" {
							j = true
							ps = "disable"
						} else if v == "unlock" || v == "enable" {
							j = false
							ps = "enable"
						} else {
							client.SendMessage(to, "Value is not valid\nPlease use lock/unlock/disable/enable")
							return
						}
						LockCommand(p, j)
						client.SendMessage(to, "Command "+p+" set to "+ps)

					} else {
						client.SendMessage(to, "Command not found")
					}
				} else if txt == GetCommand(grades, "leaveallgroup") {
					if IsGaccess(to, msg.From_) {
						return
					}
					for _, p := range Client {
						gr, _ := p.GetGroupIdsJoined()
						for _, g := range gr {
							if g != msg.To {
								p.DeleteSelfFromChat(g)
								Protected = Remove(Protected, g)
								time.Sleep(1 * time.Second)
								for _, i := range Logmode {
									if i == g {
										Logmode = Remove(Logmode, g)
									}
								}
							}
						}
					}
					Tcm = append(Tcm, "Leave done")
				} else if strings.HasPrefix(txt, GetCommand(grades, "logmode")) {
					var hi string
					ha := strings.Split(txt, GetCommand(grades, "logmode"))
					hi = StripOut(ha[1])

					if hi == "off" || hi == "disable" {
						if Contains(Logmode, to) {
							Logmode = Remove(Logmode, to)
							Delset("status", "logmode", to)
							client.SendMessage(to, "Logmode disabled.")
						} else {
							client.SendMessage(to, "Logmode already disabled.")
						}
					} else if hi == "on" || hi == "enable" {
						if !Contains(Logmode, to) {
							Logmode = append(Logmode, to)
							Upset("status", "logmode", to)
							client.SendMessage(to, "Logmode enabled.")
						} else {
							client.SendMessage(to, "Logmode already enabled.")
						}
					} else if hi == "clear" {
						Logmode = []string{}
						value, _ := sjson.Set(Settings, "status.logmode", Logmode)
						Settings = value
						JsonDump(true, JsonFile, Settings)
						client.SendMessage(to, "Logmode cleared.")
					}
				} else if txt == GetCommand(grades, "changepict") {
					if IsGaccess(to, msg.From_) {
						return
					}
					changepic = bk
					cpic = true
					Tcm = append(Tcm, "Send your image.")
					timeabort = time.Now()
				} else if txt == GetCommand(grades, "changecover") {
					if IsGaccess(to, msg.From_) {
						return
					}
					changepic = bk
					ccover = true
					Tcm = append(Tcm, "Send your image.")
					timeabort = time.Now()
				} else if strings.HasPrefix(txt, GetCommand(grades, "uimage")) {
					if IsGaccess(to, msg.From_) {
						return
					}
					if len(MentionMsg) != 0 {
						changepic = []*LineClient{}
						for _, ym := range MentionMsg {
							if Contains(Squad, ym) {
								idx := IndexOf(Squad, ym)
								changepic = append(changepic, Client[idx])
							}
						}
						if len(changepic) != 0 {
							client.SendMessage(to, "Send your image.")
						}
						cpic = true
						upimage = false
						timeabort = time.Now()
					} else if txt == GetCommand(grades, "uimage") {
						client.SendMessage(to, "Which bot's you want to update pic ?")
						timeabort = time.Now()
						upimage = true
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "autoname")) {
					if IsGaccess(to, msg.From_) {
						return
					}
					hh := strings.Split(txt, GetCommand(grades, "autoname"))
					putih := StripOut(hh[1])
					cekun := []string{}
					if putih == "" {
						for no, cl := range bk {
							no++
							RanName := RandomString(GenName) + " " + RandomString(GenName)
							if !Contains(cekun, RanName) {
								cekun = append(cekun, RanName)
							} else {
								for {
									RanName = RandomString(GenName) + " " + RandomString(GenName)
									if !Contains(cekun, RanName) {
										cekun = append(cekun, RanName)
										break
									}
								}
							}
							asul := CutNameIfLong(RanName, 17)
							profile_B := cl.GetProfile()
							profile_B.DisplayName = asul
							profile_B.StatusMessage = "LINEBots"
							cl.UpdateProfile(profile_B)
							cl.SendMessage(to, "Update name to : "+asul)
						}
					} else if putih == "korea" || putih == "korean" {
						for _, cl := range bk {
							RanName := RandomString(GenKoreaName)
							if !Contains(cekun, RanName) {
								cekun = append(cekun, RanName)
							} else {
								for {
									RanName = RandomString(GenName) + " " + RandomString(GenName)
									if !Contains(cekun, RanName) {
										cekun = append(cekun, RanName)
										break
									}
								}
							}
							asul := CutNameIfLong(RanName, 17) ///RanName + " " + convertToKorean(no)
							profile_B := cl.GetProfile()
							profile_B.DisplayName = asul
							profile_B.StatusMessage = "LINEBots"
							cl.UpdateProfile(profile_B)
							cl.SendMessage(to, "Update name to : "+asul)
						}
					} else if putih == "japan" || putih == "japanese" {
						for _, cl := range bk {
							RanName := RandomString(GenJapanName)
							if !Contains(cekun, RanName) {
								cekun = append(cekun, RanName)
							} else {
								for {
									RanName = RandomString(GenName) + " " + RandomString(GenName)
									if !Contains(cekun, RanName) {
										cekun = append(cekun, RanName)
										break
									}
								}
							}
							asul := CutNameIfLong(RanName, 17)
							profile_B := cl.GetProfile()
							profile_B.DisplayName = asul
							profile_B.StatusMessage = "LINEBots"
							cl.UpdateProfile(profile_B)
							cl.SendMessage(to, "Update name to : "+asul)
						}
					} else if putih == "thai" || putih == "thailand" {
						for _, cl := range bk {
							RanName := RandomString(GenThaiName)
							if !Contains(cekun, RanName) {
								cekun = append(cekun, RanName)
							} else {
								for {
									RanName = RandomString(GenName) + " " + RandomString(GenName)
									if !Contains(cekun, RanName) {
										cekun = append(cekun, RanName)
										break
									}
								}
							}
							asul := CutNameIfLong(RanName, 17)
							profile_B := cl.GetProfile()
							profile_B.DisplayName = asul
							profile_B.StatusMessage = "LINEBots"
							cl.UpdateProfile(profile_B)
							cl.SendMessage(to, "Update name to : "+asul)
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "uname")) {
					if IsGaccess(to, msg.From_) {
						return
					}
					var str string
					su := GetCommand(grades, "uname")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					if str != "" {
						client.SendMessage(to, fmt.Sprintf("Which bot's should be named %s ?", str))
						timeabort = time.Now()
						upname = true
						changename = str
					} else {
						client.SendMessage(to, "Name can't be empty.")
					}
				} else if txt == GetCommand(grades, "autogpict") {
					if IsGaccess(to, msg.From_) {
						return
					}
					RandomGroupPict(to)
				} else if txt == GetCommand(grades, "autopict") {
					if IsGaccess(to, msg.From_) {
						return
					}
					ChangeRandomPict(to)
				} else if txt == GetCommand(grades, "autocover") {
					if IsGaccess(to, msg.From_) {
						return
					}
					ChangeRandomCover(to)
				} else if txt == GetCommand(grades, "checkban") {
					if IsGaccess(to, msg.From_) {
						return
					}
					y := "Comrade:\n"
					for no, cl := range Client {
						no++
						res := "Limit"
						a := cl.Checkban(to)
						if a {
							res = "Fresh "
						}

						var namek string
						if len(cl.Name) > 8 {
							namek = cl.Name[0:8]
						} else {
							namek = cl.Name
						}
						y += fmt.Sprintf("\n%v. %v > %v", no, namek, res)
						cl.Kicked = false
					}
					client.SendMessage(to, y)
				} else if txt == GetCommand(grades, "getban") {
					if IsGaccess(to, msg.From_) {
						return
					}
					y := "Check Banned:\n"
					for no, cl := range Client {
						no++
						res := ""
						tcr := cl.GetHomeProfileV2(cl.Mid)
						fmt.Println(tcr)
						hasil := gjson.Get(string(tcr), "code").String()
						if hasil == "606" {
							res = "Banned"
						} else if hasil == "404" {
							res = "Banned"
						} else if hasil == "403" {
							res = "Banned"
						} else {
							res = "Good"
						}
						var namek string
						if len(cl.Name) > 8 {
							namek = cl.Name[0:8]
						} else {
							namek = cl.Name
						}
						y += fmt.Sprintf("\n%v. %v > %v", no, namek, res)
						cl.Kicked = false
					}
					client.SendMessage(to, y)
				} else if strings.HasPrefix(txt, GetCommand(grades, "allname")) {
					if IsGaccess(to, msg.From_) {
						return
					}
					var str string
					su := GetCommand(grades, "allname")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					if str != "" {
						for x, tok := range bk {
							tok.UpdateProfileName(str+fmt.Sprintf("-%v", x+1))
							tok.Name = str
							tok.SendMessage(to, "Displayname updated to "+str)
						}
					} else {
						client.SendMessage(to, "Name can't be empty.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "prefixname")) {
					if IsGaccess(to, msg.From_) {
						return
					}
					var str string
					su := GetCommand(grades, "prefixname")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					if str != "" {
						for _, tok := range bk {
							nam, _ := client.GetContact(tok.Mid)
							name := str + nam.DisplayName
							tok.UpdateProfileName(name)
							tok.Name = name
							tok.SendMessage(to, "Displayname updated to "+name)
						}
					} else {
						client.SendMessage(to, "Name prefix can't be empty.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "suffixname")) {
					if IsGaccess(to, msg.From_) {
						return
					}
					var str string
					su := GetCommand(grades, "suffixname")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					if str != "" {
						for _, tok := range bk {
							nam, _ := client.GetContact(tok.Mid)
							name := str + nam.DisplayName
							tok.UpdateProfileName(name)
							tok.Name = name
							tok.SendMessage(to, "Displayname updated to "+name)
						}
					} else {
						client.SendMessage(to, "Name prefix can't be empty.")
					}
				}
				/*owner command*/
				Pangkat = "owner"
				if strings.HasPrefix(txt, GetCommand(grades, "admin")) && txt != GetCommand(grades, "admin") {
					if IsGaccess(to, msg.From_) {
						return
					}
					if MentionMsg != nil {
						addc := []string{}
						for _, target := range MentionMsg {
							geta := GradeKick(to, target)
							if geta < 3 {
								continue
							} else if !Contains(Admin, target) {
								Admin = append(Admin, target)
								Upset("status", "admin", target)
								addc = append(addc, target)
							}
						}
						if len(addc) != 0 {
							client.SendTextMentionByListLINE(to, "Was promoted to admin", addc)
							logAccess(client, to, msg.From_, "add admin", addc, int32(msg.ToType))
						} else {
							client.SendMessage(to, "The user has a higher grade or is listed in the main list.")
						}

					} else {
						ha := strings.Split(txt, GetCommand(grades, "admin"))
						hi := StripOut(ha[1])
						_, MentionMsg = gCon(client, to, hi, grades)
						if len(MentionMsg) != 0 {
							addc := []string{}
							for _, target := range MentionMsg {
								geta := GradeKick(to, target)
								if geta < 3 {
									continue
								} else if !Contains(Admin, target) {
									Admin = append(Admin, target)
									Upset("status", "admin", target)
									addc = append(addc, target)
								}
							}
							if len(addc) != 0 {
								client.SendTextMentionByListLINE(to, "Was promoted to admin", addc)
								logAccess(client, to, msg.From_, "add admin", addc, int32(msg.ToType))
							} else {
								client.SendMessage(to, "The user has a higher grade or is listed in the main list.")
							}
						} else {
							Addadmin = true
							timeabort = time.Now()
							client.SendMessage(to, "Please send contact that I want to add")
						}
					}
				} else if txt == GetCommand(grades, "purgebl") {
					gr, _ := client.GetGroupIdsJoined()
					all := []string{}
					for _, aa := range gr {
						_, memlist, _ := client.GetChatList(to)
						lkicks := []string{}
						for _, v := range memlist {
							if MemUser(aa, v) {
								lkicks = append(lkicks, v)
							}
						}
						lkick := []string{}
						for _, ban := range lkicks {
							if Contains(Blacklist, ban) {
								lkick = append(lkick, ban)
								all = append(all, ban)
							}
						}
						nom := []*LineClient{}
						ilen := len(lkick)
						xx := 0
						exe := []*LineClient{}
						for _, c := range GetRoom(aa).Client {
							if c.Limiter {
								exe = append(exe, c)
							}
						}
						for i := 0; i < ilen; i++ {
							if xx < len(exe) {
								nom = append(nom, exe[xx])
								xx += 1
							} else {
								xx = 0
								nom = append(nom, exe[xx])
							}
						}
						for i := 0; i < ilen; i++ {
							target := lkick[i]
							cl := nom[i]
							go cl.DeleteOtherFromChat(aa, target)
						}
					}
					client.SendMessage(to, "Success to purgeall fucklist.")
					logAccess(client, to, msg.From_, "purgeall", all, int32(msg.ToType))
				} else if strings.HasPrefix(txt, GetCommand(grades, "suggest")) {
					ha := strings.Split(txt, GetCommand(grades, "suggest"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						Suggest = 1
						value, _ := sjson.Set(Settings, "suggest", 1)
						Settings = value
						JsonDump(true, JsonFile, Settings)
						client.SendMessage(to, "Suggest word set to on.")
					} else if hi == "off" || hi == "0" {
						Suggest = 0
						value, _ := sjson.Set(Settings, "suggest", 0)
						Settings = value
						JsonDump(true, JsonFile, Settings)
						client.SendMessage(to, "Suggest word set to off.")
					} else if hi == "auto" || hi == "2" {
						Suggest = 2
						value, _ := sjson.Set(Settings, "suggest", 2)
						Settings = value
						JsonDump(true, JsonFile, Settings)
						client.SendMessage(to, "Suggest word set to auto.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "broadcast")) {
					if IsGaccess(to, msg.From_) {
						return
					}
					var str string
					su := GetCommand(grades, "broadcast")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					if len(str) != 0 {
						gr, _ := client.GetGroupIdsJoined()
						for _, gid := range gr {
							client.SendMessage(gid, str)
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "deladmin")) {
					if IsGaccess(to, msg.From_) {
						return
					}
					ha := strings.Split(msg.Text, GetCommand(grades, "deladmin")+" ")
					haj := ha[1]
					_, wongs := gCon(client, to, haj, grades)
					if len(wongs) == 0 {
						hapuss := Archimed(haj, Admin)
						lisa := []string{}
						for _, wong := range hapuss {
							Admin = Remove(Admin, wong)
							Delset("status", "admin", wong)
							lisa = append(lisa, wong)
						}
						if len(lisa) != 0 {
							client.SendTextMentionByListLINE(to, "Fired from admin", lisa)
						}
					} else {
						lisa := []string{}
						for _, wong := range wongs {
							if Contains(Admin, wong) {
								Admin = Remove(Admin, wong)
								Delset("status", "admin", wong)
								lisa = append(lisa, wong)
							}
						}
						if len(lisa) != 0 {
							client.SendTextMentionByListLINE(to, "Fired from admin", lisa)
						} else {
							Tcm = append(Tcm, "The user is not in the main list.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "gourl")) {
					ha := strings.Split(txt, GetCommand(grades, "gourl"))
					hi := StripOut(ha[1])
					nim, _ := strconv.Atoi(hi)
					nim = nim - 1
					var gr []string
					if len(tempgroup) == 0 {
						gr, _ = client.GetGroupIdsJoined()
					} else {
						gr = tempgroup
					}
					gid := gr[nim]
					if Grade(gid, msg.From_) > 2 {
						return
					}
					client.UpdateChatQrByte(gid, false)
					tick := client.ReissueChatTicket(gid)
					client.SendMessage(to, "https://line.me/R/ti/g/" + tick + "\n")
				/*} else if txt == GetCommand(grades, "groups") {
					gr := []string{}
					for _, p := range Client {
						grs, _ := p.GetGroupIdsJoined()
						for _, a := range grs {
							if !InArray2(gr, a) {
								gr = append(gr, a)
							}
						}
					}
					nm := []string{}
					grup, _ := client.GetGroups(gr)
					ci := []string{}
					for _, g := range grup {
						ci = append(ci, strings.ToLower(g.ChatName))
					}
					sort.Strings(ci)
					groups := []*LineThrift.Chat{}
					tempgroup = []string{}
					for _, x := range ci {
						for _, gi := range grup {
							if strings.ToLower(gi.ChatName) == x {
								if !InArrayChat(groups, gi) {
									groups = append(groups, gi)
									tempgroup = append(tempgroup, gi.ChatMid)
								}
							}
						}
					}
					for c, a := range groups {
						name, mem := a.ChatName, a.Extra.GroupExtra.MemberMids
						c += 1
						jm := 0
						for mid := range mem {
							if InArray2(Squad, mid) {
								jm++
							}
						}
						name = fmt.Sprintf("%v. %s (%v/%v)", c, name, jm, len(mem))
						nm = append(nm, name)
						GetSquad(client, a.ChatMid)
					}
					stf := "All Group List:\n\n"
					str := strings.Join(nm, "\n")
					anu := []string{}
					for _, p := range Client {
						grs, _ := p.GetGroupIdsInvited()
						for _, a := range grs {
							if !InArray2(gr, a) && !InArray2(anu, a) {
								anu = append(anu, a)
							}
						}
					}
					grup, _ = client.GetGroups(anu)
					ci = []string{}
					for _, g := range grup {
						ci = append(ci, strings.ToLower(g.ChatName))
					}
					sort.Strings(ci)
					groups = []*LineThrift.Chat{}
					tempginv := []string{}
					for _, x := range ci {
						for _, gi := range grup {
							if strings.ToLower(gi.ChatName) == x {
								if !InArrayChat(groups, gi) {
									groups = append(groups, gi)
									tempginv = append(tempginv, gi.ChatMid)
								}
							}
						}
					}
					nm = []string{}
					nn := 1
					for _, a := range groups {
						name, mem, inv := a.ChatName, a.Extra.GroupExtra.MemberMids, a.Extra.GroupExtra.InviteeMids
						if name != "" {
							jm := 0
							for mid := range inv {
								if InArray2(Squad, mid) {
									jm++
								}
							}
							if jm != 0 {
								name = fmt.Sprintf("%v. %s (invited) (%v/%v)", nn, name, jm, len(mem))
								nm = append(nm, name)
								GetSquad(client, a.ChatMid)
								nn++
							} else {
								tempginv = Remove(tempginv, a.ChatMid)
							}
						} else {
							tempginv = Remove(tempginv, a.ChatMid)
						}
					}
					var strs, strsa = "", ""
					if len(nm) != 0 {
						strs = "\n\nAll Group Invitation:\n\n"
						strsa = strings.Join(nm, "\n")
					}
					client.SendMessage(to,stf + str + strs + strsa)*/
				} else if txt == GetCommand(grades, "groups") {
					nm := []string{}
					tempgroup = []string{}
					no := 1
					for _, ll := range Client {
						gr, _ := ll.GetGroupIdsJoined()
						for _, a := range gr {
							if !Contains(tempgroup, a) {
								tempgroup = append(tempgroup, a)
								name, mm := ll.GetGroupName(a)
								name = fmt.Sprintf("%v. %s #%v", no, name, len(mm))
								nm = append(nm, name)
								if !Contains(Protected, a) {
									GetSquad(client, a)
								}
								no++
							}
						}
					}
					stf := "Group list:\n\n"
					str := strings.Join(nm, "\n")
					client.SendMessage(to, stf+str)
				} else if txt == GetCommand(grades, "checkallgroup") {
					for _, p := range bk {
						nm := []string{}
						gr, _ := p.GetGroupIdsJoined()
						for c, a := range gr {
							name, _ := p.GetGroupName(a)
							c += 1
							name = fmt.Sprintf("%v. %s", c, name)
							nm = append(nm, name)
							if !Contains(Protected, a) {
								GetSquad(p, a)
							}
						}
						stf := "List of groups:\n\n"
						str := strings.Join(nm, "\n")
						p.SendMessage(to, stf+str)
					}
				} else if txt == GetCommand(grades, "allgpending") {
					for _, p := range bk {
						nm := []string{}
						gr, _ := p.GetGroupIdsInvited()
						for c, a := range gr {
							res, _, _ := p.GetChatList(a)
							name := res
							c += 1
							name = fmt.Sprintf("%v. %s", c, name)
							nm = append(nm, name)
						}
						stf := "Invitation list:\n\n"
						str := strings.Join(nm, "\n")
						p.SendMessage(to, stf+str)
					}
				} else if txt == GetCommand(grades, "acceptall") {
					for _, p := range bk {
						gr, _ := p.GetGroupIdsInvited()
						if len(gr) != 0 {
							for _, a := range gr {
								p.AcceptChatInvitation(a)
							}
							p.SendMessage(to, "I accept everything. I'm done.")
						}
					}
				} else if txt == GetCommand(grades, "rejectall") {
					for _, p := range bk {
						gr, _ := p.GetGroupIdsInvited()
						if len(gr) != 0 {
							for _, a := range gr {
								p.RejectChatInvitation(a)
							}
							p.SendMessage(to, "I reject everything. I'm done.")
						}
					}
				} else if txt == GetCommand(grades, "clearadmin") {
					if IsGaccess(to, msg.From_) {
						return
					}
					jum := Admin
					for _, vv := range Admin {
						Delset("status", "admin", vv)
					}
					Admin = []string{}
					str := fmt.Sprintf("Clear admin %v", len(jum))
					Tcm = append(Tcm, str)
					logAccess(client, to, msg.From_, "Clear admin", jum, int32(msg.ToType))
				} else if txt == GetCommand(grades, "clearstaff") {
					if IsGaccess(to, msg.From_) {
						return
					}
					jum := GlobalStaff
					for _, vv := range GlobalStaff {
						Delset("status", "staff", vv)
					}
					GlobalStaff = []string{}
					str := "Cleared all Staff."
					Tcm = append(Tcm, str)
					logAccess(client, to, msg.From_, "clearstaff", jum, int32(msg.ToType))
				/*} else if strings.HasPrefix(txt, GetCommand(grades, "forceqr")) {
					ha := strings.Split(txt, GetCommand(grades, "forceqr"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						if !Forceqr {
							Forceqr = true
							value, _ := sjson.Set(Settings, "settings.forceqr", true)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "forceqr enabled.")
						} else {
							Tcm = append(Tcm, "forceqr already enabled.")
						}
					} else if hi == "off" || hi == "0" {
						if Forceqr {
							Forceqr = false
							value, _ := sjson.Set(Settings, "settings.forceqr", false)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "forceqr disabled.")
						} else {
							Tcm = append(Tcm, "forceqr already disabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "attack")) {
					var ha = []string{}
					ha = strings.Split(txt, GetCommand(grades, "attack"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						if !Takeover {
							Takeover = true
							value, _ := sjson.Set(Settings, "settings.takeover", true)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							client.SendMessage(to, "Attack mode enabled.")

						} else {
							client.SendMessage(to, "Attack mode already enabled.")
						}
					} else if hi == "off" || hi == "0" {
						if Takeover {
							Takeover = false
							value, _ := sjson.Set(Settings, "settings.takeover", false)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							client.SendMessage(to, "Attack mode disabled.")
						} else {
							client.SendMessage(to, "Attack mode already disabled.")
						}
					}*/
				} else if strings.HasPrefix(txt, GetCommand(grades, "upcoms")) {
					ha := strings.Split(txt, " .")
					p := ha[1]
					v := ha[2]
					kk := CekSetCMD(p)
					if kk {
						UpSetCMD(p, v)
						client.SendMessage(to, "Command "+p+" updated to "+v)
					} else {
						client.SendMessage(to, "Command not found")
					}
				} else if strings.HasPrefix(txt, "upres") {
					ha := strings.Split(msg.Text, "*")
					p := StripOut(ha[1])
					v := ha[2]
					kk := CekSetCMD(p)
					if kk {
						UpRes(p, v)
						client.SendMessage(to, "MsgRespon "+p+" updated to "+v)
					} else {
						client.SendMessage(to, "MsgRespon not found")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "upstk")) {
					ha := strings.Split(txt, GetCommand(grades, "upstk"))
					p := ha[1]
					p = StripOut(p)
					kk := CekSetCMD(p)
					if kk {
						cstk = p
						ustk = true
						timeabort = time.Now()
						client.SendMessage(to, "send your sticker")
					} else {
						client.SendMessage(to, "Command not found")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "upbio")) {
					var str string
					su := GetCommand(grades, "upbio")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					for _, x := range bk {
						x.UpdateProfileBio(str)
					}
					client.SendMessage(to, "Profile bio updated to "+str)
				} else if strings.HasPrefix(txt, GetCommand(grades, "aupname")) {
					if IsGaccess(to, msg.From_) {
						return
					}
					ha := strings.Split(msg.Text, "*")
					if len(ha) == 3 {
						dt := StripOut(ha[1])
						nm := strings.Split(StripOut(ha[2]), "/")
						data := ArchimedCl(dt, Client)
						if len(nm) >= len(data) {
							for n, tok := range data {
								nama := nm[n]
								tok.UpdateProfileName(nama)
								tok.Name = nama
								tok.SendMessage(to, "Displayname updated to "+nama)
							}
						}
					}
					client.SendMessage(to, "Done updating displayname.")
				} else if txt == GetCommand(grades, "clearbots") {
					if IsGaccess(to, msg.From_) {
						return
					}
					ls := Bot
					jum := len(ls)
					if jum != 0 {
						for _, o := range ls {
							Delset("status", "bot", o)
						}

						Bot = []string{}
						str := fmt.Sprintf("Cleared %v bot", jum)
						Tcm = append(Tcm, str)
						logAccess(client, to, msg.From_, "clear bot", ls, int32(msg.ToType))
					} else {
						Tcm = append(Tcm, "The bot list is empty.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "spaminv")) {
					if MentionMsg != nil {
						for _, cl := range bk {
							for _, target := range MentionMsg {
								//go func(target string) {
									fl := cl.GetAllContactIds()
									if !Contains(fl, target) && target != cl.Mid {
										time.Sleep(5 * time.Second)
										cl.LINEAddFriendShareContact(to, target, msg.ID, sender)
									}
									time.Sleep(5 * time.Second)
									cl.LINEAddFriendShareContact(to, target, msg.ID, sender)
									x := 0
									for ; x < Batasan; x++ {
										time.Sleep(30 * time.Second)
										tcr , _ := cl.CreateChatV2([]string{target})
										if tcr != nil {
											cl.SendMessage(to, "Success")
										} else {
											cl.SendMessage(to, "Limit")
											break
										}
									}
								//}(target)
							}
						}
					} else {
						ha := strings.Replace(txt, GetCommand(grades, "spaminv"), "", 1)
						hi := StripOut(ha)
						con, cons := gCon(client, to, hi, grades)
						if con == "invalid" {
							client.SendMessage(to, "Invalid number.")
						} else if len(cons) != 0 {
							for _, cl := range bk {
								for _, target := range cons {
									//go func(target string) {
										fl := cl.GetAllContactIds()
										if !Contains(fl, target) && target != cl.Mid {
											time.Sleep(5 * time.Second)
											cl.LINEAddFriendShareContact(to, target, msg.ID, sender)
										}
										x := 0
										for ; x < Batasan; x++ {
											time.Sleep(30 * time.Second)
											tcr , _ := cl.CreateChatV2([]string{target})
											if tcr != nil {
												cl.SendMessage(to, "Success")
											} else {
												cl.SendMessage(to, "Limit")
												break
											}
										}
									//}(target)
								}
							}
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "getmid")) {
					str := strings.Replace(txt, GetCommand(grades, "getmid"), "", 1)
					if str != "" {
						kvs := GetMentionData(msg.ContentMetadata["MENTION"])
						for _, mention := range kvs {
							client.SendMessage(to, mention)
						}
					}
				} else if txt == GetCommand(grades, "tag") {
					//client.UnsendLastChat(to)
					client.SendTagAll(to)
				} else if txt == GetCommand(grades, "me") {
					client.SendMusicMessage(to,sender)
				} else if strings.HasPrefix(txt, GetCommand(grades, "getcontact")) {
					mm := GetCommand(grades, "getcontact")
					putih := client.AddedText(msg.Text, mm, Prefix)
					client.SendContact(to, putih)
				}

				/*admin commands*/
				Pangkat = "admin"
				if strings.HasPrefix(txt, GetCommand(grades, "kick")) {
					Shuffle(bk)
					cl := GetRoom(to).Client[0]
					if !cl.Limiter {
						client.SendMessage(to, "Bot was kickban, please try again later.")
						return
					}
					if MentionMsg != nil {
						for _, target := range MentionMsg {
							go func(target string) {
								if !MemAkses(to, target) {
									cl.DeleteOtherFromChat(to, target)
									Banned.AddBan(target, to)
									WarPro =  true

								}
							}(target)
						}
						logAccess(client, to, msg.From_, "kick", MentionMsg, int32(msg.ToType))
					} else {
						ha := strings.Replace(txt, GetCommand(grades, "kick"), "", 1)
						hi := StripOut(ha)
						con, cons := gCon(client, to, hi, grades)
						if con == "invalid" {
							client.SendMessage(to, "Invalid number.")
						} else if len(cons) != 0 {
							for _, target := range cons {
								go func(target string) {
									if !MemAkses(to, target) {
										cl.DeleteOtherFromChat(to, target)
										Banned.AddBan(target, to)
										WarPro =  true

									}
								}(target)
							}
							logAccess(client, to, msg.From_, "kick", cons, int32(msg.ToType))
						}
					}
					WarPro           = true
				} else if strings.HasPrefix(txt, GetCommand(grades, "checkaccount")) {
					Shuffle(bk)
					a := []string{}
					b := []string{}
					var str1 = "User Banned"
					var str2 = "User Good"
					if MentionMsg != nil {
						for _, target := range MentionMsg {
							//go func(target string) {
								if !MemAkses(to, target) {
									tcr := client.GetHomeProfileV2(target)
									fmt.Println(tcr)
									hasil := gjson.Get(string(tcr), "code").String()
									if hasil == "606" {
										if !InArray2(a, target) {
											a = append(a,target)
										}
									} else if hasil == "404" {
										if !InArray2(a, target) {
											a = append(a,target)
										}
									} else {
										if !InArray2(b, target) {
											b = append(b,target)
										}
									}
								}
							//}(target)
						}
						client.SendTextMentionByListLINE(to, str1, a)
						client.SendTextMentionByListLINE(to, str2, b)
						logAccess(client, to, msg.From_, "checkaccount", MentionMsg, int32(msg.ToType))
					} else {
						ha := strings.Replace(txt, GetCommand(grades, "checkaccount"), "", 1)
						hi := StripOut(ha)
						a := []string{}
						b := []string{}
						var str1 = "User Banned"
						var str2 = "User Good"
						con, cons := gCon(client, to, hi, grades)
						if con == "invalid" {
							client.SendMessage(to, "Invalid number.")
						} else if len(cons) != 0 {
							for _, target := range cons {
								//go func(target string) {
									if !MemAkses(to, target) {
										tcr := client.GetHomeProfileV2(target)
										fmt.Println(tcr)
										hasil := gjson.Get(string(tcr), "code").String()
										if hasil == "606" {
											if !InArray2(a, target) {
												a = append(a,target)
											}
										} else if hasil == "404" {
											if !InArray2(a, target) {
												a = append(a,target)
											}
										} else {
											if !InArray2(b, target) {
												b = append(b,target)
											}
										}
									}
								//}(target)
							}
							client.SendTextMentionByListLINE(to, str1, a)
							client.SendTextMentionByListLINE(to, str2, b)
							logAccess(client, to, msg.From_, "checkaccount", cons, int32(msg.ToType))
						}
					}
				} else if txt == GetCommand(grades, "listprotect") {
					allroom := map[string][]string{}
					ts := Logo + " Protect List " + Logo
					for _, o := range ProKick {
						if v, ok := allroom[o]; ok {
							if !Contains(v, "kick") {
								v = append(v, "kick")
								allroom[o] = v
							}
						} else {
							allroom[o] = []string{"kick"}
						}
					}
					for _, o := range ProInvite {
						if v, ok := allroom[o]; ok {
							if !Contains(v, "invite") {
								v = append(v, "invite")
								allroom[o] = v
							}
						} else {
							allroom[o] = []string{"invite"}
						}
					}
					for _, o := range ProQr {
						if v, ok := allroom[o]; ok {
							if !Contains(v, "qr") {
								v = append(v, "qr")
								allroom[o] = v
							}
						} else {
							allroom[o] = []string{"qr"}
						}
					}
					for _, o := range ProJoin {
						if v, ok := allroom[o]; ok {
							if !Contains(v, "join") {
								v = append(v, "join")
								allroom[o] = v
							}
						} else {
							allroom[o] = []string{"join"}
						}
					}
					for _, o := range ProCancel {
						if v, ok := allroom[o]; ok {
							if !Contains(v, "cancel") {
								v = append(v, "cancel")
								allroom[o] = v
							}
						} else {
							allroom[o] = []string{"cancel"}
						}
					}
					for k, v := range allroom {
						res, _, _ := client.GetChatList(k)
						ts += fmt.Sprintf("\n\n\u2694 %s\n", res)
						for _, g := range v {
							ts += fmt.Sprintf("\n\u2699 %s", strings.Title(g))
						}
					}
					if len(allroom) != 0 {
						client.SendMessage(msg.To, ts+"\n\n"+Logo+" "+Sflag+" "+Logo+"")
					} else {
						client.SendMessage(msg.To, "No group under protection.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "invme")) {
					ha := strings.Split(txt, GetCommand(grades, "invme"))
					hi := StripOut(ha[1])
					nim, _ := strconv.Atoi(hi)
					nim = nim - 1
					var gr []string
					if len(tempgroup) == 0 {
						gr, _ = client.GetGroupIdsJoined()
					} else {
						gr = tempgroup
					}
					gid := gr[nim]
					if Grade(gid, msg.From_) > 2 {
						return
					}
					room := GetRoom(gid)
					bk := room.Client
					for _, cl := range bk {
						if cl.Limiter {
							err := cl.InviteIntoChatCheck(gid, []string{msg.From_}, sender, msg.ID)
							if err == nil {
								res, _, _ := cl.GetChatList(gid)
								name := res
								cl.SendMessage(to, "You are invited to perm the group. "+name)
								return
							}
						}
					}
					client.SendMessage(to, "Unfortunately, all bots have had their invites banned.")
				} else if strings.HasPrefix(txt, GetCommand(grades, "lockqr")) {
					ha := strings.Split(txt, GetCommand(grades, "lockqr"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						if !LockSet {
							LockSet = true
							value, _ := sjson.Set(Settings, "settings.lockqr", true)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							LockPoint = time.Now()
							Tcm = append(Tcm, "autolock qr enabled.")
						} else {
							Tcm = append(Tcm, "autolock qr already enabled.")
						}
					} else if hi == "off" || hi == "0" {
						if LockSet {
							LockSet = false
							value, _ := sjson.Set(Settings, "settings.lockqr", false)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "autolock qr disabled.")
						} else {
							Tcm = append(Tcm, "autolock qr already disabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "forcejoin")) {
					ha := strings.Split(txt, GetCommand(grades, "forcejoin"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						if !Forcejoin {
							Forcejoin = true
							value, _ := sjson.Set(Settings, "settings.forcejoin", true)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "forcejoin enabled.")
						} else {
							Tcm = append(Tcm, "forcejoin already enabled.")
						}
					} else if hi == "off" || hi == "0" {
						if Forcejoin {
							Forcejoin = false
							value, _ := sjson.Set(Settings, "settings.forcejoin", false)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "forcejoin disabled.")
						} else {
							Tcm = append(Tcm, "forcejoin already disabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "nukejoin")) {
					ha := strings.Split(txt, GetCommand(grades, "nukejoin"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						if !Nukejoin {
							Nukejoin = true
							value, _ := sjson.Set(Settings, "settings.nukejoin", true)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Nukejoin enabled.")
						} else {
							Tcm = append(Tcm, "Nukejoin already enabled.")
						}
					} else if hi == "off" || hi == "0" {
						if Nukejoin {
							Nukejoin = false
							value, _ := sjson.Set(Settings, "settings.nukejoin", false)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Nukejoin disabled.")
						} else {
							Tcm = append(Tcm, "Nukejoin already disabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "allowban")) {
					ha := strings.Split(txt, GetCommand(grades, "allowban"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						if !AllowBan {
							AllowBan = true
							value, _ := sjson.Set(Settings, "settings.allowban", true)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "AllowBan enabled.")
						} else {
							Tcm = append(Tcm, "AllowBan already enabled.")
						}
					} else if hi == "off" || hi == "0" {
						if AllowBan {
							AllowBan = false
							value, _ := sjson.Set(Settings, "settings.allowban", false)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Allowban disabled.")
						} else {
							Tcm = append(Tcm, "Allowban already disabled.")
						}
					}
				} else if txt == GetCommand(grades, "mutes") {
					var str = "Mutelist"
					if len(Mute) != 0 {
						client.SendTextMentionByListLINE(to, str, Mute)
					} else {
						client.SendMessage(to, "Mutelist is empty.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "mute")) {
					if MentionMsg != nil {
						addc := []string{}
						for _, target := range MentionMsg {
							if !Contains(Mute, target) {
								Mute = append(Mute, target)
								Upset("status", "mute", target)
								addc = append(addc, target)
							}
						}
						if len(addc) != 0 {
							client.SendTextMentionByListLINE(to, "Added to mute list", addc)
							logAccess(client, to, msg.From_, "mute", addc, int32(msg.ToType))
						} else {
							client.SendMessage(to, "User have higher grade or exist in mutelist.")
						}

					} else {
						ha := strings.Split(txt, GetCommand(grades, "mute"))
						hi := StripOut(ha[1])
						if hi == "group" {
							addc := []string{}
							mem := client.GetGroupMember(to)
							for target := range mem {
								if !Contains(Mute, target) && MemUser(to, target) {
									Mute = append(Mute, target)
									Upset("status", "mute", target)
									addc = append(addc, target)
								}
							}
							if len(addc) != 0 {
								client.SendTextMentionByListLINE(to, "Added to mutelist", addc)
								logAccess(client, to, msg.From_, "mute", addc, int32(msg.ToType))
							} else {
								client.SendMessage(to, "User have higher grade or exist in Owner list.")
							}
						} else if hi == "pending" {
							addc := []string{}
							_, mem, _ := client.FCKGetMember(to)
							for _, target := range mem {
								if !Contains(Mute, target) && MemUser(to, target) {
									Mute = append(Mute, target)
									Upset("status", "mute", target)
									addc = append(addc, target)
								}
							}
							if len(addc) != 0 {
								client.SendTextMentionByListLINE(to, "Added to mutelist", addc)
								logAccess(client, to, msg.From_, "mute", addc, int32(msg.ToType))
							} else {
								client.SendMessage(to, "User have higher grade or exist in Owner list.")
							}
						} else {
							_, targets := gCon(client, to, hi, grades)
							if len(targets) != 0 {
								addc := []string{}
								for _, target := range targets {
									if !Contains(Mute, target) {
										Mute = append(Mute, target)
										Upset("status", "mute", target)
										addc = append(addc, target)
									}
								}
								if len(addc) != 0 {
									client.SendTextMentionByListLINE(to, "Added to mutelist", addc)
									logAccess(client, to, msg.From_, "mute", addc, int32(msg.ToType))
								} else {
									client.SendMessage(to, "User have higher grade or exist in Owner list.")
								}
							} else {
								Addmute = true
								timeabort = time.Now()
								client.SendMessage(to, "send the contact")
							}
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "unmute")) {
					if MentionMsg == nil {
						ha := strings.Split(msg.Text, GetCommand(grades, "unmute")+" ")
						haj := ha[1]
						if haj == "group" {
							lisa := []string{}
							mem := client.GetGroupMember(to)
							for wong := range mem {
								if Contains(Mute, wong) {
									Mute = Remove(Mute, wong)
									Delset("status", "mute", wong)
									lisa = append(lisa, wong)
								}
							}
							if len(lisa) != 0 {
								client.SendTextMentionByListLINE(to, "Deleted from mutelist", lisa)
								logAccess(client, to, msg.From_, "unmute", lisa, int32(msg.ToType))
							}
						} else if haj == "pending" {
							lisa := []string{}
							_, mem, _ := client.FCKGetMember(to)
							for _, wong := range mem {
								if Contains(Mute, wong) {
									Mute = Remove(Mute, wong)
									Delset("status", "mute", wong)
									lisa = append(lisa, wong)
								}
							}
							if len(lisa) != 0 {
								client.SendTextMentionByListLINE(to, "Deleted from mutelist", lisa)
								logAccess(client, to, msg.From_, "unmute", lisa, int32(msg.ToType))
							}
						} else {
							_, wongs := gCon(client, to, haj, grades)
							if len(wongs) == 0 {
								lisa := []string{}
								hapuss := Archimed(haj, Mute)
								for _, wong := range hapuss {
									Mute = Remove(Mute, wong)
									Delset("status", "mute", wong)
									lisa = append(lisa, wong)
								}
								if len(lisa) != 0 {
									client.SendTextMentionByListLINE(to, "Deleted from mutelist", lisa)
									logAccess(client, to, msg.From_, "unmute", lisa, int32(msg.ToType))
								}
							} else {
								lisa := []string{}
								for _, wong := range wongs {
									Mute = Remove(Mute, wong)
									Delset("status", "mute", wong)
									lisa = append(lisa, wong)
								}
								if len(lisa) != 0 {
									client.SendTextMentionByListLINE(to, "Deleted from mutelist", lisa)
									logAccess(client, to, msg.From_, "unmute", lisa, int32(msg.ToType))
								}
							}
						}

					} else {
						lisa := []string{}
						for _, wong := range MentionMsg {
							Mute = Remove(Mute, wong)
							Delset("status", "mute", wong)
							lisa = append(lisa, wong)
						}
						if len(lisa) != 0 {
							client.SendTextMentionByListLINE(to, "Deleted from mutelist", lisa)
							logAccess(client, to, msg.From_, "unmute", lisa, int32(msg.ToType))
						}
					}
				} else if txt == GetCommand(grades, "clearmute") {
					jum := Mute
					Mute = []string{}
					str := fmt.Sprintf("Cleared %v User.", len(jum))
					client.SendMessage(to, str)
					logAccess(client, to, msg.From_, "clearmute", jum, int32(msg.ToType))
				} else if txt == GetCommand(grades, "nukeall") {
					if msg.ToType != 2 {
						client.SendMessage(to, "This command is only available in group.")
						return
					}
					client.GetSquad(to)
					room := GetRoom(to)
					NukeAllJS(client, to, false, room.Bot, "", room)
				} else if txt == GetCommand(grades, "destructive") {
					if msg.ToType != 2 {
						client.SendMessage(to, "This command is only available in group.")
						return
					}
					opoed := []string{}
					for _, gt := range Client {
						if gt.Limiter {
							opoed = append(opoed, gt.Mid)
						}
					}
					//client.BantaiGroup(to, false, opoed, "", room, "30")

				} else if strings.HasPrefix(txt, GetCommand(grades, "jointicket")) {
					ha := strings.Split(txt, GetCommand(grades, "jointicket"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						if !JoinTicket {
							JoinTicket = true
							value, _ := sjson.Set(Settings, "settings.jointicket", true)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Allow joinTicKet enabled.")
						} else {
							Tcm = append(Tcm, "Allow joinTicKet enabled.")
						}
					} else if hi == "off" || hi == "0" {
						if JoinTicket {
							JoinTicket = false
							value, _ := sjson.Set(Settings, "settings.jointicket", false)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Deny joinTicKet enabled.")
						} else {
							Tcm = append(Tcm, "Deny joinTicKet enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "antitag")) {
					ha := strings.Split(txt, GetCommand(grades, "antitag"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						if !Antitag {
							Antitag = true
							value, _ := sjson.Set(Settings, "settings.antitag", true)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Allow antitag enabled.")
						} else {
							Tcm = append(Tcm, "Allow antitag enabled.")
						}
					} else if hi == "off" || hi == "0" {
						if Antitag {
							Antitag = false
							value, _ := sjson.Set(Settings, "settings.antitag", false)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Deny antitag enabled.")
						} else {
							Tcm = append(Tcm, "Deny antitag enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "autocban")) {
					ha := strings.Split(txt, GetCommand(grades, "autocban"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						if !Autocban {
							Autocban = true
							value, _ := sjson.Set(Settings, "settings.autocban", true)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Allow autocban enabled.")
						} else {
							Tcm = append(Tcm, "Allow autocban enabled.")
						}
					} else if hi == "off" || hi == "0" {
						if Autocban {
							Autocban = false
							value, _ := sjson.Set(Settings, "settings.autocban", false)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Deny autocban enabled.")
						} else {
							Tcm = append(Tcm, "Deny autocban enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "stnuke")) {
					ha := strings.Split(txt, GetCommand(grades, "stnuke"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						if !Staynuke {
							Staynuke = true
							value, _ := sjson.Set(Settings, "settings.staynuke", true)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Allow stnuke enabled.")
						} else {
							Tcm = append(Tcm, "Allow stnuke enabled.")
						}
					} else if hi == "off" || hi == "0" {
						if Staynuke {
							Staynuke = false
							value, _ := sjson.Set(Settings, "settings.staynuke", false)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Deny stnuke enabled.")
						} else {
							Tcm = append(Tcm, "Deny stnuke enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "autopurge")) {
					ha := strings.Split(txt, GetCommand(grades, "autopurge"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						if !Purge {
							Purge = true
							value, _ := sjson.Set(Settings, "settings.purge", true)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Allow autopurge enabled.")
						} else {
							Tcm = append(Tcm, "Allow autopurge enabled.")
						}
					} else if hi == "off" || hi == "0" {
						if Purge {
							Purge = false
							value, _ := sjson.Set(Settings, "settings.purge", false)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Deny autopurge enabled.")
						} else {
							Tcm = append(Tcm, "Deny autopurge enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "setlogo")) {
					var str string
					su := GetCommand(grades, "setlogo")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					value, _ := sjson.Set(Settings, "team_logo", str)
					Settings = value
					JsonDump(true, JsonFile, Settings)
					Logo = str
					Tcm = append(Tcm, "Success change logo to "+str)
				} else if strings.HasPrefix(txt, GetCommand(grades, "seticon")) {
					var str string
					su := GetCommand(grades, "seticon")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					value, _ := sjson.Set(Settings, "team_icon", str)
					Settings = value
					JsonDump(true, JsonFile, Settings)
					TeamIcon = str
					Tcm = append(Tcm, "Success change icon to "+str)
				} else if strings.HasPrefix(txt, GetCommand(grades, "seturl")) {
					var str string
					su := GetCommand(grades, "seturl")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					value, _ := sjson.Set(Settings, "team_url", str)
					Settings = value
					JsonDump(true, JsonFile, Settings)
					TeamUrl = str
					Tcm = append(Tcm, "Success change url to "+str)
				} else if strings.HasPrefix(txt, GetCommand(grades, "ctoken")) {
					var str string
					su := GetCommand(grades, "ctoken")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					randInt1 := fmt.Sprintf(ANDROID_DEVICE, rand.Intn(999-100))
					tcr := SettingConnection(LINE_HOST_DOMAIN, str, randInt1, 0)
					client.UpdateChatQrByte(to, false)
					ti := client.ReissueChatTicket(to)
					LINE := tcr.AcceptGroupInvitationByTicket(to, ti)
					if LINE != nil {
						client.SendMessage(to, "Token Banned")
					} else {
						tcr.SendMessage(to, tcr.AuthToken)
						nm := []string{}
						tempgroup = []string{}
						no := 1
						gr, _ := tcr.GetGroupIdsJoined()
						for _, a := range gr {
							if !Contains(tempgroup, a) {
								tempgroup = append(tempgroup, a)
								name, mm := tcr.GetGroupName(a)
								name = fmt.Sprintf("%v. %s #%v", no, name, len(mm))
								nm = append(nm, name)
								no++
							}
						}
						stf := "Group list:\n\n"
						str := strings.Join(nm, "\n")
						tcr.SendMessage(to, stf+str)
						tcr.DeleteSelfFromChat(to)
					}
					client.UpdateChatQrByte(to, true)
				} else if strings.HasPrefix(txt, GetCommand(grades, "gentoken")) {
					var str string
					su := GetCommand(grades, "gentoken")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					client.SendMessage(to, "AuthKey:\n"+str+"\n\nAuthToken:\n"+generateIOSToken(str))
					if len(str) == 33 {
						client.SendContact(to, str[:33])
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "addtoken")) {
					var str string
					su := GetCommand(grades, "addtoken")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					Len := []string{}
					for _, ir := range gjson.Get(Settings, "authTokenPrimari").Array() {
						token := ir.String()
						Len = append(Len, token)
					}
					Tok := len(Len)
					s := fmt.Sprintf("%v", Tok)
					if InArray2(Len, str) {
						client.SendMessage(to, "Token Already")
					} else {
						Data,_ := sjson.Set(Settings, "authTokenPrimari."+s, str)
						Settings = Data
						JsonDump(true, JsonFile, Settings)
						client.SendMessage(to, "Success addtoken")
						UpdateSetString("mid_restart", to)
						autorestart.RestartByExec()
					}
				} else if txt == GetCommand(grades, "ctokenv2") {
					randInt1 := fmt.Sprintf(ANDROID_DEVICE, rand.Intn(999-100))
					client.UpdateChatQrByte(to, false)
					ti := client.ReissueChatTicket(to)
					for x, tok := range TokenCek {
						tcr := SettingConnection(LINE_HOST_DOMAIN, tok, randInt1, x)
						LINE := tcr.AcceptGroupInvitationByTicket(to, ti)
						if LINE != nil {
							client.SendMessage(to, "Token Banned")
						} else {
							tcr.SendMessage(to, tcr.AuthToken)
							nm := []string{}
							tempgroup = []string{}
							no := 1
							gr, _ := tcr.GetGroupIdsJoined()
							for _, a := range gr {
								if !Contains(tempgroup, a) {
									tempgroup = append(tempgroup, a)
									name, mm := tcr.GetGroupName(a)
									name = fmt.Sprintf("%v. %s #%v", no, name, len(mm))
									nm = append(nm, name)
									no++
								}
							}
							stf := "Group list:\n\n"
							str := strings.Join(nm, "\n")
							tcr.SendMessage(to, stf+str)
							tcr.DeleteSelfFromChat(to)
						}
					}
					client.UpdateChatQrByte(to, true)
				} else if txt == GetCommand(grades, "ctokenv1") {
					client.UpdateChatQrByte(to, false)
					ti := client.ReissueChatTicket(to)
					for x, tok := range TokenRead {
						tcr := SettingConnection(LINE_HOST_DOMAIN, tok, ANDROID_DEVICE, x)
						LINE := tcr.AcceptGroupInvitationByTicket(to, ti)
						if LINE != nil {
							client.SendMessage(to, "Token Banned")
						} else {
							tcr.SendMessage(to, tcr.AuthToken)
						}
					}
					client.UpdateChatQrByte(to, true)
				} else if strings.HasPrefix(txt, GetCommand(grades, "setname")) {
					var str string
					su := GetCommand(grades, "setname")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					value, _ := sjson.Set(Settings, "team_name", str)
					Settings = value
					Sflag = str
					JsonDump(true, JsonFile, Settings)
					Tcm = append(Tcm, "Success change name team to "+str)
				} else if strings.HasPrefix(txt, GetCommand(grades, "killmode")) {
					ha := strings.Split(txt, GetCommand(grades, "killmode"))
					hi := StripOut(ha[1])

					kmo := []string{"purge", "random", "off", "range", "kill"} //"kill",
					if Contains(kmo, hi) {
						if hi != "off" {
							Killmode = hi
							Tcm = append(Tcm, fmt.Sprintf("Killmode state : %s\nEnabled.", hi))
						} else {
							Killmode = "none"
							Detectjoin.User = []string{}
							Detectjoin.Time = []int64{}
							Tcm = append(Tcm, "Killmode disabled.")
						}
						value, _ := sjson.Set(Settings, "settings.kill", hi)
						Settings = value
						JsonDump(true, JsonFile, Settings)
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "setmode")) {
					ha := strings.Split(txt, GetCommand(grades, "setmode"))
					hi := StripOut(ha[1])
					kmo := []string{"invite", "random", "qr"} //"kill",
					if Contains(kmo, hi) {
						Mode = hi
						Tcm = append(Tcm, fmt.Sprintf("Backup mode set: %s.", hi))
						value, _ := sjson.Set(Settings, "settings.mode", hi)
						Settings = value
						JsonDump(true, JsonFile, Settings)
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "template1")) {
					ha := strings.Split(txt, GetCommand(grades, "template1"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						FlexMode1 = true
						FlexMode2 = false
						FooterLINE = false
						value, _ := sjson.Set(Settings, "settings.template1", true)
						Settings = value
						JsonDump(true, JsonFile, Settings)
						value2, _ := sjson.Set(Settings, "settings.template2", false)
						Settings = value2
						JsonDump(true, JsonFile, Settings)
						value1, _ := sjson.Set(Settings, "settings.footer", false)
						Settings = value1
						JsonDump(true, JsonFile, Settings)
						Tcm = append(Tcm, "Template on.")
					} else if hi == "off" || hi == "0" {
						FlexMode1 = false
						FlexMode2 = false
						FooterLINE = false
						value, _ := sjson.Set(Settings, "settings.template1", false)
						Settings = value
						JsonDump(true, JsonFile, Settings)
						value2, _ := sjson.Set(Settings, "settings.template2", false)
						Settings = value2
						JsonDump(true, JsonFile, Settings)
						value1, _ := sjson.Set(Settings, "settings.footer", false)
						Settings = value1
						JsonDump(true, JsonFile, Settings)
						Tcm = append(Tcm, "Template off.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "template2")) {
					ha := strings.Split(txt, GetCommand(grades, "template2"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						FlexMode1 = false
						FlexMode2 = true
						FooterLINE = false
						value, _ := sjson.Set(Settings, "settings.template1", false)
						Settings = value
						JsonDump(true, JsonFile, Settings)
						value2, _ := sjson.Set(Settings, "settings.template2", true)
						Settings = value2
						JsonDump(true, JsonFile, Settings)
						value1, _ := sjson.Set(Settings, "settings.footer", false)
						Settings = value1
						JsonDump(true, JsonFile, Settings)
						Tcm = append(Tcm, "Template on.")
					} else if hi == "off" || hi == "0" {
						FlexMode1 = false
						FlexMode2 = false
						FooterLINE = false
						value, _ := sjson.Set(Settings, "settings.template1", false)
						Settings = value
						JsonDump(true, JsonFile, Settings)
						value2, _ := sjson.Set(Settings, "settings.template2", false)
						Settings = value2
						JsonDump(true, JsonFile, Settings)
						value1, _ := sjson.Set(Settings, "settings.footer", false)
						Settings = value1
						JsonDump(true, JsonFile, Settings)
						Tcm = append(Tcm, "Template off.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "footer")) {
					ha := strings.Split(txt, GetCommand(grades, "footer"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						FlexMode1 = false
						FlexMode2 = false
						FooterLINE = true
						value, _ := sjson.Set(Settings, "settings.footer", true)
						Settings = value
						JsonDump(true, JsonFile, Settings)
						value1, _ := sjson.Set(Settings, "settings.template", false)
						Settings = value1
						JsonDump(true, JsonFile, Settings)
						Tcm = append(Tcm, "Footer on.")
					} else if hi == "off" || hi == "0" {
						FlexMode1 = false
						FlexMode2 = false
						FooterLINE = false
						value, _ := sjson.Set(Settings, "settings.footer", false)
						Settings = value
						JsonDump(true, JsonFile, Settings)
						value1, _ := sjson.Set(Settings, "settings.template", false)
						Settings = value1
						JsonDump(true, JsonFile, Settings)
						Tcm = append(Tcm, "Footer off.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "modefont")) {
					ha := strings.Split(txt, GetCommand(grades, "modefont"))
					hi := StripOut(ha[1])
					if hi == "1" {
						ModeFont1 = true
						ModeFont2 = false
						ModeFont3 = false
						ModeFont4 = false
						ModeFont5 = false
						ModeFont6 = false
						ModeFont7 = false
						Tcm = append(Tcm, "Font mode 1 on.")
					} else if hi == "2" {
						ModeFont1 = false
						ModeFont2 = true
						ModeFont3 = false
						ModeFont4 = false
						ModeFont5 = false
						ModeFont6 = false
						ModeFont7 = false
						Tcm = append(Tcm, "Font mode 2 on.")
					} else if hi == "3" {
						ModeFont1 = false
						ModeFont2 = false
						ModeFont3 = true
						ModeFont4 = false
						ModeFont5 = false
						ModeFont6 = false
						ModeFont7 = false
						Tcm = append(Tcm, "Font mode 3 on.")
					} else if hi == "4" {
						ModeFont1 = false
						ModeFont2 = false
						ModeFont3 = false
						ModeFont4 = true
						ModeFont5 = false
						ModeFont6 = false
						ModeFont7 = false
						Tcm = append(Tcm, "Font mode 4 on.")
					} else if hi == "5" {
						ModeFont1 = false
						ModeFont2 = false
						ModeFont3 = false
						ModeFont4 = false
						ModeFont5 = true
						ModeFont6 = false
						ModeFont7 = false
						Tcm = append(Tcm, "Font mode 5 on.")
					} else if hi == "6" {
						ModeFont1 = false
						ModeFont2 = false
						ModeFont3 = false
						ModeFont4 = false
						ModeFont5 = false
						ModeFont6 = true
						ModeFont7 = false
						Tcm = append(Tcm, "Font mode 6 on.")
					} else if hi == "7" {
						ModeFont1 = false
						ModeFont2 = false
						ModeFont3 = false
						ModeFont4 = false
						ModeFont5 = false
						ModeFont6 = false
						ModeFont7 = true
						Tcm = append(Tcm, "Font mode 7 on.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "autopro")) {
					ha := strings.Split(txt, GetCommand(grades, "autopro"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "1" {
						if !Autopro {
							Autopro = true
							value, _ := sjson.Set(Settings, "settings.autopro", true)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Allow autopro enabled.")
						} else {
							Tcm = append(Tcm, "Allow autopro enabled.")
						}
					} else if hi == "off" || hi == "0" {
						if Autopro {
							Autopro = false
							value, _ := sjson.Set(Settings, "settings.autopro", false)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							Tcm = append(Tcm, "Deny autopro enabled.")
						} else {
							Tcm = append(Tcm, "Deny autopro enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "setlimit")) {
					nums := strings.Split(txt, GetCommand(grades, "setlimit"))
					st := nums[1]
					st = StripOut(st)
					numb, err := strconv.Atoi(st)
					value, _ := sjson.Set(Settings, "limiter", numb)
					Settings = value
					JsonDump(true, JsonFile, Settings)
					Batasan = numb
					if err != nil {
						client.SendMessage(to, "Please input the right number.")
					} else {
						client.SendMessage(to, "Limit kick set to "+st)
					}
				} else if txt == GetCommand(grades, "gojoin") {
					_, mem, _ := client.FCKGetMember(to)
					anu := []string{}
					for _, m := range mem {
						if Contains(Squad, m) {
							anu = append(anu, m)
						}
					}
					if len(anu) != 0 {
						for _, mid := range anu {
							cl := GetKorban(mid)
							go cl.AcceptChatInvitation(to)
							GetRoom(to).ConvertGo(cl)
						}
					} else {
						client.SendMessage(to, "Any squad on group invitation.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "go")) {
					nums := strings.Split(txt, GetCommand(grades, "go"))
					if txt == GetCommand(grades, "go") {
						list := append([]*LineClient{}, room.Client...)
						sort.Slice(list, func(i, j int) bool {
							return list[i].KickPoint > list[j].KickPoint
						})

						for n, o := range list {
							if n < 2 {
								o.DeleteSelfFromChat(to)
								GetRoom(to).RevertGo(o)
							} else {
								break
							}
						}
						room := GetRoom(to)
						cls := room.Client
						no := 0
						i := 0
						for _, mid := range room.GoMid {
							if i > 2 {
								if len(cls) == 1 {
									break
								}
								no++
								if no > len(cls) {
									break
								}
								i = 0
							}
							cls[no].InviteIntoChats(to, []string{mid})
							i++
						}

					} else {
						st := nums[1]
						st = StripOut(st)
						numb, err := strconv.Atoi(st)
						if err == nil {
							list := append([]*LineClient{}, room.Client...)
							sort.Slice(list, func(i, j int) bool {
								return list[i].KickPoint > list[j].KickPoint
							})

							for n, o := range list {
								if n < numb {
									o.DeleteSelfFromChat(to)
									GetRoom(to).RevertGo(o)
								} else {
									break
								}
							}
							room := GetRoom(to)
							cls := room.Cans()
							no := 0
							i := 0
							for _, mid := range room.GoMid {
								if i > 2 {
									if len(cls) == 1 {
										break
									}
									no++
									if no > len(cls) {
										break
									}
									i = 0
								}
								cls[no].InviteIntoChats(to, []string{mid})
								i++
							}
						}
					}
					GetSquad(client, to)
				} else if txt == GetCommand(grades, "here") {
					client.GetSquad(to)
					room := GetRoom(to)
					aa := len(room.Client)
					bb := len(room.GoMid)
					name := fmt.Sprintf("%v/%v bot's here\n%v bot's stay", aa, len(Client), bb)
					client.SendMessage(to, name)
				} else if txt == GetCommand(grades, "forceall") {
					client.UpdateChatQrByte(to, false)
					ti := client.ReissueChatTicket(to)
					var wg sync.WaitGroup
					if len(ti) < 2 {
						if len(bk) != 1 {
							for _, bot := range bk {
								if len(ti) > 2 {
									ti = bot.ReissueChatTicket(to)
									break
								}
							}
							if len(ti) < 2 {
								client.SendMessage(to, "I'm die dude.")
								return
							}
						} else {
							client.SendMessage(to, "I'm die dude.")
							return
						}
					}
					for i := 0; i < len(Client); i++ {
						l := Client[i]
						if l != client && !InArrayCl(KickBans, l) {
							wg.Add(1)
							go func() {
								l.AcceptGroupInvitationByTicket(to, ti)
								wg.Done()
							}()
						}
					}
					wg.Wait()
					client.UpdateChatQrByte(to, true)
					client.GetSquad(to)
				} else if strings.HasPrefix(txt, GetCommand(grades, "stay")) {
					if IsGaccess(to, msg.From_) {
						return
					} else {
						nums := strings.Split(txt, GetCommand(grades, "stay"))
						st := nums[1]
						st = StripOut(st)
						numb, _ := strconv.Atoi(st)
						client.GetSquad(to)
						room := GetRoom(to)
						aa := len(room.Client)
						if aa > numb {
							c := aa - numb
							ca := 0
							list := append([]*LineClient{}, room.Client...)
							sort.Slice(list, func(i, j int) bool {
								return list[i].KickPoint > list[j].KickPoint
							})
							for _, o := range list {
								o.DeleteSelfFromChat(to)
								ca = ca + 1
								if ca == c {
									break
								}
							}
							client.GetSquad(to)
						} else if aa < numb {
							client.UpdateChatQrByte(to, false)
							all := []*LineClient{}
							room := GetRoom(to)
							cuk := room.Client
							for _, x := range Client {
								if !InArrayCl(cuk, x) && !InArrayCl(KickBans, x) && !InArrayCl(room.GoClient, x) {
									all = append(all, x)
								}
							}
							sort.Slice(all, func(i, j int) bool {
								return all[i].KickPoint < all[j].KickPoint
							})
							g := numb - aa
							ti := client.ReissueChatTicket(to)
							if ti == "" {
								client.SendMessage(to, "Request blocked.")
								client.UpdateChatQrByte(to, true)
								return
							}
							var wg sync.WaitGroup
							wi := client.GetSquad(to)
							for i := 0; i < len(all); i++ {
								if i == g {
									break
								}
								l := all[i]
								if l != client && !InArrayCl(wi, l) {
									wg.Add(1)
									go func() {
										l.AcceptGroupInvitationByTicket(to, ti)
										wg.Done()
									}()
								}
							}
							wg.Wait()
							client.UpdateChatQrByte(to, true)
							client.GetSquad(to)
						}
					}
				} else if txt == GetCommand(grades, "countgo") {
					GetSquad(client, to)
					room := GetRoom(to)
					aa := len(room.GoMid)
					name := fmt.Sprintf("%v/%v bot's stay mode.", aa, len(Client))
					client.SendMessage(msg.To, name)
				} else if strings.HasPrefix(txt, GetCommand(grades, "nk")) {
					Shuffle(bk)
					cl := bk[0]
					if MentionMsg != nil {
						lkick := []string{}
						for _, target := range MentionMsg {
							sim := DetectSquad(cl, to, target)
							for _, va := range sim {
								if !Contains(lkick, va) && MemUser(to, va) {
									lkick = append(lkick, va)
								}
							}
						}
						for _, target := range lkick {
							if !MemAkses(to, target) {
								go cl.DeleteOtherFromChat(to, target)
							}
						}
						logAccess(client, to, msg.From_, "kick", lkick, int32(msg.ToType))
					}
				} else if txt == GetCommand(grades, "clearban") {
					if IsGaccess(to, msg.From_) {
						return
					}
					jums := Blacklist
					Banned.ClearBan(to)
					jum := len(Blacklist)
					if jum != 0 {
						var str string
						Blacklist = []string{}
						t, r := GetRes("clearban")
						if t {
							if strings.Contains(r, "%v") {
								str = fmt.Sprintf(r, jum)
							} else {
								str = r
							}
						} else {
							str = fmt.Sprintf("Cleared %v blacklist.", jum)
						}
						client.SendTextMentionByListLINE(to, str, jums)
						//Tcm = append(Tcm, str)
						value, _ := sjson.Set(Settings, "status.blacklist", Blacklist)
						Settings = value
						JsonDump(true, JsonFile, Settings)
						logAccess(client, to, msg.From_, "clearban", jums, int32(msg.ToType))
					} else {
						Tcm = append(Tcm, "Blacklist not found")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "staff")) && txt != GetCommand(grades, "staffs") {
					if IsGaccess(to, msg.From_) {
						return
					}
					if MentionMsg != nil {
						addc := []string{}
						for _, target := range MentionMsg {
							geta := GradeKick(to, target)
							if geta < 3 {
								continue
							} else if !Contains(GlobalStaff, target) {
								GlobalStaff = append(GlobalStaff, target)
								Upset("status", "staff", target)
								addc = append(addc, target)
							}
						}
						if len(addc) != 0 {
							client.SendTextMentionByListLINE(to, "Promoted as Admin", addc)
							logAccess(client, to, msg.From_, "เพิ่มแอดมิน", addc, int32(msg.ToType))
						} else {
							client.SendMessage(to, "User have higher grade or exist in Admin list.")
						}
					} else {
						ha := strings.Split(txt, GetCommand(grades, "staff"))
						hi := StripOut(ha[1])
						_, targets := gCon(client, to, hi, grades)
						if len(targets) != 0 {
							addc := []string{}
							for _, target := range targets {
								geta := GradeKick(to, target)
								if geta < 3 {
									continue
								} else if !Contains(GlobalStaff, target) {
									GlobalStaff = append(GlobalStaff, target)
									Upset("status", "staff", target)
									addc = append(addc, target)

								}
							}
							if len(addc) != 0 {
								client.SendTextMentionByListLINE(to, "Promoted as Admin", addc)
								logAccess(client, to, msg.From_, "addstaff", addc, int32(msg.ToType))
							} else {
								client.SendMessage(to, "User have higher grade or exist in Admin list.")
							}
						} else {
							Addstaff = true
							timeabort = time.Now()
							client.SendMessage(to, "send the contact")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "delstaff")) {
					if IsGaccess(to, msg.From_) {
						return
					}
					ha := strings.Split(msg.Text, GetCommand(grades, "delstaff")+" ")
					haj := ha[1]
					_, wongs := gCon(client, to, haj, grades)
					if len(wongs) == 0 {
						hapuss := Archimed(haj, GlobalStaff)
						lisa := []string{}
						for _, wong := range hapuss {
							GlobalStaff = Remove(GlobalStaff, wong)
							Delset("status", "staff", wong)
							lisa = append(lisa, wong)
						}
						if len(lisa) != 0 {
							client.SendTextMentionByListLINE(to, "delstaff", lisa)
							logAccess(client, to, msg.From_, "delstaff", lisa, int32(msg.ToType))
						}
					} else {
						lisa := []string{}
						for _, wong := range wongs {
							if Contains(GlobalStaff, wong) {
								GlobalStaff = Remove(GlobalStaff, wong)
								Delset("status", "staff", wong)
								lisa = append(lisa, wong)
							}
						}
						if len(lisa) != 0 {
							client.SendTextMentionByListLINE(to, "delstaff", lisa)
							logAccess(client, to, msg.From_, "delstaff", lisa, int32(msg.ToType))
						} else {
							client.SendMessage(to, "User not in Admin list.")
						}
					}
				} else if txt == GetCommand(grades, "botroom") {
					grup := client.GetGroupMember(to)
					addc := []string{}
					for mid := range grup {
						if MemUser(to, mid) {
							if !Contains(Bot, mid) {
								Bot = append(Bot, mid)
								Upset("status", "bot", mid)
								addc = append(addc, mid)
							}
						}
					}
					if len(addc) == 0 {
						client.SendMessage(to, "No one added to botlist.")
					} else {
						client.SendTextMentionByListLINE(to, "Promoted as bot's", addc)
						logAccess(client, to, msg.From_, "addbot", addc, int32(msg.ToType))
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "bot")) && txt != GetCommand(grades, "bots") {
					if MentionMsg != nil {
						addc := []string{}
						for _, target := range MentionMsg {
							if !MemAkses(to, target) {
								Bot = append(Bot, target)
								Upset("status", "bot", target)
								addc = append(addc, target)
							}
						}
						if len(addc) != 0 {
							client.SendTextMentionByListLINE(to, "Promoted as bot's", addc)
							logAccess(client, to, msg.From_, "addbot", addc, int32(msg.ToType))
						} else {
							client.SendMessage(to, "User have higher grade or exist in botlist.")
						}
					} else {
						ha := strings.Split(txt, GetCommand(grades, "bot"))
						hi := StripOut(ha[1])
						_, targets := gCon(client, to, hi, grades)
						if len(targets) != 0 {
							addc := []string{}
							for _, target := range targets {
								geta := Grade(to, target)
								if geta < 4 {
									continue
								} else if !Contains(Bot, target) && !Contains(Squad, target) {
									Bot = append(Bot, target)
									Upset("status", "bot", target)
									addc = append(addc, target)
								}
							}
							if len(addc) != 0 {
								client.SendTextMentionByListLINE(to, "Promoted as bot's", addc)
								logAccess(client, to, msg.From_, "addbot", addc, int32(msg.ToType))
							} else {
								client.SendMessage(to, "User have higher grade or exist in botlist.")
							}
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "delbot")) {
					ha := strings.Split(msg.Text, GetCommand(grades, "delbot")+" ")
					haj := ha[1]
					_, targets := gCon(client, to, haj, grades)
					if len(targets) != 0 {
						lisa := []string{}
						for _, wong := range targets {
							Bot = Remove(Bot, wong)
							Delset("status", "bot", wong)
							lisa = append(lisa, wong)
						}
						if len(lisa) != 0 {
							client.SendTextMentionByListLINE(to, "Expeled from Bot", lisa)
							logAccess(client, to, msg.From_, "delbot", lisa, int32(msg.ToType))
						}

					} else {
						hapuss := Archimed(haj, Bot)
						lisa := []string{}
						for _, wong := range hapuss {
							Bot = Remove(Bot, wong)
							Delset("status", "bot", wong)
							lisa = append(lisa, wong)
						}
						if len(lisa) != 0 {
							client.SendTextMentionByListLINE(to, "Expeled from Bot", lisa)
							logAccess(client, to, msg.From_, "delbot", lisa, int32(msg.ToType))
						}

					}
				} else if txt == GetCommand(grades, "bots") {
					ls := Bot
					if len(ls) != 0 {
						client.SendTextMentionByListLINE(to, "Botlist", ls)
					} else {
						client.SendMessage(to, "Botlist is empty.")
					}
				} else if txt == GetCommand(grades, "clearwl") {
					jum := len(Whitelist)
					for _, vv := range Whitelist {
						Delset("status", "wl", vv)
					}
					Whitelist = []string{}
					str := fmt.Sprintf("Clear Whitelist %v", jum)

					client.SendMessage(to, str)
				} else if txt == GetCommand(grades, "addwl") {
					ls := Whitelist
					if len(ls) != 0 {
						client.SendTextMentionByListLINE(to, "Whitelist", ls)
					} else {
						client.SendMessage(to, "Whitelist is empty.")
					}
				} else if txt == GetCommand(grades, "banlist") {
					ls := Blacklist
					var str = "Fucklist"
					t, r := GetRes("banlist")
					if t {
						str = r
					}
					if len(ls) != 0 {
						client.SendTextMentionByListLINE(to, str, ls)
						value, _ := sjson.Set(Settings, "status.blacklist", Blacklist)
						Settings = value
						JsonDump(true, JsonFile, Settings)
					} else {
						client.SendMessage(to, fmt.Sprintf("%v is empty.", str))
					}
				} else if txt == GetCommand(grades, "wblist") {
					nm := []string{}
					for c, a := range Wordban {
						c += 1
						name := fmt.Sprintf("%v. %s", c, a)
						nm = append(nm, name)
					}
					stf := "Wordban list:\n\n"
					str := strings.Join(nm, "\n")
					if len(Wordban) != 0 {
						client.SendMessage(to, stf+str)
					} else {
						client.SendMessage(to, "Wordban is empty.")
					}
				} else if txt == GetCommand(grades, "friends") {
					for _, p := range bk {
						fl := p.GetAllContactIds()
						p.SendTextMentionByListLINE(to, "Friendlist", fl)
					}
				} else if txt == GetCommand(grades, "allfriends") {
					fl := client.GetAllContactIds()
					client.SendTextMentionByListLINE(to, "Friendlist", fl)
					tempfriend = fl
				} else if strings.HasPrefix(txt, GetCommand(grades, "setrespon")) {
					var str string
					su := GetCommand(grades, "setrespon")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					MsgRespon = str
					value, _ := sjson.Set(Settings, "respon", str)
					Settings = value
					JsonDump(true, JsonFile, Settings)
					client.SendMessage(to, "MsgRespon updated to "+str)
				} else if strings.HasPrefix(txt, GetCommand(grades, "lurkmsg")) {
					var str string
					su := GetCommand(grades, "lurkmsg")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					if str == "" {
						client.SendMessage(to, fmt.Sprintf("Lurk message:\n%s", Lurk))
					} else {
						if strings.Contains(str, "@!") {
							Lurk = str
						} else {
							Lurk = "Hi, @! \n" + str
						}
						
						value, _ := sjson.Set(Settings, "lurkmsg", Lurk)
						Settings = value
						JsonDump(true, JsonFile, Settings)
						client.SendMessage(to, "Lurk message updated to "+str)
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "uprname")) {
					str := strings.Replace(txt, GetCommand(grades, "uprname")+" ", "", 1)
					Rname = str
					rname = str
					value, _ := sjson.Set(Settings, "rname", str)
					Settings = value
					JsonDump(true, JsonFile, Settings)
					client.SendMessage(to, "Respon updated to "+str)
				} else if strings.HasPrefix(txt, GetCommand(grades, "upsname")) {
					str := strings.Replace(txt, GetCommand(grades, "upsname")+" ", "", 1)
					Sname = str
					sname = str
					value, _ := sjson.Set(Settings, "sname", str)
					Settings = value
					JsonDump(true, JsonFile, Settings)
					client.SendMessage(to, "Squad updated to "+str)
				} else if strings.HasPrefix(txt, GetCommand(grades, "addwb")) {
					str := strings.Replace(txt, GetCommand(grades, "addwb")+" ", "", 1)
					str = StripOut(str)
					if Contains(Wordban, str) {
						client.SendMessage(to, "Word is exists in list. ")
					} else {
						Wordban = append(Wordban, str)
						Upset("status", "wordban", str)
						client.SendMessage(to, fmt.Sprintf("Word %s added to wordban list. ", str))
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "delwb")) {
					str := strings.Replace(txt, GetCommand(grades, "delwb")+" ", "", 1)
					str = StripOut(str)
					if !Contains(Wordban, str) {
						client.SendMessage(to, "Word is doesn't exists in list. ")
					} else {
						Wordban = Remove(Wordban, str)
						Delset("status", "wordban", str)
						client.SendMessage(to, fmt.Sprintf("Word %s deleted from wordban list. ", str))
					}
				} else if txt == GetCommand(grades, "clearwb") {
					ls := Wordban
					jum := len(ls)
					if jum != 0 {
						for _, o := range ls {
							Delset("status", "wordban", o)
						}

						Wordban = []string{}
						str := fmt.Sprintf("Cleared %v wordban list.", jum)
						Tcm = append(Tcm, str)
					} else {
						Tcm = append(Tcm, "Word Banlist is empty.")
					}
				}

				/*Staff Commands*/
				Pangkat = "staff"
				if strings.HasPrefix(txt, GetCommand(grades, "gadmin")) && txt != GetCommand(grades, "gadmins") {
					if MentionMsg != nil {
						addc := []string{}
						for _, target := range MentionMsg {
							geta := GradeKick(to, target)
							if geta < 6 {
								continue
							} else if AddGaccess(to, target, "staff") {
								addc = append(addc, target)
							}
						}
						if len(addc) != 0 {
							client.SendTextMentionByListLINE(to, "Promoted as G-Admin", addc)
							logAccess(client, to, msg.From_, "addgstaff", addc, int32(msg.ToType))
						} else {
							client.SendMessage(to, "User have higher grade or exist in G-Admin list.")
						}

					} else {
						ha := strings.Split(txt, GetCommand(grades, "gadmin"))
						hi := StripOut(ha[1])
						_, targets := gCon(client, to, hi, grades)
						if len(targets) != 0 {
							addc := []string{}
							for _, target := range targets {
								geta := GradeKick(to, target)
								if geta < 6 {
									continue
								} else if AddGaccess(to, target, "staff") {
									addc = append(addc, target)
								}
							}
							if len(addc) != 0 {
								client.SendTextMentionByListLINE(to, "Promoted as G-Admin", addc)
								logAccess(client, to, msg.From_, "addgstaff", addc, int32(msg.ToType))
							} else {
								client.SendMessage(to, "User have higher grade or exist in G-Admin list.")
							}
						} else {
							Addgstaff = to
							timeabort = time.Now()
							client.SendMessage(to, "send the contact")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "moci")) {
					var hi string
					ha := strings.Split(txt, GetCommand(grades, "moci"))
					hi = StripOut(ha[1])
					room := GetRoom(to)
					if hi == "off" || hi == "disable" {
						if room.Lurk {
							room.Seen = []string{}
							room.Lurk = false
							Delset("settings", "lurk", to)
							client.SendMessage(msg.To, "Lurking disabled.")
						} else {
							client.SendMessage(msg.To, "Lurking already disabled.")
						}
					} else if hi == "on" || hi == "enable" {
						if !room.Lurk {
							room.Seen = []string{}
							room.Lurk = true
							Upset("settings", "lurk", to)
							client.SendMessage(to, "Lurking enabled.")
						} else {
							client.SendMessage(to, "Lurking already enabled.")
						}
					} else if hi == "reset" {
						if room.Lurk {
							room.Seen = []string{}
							client.SendMessage(to, "Lurking reseted.")
						} else {
							client.SendMessage(to, "Lurking is not active.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "lurk")) {
					var hi string
					ha := strings.Split(txt, GetCommand(grades, "lurk"))
					hi = StripOut(ha[1])
					room := GetRoom(to)
					if hi == "off" || hi == "disable" {
						if room.Lurk {
							room.Seen = []string{}
							room.Lurk = false
							Delset("settings", "lurk", to)
							client.SendMessage(msg.To, "Lurking disabled.")
						} else {
							client.SendMessage(msg.To, "Lurking already disabled.")
						}
					} else if hi == "on" || hi == "enable" {
						if !room.Lurk {
							room.Seen = []string{}
							room.Lurk = true
							Upset("settings", "lurk", to)
							client.SendMessage(to, "Lurking enabled.")
						} else {
							client.SendMessage(to, "Lurking already enabled.")
						}
					} else if hi == "reset" {
						if room.Lurk {
							room.Seen = []string{}
							client.SendMessage(to, "Lurking reseted.")
						} else {
							client.SendMessage(to, "Lurking is not active.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "invite")) && !cekpro(txt, "on") && !cekpro(txt, "off") {
					Shuffle(bk)
					if MentionMsg != nil {
						addwl(to, MentionMsg)
						no := 0
						i := 0
						for _, mid := range MentionMsg {
							if i > 2 {
								if len(bk) == 1 {
									break
								}
								no++
								if no > len(bk) {
									break
								}
								i = 0
							}
							bk[no].InviteIntoChatCheck(to, []string{mid},sender,msg.ID)
							i++
						}
						logAccess(client, to, msg.From_, "invite", MentionMsg, int32(msg.ToType))
					} else {
						sp := strings.Split(txt, " ")
						if len(sp) > 1 {
							jenis := sp[1]
							con, cons := gCon(client, to, jenis, grades)
							if con == "invalid" {
								client.SendMessage(to, "Invalid number.")
							} else if len(cons) != 0 {
								addwl(to, cons)
								no := 0
								i := 0
								for _, mid := range cons {
									if i > 2 {
										if len(bk) == 1 {
											break
										}
										no++
										if no > len(bk) {
											break
										}
										i = 0
									}
									bk[no].InviteIntoChatCheck(to, []string{mid},sender,msg.ID)
									i++
								}
							}
							logAccess(client, to, msg.From_, "invite", cons, int32(msg.ToType))
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "spamcallto")) {
					//cl := client
					cuk := strings.Split(txt, " ")
					ana := cuk[1]
					ana = StripOut(ana)
					no, _ := strconv.Atoi(ana)
					if MentionMsg != nil {
						for _, target := range MentionMsg {
							x := 0
							for ; x < no; x++ {
								time.Sleep(1 * time.Second)
								bk = room.Client
								for _, cl := range bk {
									go cl.InviteIntoGroupCall(to, []string{target})
								}
							}
							client.SendMessage(to, "Succes spam "+ana+" call")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "spamcall")) {
					nums := strings.Split(txt, GetCommand(grades, "spamcall"))
					st := nums[1]
					st = StripOut(st)
					no, err := strconv.Atoi(st)
					if err != nil {
						client.SendMessage(to, "Please input the right number.")
					} else {
						_, memlist, _ := client.GetChatListMapCek(to)
						listuser := []string{}
						for i := range memlist {
							listuser = append(listuser, i)
						}
						x := 0
						for ; x < no; x++ {
							time.Sleep(1 * time.Second)
							bk = room.Client
							for _, cl := range bk {
								go cl.InviteIntoGroupCall(to, listuser)
							}
						}
						client.SendMessage(to, "Succes spam "+st+" call")
					}
				} else if txt == GetCommand(grades, "getcall") {
					x,_ := client.GetGroupCall(to)
					if len(x.MemberMids) != 0  {
						timecall := x.Started / 1000
						i, _ := strconv.ParseInt(fmt.Sprintf("%v", timecall), 10, 64)
						tm := time.Unix(i, 0)
						ss := time.Since(tm)
						waktu := fmtDuration(ss)
						Midhost := x.HostMid
						v, _ := client.GetContact(Midhost)
						x1 := "Call started :\n\n"
						x1 += "Started By "+v.DisplayName
						x1 += fmt.Sprintf("\nCall started in: %v",waktu)
						xxx := x1+"\n\nCallers"
						client.SendTextMentionByListLINE(to, xxx, x.MemberMids)
					} else {
						client.SendMessage(to, "Nothing have group call.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "ginfo")) {
					nums := strings.Split(txt, GetCommand(grades, "ginfo"))
					st := nums[1]
					st = StripOut(st)
					numb, err := strconv.Atoi(st)
					if err != nil {
						client.SendMessage(to, "Please input the right number.")
						return
					} else {
						if len(tempgroup) == 0 {
							client.SendMessage(to, "Please input the right number\nSee group number with command groups")
							return
						}
						nim, _ := strconv.Atoi(st)
						nim = nim - 1
						if numb > 0 && numb < len(tempgroup)+1 {
							gid := tempgroup[nim]
							list := InfoGroup(client, gid)
							client.SendMessage(to, list)
						} else {
							client.SendMessage(to, "out of range")
						}
					}
				} else if txt == GetCommand(grades, "groupinfo") {
					a, _ := client.GetChats(to)
					Chat := a.Chats[0]
					t := time.Unix(Chat.CreatedTime/1000, 0)
					qq := "-- Group info --\n"
					qq += "\n * CreatedTime: " + strings.Replace(fmt.Sprintf("%v", t), " +0000 UTC", "", 1)
					qq += "\n * ChatName: " + fmt.Sprintf("%v", Chat.ChatName)
					qq += "\n * ChatMid: " + fmt.Sprintf("%v", Chat.ChatMid)
					qq += "\n * Creator: @!"
					qq += "\n * Member: " + fmt.Sprintf("%v", len(Chat.Extra.GroupExtra.MemberMids))
					qq += "\n * Pending: " + fmt.Sprintf("%v", len(Chat.Extra.GroupExtra.InviteeMids))
					client.SendMention(to, qq, []string{Chat.Extra.GroupExtra.Creator})
				} else if strings.HasPrefix(txt, GetCommand(grades, "mid")) {
					cl := client
					if MentionMsg != nil {
						ml := "Result mid:\n"
						no := 1
						for _, target := range MentionMsg {
							pr, _ := client.GetContact(target)
							name := pr.DisplayName
							ml += fmt.Sprintf("\n%v. %s \n -%s", no, name, target)
							no++
						}
						cl.SendMessage(to, ml)
					} else {
						ha := strings.Replace(txt, GetCommand(grades, "mid"), "", 1)
						hi := StripOut(ha)
						con, cons := gCon(client, to, hi, grades)
						if con == "invalid" {
							client.SendMessage(to, "Invalid number.")
						} else if len(cons) != 0 {
							ml := "Result mid:\n"
							no := 1
							for _, target := range cons {
								pr, _ := client.GetContact(target)
								name := pr.DisplayName
								ml += fmt.Sprintf("\n%v. %s \n -%s", no, name, target)
								no++
							}
							cl.SendMessage(to, ml)
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "addfriends")) {
					cl := client
					//contacts := cl.GetAllContactIds()
					if MentionMsg != nil {
						ml := "Success Add:\n"
						no := 1
						for _, target := range MentionMsg {
							contacts := cl.GetAllContactIds()
							c, err := cl.GetContact(target)
							if err == nil {
								if !slices.Contains(contacts, c.Mid) {
									time.Sleep(5 * time.Second)
									cl.LINEAddFriendGroupMember(to,target)
									pr, _ := client.GetContact(target)
									name := pr.DisplayName
									ml += fmt.Sprintf("\n%v. %s \n -%s", no, name, target)
									no++
								}
							}
						}
						cl.SendMessage(to, ml)
					} else {
						ha := strings.Replace(txt, GetCommand(grades, "addfriends"), "", 1)
						hi := StripOut(ha)
						con, cons := gCon(client, to, hi, grades)
						if con == "invalid" {
							client.SendMessage(to, "Invalid number.")
						} else if len(cons) != 0 {
							ml := "Succss Add:\n"
							no := 1
							for _, target := range cons {
								contacts := cl.GetAllContactIds()
								c, err := cl.GetContact(target)
								if err == nil {
									if !slices.Contains(contacts, c.Mid) {
										time.Sleep(5 * time.Second)
										//cl.AddFriendByMid(target)
										cl.LINEAddFriendByMidV2(to, target, msg.ID, sender)
										pr, _ := client.GetContact(target)
										name := pr.DisplayName
										ml += fmt.Sprintf("\n%v. %s \n -%s", no, name, target)
										no++
									}
								}
							}
							cl.SendMessage(to, ml)
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "leave")) {
					if txt == GetCommand(grades, "leave") {
						_, mem, _ := client.FCKGetMember(to)
						anu := []string{}
						for _, m := range mem {
							if Contains(Squad, m) {
								anu = append(anu, m)
							}
						}
						if len(anu) != 0 {
							for _, mid := range anu {
								cl := GetKorban(mid)
								cl.AcceptChatInvitation(to)
								GetRoom(to).ConvertGo(cl)
							}

						}
						GetSquad(client, to)
						room := GetRoom(to)
						bk = room.Client
						for _, cl := range bk {
							go cl.DeleteSelfFromChat(to)
						}
						for _, i := range Protected {
							if i == to {
								Protected = Remove(Protected, to)
							}
						}
						for _, i := range Logmode {
							if i == to {
								Logmode = Remove(Logmode, to)
							}
						}
						logAccess(client, to, msg.From_, "leave", MentionMsg, int32(msg.ToType))
					} else if txt != GetCommand(grades, "gleave") && txt != GetCommand(grades, "leaveallgroup") {
						anu := strings.Replace(txt, GetCommand(grades, "gleave")+" ", "", 1)
						x1 := strings.SplitAfter(anu, "")
						var gr []string
						if len(tempgroup) == 0 {
							gr, _ = client.GetGroupIdsJoined()
							tempgroup = gr
						} else {
							gr = tempgroup
						}
						for _, gid := range gr {
							name, _ := client.GetGroupName(gid)
							x2 := strings.SplitAfter(name, "")
							s := difflib.NewMatcher(x1, x2)
							q := s.Ratio()
							if q > 0.95 {
								Client := GetRoom(gid).Client
								for _, cl := range Client {
									cl.DeleteSelfFromChat(gid)
								}
								client.SendMessage(to, "Bot's leave from group "+name)
								return
							}
						}
						client.SendMessage(to, "Group "+anu+" not found.")
					}
				} else if txt == GetCommand(grades, "out") {
					for _, ym := range MentionMsg {
						if Contains(Squad, ym) {
							idx := IndexOf(Squad, ym)
							cl := Client[idx]
							go cl.DeleteSelfFromChat(to)
						}
					}
					time.Sleep(1 * time.Second)
					GetSquad(client, to)
				} else if txt == GetCommand(grades, "limitout") {
					for _, cl := range bk {
						a := cl.Checkban(to)
						if !a {
							go cl.DeleteSelfFromChat(to)
						}
					}
					time.Sleep(2 * time.Second)
					GetSquad(client, to)
				} else if strings.HasPrefix(txt, GetCommand(grades, "delgadmin")) {
					if ga, ok := CheckGaccess(to); ok {
						ha := strings.Split(msg.Text, GetCommand(grades, "delgadmin")+" ")
						haj := ha[1]
						_, wongs := gCon(client, to, haj, grades)
						if len(wongs) == 0 {
							hapuss := Archimed(haj, ga.Staff)
							lisa := []string{}
							for _, wong := range hapuss {
								ExpelGaccess(to, wong)
								lisa = append(lisa, wong)
							}
							if len(lisa) != 0 {
								client.SendTextMentionByListLINE(to, "Expeled from G-Admin", lisa)
								logAccess(client, to, msg.From_, "delgstaff", lisa, int32(msg.ToType))
							}

						} else {
							lisa := []string{}
							for _, wong := range wongs {
								if Contains(ga.Staff, wong) {
									ExpelGaccess(to, wong)
									lisa = append(lisa, wong)
								}
							}
							if len(lisa) != 0 {
								client.SendTextMentionByListLINE(to, "Expeled from G-Admin", lisa)
								logAccess(client, to, msg.From_, "delgstaff", lisa, int32(msg.ToType))
							} else {
								client.SendMessage(to, "User not in G-Admin.")
							}

						}
					} else {
						client.SendMessage(to, "Group is not have a Local Access.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "say")) {
					var str string
					su := GetCommand(grades, "say")
					if strings.HasPrefix(msg.Text, rname+" ") {
						str = strings.Replace(msg.Text, rname+" "+su+" ", "", 1)
						str = strings.Replace(str, rname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname+" ") {
						str = strings.Replace(msg.Text, sname+" "+su+" ", "", 1)
						str = strings.Replace(str, sname+" "+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, rname) {
						str = strings.Replace(msg.Text, rname+su+" ", "", 1)
						str = strings.Replace(str, rname+strings.Title(su)+" ", "", 1)
					} else if strings.HasPrefix(msg.Text, sname) {
						str = strings.Replace(msg.Text, sname+su+" ", "", 1)
						str = strings.Replace(str, sname+strings.Title(su)+" ", "", 1)
					}
					for _, p := range bk {
						p.SendMessage(to, str)
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "expel")) {
					lisa := []string{}
					if MentionMsg != nil {
						froms := GradeKick(to, msg.From_)
						for _, target := range MentionMsg {
							geta := GradeKick(to, target)
							iso := ""
							if geta > froms || Contains(Creator, msg.From_) {
								if geta < 7 {
									if Contains(Resel, target) {
										if IsGaccess(to, msg.From_) {
											return
										}
										iso = "resel"
										Delset("status", iso, target)
										Resel = Remove(Resel, target)
									}
									if Contains(Owner, target) {
										if IsGaccess(to, msg.From_) {
											return
										}
										iso = "owner"
										Delset("status", iso, target)
										Owner = Remove(Owner, target)
									}
									if Contains(Admin, target) {
										if IsGaccess(to, msg.From_) {
											return
										}
										iso = "admin"
										Delset("status", iso, target)
										Admin = Remove(Admin, target)
									}
									if Contains(GlobalStaff, target) {
										if IsGaccess(to, msg.From_) {
											return
										}
										iso = "staff"
										GlobalStaff = Remove(GlobalStaff, target)
										Delset("status", iso, target)
									}
									if Contains(Bot, target) {
										iso = "bot"
										Bot = Remove(Bot, target)
										Delset("status", iso, target)

									}
									if IsGaccess(to, target) {
										ExpelGaccess(to, target)
										iso = "Gaccess"
									}
									lisa = append(lisa, target)

								} else {
									client.SendMessage(to, "User have not access.")
								}
							} else {
								client.SendMessage(to, "Sorry, your grade is too low.")
							}
						}
					} else {
						froms := GradeKick(to, msg.From_)
						ha := strings.Split(txt, GetCommand(grades, "expel"))
						hi := StripOut(ha[1])
						_, targets := gCon(client, to, hi, grades)
						if len(targets) != 0 {
							for _, target := range targets {
								geta := GradeKick(to, target)
								iso := ""
								if geta > froms || Contains(Creator, msg.From_) {
									if geta < 7 {
										if Contains(Resel, target) {
											if IsGaccess(to, msg.From_) {
												return
											}
											iso = "resel"
											Delset("status", iso, target)
											Resel = Remove(Resel, target)
										}
										if Contains(Owner, target) {
											if IsGaccess(to, msg.From_) {
												return
											}
											iso = "owner"
											Delset("status", iso, target)
											Owner = Remove(Owner, target)
										}
										if Contains(Admin, target) {
											if IsGaccess(to, msg.From_) {
												return
											}
											iso = "admin"
											Delset("status", iso, target)
											Admin = Remove(Admin, target)
										}
										if Contains(GlobalStaff, target) {
											if IsGaccess(to, msg.From_) {
												return
											}
											iso = "staff"
											GlobalStaff = Remove(GlobalStaff, target)
											Delset("status", iso, target)
										}
										if Contains(Bot, target) {
											iso = "bot"
											Bot = Remove(Bot, target)
											Delset("status", iso, target)

										}
										if IsGaccess(to, target) {
											ExpelGaccess(to, target)
											iso = "Gaccess"
										}
										lisa = append(lisa, target)
									} else {
										client.SendMessage(to, "User isn't have access.")
									}
								} else {
									client.SendMessage(to, "Sorry, your grade is too low.")
								}
							}
						} else {
							Expelstaff = true
							client.SendMessage(to, "send contact.")
						}
					}
					if len(lisa) != 0 {
						client.SendTextMentionByListLINE(to, "User expeled from Access.", lisa)
						logAccess(client, to, msg.From_, "expel", lisa, int32(msg.ToType))
					}
				} else if txt == GetCommand(grades, "respon") {
					room := GetRoom(to)
					room.Reset()
					for _, p := range bk {
						go p.SendMessage(to, MsgRespon)
					}
				} else if txt == GetCommand(grades, "ping") {
					room := GetRoom(to)
					room.Reset()
					for _, p := range bk {
						go p.SendMessage(to, "pong")
					}
				} else if txt == GetCommand(grades, "respon") {
					room := GetRoom(to)
					room.Reset()
					client.SendMessage(to, MsgRespon)
					for _, p := range bk {
						if p.Num != 0 {
							go p.SendMessage(to, MsgRespon)
						}
					}
				} else if txt == GetCommand(grades, "clearchat") {
					for _, p := range bk {
						p.RemoveMessage(to)
					}
					client.SendMessage(to, "Done.")
				} else if strings.HasPrefix(txt, "getcoms ") {
					cuk := strings.Split(txt, " ")
					ana := cuk[1]
					cms := CekSetCMDs(ana)
					if cms == "not found" {
						client.SendMessage(to, "Command '"+ana+"' not found")
					} else {
						client.SendMessage(to, "Get coms '"+ana+"' value: "+cms)
					}
				} else if txt == GetCommand(grades, "settings") {
					stf := "〔 ✧ Settings group ✧ 〕\n"
					if Contains(ProQr, msg.To) {
						stf += "\n ✔️ Protect QR"
					} else {
						stf += "\n ✖️ Protect QR"
					}
					if Contains(ProKick, msg.To) {
						stf += "\n ✔️ Protect Kick"
					} else {
						stf += "\n ✖️ Protect Kick"
					}
					if Contains(ProInvite, msg.To) {
						stf += "\n ✔️ Protect Invite"
					} else {
						stf += "\n ✖️ Protect Invite"
					}
					if Contains(ProCancel, msg.To) {
						stf += "\n ✔️ Protect Cancel"
					} else {
						stf += "\n ✖️ Protect Cancel"
					}
					if Contains(ProJoin, msg.To) {
						stf += "\n ✔️ Protect Join"
					} else {
						stf += "\n ✖️ Protect Join"
					}
					if Contains(ProName, msg.To) {
						stf += "\n ✔️ Protect GroupName"
					} else {
					stf += "\n ✖️ Protect GroupName"
					}
					if Contains(ProCall, msg.To) {
						stf += "\n ✔️ Protect GroupCall"
					} else {
						stf += "\n ✖️ Protect GroupCall"
					}
					if Contains(ProPicture, msg.To) {
						stf += "\n ✔️ Protect GroupPicture"
					} else {
						stf += "\n ✖️ Protect GroupPicture"
					}
					if Contains(ProNote, msg.To) {
						stf += "\n ✔️ Protect GroupNote"
					} else {
						stf += "\n ✖️ Protect GroupNote"
					}
					if Contains(ProAlbum, msg.To) {
						stf += "\n ✔️ Protect GroupAlbum"
					} else {
						stf += "\n ✖️ Protect GroupAlbum"
					}
					if Contains(ProContact, msg.To) {
						stf += "\n ✔️ Protect ShareContact"
					} else {
						stf += "\n ✖️ Protect ShareContact"
					}
					if Contains(ProLinkGroup, msg.To) {
						stf += "\n ✔️ Protect ShareLink"
					} else {
						stf += "\n ✖️ Protect ShareLink"
					}
					if Contains(ProFlex, msg.To) {
						stf += "\n ✔️ Protect Flex"
					} else {
						stf += "\n ✖️ Protect Flex"
					}
					if Contains(ProFile, msg.To) {
						stf += "\n ✔️ Protect ShareFile"
					} else {
						stf += "\n ✖️ Protect ShareFile"
					}

					//stf += "" + Logo + "♡ " + Sflag + " ♡"
					client.SendMessage(msg.To, stf+"\n\n"+""+Logo+" "+Sflag+" "+Logo)
				} else if txt == GetCommand(grades, "set") {
					o, _ := host.Info()
					r, _ := api.GetRunningVersion()
					m, _ := mem.VirtualMemory()
					Gplat := fmt.Sprintf("%v", r.Platform)
					Gover := fmt.Sprintf("%v", r.Version)
					Garch := fmt.Sprintf("%v", r.Architecture)
					OS := fmt.Sprintf("%v - Ubuntu %v ", o.OS, o.PlatformVersion)
					CPU := fmt.Sprintf("%v", runtime.NumCPU())
					RAM := fmt.Sprintf("%v", m.Total)
					checking := []string{}
					stf := "〔 ✧Configuration✧ 〕 \n\n"
					if Forcejoin == true {
						stf += " ✔️ Forcejoin"
					} else {
						stf += " ✖️ Forcejoin"
					}
					if Purge == true {
						stf += "\n ✔️ Purge"
					} else {
						stf += "\n ✖️ Purge"
					}
					if AllowBan == true {
						stf += "\n ✔️ AllowBan"
					} else {
						stf += "\n ✖️ AllowBan"
					}
					if LockSet == true {
						stf += "\n ✔️ LockSet"
					} else {
						stf += "\n ✖️ LockSet"
					}
					if Forceqr == true {
						stf += "\n ✔️ Forceqr"
					} else {
						stf += "\n ✖️ Forceqr"
					}
					if Nukejoin == true {
						stf += "\n ✔️ Nukejoin"
					} else {
						stf += "\n ✖️ Nukejoin"
					}
					if Staynuke == true {
						stf += "\n ✔️ Staynuke"
					} else {
						stf += "\n ✖️ Staynuke"
					}
					if JoinTicket == true {
						stf += "\n ✔️ JoinTicket"
					} else {
						stf += "\n ✖️ JoinTicket"
					}
					if Killmode != "off" {
						na := fmt.Sprintf("\n ✔️ Killmode: %s", strings.Title(Killmode))
						checking = append(checking, na)
					} else {
						na := "\n ✖️ Killmode"
						checking = append(checking, na)
					}
					if Autopro == true {
						stf += "\n ✔️ Autopro"
					} else {
						stf += "\n ✖️ Autopro"
					}
					if Antitag == true {
						stf += "\n ✔️ Antitag"
					} else {
						stf += "\n ✖️ Antitag"
					}
					if Autocban == true {
						stf += "\n ✔️ Autoclearban"
					} else {
						stf += "\n ✖️ Autoclearban"
					}
					if Notifadd == true {
						stf += "\n ✔️ Notifadd"
					} else {
						stf += "\n ✖️ Notifadd"
					}
					naw := "\n ➽ Mode: " + strings.Title(Mode)
					checking = append(checking, naw)
					checking = append(checking, " ➽ Limiter : "+strconv.Itoa(Batasan))
					checking = append(checking, " ➽ Platfrom : " + Gplat)
					checking = append(checking, " ➽ OS : " + OS)
					checking = append(checking, " ➽ Golang : " + Gover)
					checking = append(checking, " ➽ Architecture : " + Garch)
					checking = append(checking, " ➽ CPU : " + CPU + "Core")
					checking = append(checking, " ➽ RAM : " + RAM[:1] + "Gb")
					var gin string
					if Ginvite == 0 {
						gin = "buyer"
					} else if Ginvite == 1 {
						gin = "owner"
					} else if Ginvite == 2 {
						gin = "master"
					} else if Ginvite == 3 {
						gin = "admin"
					}
					checking = append(checking, " ➽ PermInv: "+strings.Title(gin))
					str := strings.Join(checking, "\n")
					client.SendMessage(to, stf+str+"\n"+Logo+" "+Sflag+" "+Logo+"")
				} else if strings.HasPrefix(txt, GetCommand(grades, "learn")) {
					if txt == GetCommand(grades, "learn") {
						tst := "Learning Command:\n"
						num := 1
						vel := []string{}
						for _, v := range helper {
							vel = append(vel, v)
						}
						vel = append(vel, "remote")
						sort.Strings(vel)
						for _, v := range vel {
							k := getKey(v)
							_, ok := details[k]
							if ok {
								var jo string
								if num < 10 {
									jo = fmt.Sprintf("\n %v.   %s", num, v)
								} else {
									jo = fmt.Sprintf("\n %v. %s", num, v)
								}
								tst += strings.Title(jo)
								num += 1
							}
						}
						if num != 1 {
							client.SendMessage(to, tst)
						} else {
							client.SendMessage(to, "Not found any command's that's have a detail.")
						}
					} else {
						a := strings.Split(txt, " ")
						if len(a) == 2 {
							kata := a[1]
							if kata == "remote" {
								det, _ := details[kata]
								tt := fmt.Sprintf(det, rname, rname)
								client.SendMessage(to, tt)

							} else {
								k := getKey(kata)
								det, anu := details[k]
								if anu {
									tt := fmt.Sprintf(det, rname, GetCommand(0, k))
									client.SendMessage(to, tt)
								} else {
									client.SendMessage(to, "Detail not found.")
								}
							}
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "help")) {
					pang := []string{"creator", "buyer", "owner", "master", "admin"}
					sb := []string{"login selfbot"}
					buy := []string{}
					own := []string{}
					adm := []string{}
					stf := []string{}
					for k, v := range helper {
						if getPermit(k) == 0 {
							buy = append(buy, v)
						} else if getPermit(k) == 1 {
							own = append(own, v)
						} else if getPermit(k) == 2 {
							adm = append(adm, v)
						} else if getPermit(k) == 3 {
							stf = append(stf, v)
						}
					}
					if txt == GetCommand(grades, "help") {
						tst := strings.Title(fmt.Sprintf("All bot instructions:\n\n%s", GetCommand(grades, "help")+" all"))
						tst += strings.Title(fmt.Sprintf("\n%s", GetCommand(grades, "help")+" protect"))
						for _, k := range pang {
							tst += strings.Title(fmt.Sprintf("\n%s %s", GetCommand(grades, "help"), k))
						}
						tst += strings.Title(fmt.Sprintf("\n%s", GetCommand(grades, "help")+" selfbot"))
						tst += strings.Title(fmt.Sprintf("\n%s <keyword>", GetCommand(grades, "help")))
						client.SendMessage(to, tst+"\n\n"+Logo+" "+Sflag+" "+Logo+"")
						return
					} else if txt == GetCommand(grades, "help")+" all" {
						tst := ("	  「 " + Logo + " Help all's " + Logo + " 」 ")
						num := 1
						tst += "\n\n	   " + Logo + " Protect " + Logo + " "
						var vel = prohelp()
						sort.Strings(vel)
						for _, v := range vel {
							var jo string
							if grades != 0 {
								k := getKey(v)
								anu := cekLock(k)
								if anu {
									continue
								}
							}
							if num < 10 {
								jo = fmt.Sprintf("\n %v.   %s  ", num, v)
							} else {
								jo = fmt.Sprintf("\n %v. %s  ", num, v)
							}
							tst += strings.Title(jo)
							num += 1
						}
						num = 1
						tst += "\n\n	   " + Logo + " Selfbot " + Logo + " "
						vel = sb
						sort.Strings(vel)
						for _, v := range vel {
							var jo string
							if grades != 0 {
								k := getKey(v)
								anu := cekLock(k)
								if anu {
									continue
								}
							}
							if num < 10 {
								jo = fmt.Sprintf("\n %v.   %s  ", num, v)
							} else {
								jo = fmt.Sprintf("\n %v. %s ", num, v)
							}
							tst += strings.Title(jo)
							num += 1
						}
						num = 1
						tst += "\n\n		" + Logo + " Creator " + Logo + " "
						vel = own
						sort.Strings(vel)
						for _, v := range vel {
							var jo string
							if grades != 0 {
								k := getKey(v)
								anu := cekLock(k)
								if anu {
									continue
								}
							}
							if num < 10 {
								jo = fmt.Sprintf("\n %v.   %s ", num, v)
							} else {
								jo = fmt.Sprintf("\n %v. %s ", num, v)
							}
							tst += strings.Title(jo)
							num += 1
						}
						num = 1
						tst += "\n\n	   " + Logo + " Owner " + Logo + " "
						vel = buy
						sort.Strings(vel)
						for _, v := range vel {
							var jo string
							if grades != 0 {
								k := getKey(v)
								anu := cekLock(k)
								if anu {
									continue
								}
							}
							if num < 10 {
								jo = fmt.Sprintf("\n %v.   %s ", num, v)
							} else {
								jo = fmt.Sprintf("\n %v. %s ", num, v)
							}
							tst += strings.Title(jo)
							num += 1
						}
						num = 1
						tst += "\n\n		" + Logo + " Master " + Logo + " "
						vel = own
						sort.Strings(vel)
						for _, v := range vel {
							var jo string
							if grades != 0 {
								k := getKey(v)
								anu := cekLock(k)
								if anu {
									continue
								}
							}
							if num < 10 {
								jo = fmt.Sprintf("\n %v.   %s ", num, v)
							} else {
								jo = fmt.Sprintf("\n %v. %s ", num, v)
							}
							tst += strings.Title(jo)
							num += 1
						}
						num = 1
						tst += "\n\n		" + Logo + " Admin " + Logo + " "
						vel = adm
						sort.Strings(vel)
						for _, v := range vel {
							var jo string
							if grades != 0 {
								k := getKey(v)
								anu := cekLock(k)
								if anu {
									continue
								}
							}
							if num < 10 {
								jo = fmt.Sprintf("\n %v.   %s ", num, v)
							} else {
								jo = fmt.Sprintf("\n %v. %s ", num, v)
							}
							tst += strings.Title(jo)
							num += 1
						}
						num = 1
						tst += "\n\n		" + Logo + " Other " + Logo + " "
						vel = stf
						sort.Strings(vel)
						for _, v := range vel {
							var jo string
							if grades != 0 {
								k := getKey(v)
								anu := cekLock(k)
								if anu {
									continue
								}
							}
							if num < 10 {
								jo = fmt.Sprintf("\n %v.   %s ", num, v)
							} else {
								jo = fmt.Sprintf("\n %v. %s  ", num, v)
							}
							tst += strings.Title(jo)
							num += 1
						}
						client.SendMessage(to, tst+"\n\n"+Logo+" "+Sflag+" "+Logo+"")
						return
					} else if txt == GetCommand(grades, "help")+" protect" {
						tst := strings.Title("Group protection command \n")
						num := 1
						var vel = prohelp()
						sort.Strings(vel)
						for _, v := range vel {
							var jo string
							if grades != 0 {
								k := getKey(v)
								anu := cekLock(k)
								if anu {
									continue
								}
							}
							if num < 10 {
								jo = fmt.Sprintf("\n%v.   %s %s ", num, rname, v)
							} else {
								jo = fmt.Sprintf("\n%v. %s %s ", num, rname, v)
							}
							tst += strings.Title(jo)
							num += 1
						}
						client.SendMessage(to, tst+"\n\n"+Logo+" "+Sflag+" "+Logo+"")
						return
					} else if txt == GetCommand(grades, "help")+" selfbot" {
						tst := strings.Title("menu selfbot: \n")
						num := 1
						var vel = sb
						sort.Strings(vel)
						for _, v := range vel {
							var jo string
							if grades != 0 {
								k := getKey(v)
								anu := cekLock(k)
								if anu {
									continue
								}
							}
							if num < 10 {
								jo = fmt.Sprintf("\n%v.   %s %s ", num, rname, v)
							} else {
								jo = fmt.Sprintf("\n%v. %s %s ", num, rname, v)
							}
							tst += strings.Title(jo)
							num += 1
						}
						client.SendMessage(to, tst+"\n\n"+Logo+" "+Sflag+" "+Logo+"")
						return
					}
					var vel = []string{}
					for _, k := range pang {
						if txt == GetCommand(grades, "help")+" "+k {
							if k == "creator" {
								if !Contains(Creator, msg.From_) {
									break
								}
								for _, va := range crcom {
									vel = append(vel, va)
								}
							} else if k == "buyer" {
								vel = buy
							} else if k == "owner" {
								vel = own
							} else if k == "master" {
								vel = adm
							} else if k == "admin" {
								vel = stf
							}
							tst := strings.Title(fmt.Sprintf("Command %s: \n", k))
							num := 1
							sort.Strings(vel)
							for _, v := range vel {
								var jo string
								if grades != 0 {
									k := getKey(v)
									anu := cekLock(k)
									if anu {
										continue
									}
								}
								if num < 10 {
									jo = fmt.Sprintf("\n%v.   %s %s ", num, rname, v)
								} else {
									jo = fmt.Sprintf("\n%v. %s %s ", num, rname, v)
								}
								tst += strings.Title(jo)
								num += 1
							}
							client.SendMessage(to, tst+"\n\n"+Logo+" "+Sflag+" "+Logo+"")
							return
						}
					}
					word := strings.Replace(txt, GetCommand(grades, "help"), "", 1)
					word = StripOut(word)
					anu := matchall(word)
					ts := "Related Help:\n"
					n := 1
					for _, x := range anu {
						if grades != 0 {
							k := getKey(x)
							anu := cekLock(k)
							if anu {
								continue
							}
						}
						ts += strings.Title(fmt.Sprintf("\n  %s", x))
						n += 1
					}
					if n != 1 {
						client.SendMessage(to, ts)
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "keymap")) {
					var vel []string
					pang := []string{"creator", "buyer", "owner", "master", "admin"}
					buy := []string{}
					own := []string{}
					adm := []string{}
					stf := []string{}
					for k, v := range helper {
						if getPermit(k) == 0 {
							buy = append(buy, v)
						} else if getPermit(k) == 1 {
							own = append(own, v)
						} else if getPermit(k) == 2 {
							adm = append(adm, v)
						} else if getPermit(k) == 3 {
							stf = append(stf, v)
						}
					}
					if txt == GetCommand(grades, "keymap") {
						tst := strings.Title(fmt.Sprintf("all command key:\n    %s", GetCommand(grades, "keymap")+" all"))
						tst += strings.Title(fmt.Sprintf("\n\nProtect cmd key:\n    %s", GetCommand(grades, "keymap")+" protect"))
						tst += fmt.Sprintf("\n\nPermission cmd key:")
						for _, k := range pang {
							tst += strings.Title(fmt.Sprintf("\n    %s %s", GetCommand(grades, "keymap"), k))
						}
						tst += strings.Title(fmt.Sprintf("\n\nRelated key cmd:\n    %s <keyword>", GetCommand(grades, "keymap")))
						client.SendMessage(to, tst+"\n\n"+Logo+" "+Sflag+" "+Logo+"")
						return
					} else if txt == GetCommand(grades, "keymap")+" all" {
						tst := ("	  「 " + Logo + " Knowledge's " + Logo + " 」 ")
						num := 1
						tst += "\n\n	   " + Logo + " Protection " + Logo + " "
						tst += strings.Title(fmt.Sprintf("\n %v.   allow\n     %s ", 1, GetCommand(0, "allow")))
						tst += strings.Title(fmt.Sprintf("\n %v.   deny\n     %s ", 2, GetCommand(0, "deny")))
						tst += strings.Title(fmt.Sprintf("\n %v.   protect\n     %s ", 3, GetCommand(0, "protect")))
						num = 1
						tst += "\n\n	   " + Logo + " Buyer " + Logo + " "
						vel = buy
						sort.Strings(vel)
						for _, v := range vel {
							k := getKey(v)
							if grades != 0 {
								anu := cekLock(k)
								if anu {
									continue
								}
							}
							var jo string
							if num < 10 {
								jo = fmt.Sprintf("\n %v.   %s\n     %s ", num, k, v)
							} else {
								jo = fmt.Sprintf("\n %v. %s\n     %s ", num, k, v)
							}
							tst += strings.Title(jo)
							num += 1
						}
						num = 1
						tst += "\n\n		" + Logo + " Creator " + Logo + " "
						vel = own
						sort.Strings(vel)
						for _, v := range vel {
							k := getKey(v)
							if grades != 0 {
								anu := cekLock(k)
								if anu {
									continue
								}
							}
							var jo string
							if num < 10 {
								jo = fmt.Sprintf("\n %v.   %s\n     %s ", num, k, v)
							} else {
								jo = fmt.Sprintf("\n %v. %s\n     %s ", num, k, v)
							}
							tst += strings.Title(jo)
							num += 1
						}
						num = 1
						tst += "\n\n		" + Logo + " Admin " + Logo + " "
						vel = adm
						sort.Strings(vel)
						for _, v := range vel {
							k := getKey(v)
							if grades != 0 {
								anu := cekLock(k)
								if anu {
									continue
								}
							}
							var jo string
							if num < 10 {
								jo = fmt.Sprintf("\n %v.   %s\n     %s ", num, k, v)
							} else {
								jo = fmt.Sprintf("\n %v. %s\n     %s ", num, k, v)
							}
							tst += strings.Title(jo)
							num += 1
						}
						num = 1
						tst += "\n\n		" + Logo + " Admin " + Logo + " "
						vel = stf
						sort.Strings(vel)
						for _, v := range vel {
							k := getKey(v)
							if grades != 0 {
								anu := cekLock(v)
								if anu {
									continue
								}
							}
							var jo string
							if num < 10 {
								jo = fmt.Sprintf("\n %v.   %s\n     %s ", num, k, v)
							} else {
								jo = fmt.Sprintf("\n %v. %s\n     %s ", num, k, v)
							}
							tst += strings.Title(jo)
							num += 1
						}
						client.SendMessage(to, tst+"\n\n"+Logo+" "+Sflag+" "+Logo+"")
						return
					} else if txt == GetCommand(grades, "keymap")+" protect" {
						tst := strings.Title("keymap protection: \n")
						tst += strings.Title(fmt.Sprintf("\n %v.   allow\n     %s ", 1, GetCommand(0, "allow")))
						tst += strings.Title(fmt.Sprintf("\n %v.   deny\n     %s ", 2, GetCommand(0, "deny")))
						tst += strings.Title(fmt.Sprintf("\n %v.   protect\n     %s ", 3, GetCommand(0, "protect")))
						client.SendMessage(to, tst+"\n\n"+Logo+" "+Sflag+" "+Logo+"")
						return
					}
					for _, k := range pang {
						if txt == GetCommand(grades, "keymap")+" "+k {
							if k == "creator" {
								if !Contains(Creator, msg.From_) {
									break
								}
								for _, va := range crcom {
									vel = append(vel, va)
								}
							} else if k == "buyer" {
								vel = buy
							} else if k == "owner" {
								vel = own
							} else if k == "master" {
								vel = adm
							} else if k == "admin" {
								vel = stf
							}
							tst := strings.Title(fmt.Sprintf("คำสั่ง %s: \n", k))
							num := 1
							sort.Strings(vel)
							for _, v := range vel {
								k := getKey(v)
								if grades != 0 {
									anu := cekLock(k)
									if anu {
										continue
									}
								}
								var jo string
								if num < 10 {
									jo = fmt.Sprintf("\n %v.   %s\n     %s ", num, k, v)
								} else {
									jo = fmt.Sprintf("\n %v. %s\n     %s ", num, k, v)
								}
								tst += strings.Title(jo)
								num += 1
							}
							client.SendMessage(to, tst+"\n\n"+Logo+" "+Sflag+" "+Logo+"")
							return
						}
					}
					word := strings.Replace(txt, GetCommand(grades, "keymap"), "", 1)
					word = StripOut(word)
					anu := matchallKey(word)
					ts := "Related Key cmd:\n"
					n := 1
					for _, x := range anu {
						ts += strings.Title(fmt.Sprintf("\n  %s", x))
						n += 1
					}
					if n != 1 {
						client.SendMessage(to, ts)
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "proinvite")) {
					ha := strings.Split(txt, GetCommand(grades, "proinvite"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "on" {
						if !Contains(ProInvite, to) {
							ProInvite = append(ProInvite, to)
							Upset("settings", "proInvite", to)
							Tcm = append(Tcm, "Allow invite enabled.")
						} else {
							Tcm = append(Tcm, "Allow invite enabled.")
						}
					} else if hi == "off" || hi == "no" {
						if Contains(ProInvite, to) {
							ProInvite = Remove(ProInvite, to)
							Delset("settings", "proInvite", to)
							Tcm = append(Tcm, "Deny invite enabled.")
						} else {
							Tcm = append(Tcm, "Deny invite enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "proqr")) {
					ha := strings.Split(txt, GetCommand(grades, "proqr"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "on" {
						if !Contains(ProQr, to) {
							ProQr = append(ProQr, to)
							Upset("settings", "proQr", to)
							Tcm = append(Tcm, "Allow qr enabled.")
						} else {
							Tcm = append(Tcm, "Allow qr enabled.")
						}
					} else if hi == "off" || hi == "no" {
						if Contains(ProQr, to) {
							ProQr = Remove(ProQr, to)
							Delset("settings", "proQr", to)
							Tcm = append(Tcm, "Deny qr enabled.")
						} else {
							Tcm = append(Tcm, "Deny qr enabled.")
						}
					}					
				} else if strings.HasPrefix(txt, GetCommand(grades, "proalbum")) {
					ha := strings.Split(txt, GetCommand(grades, "proalbum"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "on" {
						if !Contains(ProAlbum, to) {
							ProAlbum = append(ProAlbum, to)
							Upset("settings", "proAlbum", to)
							Tcm = append(Tcm, "Allow ProAlbum enabled.")
						} else {
							Tcm = append(Tcm, "Allow ProAlbum enabled.")
						}
					} else if hi == "off" || hi == "off" {
						if Contains(ProAlbum, to) {
							ProAlbum = Remove(ProAlbum, to)
							Delset("settings", "proAlbum", to)
							Tcm = append(Tcm, "Deny ProAlbum enabled.")
						} else {
							Tcm = append(Tcm, "Deny ProAlbum enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "pronote")) {
					ha := strings.Split(txt, GetCommand(grades, "pronote"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "on" {
						if !Contains(ProNote, to) {
							ProNote = append(ProNote, to)
							Upset("settings", "proNote", to)
							Tcm = append(Tcm, "Allow ProNote enabled.")
						} else {
							Tcm = append(Tcm, "Allow ProNote enabled.")
						}
					} else if hi == "off" || hi == "off" {
						if Contains(ProNote, to) {
							ProNote = Remove(ProNote, to)
							Delset("settings", "proNote", to)
							Tcm = append(Tcm, "Deny ProNote enabled.")
						} else {
							Tcm = append(Tcm, "Deny ProNote enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "prokick")) {
					ha := strings.Split(txt, GetCommand(grades, "prokick"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "on" {
						if !Contains(ProKick, to) {
							ProKick = append(ProKick, to)
							Upset("settings", "proKick", to)
							Tcm = append(Tcm, "Allow kick enabled.")
						} else {
							Tcm = append(Tcm, "Allow kick enabled.")
						}
					} else if hi == "off" || hi == "no" {
						if Contains(ProKick, to) {
							ProKick = Remove(ProKick, to)
							Delset("settings", "proKick", to)
							Tcm = append(Tcm, "Deny kick enabled.")
						} else {
							Tcm = append(Tcm, "Deny kick enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "procancel")) {
					ha := strings.Split(txt, GetCommand(grades, "procancel"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "on" {
						if !Contains(ProCancel, to) {
							ProCancel = append(ProCancel, to)
							Upset("settings", "proCancel", to)
							Tcm = append(Tcm, "Allow cancel enabled.")
						} else {
							Tcm = append(Tcm, "Allow cancel enabled.")
						}
					} else if hi == "off" || hi == "no" {
						if Contains(ProCancel, to) {
							ProCancel = Remove(ProCancel, to)
							Delset("settings", "proCancel", to)
							Tcm = append(Tcm, "Deny cancel enabled.")
						} else {
							Tcm = append(Tcm, "Deny cancel enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "projoin")) {
					ha := strings.Split(txt, GetCommand(grades, "projoin"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "on" {
						if !Contains(ProJoin, to) {
							ProJoin = append(ProJoin, to)
							Upset("settings", "proJoin", to)
							Tcm = append(Tcm, "Allow join enabled.")
						} else {
							Tcm = append(Tcm, "Allow join enabled.")
						}
					} else if hi == "off" || hi == "no" {
						if Contains(ProJoin, to) {
							ProJoin = Remove(ProJoin, to)
							Delset("settings", "proJoin", to)
							Tcm = append(Tcm, "Deny join enabled.")
						} else {
							Tcm = append(Tcm, "Deny join enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "proname")) {
					ha := strings.Split(txt, GetCommand(grades, "proname"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "on" {
						if !Contains(ProName, to) {
							ProName = append(ProName, to)
							Upset("settings", "proName", to)
							Tcm = append(Tcm, "Allow gname enabled.")
						} else {
							Tcm = append(Tcm, "Allow gname enabled.")
						}
					} else if hi == "off" || hi == "no" {
						if Contains(ProName, to) {
							ProName = Remove(ProName, to)
							Delset("settings", "proName", to)
							Tcm = append(Tcm, "Deny gname enabled.")
						} else {
							Tcm = append(Tcm, "Deny gname enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "prolink")) {
					ha := strings.Split(txt, GetCommand(grades, "prolink"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "on" {
						if !Contains(ProLinkGroup, to) {
							ProLinkGroup = append(ProLinkGroup, to)
							Upset("settings", "proLinkGroup", to)
							Tcm = append(Tcm, "Allow linkgroup enabled.")
						} else {
							Tcm = append(Tcm, "Allow linkgroup enabled.")
						}
					} else if hi == "off" || hi == "no" {
						if Contains(ProLinkGroup, to) {
							ProLinkGroup = Remove(ProLinkGroup, to)
							Delset("settings", "proLinkGroup", to)
							Tcm = append(Tcm, "Deny linkgroup enabled.")
						} else {
							Tcm = append(Tcm, "Deny linkgroup enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "proflex")) {
					ha := strings.Split(txt, GetCommand(grades, "proflex"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "on" {
						if !Contains(ProFlex, to) {
							ProFlex = append(ProFlex, to)
							Upset("settings", "proFlex", to)
							Tcm = append(Tcm, "Allow proflex enabled.")
						} else {
							Tcm = append(Tcm, "Allow proflex enabled.")
						}
					} else if hi == "off" || hi == "no" {
						if Contains(ProFlex, to) {
							ProFlex = Remove(ProFlex, to)
							Delset("settings", "proFlex", to)
							Tcm = append(Tcm, "Deny proflex enabled.")
						} else {
							Tcm = append(Tcm, "Deny proflex enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "procontact")) {
					ha := strings.Split(txt, GetCommand(grades, "procontact"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "on" {
						if !Contains(ProContact, to) {
							ProContact = append(ProContact, to)
							Upset("settings", "proContact", to)
							Tcm = append(Tcm, "Allow procon enabled.")
						} else {
							Tcm = append(Tcm, "Allow procon enabled.")
						}
					} else if hi == "off" || hi == "off" {
						if Contains(ProContact, to) {
							ProContact = Remove(ProContact, to)
							Delset("settings", "proContact", to)
							Tcm = append(Tcm, "Deny procon enabled.")
						} else {
							Tcm = append(Tcm, "Deny procon enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "profile")) {
					ha := strings.Split(txt, GetCommand(grades, "profile"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "on" {
						if !Contains(ProFile, to) {
							ProFile = append(ProFile, to)
							Upset("settings", "proFile", to)
							Tcm = append(Tcm, "Allow profile enabled.")
						} else {
							Tcm = append(Tcm, "Allow profile enabled.")
						}
					} else if hi == "off" || hi == "off" {
						if Contains(ProFile, to) {
							ProFile = Remove(ProFile, to)
							Delset("settings", "proFile", to)
							Tcm = append(Tcm, "Deny profile enabled.")
						} else {
							Tcm = append(Tcm, "Deny profile enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "procall")) {
					ha := strings.Split(txt, GetCommand(grades, "procall"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "on" {
						if !Contains(ProCall, to) {
							ProCall = append(ProCall, to)
							Upset("settings", "proCall", to)
							Tcm = append(Tcm, "Allow procall enabled.")
						} else {
							Tcm = append(Tcm, "Allow procall enabled.")
						}
					} else if hi == "off" || hi == "off" {
						if Contains(ProCall, to) {
							ProCall = Remove(ProCall, to)
							Delset("settings", "proCall", to)
							Tcm = append(Tcm, "Deny procall enabled.")
						} else {
							Tcm = append(Tcm, "Deny procall enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "propicture")) {
					ha := strings.Split(txt, GetCommand(grades, "propicture"))
					hi := StripOut(ha[1])
					if hi == "on" || hi == "on" {
						if !Contains(ProPicture, to) {
							ProPicture = append(ProPicture, to)
							Upset("settings", "proPicture", to)
							Tcm = append(Tcm, "Allow propicture enabled.")
						} else {
							Tcm = append(Tcm, "Allow propicture enabled.")
						}
					} else if hi == "off" || hi == "off" {
						if Contains(ProPicture, to) {
							ProPicture = Remove(ProPicture, to)
							Delset("settings", "proPicture", to)
							Tcm = append(Tcm, "Deny propicture enabled.")
						} else {
							Tcm = append(Tcm, "Deny propicture enabled.")
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "protect")) {
					ha := strings.Split(txt, GetCommand(grades, "protect"))
					hi := StripOut(ha[1])
					if hi == "max" || hi == "on" {
						ProInvite = append(ProInvite, to)
						Upset("settings", "proInvite", to)
						ProCancel = append(ProCancel, to)
						Upset("settings", "proCancel", to)
						ProName = append(ProName, to)
						Upset("settings", "proName", to)
						ProKick = append(ProKick, to)
						Upset("settings", "proKick", to)
						ProCall = append(ProCall, to)
						Upset("settings", "proCall", to)
						ProNote = append(ProNote, to)
						Upset("settings", "proNote", to)
						ProAlbum = append(ProAlbum, to)
						Upset("settings", "proAlbum", to)
						ProFlex = append(ProFlex, to)
						Upset("settings", "proFlex", to)
						ProContact = append(ProContact, to)
						Upset("settings", "proContact", to)
						ProFile = append(ProFile, to)
						Upset("settings", "proFile", to)
						ProLinkGroup = append(ProLinkGroup, to)
						Upset("settings", "proLinkGroup", to)
						Tcm = append(Tcm, "Max protection enabled.")
					} else if hi == "none" || hi == "off" {
						ProInvite = Remove(ProInvite, to)
						Delset("settings", "proInvite", to)
						ProCancel = Remove(ProCancel, to)
						Delset("settings", "proCancel", to)
						ProJoin = Remove(ProJoin, to)
						Delset("settings", "proJoin", to)
						ProName = Remove(ProName, to)
						Delset("settings", "proName", to)
						ProKick = Remove(ProKick, to)
						Delset("settings", "proKick", to)
						ProCall = Remove(ProCall, to)
						Delset("settings", "proCall", to)
						ProNote = Remove(ProNote, to)
						Delset("settings", "proNote", to)
						ProAlbum = Remove(ProAlbum, to)
						Delset("settings", "proAlbum", to)
						ProContact = Remove(ProContact, to)
						Delset("settings", "proAontact", to)
						ProLinkGroup = Remove(ProLinkGroup, to)
						Delset("settings", "proLinkGroup", to)
						ProFlex = Remove(ProFlex, to)
						Delset("settings", "proFlex", to)
						ProFile = Remove(ProFile, to)
						Delset("settings", "proFile", to)
						Tcm = append(Tcm, "Max protection disable.")
					}
				} else if txt == GetCommand(grades, "cleanse") {
					go client.Bypass(to)
				} else if txt == GetCommand(grades, "ourl") {
					client.UpdateChatQrByte(to, false)
				} else if txt == GetCommand(grades, "curl") {
					client.UpdateChatQrByte(to, true)
				} else if txt == GetCommand(grades, "openqr") {
					Shuffle(bk)
					n := client
					ti := n.ReissueChatTicket(to)
					link := fmt.Sprintf("line://ti/g/%s", ti)
					client.UpdateChatQrByte(to, false)
					client.SendMessage(msg.To, link)
				} else if strings.HasPrefix(txt, GetCommand(grades, "whois")) {
					//cl := client
					x := 12
					if MentionMsg != nil {
						for _, target := range MentionMsg {
							Checklistaccess(client, to, []string{target}, x, sender)
						}
					} else {
						ha := strings.Replace(txt, GetCommand(grades, "whois"), "", 1)
						hi := StripOut(ha)
						con, cons := gCon(client, to, hi, grades)
						if con == "invalid" {
							client.SendMessage(to, "Invalid number.")
						} else if len(cons) != 0 {
							for _, target := range cons {
								Checklistaccess(client, to, []string{target}, x, sender)
							}
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "contact")) {
					cl := client
					if MentionMsg != nil {
						for _, target := range MentionMsg {
							cl.SendContact(to, target)
						}
					} else {
						ha := strings.Replace(txt, GetCommand(grades, "contact"), "", 1)
						hi := StripOut(ha)
						con, cons := gCon(client, to, hi, grades)
						if con == "invalid" {
							client.SendMessage(to, "Invalid number.")
						} else if len(cons) != 0 {
							for _, target := range cons {
								cl.SendContact(to, target)
							}
						}
					}
				} else if txt == GetCommand(grades, "botcontact") {
					for _, mid := range Squad {
						client.SendContact(to, mid)
					}
				} else if txt == GetCommand(grades, "botname") {
					for _, cl := range bk {
						if cl.Name == "" {
							pr, _ := client.GetContact(cl.Mid)
							cl.Name = pr.DisplayName
						}
						cl.SendMessage(to, cl.Name)
					}
				} else if txt == GetCommand(grades, "squadmid") {
					ts := "List Squadmid\n"
					no := 1
					for _, cl := range Client {
						if cl.Name == "" {
							pr, _ := client.GetContact(cl.Mid)
							cl.Name = pr.DisplayName
						}
						ts += fmt.Sprintf("\n%v. %s\n   %s\n", no, cl.Name, cl.Mid)
						no++
					}
					client.SendMessage(to, ts)
				} else if txt == GetCommand(grades, "abort") {
					abort()
					client.SendMessage(to, "Command aborted.")
				} else if txt == GetCommand(grades, "addme") {
					client.SendMessage(to, "Please wait..")
					addCon(to, []string{msg.From_}, sender, msg.ID)
					client.SendMessage(to, "Done.")
				} else if strings.HasPrefix(txt, GetCommand(grades, "getcon")) {
					ha := strings.Split(txt, " ")
					ty := ha[1]
					haj := ha[2]
					anu := []string{}
					if ty == "buyer" {
						anu = Resel
					} else if ty == "owner" {
						anu = Owner
					} else if ty == "master" {
						anu = Admin
					} else if ty == "group" {
						_, memlist, _ := client.GetChatList(to)
						for _, v := range memlist {
							anu = append(anu, v)
						}
					} else if ty == "banned" {
						anu = Blacklist
					} else if ty == "admin" {
						anu = GlobalStaff
					} else if ty == "gadmin" {
						if ga, ok := CheckGaccess(to); ok {
							anu = ga.Staff
						}
					}
					if len(anu) == 0 {
						client.SendMessage(msg.To, "List is empty")
					} else {
						hapuss := Archimed(haj, anu)
						for _, hapus := range hapuss {
							client.SendContact(msg.To, hapus)
						}
					}
				} else if txt == GetCommand(grades, "count") {
					for i, tp := range bk {
						n := i + 1
						nmk := fmt.Sprintf("%v", n)
						tp.SendMessage(to, nmk)
					}
				} else if txt == GetCommand(grades, "unsend") {
					for _, asu := range Client {
						asu.UnsendAllChat(to)
					}
				} else if txt == GetCommand(grades, "tagall") || txt == "mentionall" {
					bt, _ := client.GetChats(to)
					memlist := bt.Chats[0].Extra.GroupExtra.MemberMids
					i := 1
					ta := false
					no := 1
					tx := ""
					tag := []string{}
					for v := range memlist {
						cancel := string(v)
						if !ta {
							tx += "Tag All Member:\n"
							ta = true
						}
						if i < 20 {
							if no == 21 || no == 41 || no == 61 || no == 81 || no == 101 || no == 121 || no == 141 || no == 161 || no == 181 || no == 201 || no == 221 || no == 241 || no == 261 {
								tx += fmt.Sprintf("%v. @!", no)
							} else {
								tx += fmt.Sprintf("\n%v. @!", no)
							}
							no += 1
							i += 1
							tag = append(tag, cancel)
						} else {
							tag = append(tag, cancel)
							tx += fmt.Sprintf("\n%v. @!", no)
							client.SendMentionReply(to, msg.ID, tx, tag)
							tag = []string{}
							tx = ""
							i = 1
							no += 1
						}
					}
					if len(tag) != 0 {
						tx += "\n\n" + TeamName
						client.SendMentionReply(to, msg.ID, tx, tag)
					}
				} else if txt == GetCommand(grades, "access") {
					nmr := []string{}
					nm := []string{}
					nma := []string{}
					nms := []string{}
					gst := []string{}
					for c, a := range Resel {
						UniqueGrade(to, a)
						res, err := client.GetContact(a)
						if err == nil {
							name := res.DisplayName
							c += 1
							name = fmt.Sprintf("%v. %s", c, name)
							nmr = append(nmr, name)
						} else {
							Resel = Remove(Resel, a)
							Delset("status", "resel", a)
						}
					}
					for c, a := range Owner {
						UniqueGrade(to, a)
						res, err := client.GetContact(a)
						if err == nil {
							name := res.DisplayName
							c += 1
							name = fmt.Sprintf("%v. %s", c, name)
							nm = append(nm, name)
						} else {
							Owner = Remove(Owner, a)
							Delset("status", "owner", a)
						}
					}
					for d, b := range Admin {
						UniqueGrade(to, b)
						res, err := client.GetContact(b)
						if err == nil {
							name := res.DisplayName
							d += 1
							name = fmt.Sprintf("%v. %s", d, name)
							nma = append(nma, name)
						} else {
							Admin = Remove(Admin, b)
							Delset("status", "admin", b)
						}
					}
					for d, b := range GlobalStaff {
						UniqueGrade(to, b)
						res, err := client.GetContact(b)
						if err == nil {
							name := res.DisplayName
							d += 1
							name = fmt.Sprintf("%v. %s", d, name)
							nms = append(nms, name)
						} else {
							GlobalStaff = Remove(GlobalStaff, b)
							Delset("status", "staff", b)
						}
					}
					if ga, ok := CheckGaccess(to); ok {
						for d, b := range ga.Staff {
							UniqueGrade(to, b)
							res, err := client.GetContact(b)
							if err == nil {
								name := res.DisplayName
								d += 1
								name = fmt.Sprintf("%v. %s", d, name)
								gst = append(gst, name)
							} else {
								ExpelGaccess(to, b)
							}
						}
					}
					stf := "\u2699 Bot Access"
					if len(Resel) != 0 {
						stf += "\n\n\u2694 Buyer\n"
						stf += strings.Join(nmr, "\n")
					}
					if len(Owner) != 0 {
						stf += "\n\n\u2694 Owner\n"
						stf += strings.Join(nm, "\n")
					}
					if len(Admin) != 0 {
						stf += "\n\n\u2694 Master\n"
						stf += strings.Join(nma, "\n")
					}
					if len(GlobalStaff) != 0 {
						stf += "\n\n\u2694 Admin\n"
						stf += strings.Join(nms, "\n")
					}
					if ga, ok := CheckGaccess(to); ok {
						if len(ga.Staff) != 0 {
							stf += "\n\n\u2694 G-Admin\n"
							stf += strings.Join(gst, "\n")
						}
					}
					if stf == "\u2699 Bot Access" {
						client.SendMessage(to, "Bot access is empty.")
					} else {
						stf += "\n\n" + Logo + " " + Sflag + " " + Logo
						client.SendMessage(to, stf)
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "addban")) && txt != GetCommand(grades, "เช็คดำ") {
					if MentionMsg != nil {
						for _, target := range MentionMsg {
							Banned.AddGBan(target, to)
						}
						value, _ := sjson.Set(Settings, "status.blacklist", Blacklist)
						Settings = value
						JsonDump(true, JsonFile, Settings)
						client.SendTextMentionByListLINE(to, "Added to the blacklist.", MentionMsg)
					} else {
						ha := strings.Split(txt, GetCommand(grades, "addban"))
						hi := StripOut(ha[1])
						_, targets := gCon(client, to, hi, grades)
						if len(targets) > 0 {
							for _, target := range targets {
								Banned.AddGBan(target, to)
							}
							value, _ := sjson.Set(Settings, "status.blacklist", Blacklist)
							Settings = value
							JsonDump(true, JsonFile, Settings)
							client.SendTextMentionByListLINE(to, "Added to the blacklist.", targets)
						}
					}
				}
				if txt == GetCommand(grades, "offbot") {
					if IsMaster(sender) {
						for _, a := range Client {
							a.SendMessage(to, "Shutdown.")
						}
						os.Exit(1)
					}
				} else if txt == GetCommand(grades, "runtime") {
					elapsed := time.Since(startBots)
					rinku := botDuration(elapsed)
					Tcm = append(Tcm, rinku)
				} else if txt == GetCommand(grades, "bans") {
					toy := len(KickBans)
					if toy != 0 {
						Limits = map[string]time.Time{}
						memlist := []string{}
						for _, cl := range KickBans {
							memlist = append(memlist, cl.Mid)
							Limits[cl.Mid] = cl.TimeBan
						}
						ta := false
						tx := ""
						tag := []string{}
						z := len(memlist) / 20
						y := z + 1
						for i := 0; i < y; i++ {
							if !ta {
								tx += fmt.Sprintf("%s:\n", "List Bots")
								ta = true
							}
							if i == z {
								tag = memlist[i*20:]
								no := i * 20
								no += 1
								for i := 0; i < len(tag); i++ {
									iki := no + i
									var ta time.Duration
									clm := tag[i]
									cl := Mclient[clm]
									t := cl.TimeBan.Add(24 * time.Hour)
									ta = t.Sub(time.Now())
									tx += fmt.Sprintf("\n\n%v. @!\nRemaining %v", iki, fmtDurations(ta))
								}
							} else {
								tag = memlist[i*20 : (i+1)*20]
								no := i * 20
								no += 1
								for i := 0; i < len(tag); i++ {
									iki := no + i
									var ta time.Duration
									clm := tag[i]
									cl := Mclient[clm]
									t := cl.TimeBan.Add(24 * time.Hour)
									ta = t.Sub(time.Now())
									if iki < 10 {
										tx += fmt.Sprintf("\n\n%v.  @!\nRemaining %v", iki, fmtDurations(ta))
										//tx += fmt.Sprintf("\n%v.  @!", iki)
									} else {
										tx += fmt.Sprintf("\n\n%v. @!\nRemaining %v", iki, fmtDurations(ta))
										//tx += fmt.Sprintf("\n%v. @!", iki)
									}
								}
							}
							if len(tag) != 0 {
								tx += "\n\n" + Logo + Sflag + Logo
								client.SendMention(to, tx, tag)
							}
							tx = ""
						}

						value, _ := sjson.Set(Settings, "status.limits", Limits)
						Settings = value
						JsonDump(true, JsonFile, Settings)
					} else {
						Limits = map[string]time.Time{}
						value, _ := sjson.Set(Settings, "status.limits", Limits)
						Settings = value
						JsonDump(true, JsonFile, Settings)
					}
				} else if txt == GetCommand(grades, "check history") {
					tyu := "History Bot:\n"
					cc := 0
					ci := 0
					cs := 0
					kc := map[string]int{}
					ic := map[string]int{}
					for _, md := range Client {
						kc[md.Mid] = md.KickCount
						cc += md.KickCount
						ic[md.Mid] = md.InvCount
						ci += md.InvCount
						cs += md.CancelCount
						name := md.Name
						if name == "" {
							pr, _ := client.GetContact(md.Mid)
							md.Name = pr.DisplayName
							name = md.Name
						}
						tyu += fmt.Sprintf("\n\u2694 %v", name)
						tyu += fmt.Sprintf("\n  - Kick: %v", md.KickCount)
						tm := time.Now().Sub(md.Lastkick)
						tyu += fmt.Sprintf("\n     %v", fmtDurations(tm))
						tyu += fmt.Sprintf("\n  - Invt: %v", md.InvCount)
						tm = time.Now().Sub(md.Lastinvite)
						tyu += fmt.Sprintf("\n     %v", fmtDurations(tm))
						tyu += fmt.Sprintf("\n  - Canc: %v", md.CancelCount)
						tm = time.Now().Sub(md.Lastcancel)
						tyu += fmt.Sprintf("\n     %v\n", fmtDurations(tm))
					}
					tyu += fmt.Sprintf("\n\n\u2694Total \n- Kick : %v\n- Invite : %v\n- Cancel : %v", cc, ci, cs)
					client.SendMessage(to, tyu)
					Kcount = kc
					Icount = ic
					value, _ := sjson.Set(Settings, "status.kcount", kc)
					value, _ = sjson.Set(value, "status.icount", ic)
					Settings = value
					JsonDump(true, JsonFile, Settings)
				} else if strings.HasPrefix(txt, GetCommand(grades, "unban")) {
					ha := strings.Split(msg.Text, GetCommand(grades, "unban")+" ")
					haj := ha[1]
					_, wongs := gCon(client, to, haj, grades)
					if len(wongs) > 0 {
						lisa := []string{}
						for _, wong := range wongs {
							if Contains(Blacklist, wong) {
								Banned.DelBan(wong, to)
								Delset("status", "blacklist", wong)
								lisa = append(lisa, wong)
							}
						}
						if len(lisa) != 0 {
							client.SendTextMentionByListLINE(to, "Unbanned User", lisa)
							logAccess(client, to, msg.From_, "unban", lisa, int32(msg.ToType))
						} else {
							client.SendMessage(to, "User not in Blacklist.")
						}

					} else {
						hapuss := Archimed(haj, Blacklist)
						lisa := []string{}
						for _, wong := range hapuss {
							Banned.DelBan(wong, to)
							Delset("status", "blacklist", wong)
							lisa = append(lisa, wong)
						}
						if len(lisa) != 0 {
							client.SendTextMentionByListLINE(to, "Unbanned User", lisa)
							logAccess(client, to, msg.From_, "unban", lisa, int32(msg.ToType))
						}

					}
				} else if txt == GetCommand(grades, "buyers") {
					var str = "Buyer List"
					if len(Resel) != 0 {
						client.SendTextMentionByListLINE(to, str, Resel)
					} else {
						client.SendMessage(to, "The buyer list is empty.")
					}
				} else if txt == GetCommand(grades, "owners") {
					var str = "Owner List"
					if len(Owner) != 0 {
						client.SendTextMentionByListLINE(to, str, Owner)
					} else {
						client.SendMessage(to, "The owner list is empty.")
					}
				} else if txt == GetCommand(grades, "admins") {
					var str = "Admin List"
					if len(Admin) != 0 {
						client.SendTextMentionByListLINE(to, str, Admin)
					} else {
						client.SendMessage(to, "The admin list is empty.")
					}
				} else if txt == GetCommand(grades, "gstaffs") {
					var str = "G-Staff List"
					if len(GlobalStaff) != 0 {
						client.SendTextMentionByListLINE(to, str, GlobalStaff)
					} else {
						client.SendMessage(to, "The gstaff list is empty.")
					}
				} else if txt == GetCommand(grades, "gadmins") {
					var str = "G-Admin List"
					if ga, ok := CheckGaccess(to); ok {
						ak := ga.Staff
						if len(ak) != 0 {
							client.SendTextMentionByListLINE(to, str, ak)
						} else {
							client.SendMessage(to, "The gadmin list is empty.")
						}
					} else {
						client.SendMessage(to, "Group is not have a Local Access.")
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "linvite")) || strings.HasPrefix(txt, GetCommand(grades, "lmid")) || strings.HasPrefix(txt, GetCommand(grades, "ladd")) || strings.HasPrefix(txt, GetCommand(grades, "lban")) || strings.HasPrefix(txt, GetCommand(grades, "lkick")) || strings.HasPrefix(txt, GetCommand(grades, "lcancel")) || strings.HasPrefix(txt, GetCommand(grades, "lqr")) || strings.HasPrefix(txt, GetCommand(grades, "ljoin")) || strings.HasPrefix(txt, GetCommand(grades, "lleave")) || strings.HasPrefix(txt, GetCommand(grades, "ltag")) || strings.HasPrefix(txt, GetCommand(grades, "lcon")) {
					con, c := gCon(client, to, txt, grades)
					if con == "invalid" {
						client.SendMessage(to, "Invalid number.")
					} else if con == "none" || len(c) == 0 {
						client.SendMessage(to, "Waiting for contact....")
					} else {
						for _, i := range c {
							client.SendContact(msg.To, i)
						}
					}
				} else if strings.HasPrefix(txt, GetCommand(grades, "cancel")) {
					tes := strings.Replace(txt, GetCommand(grades, "cancel"), "", 1)
					tes = StripOut(tes)
					if tes == "all" {
						_, _, memlist := client.GetChatList(to)
						lkick := []string{}
						for _, v := range memlist {
							if MemUser(to, v) {
								lkick = append(lkick, v)
							}
						}
						nom := []*LineClient{}
						ilen := len(lkick)
						xx := 0
						for i := 0; i < ilen; i++ {
							if xx < len(bk) {
								nom = append(nom, bk[xx])
								xx += 1
							} else {
								xx = 0
								nom = append(nom, bk[xx])
							}
						}
						for i := 0; i < ilen; i++ {
							target := lkick[i]
							cl := nom[i]
							go cl.CancelChatInvitation(to, target)
						}
						Print("cancelall act")
						logAccess(client, to, msg.From_, "cancelall", lkick, int32(msg.ToType))
					} else {
						con, lkick := gCon(client, to, tes, grades)
						if con == "invalid" {
							client.SendMessage(to, "Invalid number.")
						} else if con != "none" {
							nom := []*LineClient{}
							ilen := len(lkick)
							xx := 0
							for i := 0; i < ilen; i++ {
								if xx < len(bk) {
									nom = append(nom, bk[xx])
									xx += 1
								} else {
									xx = 0
									nom = append(nom, bk[xx])
								}
							}
							for i := 0; i < ilen; i++ {
								target := lkick[i]
								cl := nom[i]
								go cl.CancelChatInvitation(to, target)
							}
							logAccess(client, to, msg.From_, "cancel", lkick, int32(msg.ToType))
						}
					}
				}

			}
			if len(Tcm) != 0 {
				strs := strings.Join(Tcm, "\n")
				if !silent {
					if strs != "" {
						client.SendMessage(msg.To, strs)
					}
				}
				Tcm = []string{}
			} else {
				if !Nosuggest && Suggest == 1 && len(cmds) != 0 {
					anu := TxtMatch(suggestword, gettxt(pesan, rname, sname, Mid, MentionMsg))
					if anu != "" {
						client.SendMessage(to, anu)
					}
				}
			}
		}

	} else if msg.ContentType == 1 {
		if grades < 2 {
			if cpic {
				path, err := client.DownloadObjectMsg(msg.ID, "upp")
				if err != nil {
					fmt.Println(err)
					return
				}
				for _, p := range changepic {
					p.UpdatePictureProfile(path, "p")
					p.SendMessage(to, "Profile picture updated.")
				}
				changepic = []*LineClient{}
				cpic = false
			} else if ccover {
				path, err := client.DownloadObjectMsg(msg.ID, "upp")
				if err != nil {
					fmt.Println(err)
					return
				}
				for _, p := range changepic {
					p.UpdateCover(path)
					p.SendMessage(to, "Profile cover updated.")
				}
				changepic = []*LineClient{}
				ccover = false
			}
		}
	} else if op.Message.ContentType == 16 {
		if msg.ContentMetadata["serviceType"] == "GB" && MemUser(msg.To, msg.From_) {
			if Contains(ProNote, msg.To) {
				if MemUser(msg.To, msg.From_) {
					cl := GetRoom(to).Client[0]
					cl.DeleteOtherFromChat(to, msg.From_)
					Banned.AddBan(msg.From_, msg.To)
				}
			}
		}
		if msg.ContentMetadata["locKey"] == "BA" || msg.ContentMetadata["locKey"] == "BT" {
			if Contains(ProAlbum, msg.To) {
				if MemUser(msg.To, msg.From_) {
					cl := GetRoom(to).Client[0]
					cl.DeleteOtherFromChat(to, msg.From_)
					Banned.AddBan(msg.From_, msg.To)
				}
			}
		}
	} else if op.Message.ContentType == 18 {
	    if msg.ContentMetadata["LOC_KEY"] == "BD" ||  msg.ContentMetadata["LOC_KEY"] == "BO" {
		    if Contains(ProAlbum, msg.To) {
				if MemUser(msg.To, msg.From_) {
					cl := GetRoom(to).Client[0]
					cl.DeleteOtherFromChat(to, msg.From_)
					Banned.AddBan(msg.From_, msg.To)
				}
			}
		}
	} else if msg.ContentType == 13 {
		if Addresel && Contains(Creator, msg.From_) {
			mids := msg.ContentMetadata["mid"]
			nami := msg.ContentMetadata["displayName"]
			if !Contains(Resel, mids) {
				Resel = append(Resel, mids)
				Upset("status", "resel", mids)
				if !Repeat {
					Addresel = false
				}
				client.SendMessage(to, "User "+nami+" promoted as buyer.")
				logAccess(client, to, msg.From_, "addbuyer", []string{mids}, int32(msg.ToType))
				timeabort = time.Now()
			} else {
				client.SendMessage(to, "User "+nami+" is a buyer.")
				if !Repeat {
					Addresel = false
				}
				timeabort = time.Now()
			}
		} else if Addowner && grades <= getPermit("owner") {
			mids := msg.ContentMetadata["mid"]
			nami := msg.ContentMetadata["displayName"]
			if Grade(to, mids) > 1 {
				Owner = append(Owner, mids)
				Upset("status", "owner", mids)
				if !Repeat {
					Addowner = false
				}
				timeabort = time.Now()
				client.SendMessage(to, "owner "+nami+" promoted as Owner.")
				logAccess(client, to, msg.From_, "addowner", []string{mids}, int32(msg.ToType))
			} else {
				if !Repeat {
					Addowner = false
				}
				timeabort = time.Now()
				client.SendMessage(to, "User "+nami+" have greater grade.")
			}
		} else if Addadmin && grades <= getPermit("owner") {
			mids := msg.ContentMetadata["mid"]
			nami := msg.ContentMetadata["displayName"]
			if Grade(to, mids) > 2 {
				Admin = append(Admin, mids)
				Upset("status", "admin", mids)
				if !Repeat {
					Addadmin = false
				}
				timeabort = time.Now()
				client.SendMessage(to, "owner "+nami+" promoted as Admin.")
				logAccess(client, to, msg.From_, "addadmin", []string{mids}, int32(msg.ToType))
			} else {
				if !Repeat {
					Addadmin = false
				}
				timeabort = time.Now()
				client.SendMessage(to, "User "+nami+" have greater grade.")
			}
		} else if Addstaff && grades <= getPermit("admin") {
			mids := msg.ContentMetadata["mid"]
			nami := msg.ContentMetadata["displayName"]
			if Grade(to, mids) > 2 {
				Admin = append(Admin, mids)
				Upset("status", "staff", mids)
				if !Repeat {
					Addstaff = false
				}
				timeabort = time.Now()
				client.SendMessage(to, "User "+nami+" promoted as Admin.")
				logAccess(client, to, msg.From_, "addstaff", []string{mids}, int32(msg.ToType))
			} else {
				if !Repeat {
					Addstaff = false
				}
				timeabort = time.Now()
				client.SendMessage(to, "User "+nami+" have greater grade.")
			}
		} else if Addmute && grades <= getPermit("mute") {
			mids := msg.ContentMetadata["mid"]
			nami := msg.ContentMetadata["displayName"]
			if Grade(to, mids) > 7 {
				Mute = append(Mute, mids)
				Upset("status", "mute", mids)
				if !Repeat {
					Addmute = false
				}
				timeabort = time.Now()
				client.SendMessage(to, "User "+nami+" added to mute list.")
				logAccess(client, to, msg.From_, "mute", []string{mids}, int32(msg.ToType))
			} else {
				if !Repeat {
					Addmute = false
				}
				timeabort = time.Now()
				client.SendMessage(to, "User "+nami+" have an access.")
			}
		} else if Expelstaff && GradeKick(to, msg.From_) < 7 {
			target := msg.ContentMetadata["mid"]
			froms := GradeKick(to, msg.From_)
			geta := GradeKick(to, target)
			iso := ""
			if geta > froms || Contains(Creator, msg.From_) {
				if geta < 7 {
					if Contains(Resel, target) {
						if IsGaccess(to, msg.From_) {
							return
						}
						iso = "resel"
						Delset("status", iso, target)
						Resel = Remove(Resel, target)
					}
					if Contains(Owner, target) {
						if IsGaccess(to, msg.From_) {
							return
						}
						iso = "owner"
						Delset("status", iso, target)
						Owner = Remove(Owner, target)
					}
					if Contains(Admin, target) {
						if IsGaccess(to, msg.From_) {
							return
						}
						iso = "admin"
						Delset("status", iso, target)
						Admin = Remove(Admin, target)
					}
					if Contains(GlobalStaff, target) {
						if IsGaccess(to, msg.From_) {
							return
						}
						iso = "staff"
						GlobalStaff = Remove(GlobalStaff, target)
						Delset("status", iso, target)
					}
					if Contains(Bot, target) {
						iso = "bot"
						Bot = Remove(Bot, target)
						Delset("status", iso, target)

					}
					if IsGaccess(to, target) {
						ExpelGaccess(to, target)
						iso = "Gaccess"
					}
					client.SendTextMentionByListLINE(to, "User expeled from Access.", []string{target})
					logAccess(client, to, msg.From_, "expel", []string{target}, int32(msg.ToType))

					if !Repeat {
						Expelstaff = false
					}
					timeabort = time.Now()

				} else {
					client.SendMessage(to, "User have not access.")
					if !Repeat {
						Expelstaff = false
					}
					timeabort = time.Now()
				}
			} else {
				client.SendMessage(to, "Sorry, your grade is too low.")
			}
		} else if Addban && grades <= getPermit("addban") {
			mids := msg.ContentMetadata["mid"]
			nami := msg.ContentMetadata["displayName"]
			if MemUser(to, mids) {
				Banned.AddGBan(mids, to)
				Upset("status", "blacklist", mids)
				if !Repeat {
					Addban = false
				}
				timeabort = time.Now()
				client.SendMessage(to, "User "+nami+" added to shitlist.")
				logAccess(client, to, msg.From_, "addban", []string{mids}, int32(msg.ToType))
			} else {
				if !Repeat {
					Addban = false
				}
				timeabort = time.Now()
				client.SendMessage(to, "User "+nami+" have access, please expel first.")
			}
		}
	}
}