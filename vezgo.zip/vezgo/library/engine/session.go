package engine

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
	"net/http"
	"time"
	"../LineThrift"
	LineV2 "../linetcr/line"
	thrift2 "../linetcr/thrift"
	LINERelation "../RelationService"
	LINESync "../SyncService"
	LINETalk "../TalkService"
	"../thrift"
	"fmt"
	"math/rand"
	"runtime"
)

func GetNewTransport() *http.Transport {
	t := http.DefaultTransport.(*http.Transport).Clone()
	t.MaxIdleConns = 100
	t.MaxConnsPerHost = 100
	t.MaxIdleConnsPerHost = 100
	return t
}

func (p *LineClient) setDefaultHttpClient() {
	p.Connection = &http.Client{
		Transport: &http.Transport{},
	}
}

func (self *LineClient) DefaultHeaders() map[string]string {
    var (
        appName string
        userAgent string
    )
    appName      = fmt.Sprintf(ANDROID_DEVICE, rand.Intn(999-100))
    userAgent    = fmt.Sprintf("Mozilla/5.0 (compatible; Yahoo! Slurp; http://help.yahoo.com/help/us/ysearch/slurp)")
    self.AppName, self.UserAgent = appName, userAgent
    headers := map[string]string{
        "X-Line-Application": appName,
        "User-Agent": userAgent,
        "x-lal": "en_GB",
        "x-lpv": "1",
        "x-lap": "5",
        "x-lac": "51010",
    }
    return headers
}

func CreateTransportLINE(urL string, timeout int, headers map[string]string) (*thrift.TStandardClient, error) {
    var transport thrift.TTransport
    option := thrift.THttpClientOptions{
        Client: &http.Client{
            Timeout  : time.Duration(timeout) * time.Second,
            Transport: &http.Transport{},
        },
    }
    transport, _  = thrift.NewTHttpClientWithOptions(urL, option)
    connect      := transport.(*thrift.THttpClient)
    for key, val := range headers {
        connect.SetHeader(key, val)
    }
    pcol := thrift.NewTCompactProtocolFactory().GetProtocol(transport)
    res := thrift.NewTStandardClient(pcol, pcol)
    return res, nil
}

func(self *LineClient) TalkService() *LineThrift.TalkServiceClient {
    headers := self.DefaultHeaders()
    headers["X-Line-Access"] = self.AuthToken
    transport, _ := CreateTransportLINE(self.Main_host + "/S4", 0, headers)
    return LineThrift.NewTalkServiceClient(transport)
}

/*func (p *LineClient) TalkService() *LineThrift.TalkServiceClient {
	client := p.ThriftWrapper(LINE_API_QUERY_PATH_SEC, true)
	return LineThrift.NewTalkServiceClient(client)
}*/

func (cl *LineClient) ConnectTalkS5() (res *LineV2.TalkServiceClient) {
	go runtime.Gosched()
	HTTP, _ := thrift2.NewTHttpClient(cl.Main_host + "/S5")
	transport := HTTP.(*thrift2.THttpClient)
	transport.SetHeader("user-agent", cl.UserAgent)
	transport.SetHeader("x-line-application", cl.AppName)
	transport.SetHeader("x-line-access", cl.AuthToken)
	transport.SetHeader("x-lal", "en_US")
	transport.SetHeader("x-lpv", "1")
	transport.SetHeader("content-type", "application/x-thrift")
	transport.SetHeader("accept", "application/x-thrift")
	transport.SetHeader("accept-encoding", "gzip")
	//transport.SetHeader("X-Forwarded-For", "203.0.113.7")
	transport.SetMoreCompact(true)
	setProtocol := thrift2.NewTCompactProtocolFactory()
	protocol := setProtocol.GetProtocol(transport)
	return LineV2.NewTalkServiceClientProtocol(transport, protocol, protocol)
}

//var opt      thrift.THttpClientOptions

/*func (ve *LineClient) TalkService() *LineThrift.TalkServiceClient {
	httpClient, _ := thrift.NewTHttpClientWithOptionstcr(LINE_HOST_DOMAIN+"/S4", ve.Transport, opt)
	transport := httpClient.(*thrift.THttpClient)
	transport.SetHeader("user-agent", ve.UserAgent)
	transport.SetHeader("x-line-application", ve.AppName)
	transport.SetHeader("x-line-access", ve.AuthToken)
	transport.SetHeader("x-lal", "en_US")
	transport.SetHeader("x-lpv", "1")
	transport.SetHeader("content-type", "application/x-thrift")
	transport.SetHeader("accept", "application/x-thrift")
	transport.SetHeader("accept-encoding", "gzip")
	pcol := thrift.NewTCompactProtocol(httpClient)
	tstc := thrift.NewTStandardClient(pcol, pcol)
	return LineThrift.NewTalkServiceClient(tstc)
}*/

//	func (p *LineClient) CompactMessageService() *LineThrift.CompactMessageService {
//		client := p.ThriftWrapper(LINE_API_QUERY_PATH_SEC, true)
//		return LineThrift.CompactMessageServiceClient(client)
//	}
func (p *LineClient) SettingService() *LineThrift.TalkServiceClient {
	client := p.ThriftWrapper(LINE_API_QUERY_PATH_SEC, true)
	return LineThrift.NewTalkServiceClient(client)
}

func (p *LineClient) RelationService() *LineThrift.RelationServiceClient {
	client := p.ThriftWrapper(LINE_RELATION_QUERY_PATH, true)
	return LineThrift.NewRelationServiceClient(client)
}

func (p *LineClient) LINERelationService() *LINERelation.RelationServiceClient {
	client := p.ThriftWrapper(LINE_RELATION_QUERY_PATH, true)
	return LINERelation.NewRelationServiceClient(client)
}

func (p *LineClient) LINESyncService() *LINESync.SyncServiceClient {
	client := p.ThriftWrapper(LINE_POLL_QUERY_PATH_FIR, true)
	return LINESync.NewSyncServiceClient(client)
}

func (p *LineClient) LINETalkService() *LINETalk.TalkServiceClient {
	client := p.ThriftWrapper(LINE_API_QUERY_PATH_SEC, true)
	return LINETalk.NewTalkServiceClient(client)
}

func (p *LineClient) SyncService() *LineThrift.TalkServiceClient {
	client := p.ThriftWrapper(LINE_POLL_QUERY_PATH_FIR, true)
	return LineThrift.NewTalkServiceClient(client)
}

func (p *LineClient) ChannelService() *LineThrift.ChannelServiceClient {
	client := p.ThriftWrapper(LINE_CHAN_QUERY_PATH, true)
	return LineThrift.NewChannelServiceClient(client)
}

func (p *LineClient) CallService() *LineThrift.CallServiceClient {
	client := p.ThriftWrapper(LINE_CALL_QUERY_PATH, true)
	return LineThrift.NewCallServiceClient(client)
}

func (p *LineClient) SquareService() *LineThrift.SquareServiceClient {
	client := p.ThriftWrapper(LINE_SQUARE_QUERY_PATH, true)
	return LineThrift.NewSquareServiceClient(client)
}

func (p *LineClient) LiffService() *LineThrift.LiffServiceClient {
	client := p.ThriftWrapper(LINE_LIFF_QUERY_PATH, true)
	return LineThrift.NewLiffServiceClient(client)
}
func (p *LineClient) AuthService() *LineThrift.TalkServiceClient {
	client := p.ThriftWrapper(LINE_LOGIN_QUERY_PATH, false)
	return LineThrift.NewTalkServiceClient(client)
}

func (p *LineClient) VerifyService() *LineThrift.AuthServiceClient {
	client := p.ThriftWrapper(LINE_AUTH_QUERY_PATH, true)
	return LineThrift.NewAuthServiceClient(client)
}

func (p *LineClient) LoginZService() *LineThrift.AuthServiceClient {
	client := p.ThriftWrapper(LINE_AUTH_LOGIN_QUERY_PATH, true)
	return LineThrift.NewAuthServiceClient(client)
}

func (p *LineClient) RefreshTokenService() *LineThrift.AccessTokenRefreshServiceClient {
	client := p.ThriftWrapper("/EXT/auth/tokenrefresh/v1", true)
	return LineThrift.NewAccessTokenRefreshServiceClient(client)
}

func (p *LineClient) QrService() *LineThrift.SecondaryQrCodeLoginServiceClient {
	client := p.ThriftWrapper(LINE_SQ_QUERY_PATH, false)
	return LineThrift.NewSecondaryQrCodeLoginServiceClient(client)
}

func (p *LineClient) QrVService() *LineThrift.SecondaryQrCodeLoginServiceClient {
	client := p.ThriftWrapper(LINE_SQ_VERIFY_QUERY_PATH, true)
	return LineThrift.NewSecondaryQrCodeLoginServiceClient(client)
}

func (p *LineClient) PwlessService() *LineThrift.SecondaryPwlessLoginServiceClient {
	client := p.ThriftWrapper("/acct/lgn/secpwless/v1", false)
	return LineThrift.NewSecondaryPwlessLoginServiceClient(client)
}

func (p *LineClient) PwlessVerifyService() *LineThrift.SecondaryPwlessLoginPermitNoticeServiceClient {
	client := p.ThriftWrapper("/acct/lp/lgn/secpwless/v1", true)
	return LineThrift.NewSecondaryPwlessLoginPermitNoticeServiceClient(client)
}

func (p *LineClient) PwlessPinService() *LineThrift.SecondAuthFactorPinCodeServiceClient {
	client := p.ThriftWrapper("/ACCT/authfactor/second/pincode/v1", false)
	return LineThrift.NewSecondAuthFactorPinCodeServiceClient(client)
}

func (p *LineClient) PwlessLoginService() *LineThrift.SecondaryPwlessLoginPermitServiceClient {
	client := p.ThriftWrapper("/ACCT/lgn/secpwless/v1", true)
	return LineThrift.NewSecondaryPwlessLoginPermitServiceClient(client)
}

func (p *LineClient) SnsService() *LineThrift.SnsAdaptorServiceClient {
	client := p.ThriftWrapper("/api/v4p/sa", false)
	return LineThrift.NewSnsAdaptorServiceClient(client)
}

func (p *LineClient) PrimaryQRMigrationLPService() *LineThrift.PrimaryQrCodeMigrationLongPollingServiceClient {
	client := p.ThriftWrapper("/EXT/auth/feature-user/lp/api/primary/mig/qr", true)
	return LineThrift.NewPrimaryQrCodeMigrationLongPollingServiceClient(client)
}

func (p *LineClient) PrimaryQRMigrationPreService() *LineThrift.PrimaryQrCodeMigrationPreparationServiceClient {
	client := p.ThriftWrapper("/EXT/auth/feature-user/api/primary/mig/qr/prepare", true)
	return LineThrift.NewPrimaryQrCodeMigrationPreparationServiceClient(client)
}

func (p *LineClient) PrimaryQRMigrationService() *LineThrift.PrimaryQrCodeMigrationServiceClient {
	client := p.ThriftWrapper("/ext/auth/feature-guest/api/primary/mig/qr", true)
	return LineThrift.NewPrimaryQrCodeMigrationServiceClient(client)
}

func (p *LineClient) ProxyService() *LineThrift.ProxyServiceClient {
	client := p.ThriftWrapper("/proxy", true)
	return LineThrift.NewProxyServiceClient(client)
}

func CreateTransport(urL string, timeout int, headers map[string]string) (*thrift.TStandardClient, error) {
    var transport thrift.TTransport
    option := thrift.THttpClientOptions{
        Client: &http.Client{
            Timeout  : time.Duration(timeout) * time.Second,
            Transport: &http.Transport{},
        },
    }
    transport, _  = thrift.NewTHttpClientWithOptions(LINE_HOST_DOMAIN+urL, option)
    connect      := transport.(*thrift.THttpClient)
    for key, val := range headers {
        connect.SetHeader(key, val)
    }
    pcol := thrift.NewTCompactProtocolFactory().GetProtocol(transport)
    res := thrift.NewTStandardClient(pcol, pcol)
    return res, nil
}

func (ve *LineClient) ConnectMoreCompact(fckV []byte, path string) (res []byte, err error) {
	var httpClient thrift.TTransport
	httpClient, _ = thrift.NewTHttpClientWithOptions(LINE_HOST_DOMAIN+path, thrift.THttpClientOptions{
		Client: ve.HttpClient,
	})
	transport := httpClient.(*thrift.THttpClient)
	transport.SetHeader("user-agent", ve.UserAgent)
	transport.SetHeader("x-line-application", ve.AppName)
	transport.SetHeader("x-line-access", ve.AuthToken)
	transport.SetHeader("x-lal", "en_US")
	transport.SetHeader("x-lpv", "1")
	transport.SetHeader("content-type", "application/x-thrift")
	transport.SetHeader("accept", "application/x-thrift")
	transport.SetHeader("accept-encoding", "gzip")
	transport.Write(fckV)
	err = transport.Flush(ve.Ctx)
	return res, err
}

func (p *LineClient) ThriftWrapper(apiUrl string, withToken bool) *thrift.TStandardClient {
	//p.setDefaultHttpClient()
	var httpClient thrift.TTransport
	var protocol thrift.TProtocol
	httpClient, _ = thrift.NewTHttpClientWithOptions(LINE_HOST_DOMAIN+apiUrl, thrift.THttpClientOptions{
		Client: &http.Client{
			Transport: &http.Transport{},
		},
	})
	buffer := thrift.NewTBufferedTransportFactory(2048)
	trans := httpClient.(*thrift.THttpClient)
	if withToken && p.AuthToken != "" {
		trans.SetHeader("x-line-access", p.AuthToken)
	}
	if apiUrl == LINE_POLL_QUERY_PATH_FIR || apiUrl == LINE_POLL_QUERY_PATH_SEC || apiUrl == LINE_POLL_QUERY_PATH_THI {
		trans.SetHeader("x-las", "F")
		trans.SetHeader("x-lam", "w")
		trans.SetHeader("x-lac", "44125")
	}
	trans.SetHeader("user-agent", p.UserAgent)
	trans.SetHeader("x-line-application", p.AppName)
	trans.SetHeader("x-lal", "id_ID")
	trans.SetHeader("x-lpv", "1")
	trans.SetHeader("content-type", "application/x-thrift")
	buftrans, _ := buffer.GetTransport(trans)
	protocol = thrift.NewTCompactProtocolFactoryConf(nil).GetProtocol(buftrans)
	thriftClient := thrift.NewTStandardClient(protocol, protocol)
	return thriftClient
}

func (p *LineClient) ThriftWrapperWar(addr string) *thrift.TStandardClient {
	httpClient, _ := thrift.NewTHttpWar(addr, thrift.THttpClientOptions{
		Client:  p.Connection,
		Header:  p.Header,
		Timeout: 30 * time.Second,
	})
	buffer := thrift.NewTBufferedTransportFactory(1024)
	trans := httpClient.(*thrift.THttpClient)
	buftrans, _ := buffer.GetTransport(trans)
	protocol := thrift.NewTCompactProtocolFactoryConf(nil).GetProtocol(buftrans)
	thriftClient := thrift.NewTStandardClient(protocol, protocol)
	return thriftClient
}
