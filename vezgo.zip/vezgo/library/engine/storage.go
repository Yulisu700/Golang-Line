package engine

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

var Limits = map[string]time.Time{}
var Kcount = map[string]int{}
var Icount = map[string]int{}

func jsonPrettyPrint(in string) string {
	var out bytes.Buffer
	err := json.Indent(&out, []byte(in), "", "   ")
	if err != nil {
		return in
	}
	return out.String()
}

func DumpDataJson(filename string, value string) {
	f, err := os.Create(filename)
	if err != nil {
		fmt.Println(err)
	}
	_, err = f.WriteString(jsonPrettyPrint(value))
	if err != nil {
		fmt.Println(err)
		f.Close()
	}
	err = f.Close()
	if err != nil {
		fmt.Println(err)
	}
}

func ReloadData(base string) string {
	directory := "./database/setting/"
	_, su := os.Stat(directory)
	if os.IsNotExist(su) {
		errDir := os.MkdirAll("./database/setting/", 0755)
		if errDir != nil {
			fmt.Println(su)
		}
	}
	file, err := os.Open(base)
	if err != nil {
		fmt.Println("Create new data " + base + " , \nPlease check your folder database/setting/" + base + " for input mid, token and more data")
		DumpDataJson(base, CreateNewJson(os.Args[1]))
		file, _ = os.Open(base)
	}
	scanner := bufio.NewScanner(file)
	scanner.Split(bufio.ScanLines)
	var txtlines []string
	for scanner.Scan() {
		txtlines = append(txtlines, scanner.Text())
	}
	file.Close()
	asu := strings.Join(txtlines, "\n")
	return asu
}

func ReloadCMD(base string) string {
	directory := "./database/cmd/"
	_, su := os.Stat(directory)
	if os.IsNotExist(su) {
		errDir := os.MkdirAll("./database/cmd/", 0755)
		if errDir != nil {
			fmt.Println(su)
		}
	}
	haniKu := base
	file, err := os.Open(haniKu)
	if err != nil {
		fmt.Println("Create new commands " + haniKu + " , \nPlease check your folder database/cmd/" + haniKu + "")
		DumpDataJson(haniKu, `{}`)
		file, _ = os.Open(haniKu)
	}
	scanner := bufio.NewScanner(file)
	scanner.Split(bufio.ScanLines)
	var txtlines []string
	for scanner.Scan() {
		txtlines = append(txtlines, scanner.Text())
	}
	file.Close()
	asu := strings.Join(txtlines, "\n")
	return asu
}

func DataBaseLoad() {
	Prefix = gjson.Get(Settings, "prefix").String()
	MsgRespon = gjson.Get(Settings, "message_bot.msg_respon").String()
	v1 := gjson.Get(Settings, "rname")
	Rname = v1.String()
	v2 := gjson.Get(Settings, "sname")
	Sname = v2.String()
	v2 = gjson.Get(Settings, "prefixsb")
	if v2.Exists() {
		Prefixsb = v2.String()
	}
	gess := gjson.Get(Settings, "settings.lurkmsg")
	if gess.Exists() {
		Lurk = gess.String()
	} else {
		value, _ := sjson.Set(Settings, "settings.lurkmsg", "Hi, @! \nCome here.")
		Settings = value
	}

	getown := gjson.Get(Settings, "status.owner")
	for _, own := range getown.Array() {
		if !Contains(Owner, own.String()) {
			Owner = append(Owner, own.String())
		}
	}

	getcra := gjson.Get(Settings, "status.resel")
	if getcra.Exists() {
		for _, cr := range getcra.Array() {
			if !Contains(Resel, cr.String()) {
				Resel = append(Resel, cr.String())
			}
		}
	} else {
		value, _ := sjson.Set(Settings, "status.resel", []string{})
		Settings = value
	}

	gesqt := gjson.Get(Settings, "status.stay")
	if gesqt.Exists() {
		for _, cr := range gesqt.Array() {
			Staymid = append(Staymid, cr.String())
		}
	} else {
		value, _ := sjson.Set(Settings, "status.stay", []int{})
		Settings = value
	}

	ges := gjson.Get(Settings, "status.stay")
	if ges.Exists() {
		for _, cr := range ges.Array() {
			ihi, _ := strconv.Atoi(cr.String())
			Staylist = append(Staylist, ihi)
		}
	} else {
		value, _ := sjson.Set(Settings, "status.stay", []string{})
		Settings = value
	}

	getadmin := gjson.Get(Settings, "status.admin")
	for _, a := range getadmin.Array() {
		Admin = append(Admin, a.String())
	}

	getas := gjson.Get(Settings, "status.staff")
	if getas.Exists() {
		for _, a := range getas.Array() {
			GlobalStaff = append(GlobalStaff, a.String())
		}
	} else {
		value, _ := sjson.Set(Settings, "status.staff", []string{})
		Settings = value
	}

	getas = gjson.Get(Settings, "status.wl")
	if getas.Exists() {
		for _, a := range getas.Array() {
			Whitelist = append(Whitelist, a.String())
		}
	} else {
		value, _ := sjson.Set(Settings, "status.wl", []string{})
		Settings = value
	}

	gst := gjson.Get(Settings, "status.gaccess")
	if gst.Exists() {
		m, _ := gjson.Parse(gst.String()).Value().(map[string]interface{})
		for x, v := range m {
			ma := v.(map[string]interface{})
			g := &GAccess{Id: x, Owner: []string{}, Admin: []string{}, Staff: []string{}}
			for k, s := range ma {
				if k == "owner" {
					h := s.([]interface{})
					for _, j := range h {
						g.Owner = append(g.Owner, j.(string))
					}
				} else if k == "admin" {
					h := s.([]interface{})
					for _, j := range h {
						g.Admin = append(g.Admin, j.(string))
					}
				} else if k == "staff" {
					h := s.([]interface{})
					for _, j := range h {
						g.Staff = append(g.Staff, j.(string))
					}
				}
			}
			ChatAccess = append(ChatAccess, g)
		}
	} else {
		value, _ := sjson.Set(Settings, "status.gaccess", map[string]string{})
		Settings = value
	}

	getb := gjson.Get(Settings, "suggest")
	if getb.Exists() {
		Suggest = int(getb.Int())
	} else {
		value, _ := sjson.Set(Settings, "suggest", 0)
		Settings = value
	}

	getasb := gjson.Get(Settings, "status.blacklist")
	if getasb.Exists() {
		for _, a := range getasb.Array() {
			Blacklist = append(Blacklist, a.String())
		}
	} else {
		value, _ := sjson.Set(Settings, "status.blacklist", []string{})
		Settings = value
	}

	getasb = gjson.Get(Settings, "status.mute")
	if getasb.Exists() {
		for _, a := range getasb.Array() {
			Mute = append(Mute, a.String())
		}
	} else {
		value, _ := sjson.Set(Settings, "status.mute", []string{})
		Settings = value
	}
	getasb = gjson.Get(Settings, "status.logmode")
	if getasb.Exists() {
		for _, a := range getasb.Array() {
			Logmode = append(Logmode, a.String())
		}
	} else {
		value, _ := sjson.Set(Settings, "status.logmode", []string{})
		Settings = value
	}

	/*gbn := gjson.Get(Settings, "status.gban")
	if gbn.Exists() {
		m, _ := gjson.Parse(gbn.String()).Value().(map[string]interface{})
		for x, v := range m {
			loopban(v, x)
		}
	} else {
		value, _ := sjson.Set(Settings, "status.gban", map[string]string{})
		Settings = value
	}*/

	gkc := gjson.Get(Settings, "status.kcount")
	if gkc.Exists() {
		m, _ := gjson.Parse(gkc.String()).Value().(map[string]interface{})
		if m != nil {
			for k, v := range m {
				Kcount[k] = int(v.(float64))
			}
		}
	} else {
		value, _ := sjson.Set(Settings, "status.kcount", map[string]int{})
		Settings = value
		for _, mid := range Squad {
			Kcount[mid] = 0
		}
	}

	gkc = gjson.Get(Settings, "status.limits")
	if gkc.Exists() {
		m, _ := gjson.Parse(gkc.String()).Value().(map[string]interface{})
		if m != nil {
			for k, v := range m {
				h := v.(string)
				var date, _ = time.Parse(time.RFC3339, h)
				Limits[k] = date
			}
		}
	} else {
		value, _ := sjson.Set(Settings, "status.limits", map[string]time.Time{})
		Settings = value
	}

	gkc = gjson.Get(Settings, "status.invite")
	if gkc.Exists() {
		m, _ := gjson.Parse(gkc.String()).Value().(map[string]interface{})
		if m != nil {
			for k, v := range m {
				ah := []string{}
				h := v.([]interface{})
				for _, j := range h {
					ah = append(ah, j.(string))
				}
				Invitelist[k] = ah
			}
		}
	} else {
		value, _ := sjson.Set(Settings, "status.limits", map[string][]string{})
		Settings = value
	}

	gic := gjson.Get(Settings, "status.icount")
	if gic.Exists() {
		m, _ := gjson.Parse(gic.String()).Value().(map[string]interface{})
		if m != nil {
			for k, v := range m {
				Icount[k] = int(v.(float64))
			}
		}
	} else {
		value, _ := sjson.Set(Settings, "status.icount", map[string]int{})
		Settings = value
		for _, mid := range Squad {
			Icount[mid] = 0
		}
	}

	getbot := gjson.Get(Settings, "status.bot")
	for _, a := range getbot.Array() {
		Bot = append(Bot, a.String())
	}

	getpqr := gjson.Get(Settings, "settings.proQr")
	for _, a := range getpqr.Array() {
		ProQr = append(ProQr, a.String())
	}

	getpin := gjson.Get(Settings, "settings.proInvite")
	for _, a := range getpin.Array() {
		ProInvite = append(ProInvite, a.String())
	}
	
	getcall := gjson.Get(Settings, "settings.proCall")
	for _, a := range getcall.Array() {
		ProCall = append(ProCall, a.String())
	}
	
	getnote := gjson.Get(Settings, "settings.proNote")
	for _, a := range getnote.Array() {
		ProNote = append(ProNote, a.String())
	}
	
	getalbum := gjson.Get(Settings, "settings.proAlbum")
	for _, a := range getalbum.Array() {
		ProAlbum = append(ProAlbum, a.String())
	}
	
	getflex := gjson.Get(Settings, "settings.proFlex")
	for _, a := range getflex.Array() {
		ProFlex = append(ProFlex, a.String())
	}
	
	getcon := gjson.Get(Settings, "settings.proContact")
	for _, a := range getcon.Array() {
		ProContact = append(ProContact, a.String())
	}
	
	getfli := gjson.Get(Settings, "settings.proFile")
	for _, a := range getfli.Array() {
		ProFile = append(ProFile, a.String())
	}

	getpk := gjson.Get(Settings, "settings.proKick")
	for _, a := range getpk.Array() {
		ProKick = append(ProKick, a.String())
	}
	
	getlinkgc := gjson.Get(Settings, "settings.proLinkGroup")
	for _, a := range getlinkgc.Array() {
		ProLinkGroup = append(ProLinkGroup, a.String())
	}

	getpname := gjson.Get(Settings, "settings.proName")
	if getpname.Exists() {
		for _, a := range getpname.Array() {
			ProName = append(ProName, a.String())
		}
	} else {
		value, _ := sjson.Set(Settings, "settings.proName", []string{})
		Settings = value
	}
	getpname = gjson.Get(Settings, "settings.lurk")
	if getpname.Exists() {
		for _, a := range getpname.Array() {
			room := GetRoom(a.String())
			room.Lurk = true
		}
	} else {
		value, _ := sjson.Set(Settings, "settings.lurk", []string{})
		Settings = value
	}

	getps := gjson.Get(Settings, "settings.prostay")
	if getps.Exists() {
		for _, a := range getps.Array() {
			ProStay = append(ProStay, a.String())
		}
	} else {
		value, _ := sjson.Set(Settings, "settings.prostay", []string{})
		Settings = value
	}

	getcan := gjson.Get(Settings, "settings.proCancel")
	if getcan.Exists() {
		for _, a := range getcan.Array() {
			ProCancel = append(ProCancel, a.String())
		}
	} else {
		value, _ := sjson.Set(Settings, "settings.proCancel", []string{})
		Settings = value
	}

	getpj := gjson.Get(Settings, "settings.proJoin")
	for _, a := range getpj.Array() {
		ProJoin = append(ProJoin, a.String())
	}

	getpg := gjson.Get(Settings, "settings.purge")
	Purge = getpg.Bool()

	getfj := gjson.Get(Settings, "settings.forcejoin")
	if getfj.Exists() {
		Forcejoin = getfj.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.forcejoin", false)
		Settings = value
	}

	getfj = gjson.Get(Settings, "settings.allowban")
	if getfj.Exists() {
		AllowBan = getfj.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.allowban", true)
		Settings = value
	}
	
	getenc := gjson.Get(Settings, "settings.encmode")
	if getenc.Exists() {
		EncMetode = getenc.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.encmode", true)
		Settings = value
	}

	getsi := gjson.Get(Settings, "settings.silent")
	if getsi.Exists() {
		Silents = getsi.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.silent", false)
		Settings = value
	}

	getfc := gjson.Get(Settings, "settings.antitag")
	if getfc.Exists() {
		Antitag = getfc.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.antitag", false)
		Settings = value
	}
	getfcx := gjson.Get(Settings, "settings.autocban")
	if getfcx.Exists() {
		Autocban = getfcx.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.autocban", false)
		Settings = value
	}
	getfooter := gjson.Get(Settings, "settings.footer")
	if getfooter.Exists() {
		FooterLINE = getfooter.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.footer", false)
		Settings = value
	}
	getflex1 := gjson.Get(Settings, "settings.template1")
	if getflex1.Exists() {
		FlexMode1 = getflex.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.template1", false)
		Settings = value
	}
	getflex2 := gjson.Get(Settings, "settings.template2")
	if getflex2.Exists() {
		FlexMode2 = getflex.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.template2", false)
		Settings = value
	}
	gelogo := gjson.Get(Settings, "team_logo")
	if gelogo.Exists() {
		Logo = gelogo.String()
	} else {
		value, _ := sjson.Set(Settings, "team_logo", "")
		Settings = value
	}
	gelimit := gjson.Get(Settings, "limiter")
	if gelimit.Exists() {
		Batasan = int(gelimit.Int())
	} else {
		value, _ := sjson.Set(Settings, "limiter", 0)
		Settings = value
	}
    kicklimit := gjson.Get(Settings, "kicker")
	if kicklimit.Exists() {
		Kicker = int(kicklimit.Int())
	} else {
		value, _ := sjson.Set(Settings, "kicker", 0)
		Settings = value
	}
	cancellimit := gjson.Get(Settings, "canceler")
	if cancellimit.Exists() {
		Canceler = int(cancellimit.Int())
	} else {
		value, _ := sjson.Set(Settings, "canceler", 0)
		Settings = value
	}
	invitelimit := gjson.Get(Settings, "inviter")
	if invitelimit.Exists() {
		Inviter = int(invitelimit.Int())
	} else {
		value, _ := sjson.Set(Settings, "inviter", 0)
		Settings = value
	}
	gename := gjson.Get(Settings, "team_name")
	if gename.Exists() {
		TeamName = gename.String()
		Sflag = gename.String()
	} else {
		value, _ := sjson.Set(Settings, "team_name", "")
		Settings = value
	}
	geicon := gjson.Get(Settings, "team_icon")
	if geicon.Exists() {
		TeamIcon = geicon.String()
	} else {
		value, _ := sjson.Set(Settings, "team_icon", "")
		Settings = value
	}
	geurl := gjson.Get(Settings, "team_url")
	if geurl.Exists() {
		TeamUrl = geurl.String()
	} else {
		value, _ := sjson.Set(Settings, "team_url", "")
		Settings = value
	}
	getk := gjson.Get(Settings, "settings.kill")
	if getk.Exists() {
		anu := getk.String()
		if anu == "off" {
			anu = "none"
		}
		Killmode = anu
	} else {
		value, _ := sjson.Set(Settings, "settings.kill", "none")
		Settings = value
	}
	getk = gjson.Get(Settings, "settings.mode")
	if getk.Exists() {
		Mode = getk.String()
	} else {
		value, _ := sjson.Set(Settings, "settings.mode", "invite")
		Settings = value
	}
	getk = gjson.Get(Settings, "settings.gradeinvite")
	if getk.Exists() {
		Ginvite = int(getk.Int())
	} else {
		value, _ := sjson.Set(Settings, "settings.gradeinvite", 2)
		Settings = value
	}

	getr := gjson.Get(Settings, "settings.random")
	if getr.Exists() {
		Random = getr.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.random", false)
		Settings = value
	}

	getra := gjson.Get(Settings, "settings.autopro")
	if getra.Exists() {
		Autopro = getra.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.autopro", false)
		Settings = value
	}

	getnu := gjson.Get(Settings, "settings.staynuke")
	if getnu.Exists() {
		Staynuke = getnu.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.staynuke", false)
		Settings = value
	}

	getfq := gjson.Get(Settings, "settings.forceqr")
	if getfq.Exists() {
		Forceqr = getfq.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.forceqr", false)
		Settings = value
	}

	getnj := gjson.Get(Settings, "settings.nukejoin")
	if getnj.Exists() {
		Nukejoin = getnj.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.nukejoin", false)
		Settings = value
	}

	getnj = gjson.Get(Settings, "settings.takeover")
	if getnj.Exists() {
		Takeover = getnj.Bool()
	} else {
		value, _ := sjson.Set(Settings, "settings.takeover", false)
		Settings = value
	}

	getwb := gjson.Get(Settings, "status.wordban")
	if getwb.Exists() {
		for _, own := range getwb.Array() {
			Wordban = append(Wordban, own.String())
		}
	} else {
		value, _ := sjson.Set(Settings, "status.wordban", []string{})
		Settings = value
	}
	getpgl := gjson.Get(Settings, "settings.lockqr")
	LockSet = getpgl.Bool()

	getpjs := gjson.Get(Settings, "settings.jointicket")
	if getpjs.Exists() {
		JoinTicket = getpjs.Bool()
	}
}

func UpdateSetStringCMD(param string, val string) {
	value, _ := sjson.Set(SetCMD, param, val)
	SetCMD = value
	DumpDataJson(Cmd, SetCMD)
}

func DeleteSetStringCMD(param string) {
	value, _ := sjson.Delete(SetCMD, param)
	SetCMD = value
	DumpDataJson(Cmd, SetCMD)
}

func UpdateSetString(param string, val string) {
	value, _ := sjson.Set(Settings, param, val)
	Settings = value
	DumpDataJson(JsonFile, Settings)
}
func UpdateSetInt(param string, val int) {
	value, _ := sjson.Set(Settings, param, val)
	Settings = value
	DumpDataJson(JsonFile, Settings)
}
func UpdateSetBool(param string, val bool) {
	value, _ := sjson.Set(Settings, param, val)
	Settings = value
	DumpDataJson(JsonFile, Settings)
}

func UpdateSetArray(param string, val string) {
	tam := fmt.Sprintf("%s.-1", param)
	value, _ := sjson.Set(Settings, tam, val)
	Settings = value
	DumpDataJson(JsonFile, Settings)
}

func UpdateSetArrayV2(jsonFile string, set string, pref string, param string, val string) {
	tam := fmt.Sprintf("%s.-1", param)
	value, err := sjson.Set(set, tam, val)
	if err != nil {
		fmt.Println(err)
	}
	SetTemp[pref] = value
	DumpDataJson(jsonFile, SetTemp[pref])
}

func UpdateSetMapArray(param string, val []string) {
	value, _ := sjson.Set(Settings, param, val)
	Settings = value
	DumpDataJson(JsonFile, Settings)
}

func DelSetArray(param string, val string) {
	tam := param
	getval := gjson.Get(Settings, tam)
	n := 0
	var ini int
	for _, a := range getval.Array() {
		if a.String() == val {
			ini = n
		}
		n += 1
	}
	tam = fmt.Sprintf("%s.%v", param, ini)
	value, _ := sjson.Delete(Settings, tam)
	Settings = value
	DumpDataJson(JsonFile, Settings)
}

func JsonDump(tipe bool, Baskom string, value string) {
	if tipe {
		value, _ = sjson.Set(value, "status.limits", Limits)
		Settings = value
		value, _ = sjson.Set(value, "status.kcount", Kcount)
		Settings = value
		value, _ = sjson.Set(value, "status.icount", Icount)
		Settings = value
	}
	DumpDataJson(Baskom, value)
}

func Delset(data string, param string, val string) {
	tam := fmt.Sprintf("%s.%s", data, param)
	getval := gjson.Get(Settings, tam)
	n := 0
	var ini int
	for _, a := range getval.Array() {
		if a.String() == val {
			ini = n
		}
		n += 1
	}
	tam = fmt.Sprintf("%s.%s.%v", data, param, ini)
	value, _ := sjson.Delete(Settings, tam)
	Settings = value
	JsonDump(true, JsonFile, Settings)
}

func Upset(data string, param string, val string) {
	tam := fmt.Sprintf("%s.%s.-1", data, param)
	value, _ := sjson.Set(Settings, tam, val)
	Settings = value
	JsonDump(true, JsonFile, Settings)
}

func BeforeChange(tier string, comm string) string {
	valued := []string{"bot", "group", "protect", "media"}
	for _, asu := range valued {
		values := []string{"asw1", "asw2", "asw3", "asw4"}
		for _, comli := range values {
			hasile := fmt.Sprintf("command.%s.%s.%s", tier, asu, comli)
			value := gjson.Get(SetCMD, hasile)
			if value.Exists() {
				for asd := range value.Map() {
					if asd == comm {
						return hasile
					}
				}
			}
		}
	}
	return ""
}

func CreateNewJson(prefix string) string {
	Data := `{"authTokenPrimari":[],"authTokenV3":[{"V3token":"refreshToken"}],"authEmail":[{"email":"fckveza@vhtear.com","password":"Your passwd","certificate":"Your cert"}],"team_logo":"</>","team_icon":"https://vhtear.com/static/icon/vhtear.png","team_url":"https://vhtear.com","team_name":"VHTear-2023","team_mid":"u0544cc8501324324fb7f35d334881c5c","prefix":"/","message_bot":{"msg_welcome":"Hello , I hope you are happy here","msg_leave":"Goodbye dud!","msg_respon":"asu","msg_sider":"Come on @!","msg_kick":"Son of a bitch @!","msg_out":"Goodbye @!","msg_clearbans":"Omit blacklist","msg_limit":"○","msg_fresh":"●"},"mid_restart":"","authToken_revoke":[],"blacklist":[],"whitelist":[],"typo_correct":false,"typo_detect":false,"SeqMessage":[1]}`
	return Data
}

func LoadSugest() {
	sugest1 = []string{}
	sugest2 = []string{}
	sugest3 = []string{}
	sugest4 = []string{}
	sugest5 = []string{}
	tier := "master"
	hel := gjson.Get(SetCMD, "command."+tier+".helper.asw1")
	hel2m := gjson.Get(SetCMD, "command."+tier+".helper.asw2")
	hel3m := gjson.Get(SetCMD, "command."+tier+".helper.asw3")
	hel4m := gjson.Get(SetCMD, "command."+tier+".helper.asw4")
	helP := gjson.Get(SetCMD, "command."+tier+".bot.asw1")
	helP2 := gjson.Get(SetCMD, "command."+tier+".bot.asw2")
	helP3 := gjson.Get(SetCMD, "command."+tier+".bot.asw3")
	helP4 := gjson.Get(SetCMD, "command."+tier+".bot.asw4")
	helPg := gjson.Get(SetCMD, "command."+tier+".group.asw1")
	helPg2 := gjson.Get(SetCMD, "command."+tier+".group.asw2")
	helPg3 := gjson.Get(SetCMD, "command."+tier+".group.asw3")
	helPg4 := gjson.Get(SetCMD, "command."+tier+".group.asw4")
	helPgp := gjson.Get(SetCMD, "command."+tier+".protect.asw1")
	helPgp2 := gjson.Get(SetCMD, "command."+tier+".protect.asw2")
	helPgp3 := gjson.Get(SetCMD, "command."+tier+".protect.asw3")
	helPgp4 := gjson.Get(SetCMD, "command."+tier+".protect.asw4")
	helPgpm := gjson.Get(SetCMD, "command."+tier+".media.asw1")
	helPgp2m := gjson.Get(SetCMD, "command."+tier+".media.asw2")
	helPgp3m := gjson.Get(SetCMD, "command."+tier+".media.asw3")
	helPgp4m := gjson.Get(SetCMD, "command."+tier+".media.asw4")
	for rew := range hel.Map() {
		sugest1 = append(sugest1, hel.Map()[rew].String())
	}
	for rew := range hel2m.Map() {
		sugest1 = append(sugest1, hel2m.Map()[rew].String())
	}
	for rew := range hel3m.Map() {
		sugest1 = append(sugest1, hel3m.Map()[rew].String())
	}
	for rew := range hel4m.Map() {
		sugest1 = append(sugest1, hel4m.Map()[rew].String())
	}
	for rew := range helP.Map() {
		sugest2 = append(sugest2, helP.Map()[rew].String())
	}
	for rew := range helP2.Map() {
		sugest2 = append(sugest2, helP2.Map()[rew].String())
	}
	for rew := range helP3.Map() {
		sugest2 = append(sugest2, helP3.Map()[rew].String())
	}
	for rew := range helP4.Map() {
		sugest2 = append(sugest2, helP4.Map()[rew].String())
	}
	for rew := range helPg.Map() {
		sugest3 = append(sugest3, helPg.Map()[rew].String())
	}
	for rew := range helPg2.Map() {
		sugest3 = append(sugest3, helPg2.Map()[rew].String())
	}
	for rew := range helPg3.Map() {
		sugest3 = append(sugest3, helPg3.Map()[rew].String())
	}
	for rew := range helPg4.Map() {
		sugest3 = append(sugest3, helPg4.Map()[rew].String())
	}
	for rew := range helPgp.Map() {
		sugest4 = append(sugest4, helPgp.Map()[rew].String())
	}
	for rew := range helPgp2.Map() {
		sugest4 = append(sugest4, helPgp2.Map()[rew].String())
	}
	for rew := range helPgp3.Map() {
		sugest4 = append(sugest4, helPgp3.Map()[rew].String())
	}
	for rew := range helPgp4.Map() {
		sugest4 = append(sugest4, helPgp4.Map()[rew].String())
	}
	for rew := range helPgpm.Map() {
		sugest5 = append(sugest5, helPgpm.Map()[rew].String())
	}
	for rew := range helPgp2m.Map() {
		sugest5 = append(sugest5, helPgp2m.Map()[rew].String())
	}
	for rew := range helPgp3m.Map() {
		sugest5 = append(sugest5, helPgp3m.Map()[rew].String())
	}
	for rew := range helPgp4m.Map() {
		sugest5 = append(sugest5, helPgp4m.Map()[rew].String())
	}
}
