package engine

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"image/png"
	"math/rand"
	"regexp"
	"runtime/debug"
	"sort"
	"strconv"
	"strings"
	"time"

	"fmt"
	"os"
	mcp "../vhTearCP"

	"github.com/boombuler/barcode"
	"github.com/boombuler/barcode/qr"
	"github.com/pmezard/go-difflib/difflib"
	qrcode "github.com/skip2/go-qrcode"
	"github.com/tidwall/gjson"
	"golang.org/x/text/cases"
	"golang.org/x/text/language"
)

func GetLenStrBytes(n int) (valo []byte) {
	var bits = 64
	zigzag := ((n << 0) ^ (n >> (bits)))
	for {
		if zigzag&-128 == 0 {
			valo = append(valo, byte(zigzag))
			return
		} else {
			valo = append(valo, byte((zigzag&0xff)|0x80))
			zigzag >>= 7
		}
	}
}

func GetIntBytes(n int) (valo []byte) {
	var bits = 64
	zigzag := ((n << 1) ^ (n >> (bits - 1)))
	for {
		if zigzag&-128 == 0 {
			valo = append(valo, byte(zigzag))
			break
		} else {
			valo = append(valo, byte((zigzag&0xff)|0x80))
			zigzag >>= 7
		}
	}
	return valo
}

func GetStringBytes(str string, isCompact bool) []byte {
	var va []byte
	if isCompact {
		fck := mcp.WriteVarint(len(str))
		va = append(va, fck...)
	}
	va = append(va, []byte(str)...)
	return va
}

func Shuffle(in []*LineClient) []*LineClient {
	defer VHrecover("kk")
	rand.Seed(time.Now().Unix())
	rand.Shuffle(len(in), func(i, j int) {
		in[i], in[j] = in[j], in[i]
	})
	rand.Shuffle(len(in), func(i, j int) {
		in[i], in[j] = in[j], in[i]
	})
	return in
}

func Shufffle(in []string) []string {
	rand.Seed(time.Now().Unix())
	rand.Shuffle(len(in), func(i, j int) {
		in[i], in[j] = in[j], in[i]
	})
	rand.Shuffle(len(in), func(i, j int) {
		in[i], in[j] = in[j], in[i]
	})
	return in
}

func GetStringBytesV2(text interface{}) []byte {
	var textBytes []byte

	if text == nil {
		text = ""
	}

	switch t := text.(type) {
	case []byte:
		textBytes = t
	default:
		textBytes = []byte(fmt.Sprint(text))
	}

	var sqrd []byte
	textLength := len(textBytes)

	lengthBytes := make([]byte, 4)
	binary.BigEndian.PutUint32(lengthBytes, uint32(textLength))
	sqrd = append(sqrd, lengthBytes...)

	sqrd = append(sqrd, textBytes...)

	return sqrd
}

func GetIntBytesV2(i int) []byte {
	j := 4
	isCompact := false
	if isCompact {
		var a = int32(i)
		if j*j == 16 {
			a = int32(i)
		} else {
			a = int32(i)
		}

		a = (a << 1) ^ (a >> 31)
		var b []byte
		for a >= 0x80 {
			b = append(b, byte(a)|0x80)
			a >>= 7
		}
		b = append(b, byte(a))
		return b
	}

	res := make([]byte, j)
	if j*j == 16 {
		binary.BigEndian.PutUint32(res, uint32(i))
	} else {
		binary.BigEndian.PutUint64(res, uint64(i))
	}
	return res
}

func GetMagicStringBytes(val string, rev bool) []byte {
	var res []byte

	if rev {
		// Convert the input string to bytes
		valBytes, err := hex.DecodeString(val)
		if err != nil {
			fmt.Println("errGetMagicStringBytes", err)
			return nil
		}
		res = valBytes
	} else {
		if len(val) == 32 {
			for ii := 0; ii < 16; ii++ {
				iii := ii * 2
				i := iii + 1
				mgc := (hexDigitToByte(val[iii]) << 4) + hexDigitToByte(val[i])
				res = append(res, mgc)
			}
		} else {
			fmt.Printf("getMagicStringBytes() expected 32, but got %d", len(val))
			return nil
		}
	}

	return res
}

func hexDigitToByte(hexDigit byte) byte {
	switch {
	case hexDigit >= '0' && hexDigit <= '9':
		return hexDigit - '0'
	case hexDigit >= 'a' && hexDigit <= 'f':
		return hexDigit - 'a' + 10
	case hexDigit >= 'A' && hexDigit <= 'F':
		return hexDigit - 'A' + 10
	}
	return 0
}

func RandomString(ve []string) string {
	defer VHrecover("RandomString")
	rand.Seed(time.Now().UnixNano())
	min := 0
	max := len(ve)
	cuk := ve[rand.Intn(max-min)+min]
	rand.Seed(time.Now().Unix())
	return cuk
}

func GetMentionData(data string) []string {
	var midmen []string
	res := mentionMsg{}
	json.Unmarshal([]byte(data), &res)
	for _, v := range res.MENTIONEES {
		if !Contains(midmen, v.M) {
			midmen = append(midmen, v.M)
		}
	}
	return midmen
}

/*func Byte2int(b []byte) int {
	var result int
	for _, v := range b {
		result = 256*result + int(v)
	}
	return result
}*/

func RandomArray(celeng []string) string {
	rand.Seed(time.Now().UnixNano()) // Ganti dengan objek yang Anda miliki
	// Mengambil indeks acak dari slice
	randomIndex := rand.Intn(len(celeng))
	// Mengambil objek acak dari slice
	randomObject := celeng[randomIndex]
	return randomObject
}

func matcher(text string) string {
	mat := map[string]float64{}
	ori := text
	sp := strings.Split(text, " ")
	repl := false
	if len(sp) > 1 {
		text = sp[0]
		repl = true
	}
	x1 := strings.SplitAfter(text, "")
	for _, v := range sugest1 {
		if strings.HasPrefix(text, v) {
			return "percuma"
		}
		x2 := strings.SplitAfter(v, "")
		s := difflib.NewMatcher(x1, x2)
		q := s.Ratio()
		if q > 0.7 {
			mat[v] = q
		}
	}
	for _, v := range sugest2 {
		if strings.HasPrefix(text, v) {
			return "percuma"
		}
		x2 := strings.SplitAfter(v, "")
		s := difflib.NewMatcher(x1, x2)
		q := s.Ratio()
		if q > 0.7 {
			mat[v] = q
		}
	}
	for _, v := range sugest3 {
		if strings.HasPrefix(text, v) {
			return "percuma"
		}
		x2 := strings.SplitAfter(v, "")
		s := difflib.NewMatcher(x1, x2)
		q := s.Ratio()
		if q > 0.7 {
			mat[v] = q
		}
	}
	for _, v := range sugest4 {
		if strings.HasPrefix(text, v) {
			return "percuma"
		}
		x2 := strings.SplitAfter(v, "")
		s := difflib.NewMatcher(x1, x2)
		q := s.Ratio()
		if q > 0.7 {
			mat[v] = q
		}
	}
	for _, v := range sugest5 {
		if strings.HasPrefix(text, v) {
			return "percuma"
		}
		x2 := strings.SplitAfter(v, "")
		s := difflib.NewMatcher(x1, x2)
		q := s.Ratio()
		if q > 0.7 {
			mat[v] = q
		}
	}
	nah := []float64{}
	for _, val := range mat {
		nah = append(nah, val)
	}
	sort.Sort(sort.Reverse(sort.Float64Slice(nah)))
	for ke, valu := range mat {
		if valu == nah[0] {
			if repl {
				ke = strings.Replace(ori, text, ke, 1)
			}
			return ke
		}
	}
	return "percuma"
}

func TextMatcher(client *LineClient, to string, texts []string) {
	hasil := []string{}
	for _, text := range texts {
		has := matcher(text)
		if has != "percuma" {
			hasil = append(hasil, has)
		}
	}
	if len(hasil) != 0 {
		tex := "Did you mean "
		for _, valu := range hasil {
			tex += fmt.Sprintf("%v, ", valu)
		}
		tex = strings.TrimSuffix(tex, ", ")
		tex += " ?"
		client.SendMessage(to, tex)
	}
	suggestword = []string{}
}

func VHrecover(t string) {
	if r := recover(); r != nil {
		ret := "\nVHrecover"
		ret += fmt.Sprintf("\nFunction: %v", t)
		ret += fmt.Sprintf("\nError: %v", r)
		ret += "\nStack Trace:\n "
		ret += string(debug.Stack())
		go func(rr string) { fmt.Println(rr) }(ret)
	}
}

func AnyPanicHandle() {
	if r := recover(); r != nil {
		go fmt.Println(r)
		return
	}
}

func appendAndSort(slice *[]string, help gjson.Result) {
	for rew := range help.Map() {
		*slice = append(*slice, rew)
	}
	sort.Strings(*slice)
}
func TitleJos(txt string) string {
	caser := cases.Title(language.English)
	return caser.String(txt)
}

func P(p string) {
	go func(p string) { fmt.Println(string(ColorRed)+p, string(ColorReset)) }(p)
}

func TimeWibNow() time.Time {
	loc, err := time.LoadLocation("Asia/Jakarta")
	if err != nil {
		fmt.Println("TimeWibNow", err)
	}
	now := time.Now().In(loc)
	return now
}

type addFuncInt func(data []string, element string) int

type addFuncArStr func(s []string, element string) []string

func VHremove[T comparable](l []T, item T) []T {
	for i, other := range l {
		if other == item {
			return append(l[:i], l[i+1:]...)
		}
	}
	return l
}

func Contains(arr []string, str string) bool {
	for i := 0; i < len(arr); i++ {
		if arr[i] == str {
			return true
		}
	}
	return false
}

func ContainsV2(arr interface{}, item interface{}) bool {
	switch arr.(type) {
	case []string:
		strArr := arr.([]string)
		strItem, isString := item.(string)
		if !isString {
			return false
		}

		for i := 0; i < len(strArr); i++ {
			if strArr[i] == strItem {
				return true
			}
		}
	case []int:
		intArr := arr.([]int)
		intItem, isInt := item.(int)
		if !isInt {
			return false
		}

		for i := 0; i < len(intArr); i++ {
			if intArr[i] == intItem {
				return true
			}
		}
	}

	return false
}

func DetectIfNumber(str string) string {
	pattern := regexp.MustCompile("[0-9]+")
	result := pattern.FindString(str)
	if result != "" {
		return result
	} else {
		return ""
	}
}

func ReplaceAtIndex(in string, r rune, i int) string {
	//Delete text with number
	out := []rune(in)
	out[i-1] = r
	return string(out)
}

func IndexNumAtString(VezaGans string) (int, int) {
	VezaGans = strings.ReplaceAll(VezaGans, "\n", "")
	VezaGans = strings.ReplaceAll(VezaGans, " ", "")
	tol := strings.Split(VezaGans, ">")
	var no1, _ = strconv.Atoi(tol[0])
	var no2, _ = strconv.Atoi(tol[1])
	return no1, no2
}

var NumberToWord = map[int]string{
	0:  "zero",
	1:  "one",
	2:  "two",
	3:  "three",
	4:  "four",
	5:  "five",
	6:  "six",
	7:  "seven",
	8:  "eight",
	9:  "nine",
	10: "ten",
	11: "eleven",
	12: "twelve",
	13: "thirteen",
	14: "fourteen",
	15: "fifteen",
	16: "sixteen",
	17: "seventeen",
	18: "eighteen",
	19: "nineteen",
	20: "twenty",
	30: "thirty",
	40: "forty",
	50: "fifty",
	60: "sixty",
	70: "seventy",
	80: "eighty",
	90: "ninety",
}

func convert1to99(n int) (w string) {
	if n < 20 {
		w = NumberToWord[n]
		return
	}

	r := n % 10
	if r == 0 {
		w = NumberToWord[n]
	} else {
		w = NumberToWord[n-r] + "-" + NumberToWord[r]
	}
	return
}

func convert100to999(n int) (w string) {
	q := n / 100
	r := n % 100
	w = NumberToWord[q] + " " + "hundred"
	if r == 0 {
		return
	} else {
		w = w + " and " + convert1to99(r)
	}
	return
}

func ConvertEn1to1000(n int) (w string) {
	if n > 1000 || n < 1 {
		panic("func Convert1to1000: n > 1000 or n < 1")
	}

	if n < 100 {
		w = convert1to99(n)
		return
	}
	if n == 1000 {
		w = "one thousand"
		return
	}
	w = convert100to999(n)
	return
}

func StripOut(kata string) string {
	kata = strings.TrimPrefix(kata, " ")
	kata = strings.TrimSuffix(kata, " ")
	return kata
}

func mycmd(pesan string, rname string, sname string, Mid string, MentionMsg []string) []string {
	var result = []string{}
	var txt string
	if strings.HasPrefix(pesan, rname+" ") {
		txt = strings.Replace(pesan, rname+" ", "", 1)
		if strings.Contains(txt, ",") {
			hasil := strings.Split(txt, ",")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(txt, ";") {
			hasil := strings.Split(txt, "&")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(txt, ";") {
			hasil := strings.Split(txt, ";")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else {
			result = []string{txt}
		}
	} else if strings.HasPrefix(pesan, sname+" ") {
		txt = strings.Replace(pesan, sname+" ", "", 1)
		if strings.Contains(txt, ",") {
			hasil := strings.Split(txt, ",")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(txt, ";") {
			hasil := strings.Split(txt, "&")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(txt, ";") {
			hasil := strings.Split(txt, ";")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else {
			result = []string{txt}
		}
	} else if strings.HasPrefix(pesan, "vh") {
		txt = strings.Replace(pesan, "vh", "", 1)
		if strings.Contains(txt, ",") {
			hasil := strings.Split(txt, ",")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(txt, ";") {
			hasil := strings.Split(txt, "&")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(txt, ";") {
			hasil := strings.Split(txt, ";")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else {
			result = []string{txt}
		}
	} else if strings.HasPrefix(pesan, sname) {
		txt = strings.Replace(pesan, sname, "", 1)
		if strings.Contains(pesan, ",") {
			hasil := strings.Split(txt, ",")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(pesan, ";") {
			hasil := strings.Split(txt, "&")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(pesan, ";") {
			hasil := strings.Split(txt, ";")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else {
			result = []string{txt}
		}
	} else if strings.HasPrefix(pesan, rname) {
		txt = strings.Replace(pesan, rname, "", 1)
		if strings.Contains(pesan, ",") {
			hasil := strings.Split(txt, ",")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(pesan, ";") {
			hasil := strings.Split(txt, "&")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(pesan, ";") {
			hasil := strings.Split(txt, ";")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else {
			result = []string{txt}
		}
	} else {
		for _, ser := range Squad {
			if Contains(MentionMsg, ser) {
				//Leader = Mclient[ser]
				pr := Mclient[ser].GetProfile()
				name := pr.DisplayName
				Vs := fmt.Sprintf("@%v", name)
				Vs = strings.ToLower(Vs)
				Vs = strings.TrimSuffix(Vs, " ")
				txt = strings.Replace(pesan, Vs, "", 1)
				txt = strings.TrimPrefix(txt, " ")
				for _, men := range MentionMsg {
					prs, _ := Mclient[ser].GetContact(men)
					names := prs.DisplayName
					jj := fmt.Sprintf("@%v", names)
					jj = strings.ToLower(jj)
					jj = strings.TrimSuffix(jj, " ")
					txt = strings.Replace(txt, jj, "", 1)
					txt = strings.TrimPrefix(txt, " ")
				}
				if strings.Contains(txt, ",") {
					hasil := strings.Split(txt, ",")
					for _, id := range hasil {
						id = StripOut(id)
						result = append(result, id)
					}
				} else if strings.Contains(txt, ";") {
					hasil := strings.Split(txt, "&")
					for _, id := range hasil {
						id = StripOut(id)
						result = append(result, id)
					}
				} else if strings.Contains(txt, ";") {
					hasil := strings.Split(txt, ";")
					for _, id := range hasil {
						id = StripOut(id)
						result = append(result, id)
					}
				} else {
					result = []string{txt}
				}
			}
		}
	}
	return result
}

func IfString(condition bool, trueVal, falseVal string) string {
	if condition {
		return trueVal
	} else {
		return falseVal
	}
}

func PrefixWithName(tier string, cmd string, types string, num int) string {
	return "" //Prefix + GetCommand(tier, cmd, types, num)
}

func UniqueGrade(group string, from string) {
	aa := GradeKick(group, from)
	if Contains(Owner, from) && aa < 1 {
		Owner = Remove(Owner, from)
		Delset("status", "owner", from)
	}
	if Contains(Admin, from) && aa < 2 {
		Admin = Remove(Admin, from)
		Delset("status", "admin", from)
	}
	if Contains(Bot, from) && aa < 3 {
		Bot = Remove(Bot, from)
		Delset("status", "bot", from)
	}
	if Contains(GlobalStaff, from) && aa < 3 {
		GlobalStaff = Remove(GlobalStaff, from)
		Delset("status", "staff", from)
	}
	if v, ok := CheckGaccess(group); ok {
		if Contains(v.Staff, from) && aa < 6 {
			v.Staff = Remove(v.Staff, from)
		}
		SaveGaccess(group, v)
	}
	JsonDump(true, JsonFile, Settings)
}

func ArchimedCl(s string, list []*LineClient) []*LineClient {
	ln := len(list)
	ls := []int{}
	ind := []int{}
	hasil := []*LineClient{}
	if strings.Contains(s, ",") {
		logics := strings.Split(s, ",")
		for _, logic := range logics {
			if strings.Contains(logic, ">") {
				su := strings.TrimPrefix(logic, ">")
				si, _ := strconv.Atoi(su)
				si -= 1
				for i := (si + 1); i > si && i <= ln; i++ {
					ls = append(ls, i)
				}
			} else if strings.Contains(logic, "<") {
				su := strings.TrimPrefix(logic, "<")
				si, _ := strconv.Atoi(su)
				si -= 1
				for i := 0; i <= si; i++ {
					ls = append(ls, i)
				}
			} else if strings.Contains(logic, "-") {
				las := strings.Split(logic, "-")
				si := las[0]
				siu, _ := strconv.Atoi(si)
				siu -= 1
				sa := las[1]
				sau, _ := strconv.Atoi(sa)
				sau -= 1
				for i := (siu); i >= siu && i <= sau; i++ {
					ls = append(ls, i)
				}
			} else {
				sau, _ := strconv.Atoi(logic)
				sau -= 1
				ls = append(ls, sau)
			}
		}
	} else {
		logic := s
		if strings.Contains(logic, ">") {
			su := strings.TrimPrefix(logic, ">")
			si, _ := strconv.Atoi(su)
			si -= 1
			for i := (si + 1); i > si && i <= ln; i++ {
				ls = append(ls, i)
			}
		} else if strings.Contains(logic, "<") {
			su := strings.TrimPrefix(logic, "<")
			si, _ := strconv.Atoi(su)
			si -= 1
			for i := 0; i <= si; i++ {
				ls = append(ls, i)
			}
		} else if strings.Contains(logic, "-") {
			las := strings.Split(logic, "-")
			si := las[0]
			siu, _ := strconv.Atoi(si)
			siu -= 1
			sa := las[1]
			sau, _ := strconv.Atoi(sa)
			sau -= 1
			for i := (siu); i >= siu && i <= sau; i++ {
				ls = append(ls, i)
			}
		} else {
			sau, _ := strconv.Atoi(logic)
			sau -= 1
			ls = append(ls, sau)
		}
	}
	for _, do := range ls {
		if !InArrayInt(ind, do) && do < ln {
			jo := list[do]
			ind = append(ind, do)
			hasil = append(hasil, jo)
		}
	}
	return hasil
}

func CutNameIfLong(name string, maxLength int) string {
	if len(name) > maxLength {
		return name[:maxLength-3] + "..."
	}
	return name
}

func IsTeam(mids string) bool {
	if Contains(Creator, mids) {
		return true
	} else if Contains(Squad, mids) {
		return true
	} else {
		return false
	}
}
func IsMaster(from string) bool {
	if Contains(Creator, from) {
		return true
	} else if Contains(Creator, from) {
		return true
	}
	return false
}
func ArabicNum(num string) string {
	veza := map[string]interface{}{
		"0": "۰",
		"1": "١",
		"2": "٢",
		"3": "۳",
		"4": "٤",
		"5": "۵",
		"6": "٦",
		"7": "۷",
		"8": "۸",
		"9": "۹",
	}
	if _, ok := veza[num]; ok {
		return fmt.Sprintf("%v", veza[num])
	}
	return ""
}

func GetMidFromMentionees(data string) []string {
	var midmen []string
	var midbefore []string
	res := mentionMsg{}
	json.Unmarshal([]byte(data), &res)
	for _, v := range res.MENTIONEES {
		if !Contains(midbefore, v.M) {
			midbefore = append(midbefore, v.M)
			midmen = append(midmen, v.M)
			//fmt.Println(v.M)
		}
	}
	return midmen
}

func CreateQRImage(query string, mid string) {
	//err := qrcode.WriteColorFile("https://example.org", qrcode.Medium, 256, color.Black, color.White, "qr.png")
	qr, err := qrcode.New(query, qrcode.Medium)
	if err != nil {
		fmt.Println(err)
	}
	file, err := os.Create("./tmp/" + mid + ".png")
	if err != nil {
		fmt.Println(err)
	}
	defer file.Close()
	err = png.Encode(file, qr.Image(500))
	if err != nil {
		fmt.Println(err)
	}
}

func CreateQRImage2(query string, mid string) {
	qrCode, _ := qr.Encode(query, qr.M, qr.Auto)

	// Scale the barcode to 200x200 pixels
	qrCode, _ = barcode.Scale(qrCode, 800, 800)

	// create the output file
	file, _ := os.Create("./tmp/" + mid + ".png")
	defer file.Close()

	// encode the barcode as png
	png.Encode(file, qrCode)
}

func ResetSuggest() {
	suggestword = Kosong
}

func GetToType(mid string) int {
	_u := mid[0]
	if _u == 'u' {
		return 0
	}
	if _u == 'r' {
		return 1
	}
	if _u == 'c' {
		return 2
	}
	if _u == 's' {
		return 3
	}
	if _u == 'm' {
		return 4
	}
	if _u == 'p' {
		return 5
	}
	if _u == 'v' {
		return 6
	}
	return -1 // Tambahkan penanganan kesalahan sesuai kebutuhan
}

func PrintByte(args ...interface{}) {
	byteString := ""

	var message string
	var byteData []byte

	for i, arg := range args {
		switch val := arg.(type) {
		case string:
			message = val
		case []byte:
			byteData = val
		default:
			fmt.Printf("Parameter ke-%d tidak dikenali\n", i+1)
			return
		}
	}

	for i, b := range byteData {
		if i > 0 {
			byteString += ", "
		}
		byteString += fmt.Sprintf("%d", b)
	}

	if message != "" {
		fmt.Println(ColorBlue + message + " " + byteString + ColorReset)
	} else {
		fmt.Println(ColorBlue + byteString + ColorReset)
	}
}

func GetSTRBytes(str string) []byte {
	var va []byte
	for a := range str {
		va = append(va, byte(int(str[a])))
	}
	return va
}
