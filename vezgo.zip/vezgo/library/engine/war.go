package engine

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
	"fmt"
	"regexp"
	"sort"
	"strings"
	"time"
	"../LineThrift"
	"../hashmap"
	valid "github.com/asaskevich/govalidator"
	"github.com/tidwall/sjson"
	"sync"
	"os/exec"
	"runtime"
	//LineV2 "../linetcr/line" //TALKSERVICE S5/P5
	modcompact "../linetcr/modcompact"
	thrift2 "../linetcr/thrift"
)

var Autopro = false
var LogMode = ""
var Logmode = []string{}
var LastBan = []string{}
var LastActive = &hashmap.HashMap{}
var Lastinvite = &hashmap.HashMap{}
var Lastkick = &hashmap.HashMap{}
var Lastjoin = &hashmap.HashMap{}
var Lastadd = &hashmap.HashMap{}
var Lastcancel = &hashmap.HashMap{}
var Lastupdate = &hashmap.HashMap{}
var Lastleave = &hashmap.HashMap{}
var Lastmid = &hashmap.HashMap{}
var Lasttag = &hashmap.HashMap{}
var Lastcon = &hashmap.HashMap{}

func (cl *LineBanned) ClearBan(group string) {
	ix := IndexOf(cl.Group, group)
	if ix != -1 {
		cl.User[ix] = []string{}

	} else {
		cl.Group = append(cl.Group, group)
		cl.User = append(cl.User, []string{})
	}
}

func HashToMap(mas *hashmap.HashMap) map[string]interface{} {
	ama := map[string]interface{}{}
	aa := mas.Listing() //.Listing()
	for _, ma := range aa {
		ama[ma.Key.(string)] = ma.Value
	}
	return ama
}

func GetWellcome(to string) *Wellcome {
	gc, ok := Greeting.Get(to)
	if !ok {
		gs := &Wellcome{Msg: "Hi, @user .\nWellcome to @group", State: false}
		Greeting.Set(to, gs)
		return gs
	}
	return gc.(*Wellcome)
}

func IsGreeting(to string) bool {
	gc, ok := Greeting.Get(to)
	if !ok {
		return false
	}
	g := gc.(*Wellcome)
	return g.State
}

func ContainsCl(arr []*LineClient, str *LineClient) bool {
	for _, tar := range arr {
		if tar == str {
			return true
		}
	}
	return false
}
func ContainsInt64(arr []int64, str int64) bool {
	for _, tar := range arr {
		if tar == str {
			return true
		}
	}
	return false
}
func GetKorban(user string) *LineClient {
	for _, cl := range Client {
		if cl.Mid == user {
			return cl
		}
	}
	return nil
}

func Actor(to string) (anu []*LineClient) {
	for _, room := range SquadRoom {
		if room.Id == to {
			return room.Actor
		}
	}
	return anu
}

func RemoveCl(items []*LineClient, item *LineClient) []*LineClient {
	defer AnyPanicHandle()
	newitems := []*LineClient{}
	for _, i := range items {
		if i != item {
			newitems = append(newitems, i)
		}
	}
	return newitems
}

func GetRoom(to string) *LineRoom {
	for _, room := range SquadRoom {
		if room.Id == to {
			return room
		}
	}
	new := &LineRoom{Id: to, Seen: []string{}, Kicked: []string{}, Hostage: []string{}, Qr: true, Nuke: false, Purge: false, Danger: false, Tclient: ""}
	SquadRoom = append(SquadRoom, new)
	return new
}

func Qrstart(to string) {
	for _, room := range SquadRoom {
		if room.Id == to {
			room.Qr = false
		}
	}
	new := &LineRoom{Id: to, Seen: []string{}, Kicked: []string{}, Hostage: []string{}, Qr: false, Nuke: false, Purge: false, Danger: false}
	SquadRoom = append(SquadRoom, new)
}

func Qrend(to string) {
	for _, room := range SquadRoom {
		if room.Id == to {
			room.Qr = true
		}
	}
	new := &LineRoom{Id: to, Seen: []string{}, Kicked: []string{}, Hostage: []string{}, Qr: true, Nuke: false, Purge: false, Danger: false}
	SquadRoom = append(SquadRoom, new)
}

func (cln *LineRoom) Act(cl *LineClient) bool {
	for _, cls := range cln.Ava {
		if cls.Client == cl {
			if cls.Exist {
				return true
			} else {
				return false
			}
		}
	}
	return false
}

func (cln *LineRoom) AddCount(tipe string) {
	if tipe == "k" {
		cln.Kick += 1
		if cln.Kick >= 50 {
			sort.Slice(cln.Ava, func(i, j int) bool {
				return cln.Ava[i].Client.KickPoint < cln.Ava[j].Client.KickPoint
			})
			sort.Slice(cln.Client, func(i, j int) bool {
				return cln.Client[i].KickPoint < cln.Client[j].KickPoint
			})
		}
	} else if tipe == "i" {
		cln.Invite += 1
	} else {
		cln.Cancel += 1
	}
	cln.Fight = time.Now()
}

func (cln *LineRoom) RevertGo(cl *LineClient) {
	if Contains(cln.Bot, cl.Mid) {
		cln.Bot = Remove(cln.Bot, cl.Mid)
	}
	if ContainsCl(cln.Client, cl) {
		cln.Client = RemoveCl(cln.Client, cl)
	}
	for _, ava := range cln.Ava {
		if ava.Client == cl {
			cln.Ava = RemoveAva(cln.Ava, ava)
		}
	}
	if !Contains(cln.GoMid, cl.Mid) {
		cln.GoMid = append(cln.GoMid, cl.Mid)
	}
	if !ContainsCl(cln.GoClient, cl) {
		cln.GoClient = append(cln.GoClient, cl)
	}
}

func (cln *LineRoom) DelGo(cl *LineClient) {
	if Contains(cln.GoMid, cl.Mid) {
		cln.GoMid = Remove(cln.GoMid, cl.Mid)
	}
	if ContainsCl(cln.GoClient, cl) {
		cln.GoClient = RemoveCl(cln.GoClient, cl)
	}
}

func (cln *LineRoom) ConvertGo(cl *LineClient) {
	if !Contains(cln.Bot, cl.Mid) {
		cln.Bot = append(cln.Bot, cl.Mid)
	}
	if !ContainsCl(cln.Client, cl) {
		cln.Client = append(cln.Client, cl)
	}
	if !ContainsAva(cln.Ava, cl) {
		if cl.Limiter {
			cln.Ava = append(cln.Ava, &Ava{Client: cl, Exist: true, Mid: cl.Mid})
		} else {
			cln.Ava = append(cln.Ava, &Ava{Client: cl, Exist: false, Mid: cl.Mid})
		}
	}
	if Contains(cln.GoMid, cl.Mid) {
		cln.GoMid = Remove(cln.GoMid, cl.Mid)
	}
	if ContainsCl(cln.GoClient, cl) {
		cln.GoClient = RemoveCl(cln.GoClient, cl)
	}
}

func (cln *LineRoom) AddSquad(bot, staff []string, cls []*LineClient) {
	cln.Bot = bot
	sort.Slice(cls, func(i, j int) bool {
		return cls[i].CustomPoint < cls[j].CustomPoint
	})
	cln.Client = cls
	cln.Ava = []*Ava{}
	for _, cl := range cls {
		if cl.Limiter {
			cln.Ava = append(cln.Ava, &Ava{Client: cl, Exist: true, Mid: cl.Mid})
		} else {
			cln.Ava = append(cln.Ava, &Ava{Client: cl, Exist: false, Mid: cl.Mid})
		}
	}
	cln.Staff = staff
}

func (cln *LineRoom) Joins(cl *LineClient) {
	defer AnyPanicHandle()
	for _, cls := range cln.Ava {
		if cls.Client == cl {
			if cl.Limiter {
				cls.Exist = true
			}
			return
		}
	}
}

func (cln *LineRoom) Cans() []*LineClient {
	anu := []*LineClient{}
	for _, cl := range cln.Ava {
		if cl.Exist {
			anu = append(anu, cl.Client)
		}
	}
	return anu
}

func Gone(to string, cl *LineClient) {
	for _, room := range SquadRoom {
		if room.Id == to {
			room.Danger = true
			if !Contains(room.Tcore, cl.Mid) {
				room.Tcore = append(room.Tcore, cl.Mid)
			}
			for _, cls := range room.Ava {
				if cls.Client == cl {
					cls.Exist = false
					cl.Kicked = true
					cl.CustomPoint = len(Blacklist)
					return
				}
			}
		}
	}
}

func AppendLast(s []string, e string) []string {
	defer AnyPanicHandle()
	s = append(s, e)
	if len(s) >= 1000 {
		p := len(s)
		s = s[1:p]
		return s
	}
	return s
}

func (cln *LineBanned) AddBan(asu string, group string) {
	if !AllowBan {
		return
	} else if MemAkses(group, asu) {
		return
	} else if asu == "" {
		return
	}
	if !Contains(Blacklist, asu) {
		Blacklist = append(Blacklist, asu)
		LastBan = AppendLast(LastBan, asu)
	}
	ro := GetRoom(group)
	if !Contains(ro.Bajingan, asu) {
		ro.Bajingan = append(ro.Bajingan, asu)
	}
}

func (cln *LineBanned) AddGBan(asu string, group string) {
	println(asu)
	if MemAkses(group, asu) {
		return
	} else if asu == "" {
		return
	} else if !Contains(Blacklist, asu) {
		Blacklist = append(Blacklist, asu)
		LastBan = AppendLast(LastBan, asu)
	}
}

func IndexOf(data []string, element string) int {
	for k, v := range data {
		if element == v {
			return k
		}
	}
	return -1
}

func (cln *LineBanned) DelBan(asu string, group string) {
	if Contains(Blacklist, asu) {
		Blacklist = Remove(Blacklist, asu)
	}
	ix := IndexOf(cln.Group, group)
	if ix != -1 {
		isi := cln.User[ix]
		if !Contains(isi, asu) {
			cln.User[ix] = Remove(isi, asu)
		}
	} else {
		cln.Group = append(cln.Group, group)
		cln.User = append(cln.User, []string{})
	}
}

func IsBan(gid, user string) bool {
	if Contains(Blacklist, user) {
		return true
	} else if ga, ok := CheckGaccess(gid); ok {
		return Contains(ga.Blacklist, user)
	}
	return false
}

func IsBanArray(gid string, s []string) bool {
	for _, user := range s {
		if Contains(Blacklist, user) {
			return true
		} else if ga, ok := CheckGaccess(gid); ok {
			return Contains(ga.Blacklist, user)
		}
		return false
	}
	return false
}

func DelBan(asu, gid string) {
	if Contains(Blacklist, asu) {
		Blacklist = Remove(Blacklist, asu)
	} else if ga, ok := CheckGaccess(gid); ok {
		if Contains(ga.Blacklist, asu) {
			ga.Blacklist = Remove(ga.Blacklist, asu)
			SaveGaccess(gid, ga)
		}
	}
}

func SaveGaccess(to string, access *GAccess) {
	tam := fmt.Sprintf("status.gaccess.%v", to)
	ma := map[string][]string{"blacklist": access.Blacklist, "mute": access.Mute, "staff": access.Staff, "bot": access.Bot}
	value, _ := sjson.Set(Settings, tam, ma)
	Settings = value
	JsonDump(true, JsonFile, Settings)
}

func LogLast(op *LineThrift.Operation, midds string) {
	defer VHrecover("LOGOP")
	LastActive.Set(midds, op)
}

func AppendLastD(s [][]string, e []string) [][]string {
	defer VHrecover("kko")
	s = append(s, e)
	if len(s) >= 1000 {
		s = s[1:]
		return s
	}
	return s
}

func LogOp(op *LineThrift.Operation, client *LineClient) {
	defer VHrecover("LOGOP")
	tipe := op.Type
	group := op.Param1
	pelaku := op.Param2
	korban := op.Param3
	if tipe == 124 || tipe == 123 {
		var invites []string
		if tipe == 124 {
			LogLast(op, pelaku)
			invites = strings.Split(korban, "\x1e")
		} else {
			invites = strings.Split(pelaku, "\x1e")
		}

		ll := len(invites)
		if ll != 0 {
			g, ok := Lastinvite.Get(op.Param1)
			if !ok {
				Lastinvite.Set(op.Param1, invites)
			} else {
				c := g.([]string)
				for _, can := range invites {
					c = AppendLast(c, can)
				}
				Lastinvite.Set(op.Param1, c)
			}
		}

		if len(Logmode) != 0 && Grade(group, pelaku) < 4 && !Contains(Creator, pelaku) {
			if ll > 0 {
				rm := GetRoom(group)
				var nm string
				if rm.Name == "" {
					nm, _ := client.GetGroupName(group)
					rm.Name = nm
				} else {
					nm = rm.Name
				}
				for _, to := range Logmode {
					if !Contains(Protected, to) {
						continue
					}
					exe := rm.Client[0]
					var names string
					if tipe == 124 {
						prs, _ := client.GetContact(pelaku)
						names = prs.DisplayName
					} else {
						names = "Squad"
					}
					var tex = fmt.Sprintf("%s\n\nInviter: %s .\nInvited: %v user.", nm, names, ll)
					exe.SendText(to, tex)
				}
			}
		}

	} else if tipe == 133 {
		g, ok := Lastkick.Get(op.Param1)
		if !ok {
			g = []string{op.Param3}
			Lastkick.Set(op.Param1, g)
		} else {
			c := g.([]string)
			c = AppendLast(c, op.Param3)
			Lastkick.Set(op.Param1, c)
		}
		LogLast(op, pelaku)
		if len(Logmode) != 0 && Grade(group, pelaku) < 4 && !Contains(Creator, pelaku) {
			rm := GetRoom(group)
			var nm string
			if rm.Name == "" {
				nm, _ := client.GetGroupName(group)
				rm.Name = nm
			} else {
				nm = rm.Name
			}
			for _, to := range Logmode {
				if !Contains(Protected, to) {
					continue
				}

				exe := rm.Client[0]
				if exe == nil {
					continue
				}
				prs, _ := client.GetContact(pelaku)
				names := prs.DisplayName
				prs, _ = client.GetContact(korban)
				names2 := prs.DisplayName
				var tex = fmt.Sprintf("%s\n\nKicker: %s .\nKicked: %s .", nm, names, names2)
				exe.SendText(to, tex)
			}
		}
	} else if tipe == 132 {
		g, ok := Lastkick.Get(op.Param1)
		if !ok {
			g = []string{op.Param2}
			Lastkick.Set(op.Param1, g)
		} else {
			c := g.([]string)
			c = AppendLast(c, op.Param2)
			Lastkick.Set(op.Param1, c)
		}

	} else if tipe == 130 {
		LogLast(op, pelaku)
		g, ok := Lastjoin.Get(op.Param1)
		if !ok {
			g = []string{op.Param2}
			Lastjoin.Set(op.Param1, g)
		} else {
			c := g.([]string)
			c = AppendLast(c, op.Param2)
			Lastjoin.Set(op.Param1, c)
		}
		if len(Logmode) != 0 && Grade(group, pelaku) < 4 && !Contains(Creator, pelaku) {
			rm := GetRoom(group)
			var nm string
			if rm.Name == "" {
				nm, _ := client.GetGroupName(group)
				rm.Name = nm
			} else {
				nm = rm.Name
			}
			for _, to := range Logmode {
				if !Contains(Protected, to) {
					continue
				}

				exe := rm.Client[0]
				if exe == nil {
					continue
				}
				prs, _ := client.GetContact(pelaku)
				names := prs.DisplayName
				var tex = fmt.Sprintf("%s\n\nJoin: %s .", nm, names)
				exe.SendText(to, tex)
			}
		}
	} else if tipe == 5 {
		g, ok := Lastadd.Get("add")
		if !ok {
			g = []string{group}
			Lastadd.Set("add", g)
		} else {
			c := g.([]string)
			c = AppendLast(c, group)
			Lastadd.Set("add", c)
		}
		if len(Logmode) != 0 {
			for _, to := range Logmode {
				if !Contains(Protected, to) {
					continue
				}

				exe := Client[0]
				if exe == nil {
					continue
				}
				prs, _ := client.GetContact(group)
				names := prs.DisplayName
				var tex = fmt.Sprintf("%s added a bot %s \nAdder Mid: %s", names, client.Name, group)
				exe.SendText(to, tex)
			}
		}
	} else if tipe == 126 {
		LogLast(op, pelaku)
		g, ok := Lastcancel.Get(op.Param1)
		if !ok {
			g = []string{op.Param3}
			Lastcancel.Set(op.Param1, g)
		} else {
			c := g.([]string)
			c = AppendLast(c, op.Param3)
			Lastcancel.Set(op.Param1, c)
		}
		if len(Logmode) != 0 && Grade(group, pelaku) < 4 && !Contains(Creator, pelaku) {
			rm := GetRoom(group)
			var nm string
			if rm.Name == "" {
				nm, _ := client.GetGroupName(group)
				rm.Name = nm
			} else {
				nm = rm.Name
			}
			for _, to := range Logmode {
				if !Contains(Protected, to) {
					continue
				}

				exe := rm.Client[0]
				if exe == nil {
					continue
				}
				prs, _ := client.GetContact(pelaku)
				names := prs.DisplayName
				prs, _ = client.GetContact(korban)
				names2 := prs.DisplayName
				var tex = fmt.Sprintf("%s\n\nCanceler: %s .\nCanceled: %s .", nm, names, names2)
				exe.SendText(to, tex)
			}
		}
	} else if tipe == 122 {
		LogLast(op, pelaku)
		g, ok := Lastupdate.Get(op.Param1)
		if !ok {
			g = []string{op.Param2}
			Lastupdate.Set(op.Param1, g)
		} else {
			c := g.([]string)
			c = AppendLast(c, op.Param2)
			Lastupdate.Set(op.Param1, c)
		}
		if len(Logmode) != 0 && Grade(group, pelaku) < 4 && !Contains(Creator, pelaku) {
			_, _, gg := client.FCKGetMember(group)
			var ti = "close"
			rm := GetRoom(group)
			if op.Param3 == "4" {
				if !gg {
					ti = "Open qr"
				} else {
					ti = "Close qr"
				}
			} else if op.Param3 == "1" {
				ti = "Change Group Name"
			}
			for _, to := range Logmode {
				if !Contains(Protected, to) {
					continue
				}

				exe := rm.Client[0]
				if exe == nil {
					continue
				}
				prs, _ := client.GetContact(pelaku)
				names := prs.DisplayName
				var tex = fmt.Sprintf("%s\n\nGroup Update:\n %s \nState: %s.", rm.Name, names, ti)
				exe.SendText(to, tex)
			}
		}
	} else if tipe == 128 {
		LogLast(op, pelaku)
		g, ok := Lastleave.Get(op.Param1)
		if !ok {
			g = []string{op.Param2}
			Lastleave.Set(op.Param1, g)
		} else {
			c := g.([]string)
			c = AppendLast(c, op.Param2)
			Lastleave.Set(op.Param1, c)
		}
		if len(Logmode) != 0 && Grade(group, pelaku) < 4 && !Contains(Creator, pelaku) {
			rm := GetRoom(group)
			var nm string
			if rm.Name == "" {
				nm, _ := client.GetGroupName(group)
				rm.Name = nm
			} else {
				nm = rm.Name
			}
			for _, to := range Logmode {
				if !Contains(Protected, to) {
					continue
				}

				exe := rm.Client[0]
				if exe == nil {
					continue
				}
				prs, _ := client.GetContact(pelaku)
				names := prs.DisplayName
				var tex = fmt.Sprintf("%s\n\nLeave: %s .", nm, names)
				exe.SendText(to, tex)
			}
		}
	} else if tipe == 26 {
		var MentionMsg = MentionList(op)
		msg := op.Message
		if Contains(Squad, msg.From_) {
			return
		}
		LogLast(op, msg.From_)
		if len(MentionMsg) != 0 {
			g, ok := Lasttag.Get(msg.To)
			if !ok {
				g = MentionMsg
				Lasttag.Set(msg.To, g)
			} else {
				c := g.([]string)
				for _, men := range MentionMsg {
					c = AppendLast(c, men)
				}
				Lasttag.Set(msg.To, c)
			}
			if strings.Contains(msg.Text, "u") {
				regex, _ := regexp.Compile(`u\w{32}`)
				links := regex.FindAllString(msg.Text, -1)
				mmd := []string{}
				for _, a := range links {
					if len(a) == 33 {
						mmd = append(mmd, a)
					}
				}
				if len(mmd) != 0 {
					g, ok := Lastmid.Get(msg.To)
					if !ok {
						g = [][]string{mmd}
						Lastmid.Set(msg.To, g)
					} else {
						c := g.([][]string)
						c = AppendLastD(c, mmd)
						Lastmid.Set(msg.To, c)
					}
				}
			}
		} else if msg.ContentType == 13 {
			mids := msg.ContentMetadata["mid"]
			g, ok := Lastcon.Get(msg.To)
			if !ok {
				g = []string{mids}
				Lastcon.Set(msg.To, g)
			} else {
				c := g.([]string)
				c = AppendLast(c, mids)
				Lastcon.Set(msg.To, c)
			}

		} else if msg.ContentType == 0 {
			if strings.Contains(msg.Text, "u") {
				regex, _ := regexp.Compile(`u\w{32}`)
				links := regex.FindAllString(msg.Text, -1)
				mmd := []string{}
				for _, a := range links {
					if len(a) == 33 {
						mmd = append(mmd, a)
					}
				}
				if len(mmd) != 0 {
					g, ok := Lastmid.Get(msg.To)
					if !ok {
						g = [][]string{mmd}
						Lastmid.Set(msg.To, g)
					} else {
						c := g.([][]string)
						c = AppendLastD(c, mmd)
						Lastmid.Set(msg.To, c)
					}
				}
			}
		}
	}
}

func CheckGaccess(gid string) (a *GAccess, b bool) {
	for _, g := range ChatAccess {
		if g.Id == gid {
			return g, true
		}
	}
	return nil, false
}

func Grade(group string, from string) int {
	if Contains(Creator, from) || Contains(Resel, from) {
		return 0
	} else if Contains(Owner, from) {
		return 1
	} else if Contains(Admin, from) {
		return 2
	} else if Contains(GlobalStaff, from) {
		return 3
	} else if v, ok := CheckGaccess(group); ok {
		if Contains(v.Staff, from) {
			return 3
		}
	}
	return 100
}

func GradeKick(group string, from string) int {
	if Contains(Creator, from) || Contains(Resel, from) {
		return 0
	} else if Contains(Owner, from) {
		return 1
	} else if Contains(Admin, from) {
		return 2
	} else if Contains(Squad, from) || Contains(Bot, from) || Contains(GlobalStaff, from) {
		return 3
	} else if v, ok := CheckGaccess(group); ok {
		if Contains(v.Staff, from) {
			return 4
		} else if Contains(v.Bot, from) {
			return 3
		}
	}
	return 100
}

func MemUser(group string, from string) bool {
	if Contains(Squad, from) {
		return false
	} else if Contains(Creator, from) {
		return false
	} else if Contains(Resel, from) {
		return false
	} else if Contains(Owner, from) {
		return false
	} else if Contains(Admin, from) {
		return false
	} else if Contains(Bot, from) {
		return false
	} else if IsGbot(group, from) {
		return false
	} else if Contains(Staymid, from) {
		return false
	} else if Contains(GlobalStaff, from) {
		return false
	} else if IsGaccess(group, from) {
		return false
	}
	return true
}

func MemAkses(group string, from string) bool {
	if Contains(Squad, from) {
		return true
	} else if Contains(Creator, from) {
		return true
	} else if Contains(Resel, from) {
		return true
	} else if Contains(Owner, from) {
		return true
	} else if Contains(Admin, from) {
		return true
	} else if Contains(Bot, from) {
		return true
	} else if IsGbot(group, from) {
		return true
	} else if Contains(Staymid, from) {
		return true
	} else if Contains(GlobalStaff, from) {
		return true
	} else if IsGaccess(group, from) {
		return true
	}
	return false
}

func Remove(items []string, item string) []string {
	defer AnyPanicHandle()
	newitems := []string{}
	for _, i := range items {
		if i != item {
			newitems = append(newitems, i)
		}
	}

	return newitems
}

func RemoveAva(items []*Ava, item *Ava) []*Ava {
	defer AnyPanicHandle()
	newitems := []*Ava{}
	for _, i := range items {
		if i != item {
			newitems = append(newitems, i)
		}
	}
	return newitems
}

func ContainsAva(arr []*Ava, str *LineClient) bool {
	for _, tar := range arr {
		if tar.Client == str {
			return true
		}
	}
	return false
}

func IsWar(to string, cl *LineClient) bool {
	for _, room := range SquadRoom {
		if room.Id == to {
			for _, cls := range room.GoClient {
				if cl == cls {
					return false
				}
			}
			return true
		}
	}
	return true
}

func IsGbot(gid, user string) bool {
	if ga, ok := CheckGaccess(gid); ok {
		return Contains(ga.Bot, user)
	}
	return false
}

func IsGaccess(gid, user string) bool {
	if ga, ok := CheckGaccess(gid); ok {
		return Contains(ga.Bot, user)
	}
	return false
}

func (cl *LineClient) GetChatListMapCek(to string) (peek bool, memb map[string]int64, pend map[string]int64) {
	defer VHrecover("FCKGetMember: " + cl.Name)
	p11, err := cl.GetChats(to)
	if err != nil {
		p11, err = cl.GetChats(to)
		if err != nil {
			return peek, memb, pend
		}
	}
	p13 := p11.Chats[0]
	return p13.Extra.GroupExtra.PreventedJoinByTicket, p13.Extra.GroupExtra.MemberMids, p13.Extra.GroupExtra.InviteeMids
}

func (cl *LineClient) GetChatListLINE(to string) (peek bool, memb map[string]int64, pend map[string]int64) {
	defer VHrecover("GetChatsByte: " + cl.Name)
	p11 := cl.GetChatsByte(to)
	p13 := p11.Chats[0]
	return p13.Extra.GroupExtra.PreventedJoinByTicket, p13.Extra.GroupExtra.MemberMids, p13.Extra.GroupExtra.InviteeMids
}

func (cl *LineClient) GetGroupMember(to string) (memb map[string]int64) {
	defer VHrecover("FCKGetMember: " + cl.Name)
	p11, err := cl.GetChats(to)
	if err != nil {
		p11, err = cl.GetChats(to)
		if err != nil {
			P(fmt.Sprintf("GetChatsFCK %v", err))
			return memb
		}
	}
	p13 := p11.Chats[0]
	return p13.Extra.GroupExtra.MemberMids
}

func (cln *LineClient) GetChatList(to string) (name string, mem, inv []string) {
	res, err := cln.GetChats(to)
	if err != nil {
		P(fmt.Sprintf("GetChatsFCK %v", err))
		return name, mem, inv
	}
	if len(res.Chats) == 0 {
		return name, mem, inv
	}
	ch := res.Chats[0]
	for a := range ch.Extra.GroupExtra.MemberMids {
		mem = append(mem, a)
	}
	for a := range ch.Extra.GroupExtra.InviteeMids {
		inv = append(inv, a)
	}
	return ch.ChatName, mem, inv
}

func (cln *LineRoom) Reset() {
	cln.Qr = false
	for _, cl := range cln.Ava {
		if cl.Client.Limiter {
			cl.Exist = true
		}
	}
	cln.Tclient = ""
	cln.Tcore = []string{}
	cln.Bajingan = []string{}
	cln.Danger = false
	cln.Nuke = false
	cln.Mparam2 = ""
	cln.Purge = false
}

func (cln *LineBanned) GetBan(group string) []string {
	ix := IndexOf(cln.Group, group)
	if ix != -1 {
		isi := cln.User[ix]
		return isi

	} else {
		cln.Group = append(cln.Group, group)
		cln.User = append(cln.User, []string{})
		return []string{}
	}
}

func (tok *LineClient) GetSquad(to string) []*LineClient {
	defer VHrecover("FCKGetSquad")
	_, memlist, invs := tok.GetChatList(to)
	gmem := []*LineClient{}
	gs := []string{}
	gsm := []string{}
	for _, ym := range memlist {
		if Contains(Squad, ym) {
			idx := IndexOf(Squad, ym)
			gs = append(gs, ym)
			gmem = append(gmem, Client[idx])
		}
		if Grade(to, ym) < 4 {
			gsm = append(gsm, ym)
		}
	}
	for _, me := range Staymid {
		if !Contains(gsm, me) {
			gsm = append(gsm, me)
		}
	}
	if ShortFight {
		sort.Slice(gmem, func(i, j int) bool {
			return gmem[i].CustomPoint < gmem[j].CustomPoint
		})
	} else {
		sort.Slice(gmem, func(i, j int) bool {
			return gmem[i].KickPoint < gmem[j].KickPoint
		})
	}
	room := GetRoom(to)
	room.AddSquad(gs, gsm, gmem)

	if !Contains(Protected, to) {
		Protected = append(Protected, to)
	}

	inlis := []string{}
	for _, ym := range invs {
		if Contains(Squad, ym) {
			idx := GetKorban(ym)
			GetRoom(to).RevertGo(idx)
		}
		inlis = append(inlis, ym)
	}
	for _, mid := range room.GoMid {
		if !Contains(inlis, mid) {
			cl := GetKorban(mid)
			room.DelGo(cl)
		}
	}
	Banned.GetBan(to)
	return gmem
}

func LogFight(room *LineRoom) {
	defer VHrecover("LOGFIGhT")
	var tx = "「  Log Mode 」\n\n"
	if room.Name == "" || len(room.Name) < 3 {
		for i := 0; i < len(room.Client); i++ {
			exe := room.Client[0]
			if exe.Ready {
				g, _ := exe.GetGroupName(room.Id)
				room.Name = g
				break
			}
		}
		if room.Name == "" || len(room.Name) < 3 {
			for _, cl := range Client {
				if cl.Ready {
					g, _ := cl.GetGroupName(room.Id)
					room.Name = g
					break
				}
			}
		}
	}

	tx += fmt.Sprintf("Squad action's in Group:\n%s\n", room.Name)
	tx += fmt.Sprintf("\nKick's: %v", room.Kick)
	tx += fmt.Sprintf("\nInvite's: %v", room.Invite)
	tx += fmt.Sprintf("\nCancel's: %v", room.Cancel)
	fmt.Printf(tx)
	if len(Logmode) != 0 {
		tt := []string{}
		for _, to := range Logmode {
			if !Contains(tt, to) {
				tt = append(tt, to)
			}
		}
		Logmode = tt
	asu:
		for _, to := range tt {
			room := GetRoom(to)
			if Contains(Protected, to) {
				for i := 0; i < len(room.Client); i++ {
					exe := room.Client[0]
					if exe.Ready {
						exe.SendText(to, tx)
						break asu
					}
				}
			}
		}
	}

	room.Kick = 0
	room.Invite = 0
	room.Cancel = 0
}
func NewGaccess(group string) *GAccess {
	var gas *GAccess
	if _, t := CheckGaccess(group); !t {
		gas = &GAccess{Id: group, Blacklist: []string{}, Mute: []string{}, Staff: []string{}, Bot: []string{}}
		ChatAccess = append(ChatAccess, gas)
	}
	return gas
}
func AddGaccess(gid, user, tipe string) bool {
	ga, ok := CheckGaccess(gid)
	if !ok {
		ga = NewGaccess(gid)
	}
	if tipe == "blacklist" && !Contains(ga.Blacklist, user) {
		if !Contains(ga.Blacklist, user) {
			ga.Blacklist = append(ga.Blacklist, user)
			SaveGaccess(gid, ga)
			return true
		}
		return false
	} else if tipe == "mute" && !Contains(ga.Mute, user) {
		if !Contains(ga.Mute, user) {
			ga.Mute = append(ga.Mute, user)
			SaveGaccess(gid, ga)
			return true
		}
		return false
	} else if tipe == "staff" && !Contains(ga.Staff, user) {
		if !Contains(ga.Staff, user) {
			ga.Staff = append(ga.Staff, user)
			SaveGaccess(gid, ga)
			return true
		}
		return false
	} else if tipe == "bot" && !Contains(ga.Bot, user) {
		if !Contains(ga.Bot, user) {
			ga.Bot = append(ga.Bot, user)
			SaveGaccess(gid, ga)
			return true
		}
		return false
	}
	return false
}

func ExpelGaccess(gid, user string) bool {
	if ga, ok := CheckGaccess(gid); ok {
		if Contains(ga.Staff, user) {
			ga.Staff = Remove(ga.Staff, user)
			SaveGaccess(gid, ga)
			return true
		}
		return false
	}
	return false
}
func InArrayInt64(arr []int64, str int64) bool {
	for _, tar := range arr {
		if tar == str {
			return true
		}
	}
	return false
}
func InArrayCl(arr []*LineClient, str *LineClient) bool {
	for _, tar := range arr {
		if tar == str {
			return true
		}
	}
	return false
}
func Addwl(g string, w []string) {
	for _, mid := range w {
		if !IsBan(g, mid) {
			if !Contains(Whitelist, mid) && MemUser(g, mid) {
				Whitelist = append(Whitelist, mid)
			}
		}
	}
}
func (cl *LineClient) AddOps(op *LineThrift.Operation) {
	cl.Ops = append(cl.Ops, op)
}
func (cl *LineClient) CekOp(op *LineThrift.Operation) bool {
	for _, ops := range cl.Ops {
		if ops.Type == op.Type && ops.CreatedTime == op.CreatedTime {
			if op.Param3 != cl.Mid {
				return true
			} else {
				return false
			}
		}
	}
	return false
}

func (cl *LineClient) SafeClient(to string, param2 string, param3 string, heh bool) {
	defer func() {
		VHrecover("SafeClient: " + cl.Name)
	}()
	go cl.NewKickLINE(to, param2)
	var room = GetRoom(to)
	memb, inv, tickt := cl.FCKGetMember(to)
	if len(memb) == 0 {
		bott := room.Cans()
		for _, bn := range bott {
			if bn != cl {
				memb, inv, tickt = bn.FCKGetMember(to)
				if len(memb) != 0 {
					break
				}
			}
		}
	}
	var sy = 0
	var babi = []string{}
	var NotInv = []string{}
	var bot = room.Bot
	var Slenght = len(bot)
	var exe = []*LineClient{}
	if heh {
		for i := len(memb) - 1; i >= 0; i-- {
			mid := memb[i]
			if mid == cl.Mid {
				sy = 1
			}
			if Contains(bot, mid) {
				NotInv = append(NotInv, mid)
				if Mclient[mid].Kicked {
					room.Tclient = mid
					sy = 1
					exe = append(exe, Mclient[mid])
				}
			} else if IsBan(to, mid) {
				if mid != param2 {
					babi = append(babi, mid)
				}
			}
		}
	} else {
		for i := len(memb) - 1; i >= 0; i-- {
			mid := memb[i]
			if mid == cl.Mid {
				sy = 1
			}
			if Contains(bot, mid) {
				NotInv = append(NotInv, mid)
				if Mclient[mid].Kicked {
					room.Tclient = mid
					sy = 1
					exe = append(exe, Mclient[mid])
				}
			}
		}
	}
	if sy == 0 {
		fc := len(NotInv)
		if fc != 0 {
			if !Contains(NotInv, room.Tclient) {
				for _, client := range NotInv {
					room.Tclient = client
					break
				}
			}
		} else {
			return
		}
	}
	for i := 0; i < len(babi); i++ {
		go func(o string) {
			Mclient[room.Tclient].NewKickLINE(to, o)
		}(babi[i])
	}
	for _, i := range inv {
		if IsBan(to, i) {
			go func(is string) {
				Mclient[room.Tclient].NewCancelLINE(to, is)
			}(i)
		}
	}
	cno := 0
	xl := Mclient[room.Tclient]
	for i := len(bot) - 1; i >= 0; i-- {
		mie := bot[i]
		if !Contains(NotInv, mie) && room.Tclient != mie {
			cno++
			go func(bi string, xx *LineClient) {
				xx.NewInviteLINE(to, []string{bi})
			}(mie, xl)
			if cno == 3 {
				break
			}
		}
	}
	if !tickt {
		tickets := cl.ReissueChatTicket(to)
		if len(tickets) < 2 {
			return
		}
		for i := 0; i < Slenght; i++ {
			if !Contains(NotInv, bot[i]) {
				go func(mie string) {
					Mclient[mie].AcceptGroupInvitationByTicket(to, tickets)
				}(bot[i])
			}
		}
	}
}

func (client *LineClient) LINEFastJoin(to string) {
	defer VHrecover("LINEFastJoin: " + client.Name)
	go func(to string) {
		go client.NewAcceptLINE(to)
	}(to)
	_, memlist, inv := client.GetChatListMapCek(to)
	if memlist != nil {
		for v := range memlist {
			if IsBan(to, v) == true {
				go func(v string) {
					go client.NewKickLINE(to, v)
				}(v)
			}
		}
	}
	if inv != nil {
		for v := range inv {
			if IsBan(to, v) == true {
				go func(v string) {
					go client.NewCancelLINE(to, v)
				}(v)
			}
		}
	}
}

func (client *LineClient) BackupV2(to string, mid string, korban string) {
	defer VHrecover("BackupV2: " + client.Name)
	go runtime.Gosched()
	go func() {
		client.NewInviteLINE(to, []string{korban})
	}()
	var Batas = 0
	_, targets, targets2 := client.GetChatListMapCek(to)
	listMid := []string{}
	listMid2 := []string{}
	for cok := range targets {
		listMid = append(listMid, cok)
	}
	for cok := range targets2 {
		listMid2 = append(listMid2, cok)
	}
	for v := range Blacklist {
		go runtime.Gosched()
		if Contains(listMid2, Blacklist[v]) {
			go runtime.Gosched()
			go func(v string) {
				client.NewCancelLINE(to, v)
			}(Blacklist[v])
			Batas = Batas + 1
			if int64(Batas) >= int64(Batasan) {
				Batas = 0
				break
			}
		} else if Contains(listMid, Blacklist[v]) {
			go runtime.Gosched()
			go func(v string) {
				client.NewKickLINE(to, v)
			}(Blacklist[v])
				Batas = Batas + 1
				if int64(Batas) >= int64(Batasan) {
				Batas = 0
				break
			}
		}
	}
}


func (client *LineClient) GroupBackup(to, pelaku string, korban string, cek bool) {
	defer VHrecover("GroupBackup: " + client.Name)
	var Batas = 0
	qr, memlist, inv := client.GetChatListMapCek(to)
	room := GetRoom(to)
	if len(memlist) == 0 {
		va := room.Cans()
		for _, cl := range va {
			qr, memlist, inv = cl.GetChatListMapCek(to)
			if len(memlist) != 0 {
				break
			}
		}
	}
	bot := room.Bot
	exe := []*LineClient{}
	oke := []string{}
	ban := []string{pelaku}
	hei := false
	for mid := range memlist {
		if Contains(bot, mid) {
			cl := Mclient[mid]
			if cl.Kicked {
				exe = append(exe, cl)
				room.Tclient = mid
				hei = true
			}
			oke = append(oke, mid)
			if room.Tclient == mid {
				hei = true
			}
		} else if IsBan(to, mid) {
			if pelaku != mid {
				ban = append(ban, mid)
			}
		}
	}
	if !hei {
		if len(exe) != 0 {
			room.Tclient = exe[0].Mid
		} else if len(oke) != 0 {
			room.Tclient = oke[0]
		} else {
			return
		}
	}
	go func(inv map[string]int64) {
		for i := range inv {
			if IsBan(to, i) {
				go Mclient[room.Tclient].NewCancelLINE(to, i)
			}
		}
	}(inv)
	go func() {
		cno := 0
		for _, mie := range bot {
			if !Contains(oke, mie) {
				cno++
				go Mclient[room.Tclient].NewInviteLINE(to, []string{mie})
				if cno == 3 {
					break
				}
			}
		}
	}()
	cl := Mclient[room.Tclient]
	if Killmode != "none" && AllowBan && cek {
		if Killmode == "kill" {
			var createdTime int64
			for mid, tt := range memlist {
				if pelaku == mid {
					createdTime = tt
					break
				}
			}
			for mid, tt := range memlist {
				ct := float64(createdTime/1000 - tt/1000)
				if valid.Abs(ct) <= 10 {
					if MemUser(to, mid) {
						Banned.AddBan(mid,to)
						ban = append(ban, mid)
					}
				}
			}
			for _, target := range ban {
				go func(target string) {
					cl.NewKickLINE(to, target)
				}(target)
				Batas = Batas + 1
				if int64(Batas) >= int64(Batasan) {
					Batas = 0
					break
				}
			}
		} else {
			for _, cok := range ban {
				go cl.NewKickLINE(to, cok)
				Batas = Batas + 1
				if int64(Batas) >= int64(Batasan) {
					Batas = 0
					break
				}
			}
		}
		/*for _, cok := range ban {
			go Mclient[room.Tclient].NewKickLINE(to, cok)
		}*/
	} else {
		cl.NewKickLINE(to, pelaku)
	}
	if !qr {
		tickets := Mclient[room.Tclient].ReissueChatTicket(to)
		if len(tickets) < 2 {
			return
		}
		for i := 0; i < len(oke); i++ {
			if !Contains(oke, bot[i]) {
				go func(mie string) {
					Mclient[mie].AcceptGroupInvitationByTicket(to, tickets)
				}(bot[i])
			}
		}
	}
}

func (client *LineClient) GroupBackup2(to, pelaku string, korban string, cek bool) {
	defer VHrecover("GroupBackup: " + client.Name)
	var Batas = 0
	qr, memlist, inv := client.GetChatListMapCek(to)
	room := GetRoom(to)
	if len(memlist) == 0 {
		va := room.Cans()
		for _, cl := range va {
			qr, memlist, inv = cl.GetChatListMapCek(to)
			if len(memlist) != 0 {
				break
			}
		}
	}
	bot := room.Bot
	exe := []*LineClient{}
	oke := []string{}
	ban := []string{pelaku}
	hei := false
	for mid := range memlist {
		if Contains(bot, mid) {
			cl := Mclient[mid]
			if cl.Kicked {
				exe = append(exe, cl)
				room.Tclient = mid
				hei = true
			}
			oke = append(oke, mid)
			if room.Tclient == mid {
				hei = true
			}
		} else if IsBan(to, mid) {
			if pelaku != mid {
				ban = append(ban, mid)
			}
		}
	}
	if !hei {
		if len(exe) != 0 {
			room.Tclient = exe[0].Mid
		} else if len(oke) != 0 {
			room.Tclient = oke[0]
		} else {
			return
		}
	}
	cl := Mclient[room.Tclient]
	go func(inva map[string]int64) {
		for i := range inva {
			if IsBan(to, i) {
				go func(to string, is string) {
					cl.NewLINECancelChat(to, is)
				}(to, i)
			}
		}
	}(inv)
	go func() {
		cno := 0
		if Random {
			Random = false
			for _, mie := range bot {
				if !Contains(oke, mie) {
					cno++
					go func(bi string, xx *LineClient) {
						xx.InviteIntoChatByte(to, []string{bi})
					}(mie, cl)
					if cno == 3 {
						break
					}
				}
			}
		} else {
			Random = true
			ci := len(bot) - 1
			for i := ci; i >= 0; i-- {
				mie := bot[i]
				if !Contains(oke, mie) {
					cno++
					go func(bi string, xx *LineClient) {
						xx.InviteIntoChatByte(to, []string{bi})
					}(mie, cl)
					if cno == 3 {
						break
					}
				}
			}
		}
	}()
	if Killmode != "none" && AllowBan && cek {
		if Killmode == "kill" {
			var createdTime int64
			for mid, tt := range memlist {
				if pelaku == mid {
					createdTime = tt
					break
				}
			}
			for mid, tt := range memlist {
				ct := float64(createdTime/1000 - tt/1000)
				if valid.Abs(ct) <= 10 {
					if MemUser(to, mid) {
						Banned.AddBan(mid,to)
						ban = append(ban, mid)
					}
				}
			}
			for _, target := range ban {
				go func(target string) {
					cl.NewLINEKickChat(to, target)
				}(target)
				Batas = Batas + 1
				if int64(Batas) >= int64(Kicker) {
					Batas = 0
					break
				}
			}
		} else {
			for _, cok := range ban {
				go cl.NewLINEKickChat(to, cok)
				Batas = Batas + 1
				if int64(Batas) >= int64(Kicker) {
					Batas = 0
					break
				}
			}
		}
	} else {
		cl.NewLINEKickChat(to, pelaku)
	}
	if !qr {
		tickets := cl.ReissueChatTicket(to)
		if len(tickets) < 2 {
			return
		}
		for i := 0; i < len(oke); i++ {
			if !Contains(oke, bot[i]) {
				go func(mie string) {
					Mclient[mie].AcceptGroupInvitationByTicket(to, tickets)
				}(bot[i])
			}
		}
	}
}

func (cl *LineRoom) CorrectParam2(param2 string) bool {
	if param2 == cl.Mparam2 {
		return false
	} else {
		cl.Mparam2 = param2
		return true
	}
}

func (client *LineClient) KickCansBL (to string) {
	var Batas = 0
	_, memlists, inv := client.GetChatListMapCek(to)
	go func(){
		for mid := range memlists {
			if IsBan(to, mid) {
				go func(mid string) {
					go client.NewKickLINE(to, mid)
				}(mid)
				Batas = Batas + 1
				if int64(Batas) >= int64(Batasan) {
					Batas = 0
					break
				}
			}
		}
	}()
	go func(){
		for mid := range inv {
			if IsBan(to, mid) {
				go func(mid string) {
					go client.NewCancelLINE(to, mid)
				}(mid)
				Batas = Batas + 1
				if int64(Batas) >= int64(Batasan) {
					Batas = 0
					break
				}
			}
		}
	}()
}

func KickBl(cl *LineClient, to string) {
	chat,_ := cl.tcrGetChats(to)
	memlists := chat[0].Extra.GroupExtra.MemberMids
	inv := chat[0].Extra.GroupExtra.InviteeMids
	if len(memlists) == 0 {
		return
	}
	var Batas1 = 0
	go func(inva map[string]int64) {
		for i := range inva {
			if IsBan(to, i) {
				go func(is string) {
					cl.NewCancelLINE(to, is)
				}(i)
				if int64(Batas1) >= int64(Batasan) {
					Batas1 = 0
					break
				}
				Batas1++
			}
		}
	}(inv)
	var Batas2 = 0
	for mid := range memlists {
		if IsBan(to, mid) {
			go cl.NewKickLINE(to, mid)
			if int64(Batas2) >= int64(Batasan) {
				Batas2 = 0
				break
			}
			Batas2++
		}
	}
}

func DetectBotOnly(memlist map[string]int64, to string) []string {
	defer VHrecover("detect bot")
	cluster := []*clustering{}
	bot := []string{}
	for a, t := range memlist {
		cluster = append(cluster, &clustering{mem: a, tm: t, fr: []string{a}})
	}
	for _, cl := range cluster {
		no := 0
		for us, tms := range memlist {
			if cl.mem != us {
				cak := tms - cl.tm
				if cak < 6000 && cak >= 0 {
					cl.fr = append(cl.fr, us)
					delete(memlist, us)

				} else if cak > -6000 && cak <= 0 {
					cl.fr = append(cl.fr, us)
					delete(memlist, us)
				}
			}
			no++
		}
		if len(cl.fr) > 4 {
			for _, mid := range cl.fr {
				if !Contains(bot, mid) && MemUser(to, mid) {
					bot = append(bot, mid)
				}
			}
		}
	}
	return bot
}

func (selfb *LineClient) BantaiGroup(to string, po bool, akl []string, prm string, room *LineRoom, delayMs string) []string {
	defer AnyPanicHandle()
	act := []*LineClient{}
	pri := []string{}
	priCancel := []string{}
	_, memlist, pendinglist := selfb.GetChatListMapCek(to)
	if len(memlist) == 0 {
		for _, mid := range akl {
			if mid != selfb.Mid {
				cls := Mclient[mid]
				_, memlist, _ = cls.GetChatListMapCek(to)
				if len(memlist) != 0 {
					break
				}
			}
		}
	}
	hunt := []string{}
	for a := range memlist {
		hunt = append(hunt, a)
	}
	huntCanc := []string{}
	for a := range pendinglist {
		huntCanc = append(huntCanc, a)
	}
	targetsKick := []string{}
	targetsCancel := []string{}
	targetsKick = append(targetsKick, DetectBotOnly(memlist, to)...)
	for _, a := range hunt {
		if MemUser(to, a) {
			if !Contains(targetsKick, a) {
				pri = append(pri, a)
			}
		}
	}
	targetsCancel = append(targetsCancel, DetectBotOnly(pendinglist, to)...)
	for _, a := range huntCanc {
		if MemUser(to, a) {
			if !Contains(targetsCancel, a) {
				priCancel = append(priCancel, a)
			}
		}
	}

	for _, p := range akl {
		if Contains(Squad, p) {
			ch := Mclient[p]
			if !ContainsCl(act, ch) && ch != selfb {
				act = append(act, ch)
			}
		}
	}

	pram2 := []*LineClient{}
	priInvi := []string{}
	if len(act) > 6 {
		pram2 = act[:6]
		ashjk := act[6:]
		for _, hehe := range ashjk {
			priInvi = append(priInvi, hehe.Mid)
		}
	} else {
		pram2 = act
	}

	lact := len(pram2)
	Atpro(to, selfb)
	fixFirstKick := []string{}
	if len(targetsKick) > 90 {
		fixFirstKick = targetsKick[:90]
		for i := 90; i < len(targetsKick); i++ {
			pri = append(pri, targetsKick[i])
		}
	} else {
		fixFirstKick = targetsKick
	}

	fixFirstCancel := []string{}
	if len(targetsCancel) > 28 {
		fixFirstCancel = targetsCancel[:28]
		for i := 28; i < len(targetsCancel); i++ {
			priCancel = append(priCancel, targetsCancel[i])
		}
	} else {
		fixFirstCancel = targetsCancel
		if len(priCancel) != 0 {
			if len(targetsCancel) == 0 {
				fixFirstCancel = priCancel
				priCancel = Kosong
			}
		}
	}

	no := 0
	acts := []*LineClient{}
	var cls *LineClient
	i := 0
	lm := len(pri)
	for ; i < lm; i++ {
		if no >= lact {
			no = 0
		}
		acts = append(acts, pram2[no])
		no += 1
	}
	no2 := 0
	acts2 := []*LineClient{}
	i2 := 0
	lm2 := len(priCancel)
	for ; i2 < lm2; i2++ {
		if no2 >= lact {
			no2 = 0
		}
		acts2 = append(acts2, pram2[no2])
		no2 += 1
	}

	no3 := 0
	acts3 := []*LineClient{}
	i3 := 0
	lm3 := len(priInvi)
	for ; i3 < lm3; i3++ {
		if no3 >= lact {
			no3 = 0
		}
		acts3 = append(acts3, pram2[no3])
		no3 += 1
	}

	daata := map[*LineClient][]string{}
	for n, target := range pri {
		cls = acts[n]
		daata[cls] = append(daata[cls], target)
	}

	daataCan := map[*LineClient][]string{}
	for n, target := range priCancel {
		cls = acts2[n]
		daataCan[cls] = append(daataCan[cls], target)
	}

	daataInv := map[*LineClient][]string{}
	for n, target := range priInvi {
		cls = acts3[n]
		daataInv[cls] = append(daataInv[cls], target)
	}

	dataClient := []map[string]interface{}{}
	for _, cok := range pram2 {
		if cok.Mid != selfb.Mid {
			asw := map[string]interface{}{
				cok.Mid: map[string]interface{}{
					"user_agent": Mclient[cok.Mid].UserAgent,
					"appname":    Mclient[cok.Mid].AppName,
					"authtoken":  Mclient[cok.Mid].AuthToken,
					"cancel":     daataCan[Mclient[cok.Mid]],
					"kick":       daata[Mclient[cok.Mid]],
					"invite":     daataInv[Mclient[cok.Mid]],
				},
			}
			//fmt.Println("\n\n", Mclient[cok.Mid].Name, len(daata[Mclient[cok.Mid]]))
			dataClient = append(dataClient, asw)
		}
	}

	sbInv := []string{}
	for _, s := range pram2 {
		if !Contains(hunt, s.Mid) {
			sbInv = append(sbInv, s.Mid)
		}
	}
	dataClient = append(dataClient, map[string]interface{}{
		selfb.Mid: map[string]interface{}{
			"user_agent": selfb.UserAgent,
			"appname":    selfb.AppName,
			"authtoken":  selfb.AuthToken,
			"cancel":     fixFirstCancel,
			"kick":       fixFirstKick,
			"invite":     sbInv,
		},
	})

	fl := selfb.GetAllContactIds()
	for _, nuss := range akl {
		if !Contains(fl, nuss) {
			selfb.AddFriendByMid(nuss)
			time.Sleep(5 * time.Second)
		}
	}
	// fmt.Println("\n\n", Mclient[selfb.Mid].Name, len(fixFirstKick))
	// fmt.Println(len(dataClient))
	// fmt.Println(len(sbInv))
	// jsonData, _ := json.MarshalIndent(dataClient, "", "  ")
	// fmt.Println(string(jsonData))

	time.Sleep(5 * time.Second)
	for _, mid := range akl {
		if mid != selfb.Mid {
			cls := Mclient[mid]
			_, memlist, _ = cls.GetChatListMapCek(to)
			if len(memlist) != 0 {
				NukeAllJS(cls, to, false, room.Bot, "", room)
				break
			}
		}
	}
	fmt.Println("GROUP RUSAK")
	return pri
}

func BanAll(memlist []string, to string) {
	ilen := len(memlist)
	for i := 0; i < ilen; i++ {
		Banned.AddBan(memlist[i], to)
	}
}

func (self *LineClient) Bypass(to string) {
    _,memlist,inv := self.GetChatListMapCek(to)
    members := make([]string, 0)
	invites := make([]string, 0)
    for k := range memlist {
        members = append(members, k)
    }
	for a := range inv {
        invites = append(invites, a)
    }
	ret := fmt.Sprintf("node kickall.js gid=%s type=dual token=%s app=android", to, self.AuthToken)
	for _, m := range members {
        ret += fmt.Sprintf(" uid=%s", m)
    }
	for _, x := range invites {
        ret += fmt.Sprintf(" uik=%s", x)
    }
	fmt.Println(ret)
    cmd := strings.Fields(ret)
    cmds := exec.Command(cmd[0], cmd[1:]...)
	//fmt.Println(cmds)
    output, err := cmds.CombinedOutput()
    if err != nil {
        fmt.Println("Error executing command:", err)
        return
    }
    fmt.Println(string(output))
}

/*func (client *LineClient) ByPass(to string) {
	_,memlist,inv := client.GetChatListMapCek(to)
	lkick := []string{}
	lcancel := []string{}
	for v := range memlist {
		if MemUser(to, v) {
			lkick = append(lkick, v)
		}
	}
	for x := range inv {
		if MemUser(to, x) {
			lcancel = append(lcancel, x)
		}
	}
	BanAll(lkick, to)
	BanAll(lcancel, to)
	bot := len(Squad)
	fmt.Println(lkick)
	fmt.Println(lcancel)
	for i := 0; i < bot; i++ {
		mem := lkick
		inv := lcancel
		go func(mem []string) {
			for _, mid := range mem {
				go client.NewKickLINE(to, mid)
			}
		}(mem)
		go func(inv []string) {
			for _, midx := range inv {
				go client.NewCancelLINE(to, midx)
			}
		}(inv)
	}
}*/

func NukeAllJS(cl *LineClient, to string, po bool, akl []string, prm string, room *LineRoom) []string {
	defer AnyPanicHandle()
	act := []*LineClient{}
	pri := []string{}
	_, memlist, _ := cl.GetChatListMapCek(to)
	if len(memlist) == 0 {
		for _, mid := range akl {
			if mid != cl.Mid {
				cls := Mclient[mid]
				_, memlist, _ = cls.GetChatListMapCek(to)
				if len(memlist) != 0 {
					break
				}
			}
		}
	}
	hunt := []string{}
	for a := range memlist {
		hunt = append(hunt, a)
	}
	targets := DetectBotOnly(memlist, to)
	for _, a := range hunt {
		if IsBan(to, a) {
			if !Contains(targets, a) {
				pri = append(pri, a)
			}
		} else if MemUser(to, a) {
			if !Contains(targets, a) {
				targets = append(targets, a)
			}

		} else if Contains(Squad, a) {
			act = append(act, Mclient[a])
		}
	}
	for _, p := range akl {
		if Contains(Squad, p) {
			ch := Mclient[p]
			if !ContainsCl(act, ch) {
				act = append(act, ch)
			}
		}
	}
	targets = append(pri, targets...)
	lact := len(act)
	if len(targets) < 1 {
		return targets
	} else {
		Atpro(to, cl)
		no := 0
		acts := []*LineClient{}
		var cls *LineClient
		i := 0
		lm := len(targets)
		for ; i < lm; i++ {
			if no >= lact {
				no = 0
			}
			acts = append(acts, act[no])
			no += 1
		}
		daata := map[*LineClient][]string{}
		for n, target := range targets {
			cls = acts[n]
			daata[cls] = append(daata[cls], target)
		}
		dataClient := []map[string]interface{}{}

		// for _, item := range arrs {
		// 	data = append(data, fmt.Sprintf("%q", item))
		// }
		// result := fmt.Sprintf("[%s]", strings.Join(data, ", "))
		for cok := range daata {
			asw := map[string]interface{}{
				cok.Mid: map[string]interface{}{
					"user_agent": cok.UserAgent,
					"appname":    cok.AppName,
					"authtoken":  cok.AuthToken,
					"cancel":     Kosong,
					"kick":       daata[cok],
					"invite":     Kosong,
				},
			}
			dataClient = append(dataClient, asw)
			// go func(clcok *LineClient) {
			//     clcok.JS_NukeALL(to, daata[clcok])
			// }(cok)
		}
		//JS_NukeALL(to, dataClient, []map[string]interface{}{})
		return targets
	}
}

func CounterAttackV12(client *LineClient, to string) {
	defer VHrecover("CounterAttackV12: " + client.Name)
	var Batas = 0
	_, targets, targets2 := client.GetChatListMapCek(to)
	listMid := []string{}
	listMid2 := []string{}
	for cok := range targets {
		listMid = append(listMid, cok)
		listMid = Remove(listMid, client.Mid)
	}
	for cok := range targets2 {
		listMid2 = append(listMid2, cok)
		listMid2 = Remove(listMid2, client.Mid)
	}
	for v := range Blacklist {
		if Contains(listMid, Blacklist[v]) {
			go runtime.Gosched()
			go func(v string) {
				client.NewKickLINE(to, v)
			}(Blacklist[v])
			Batas = Batas + 1
			if int64(Batas) >= int64(Batasan) {
				Batas = 0
				break
			}
		}
		if Contains(listMid2, Blacklist[v]) {
			go runtime.Gosched()
			go func(v string) {
				client.NewCancelLINE(to, v)
			}(Blacklist[v])
			Batas = Batas + 1
			if int64(Batas) >= int64(Batasan) {
				Batas = 0
				break
			}
		}
	}
}

func KickCancelRandomV12(client *LineClient, to string) {
	defer VHrecover("KickCancelRandomV12: " + client.Name)
	var Batas = 0
	_, targets, targets2 := client.GetChatListMapCek(to)
	listMid := []string{}
	listMid2 := []string{}
	for cok := range targets {
		listMid = append(listMid, cok)
		listMid = Remove(listMid, client.Mid)
	}
	for cok := range targets2 {
		listMid2 = append(listMid2, cok)
		listMid2 = Remove(listMid2, client.Mid)
	}
	for v := range Blacklist {
		if Contains(listMid, Blacklist[v]) {
			go func(v string) {
				client.NewKickLINE(to, v)
			}(Blacklist[v])
			Batas = Batas + 1
			if int64(Batas) >= int64(Batasan) {
				Batas = 0
				break
			}
		}
		if Contains(listMid2, Blacklist[v]) {
			go func(v string) {
				client.NewCancelLINE(to, v)
			}(Blacklist[v])
			Batas = Batas + 1
			if int64(Batas) >= int64(Batasan) {
				Batas = 0
				break
			}
		}
	}
}

func KickCancelRandom(client *LineClient, to string) {
	defer VHrecover("KickCancelRandom: " + client.Name)
	_, targets, targets2 := client.GetChatListMapCek(to)
	var Batas = 0
	listMid := []string{}
	listMid2 := []string{}
	for cok := range targets {
		listMid = append(listMid, cok)
		listMid = Remove(listMid, client.Mid)
	}
	for cok := range targets2 {
		listMid2 = append(listMid2, cok)
		listMid2 = Remove(listMid2, client.Mid)
	}
	for v := range Blacklist {
		if Contains(listMid, Blacklist[v]) {
			go func(v string) {
				client.NewLINEKickChat(to, v)
			}(Blacklist[v])
			Batas = Batas + 1
			if int64(Batas) >= int64(Kicker) {
				Batas = 0
				break
			}
		}
		if Contains(listMid2, Blacklist[v]) {
			go func(v string) {
				client.NewLINECancelChat(to, v)
			}(Blacklist[v])
			Batas = Batas + 1
			if int64(Batas) >= int64(Canceler) {
				Batas = 0
				break
			}
		}
	}
}

func GassKick(client *LineClient, to string) {
	defer VHrecover("GassKick")
	var Batas = 0
	memb := []string{}
	asu, err := client.tcrGetChats(to)
	if err != nil {
		asu, err = client.tcrGetChats(to)
		if err != nil {
			return
		}
	}
	mb := asu[0].Extra.GroupExtra.MemberMids
	for f := range mb {
		memb = append(memb, f)
	}
	if memb != nil {
		if len(Blacklist) != 0 {
			for v := range Blacklist {
				if Contains(memb, Blacklist[v]) {
					go func(v string) {
						client.NewKickLINE(to, v)
					}(Blacklist[v])
					if int64(Batas) >= int64(Batasan) {
						break
					}
					Batas++
				}
			}
		}
	}
	return
}

func Cancelled(client *LineClient, to string, mid string, korban []string) {
	defer VHrecover("Cancelled")
	var Batas = 0
	for _, target := range korban {
		go client.NewCancelLINE(to, target)
		if int64(Batas) >= int64(Batasan) {
			Batas = 0
			break
		}
		Batas++
	}
	for _, target := range Blacklist {
		go client.NewKickLINE(to, target)
		if int64(Batas) >= int64(Batasan) {
			Batas = 0
			break
		}
		Batas++
	}
}

func groupRecovery(client *LineClient, to string) {
	defer VHrecover("groupRecovery")
	memlist := client.GetGroupMember(to)
	room := GetRoom(to)
	if len(memlist) == 0 {
		cans := room.Ava
		for _, cls := range cans {
			if cls.Exist {
				memlist = cls.Client.GetGroupMember(to)
				if len(memlist) != 0 {
					break
				}
			}
		}
	}
	bot := room.Client
	exe := []*LineClient{}
	exe2 := []*LineClient{}
	oke := []string{}
	for _, cl := range bot {
		if _, ok := memlist[cl.Mid]; ok {
			if cl.Kicked {
				exe2 = append(exe2, cl)
			} else {
				exe = append(exe, cl)
			}

		} else {
			oke = append(oke, cl.Mid)
		}
	}
	ci := append(exe2, exe...)
	ClAct := len(ci)
	if ClAct != 0 {
		invRec(ci, to, oke)
	}
}
func invRec(exe []*LineClient, to string, ban []string) {
	defer VHrecover("inv_backup")
	no := 0
	ClAct := len(exe)
	hajar := []string{}
	fmt.Println(len(ban))
	z := len(ban) / 3
	y := z + 1
	for i := 0; i < y; i++ {
		if no >= ClAct {
			no = 0
		}
		go func(to string, no int, i int, z int, ban []string, exe []*LineClient) {
			client := exe[no]
			if i == z {
				hajar = ban[i*3:]
			} else {
				hajar = ban[i*3 : (i+1)*3]
			}
			if len(hajar) != 0 {
				go client.NewInviteLINE(to, hajar)
				//for _, target := range hajar {
					//go client.NewInviteLINE(to, []string{target})
				//}
			}
		}(to, no, i, z, ban, exe)
		no += 1
	}
}

//Backup NewBot
func CansBanOnly(client *LineClient, to string) {
	var Batas = 0
	_, memb, memb1 := client.GetChatListMapCek(to)
	for x := range Squad {
		if _, blog := memb[Squad[x]]; blog {
			if client.Mid == Squad[x] {
				go func(){
				    for mid := range memb1 {
		                if IsBan(to, mid) == true {
			                go func(mid string) {
		                        go client.NewCancelLINE(to, mid)
			                }(mid)
							if int64(Batas) >= int64(Batasan) {
								Batas = 0
								break
							}
						}
	                }
			    }()
			}
			break
		} else {
			continue
		}
	}
}

func KickBanOnly(client *LineClient, to string) {
	var Batas = 0
	_, memb, _ := client.GetChatListMapCek(to)
	for x := range Squad {
		if _, blog := memb[Squad[x]]; blog {
			if client.Mid == Squad[x] {
				go func(){
				    for mid := range memb {
		                if IsBan(to, mid) == true {
			                go func(mid string) {
		                        go client.NewKickLINE(to, mid)
			                }(mid)
							if int64(Batas) >= int64(Batasan) {
								Batas = 0
								break
							}
						}
	                }
			    }()
			}
			break
		} else {
			continue
		}
	}
}

func KickV3(client *LineClient, to string, mid string) {
	_, memb, _ := client.GetChatListMapCek(to)
	for x := range Squad {
		if _, blog := memb[Squad[x]]; blog {
			if client.Mid == Squad[x] {
				var wg sync.WaitGroup
				wg.Add(1)
				go func() {
					defer wg.Done()
					go client.NewKickLINE(to, mid)
				}()
				wg.Wait()
			}
			break
		} else {
			continue
		}
	}
}

func CancelV3(client *LineClient, to string, korban []string) {
	_, memb, _ := client.GetChatListMapCek(to)
	for x := range Squad {
		if _, blog := memb[Squad[x]]; blog {
			if client.Mid == Squad[x] {
				var wg sync.WaitGroup
				wg.Add(len(korban))
				for i := 0; i < len(korban); i++ {
					go func(i int) {
						defer wg.Done()
						go client.NewCancelLINE(to, korban[i])
					}(i)
				}
			}
			break
		} else {
			continue
		}
	}
}

func InviteV3(client *LineClient, to string, mid string) {
	_, memb, _ := client.GetChatListMapCek(to)
	for x := range Squad {
		if _, blog := memb[Squad[x]]; blog {
			if client.Mid == Squad[x] {
				var wg sync.WaitGroup
				wg.Add(1)
				go func() {
					defer wg.Done()
					go client.NewInviteLINE(to, []string{mid})
				}()
				wg.Wait()
			}
			break
		} else {
			continue
		}
	}
}

func InviteV4(client *LineClient, to string, mid string) {
	_, memb, _ := client.GetChatListMapCek(to)
	for x := range Squad {
		if _, blog := memb[Squad[x]]; blog {
			if client.Mid == Squad[x] {
				var wg sync.WaitGroup
				wg.Add(1)
				go func() {
					defer wg.Done()
					go client.NewInviteLINE(to, []string{mid})
				}()
				wg.Wait()
			}
			break
		} else {
			continue
		}
	}
}

func KickbansV2(client *LineClient, to string) {
	count := 0
	_, mb, _ := client.GetChatListMapCek(to)
	for v := range mb {
		if IsBan(to, v) == true && count < Batasan {
			go func(v string) {
				go client.NewKickLINE(to, v)
			}(v)
			count++
		}
		if count >= Batasan {
			break
		}
	}
}

func BackupV42(client *LineClient, to string, korban string) {
	_, memb, _ := client.GetChatListMapCek(to)
	for x := range Squad {
		if _, blog := memb[Squad[x]]; blog {
			if client.Mid == Squad[x] {
				go func() {
					KickbansV2(client, to);go client.NewInviteLINE(to, []string{korban})
				}()
			}
			break
		} else {
			continue
		}
	}
}
//NEW BACKUP 2025
func LINEKickBanOnly(client *LineClient, to string) {
	var Batas = 0
	_, memb, _ := client.GetChatListMapCek(to)
	for mid := range memb {
        if IsBan(to, mid) == true {
        	go func(to string, mid string) {
	            go client.NewLINEKickChat(to, mid)
	        }(to,mid)
			if int64(Batas) >= int64(Kicker) {
	            Batas = 0
				break
			}
		}
	}
}

func LINECanBanOnly(client *LineClient, to string) {
	var Batas = 0
	_, _, memb := client.GetChatListMapCek(to)
	for mid := range memb {
        if IsBan(to, mid) == true {
        	go func(to string, mid string) {
	            go client.NewLINEKickChat(to, mid)
	        }(to,mid)
			if int64(Batas) >= int64(Canceler) {
	            Batas = 0
				break
			}
		}
	}
}

func GetStringBytesV3(str string) []byte {
	var va []byte
	for a := range str {
		va = append(va, byte(int(str[a])))
	}
	return va
}

func (cl *LineClient) LINEMoreCompact(LINE []byte) string {
	HTTP, _ := thrift2.NewTHttpClient(cl.Main_host + "/S5")
	transport := HTTP.(*thrift2.THttpClient)
	transport.SetHeader("user-agent", cl.UserAgent)
	transport.SetHeader("x-line-application", cl.AppName)
	transport.SetHeader("x-line-access", cl.AuthToken)
	transport.SetHeader("x-lal", "en_US")
	transport.SetHeader("x-lpv", "1")
	transport.SetHeader("content-type", "application/x-thrift")
	transport.SetHeader("accept", "application/x-thrift")
	transport.SetHeader("accept-encoding", "gzip")
	transport.SetMoreCompact(true)
	transport.Write(LINE)
	transport.Flush(cl.Ctx)
	b := transport.GetBody()
	if len(b) > 0 {
		tmcp := modcompact.TMoreCompactProtocolGoods(b)
		return tmcp.GetResponCompact().Reason
	}
	return ""
}

func (cl *LineClient) AcceptGroupInvitationByTicketByte(to string, ticket string) string {
	fckV := []byte{130, 33, 2, 29, 97, 99, 99, 101, 112, 116, 71, 114, 111, 117, 112, 73, 110, 118, 105, 116, 97, 116, 105, 111, 110, 66, 121, 84, 105, 99, 107, 101, 116, 21, 0, 24, 33}
	fckV = append(fckV, GetStringBytesV3(to)...)
	fckV = append(fckV, []byte{24, 10}...)
	fckV = append(fckV, GetStringBytesV3(ticket)...)
	fckV = append(fckV, []byte{0}...)
	return cl.LINEMoreCompact(fckV)
}

func (cl *LineClient) AcceptChatInvitationByte(to string) string {
	fckV := []byte{130, 33, 1, 20, 97, 99, 99, 101, 112, 116, 67, 104, 97, 116, 73, 110, 118, 105, 116, 97, 116, 105, 111, 110, 28, 21, 0, 24, 33}
	fckV = append(fckV, GetStringBytesV3(to)...)
	fckV = append(fckV, []byte{0, 0}...)
	return cl.LINEMoreCompact(fckV)
}
func (cl *LineClient) DeleteOtherFromChatByte(to string, mid string) string {
	fckV := []byte{130, 33, 1, 19, 100, 101, 108, 101, 116, 101, 79, 116, 104, 101, 114, 70, 114, 111, 109, 67, 104, 97, 116, 28, 21, 0, 24, 33}
	fckV = append(fckV, GetStringBytesV3(to)...)
	fckV = append(fckV, []byte{26, 24, 33}...)
	fckV = append(fckV, GetStringBytesV3(mid)...)
	fckV = append(fckV, []byte{0, 0}...)
	return cl.LINEMoreCompact(fckV)
}
func (cl *LineClient) CancelChatInvitationByte(to string, mid string) string {
	fckV := []byte{130, 33, 1, 20, 99, 97, 110, 99, 101, 108, 67, 104, 97, 116, 73, 110, 118, 105, 116, 97, 116, 105, 111, 110, 28, 21, 0, 24, 33}
	fckV = append(fckV, GetStringBytesV3(to)...)
	fckV = append(fckV, []byte{26, 24, 33}...)
	fckV = append(fckV, GetStringBytesV3(mid)...)
	fckV = append(fckV, []byte{0, 0}...)
	return cl.LINEMoreCompact(fckV)
}
func (cl *LineClient) InviteIntoChatByte(to string, mid []string) string {
	fckV := []byte{130, 33, 1, 14, 105, 110, 118, 105, 116, 101, 73, 110, 116, 111, 67, 104, 97, 116, 28, 21, 0, 24, 33}
	fckV = append(fckV, GetStringBytesV3(to)...)
	fckV = append(fckV, []byte{26}...)
	byteCount := 8
	for _ = range mid {
		byteCount += 16
	}
	fckV = append(fckV, GetLenStrBytes(byteCount)...)
	for _, mids := range mid {
		fckV = append(fckV, []byte{33}...)
		fckV = append(fckV, GetStringBytesV3(mids)...)
	}
	fckV = append(fckV, []byte{0, 0}...)
	return cl.LINEMoreCompact(fckV)
}

//NewBot 2025
func KillSameV2(kill []*LineClient, mem []string, to string) {
    if len(kill) != 0 && len(mem) != 0 {
        var no, ex int
        var wg sync.WaitGroup
        wg.Add(len(mem))
        for i := 0; i < len(mem); i++ {
            go func(no int, i int) {
                kill[no].NewLINEKickChat(to, mem[i])
                wg.Done()
            }(no, i)
            if ex >= Kicker {
                no++
                if no >= len(kill) {
                    no = 0
                }
                ex = 0
            }
            ex++
        }
        wg.Wait()
    }
}

func KickAllBan(client *LineClient, Room *LineRoom, Group string) {
	ban  := []string{}
    _, memlist, _ := client.GetChatListMapCek(Group)
    for mid, _ := range memlist {
        if IsBan(Group, mid) {
            ban = append(ban, mid)
        }
    }
    cans := Room.Cans()
    if cans == nil || len(cans) == 0 || len(ban) == 0 {
        return
    }
    KillSameV2(cans, ban, Group)
}

func CansSameV2(kill []*LineClient, inv []string, to string) {
    if len(kill) > 0 && len(inv) > 0 {
        var no, ex int
        var wg sync.WaitGroup
        wg.Add(len(inv))
        for i := 0; i < len(inv); i++ {
            go func(no int, i int) {
                kill[no].NewLINECancelChat(to, inv[i])
                wg.Done()
            }(no, i)
            if ex >= Canceler {
                no++
                if no >= len(kill) {
                    no = 0
                }
                ex = 0
            }
            ex++
        }
        wg.Wait()
    }
}

func CancelAllBan(client *LineClient, Room *LineRoom, Group string) {
    ban  := []string{}
    _, _, memlist := client.GetChatListMapCek(Group)
    if len(memlist) != 0 {
        for mid, _ := range memlist {
            if IsBan(Group, mid) {
                ban = append(ban, mid)
            }
        }
    }
    cans := Room.Cans()
    if cans == nil || len(cans) == 0 || len(ban) == 0 {
        return
    }
    CansSameV2(cans, ban, Group)
}

func (client *LineClient) BackupGroupNew(to, pelaku string, korban string, cek bool) {
	defer VHrecover("BackupGroupNew: " + client.Name)
	var Batas = 0
	qr, memlist, inv := client.GetChatListMapCek(to)
	room := GetRoom(to)
	bot := room.Bot
	oke := []string{}
	ban := []string{pelaku}
	for mid := range memlist {
		if Contains(bot, mid) {
			oke = append(oke, mid)
		} else if IsBan(to, mid) {
			if pelaku != mid {
				ban = append(ban, mid)
			}
		}
	}
	go func(){
		for mid := range inv {
			if IsBan(to, mid) == true {
				go func(mid string) {
					client.NewLINECancelChat(to, mid)
				}(mid)
				Batas = Batas + 1
				if int64(Batas) >= int64(Canceler) {
					Batas = 0
					break
				}
			}
		}
	}()
	go func() {
		cno := 0
		if Random {
			Random = false
			for _, mie := range bot {
				if !Contains(oke, mie) {
					cno++
					go func(bi string, xx *LineClient) {
						xx.InviteIntoChatByte(to, []string{bi})
					}(mie, client)
					if cno == 3 {
						break
					}
				}
			}
		} else {
			Random = true
			ci := len(bot) - 1
			for i := ci; i >= 0; i-- {
				mie := bot[i]
				if !Contains(oke, mie) {
					cno++
					go func(bi string, xx *LineClient) {
						xx.InviteIntoChatByte(to, []string{bi})
					}(mie, client)
					if cno == 3 {
						break
					}
				}
			}
		}
	}()
	if Killmode != "none" && AllowBan && cek {
		if Killmode == "kill" {
			var createdTime int64
			for mid, tt := range memlist {
				if pelaku == mid {
					createdTime = tt
					break
				}
			}
			for mid, tt := range memlist {
				ct := float64(createdTime/1000 - tt/1000)
				if valid.Abs(ct) <= 10 {
					if MemUser(to, mid) {
						Banned.AddBan(mid,to)
						ban = append(ban, mid)
					}
				}
			}
			for _, target := range ban {
				go func(target string) {
					client.NewLINEKickChat(to, target)
				}(target)
				Batas = Batas + 1
				if int64(Batas) >= int64(Kicker) {
					Batas = 0
					break
				}
			}
		} else {
			for _, cok := range ban {
				go client.NewLINEKickChat(to, cok)
				Batas = Batas + 1
				if int64(Batas) >= int64(Kicker) {
					Batas = 0
					break
				}
			}
		}
	} else {
		go client.NewLINEKickChat(to, pelaku)
	}
	if !qr {
		tickets := client.ReissueChatTicket(to)
		if len(tickets) < 2 {
			return
		}
		for i := 0; i < len(oke); i++ {
			if !Contains(oke, bot[i]) {
				go func(mie string) {
					client.AcceptGroupInvitationByTicket(to, tickets)
				}(bot[i])
			}
		}
	}
}

func (client *LineClient) KickCancelPro(to string, pelaku string, korban []string) {
	defer VHrecover("KickCancelPro")
	var Batas = 0
	go Banned.AddBan(pelaku, to)
	go BanAll(korban, to)
	_, memlist, inv := client.GetChatListMapCek(to)
	go func(invb map[string]int64) {
		for i := range invb {
			if IsBan(to, i) {
				go func(is string) {
					client.NewLINEKickChat(to, is)
				}(i)
				Batas = Batas + 1
				if int64(Batas) >= int64(Kicker) {
					Batas = 0
					break
				}
			}
		}
	}(memlist)
	go func(inva map[string]int64){
		for mid := range inva {
			if IsBan(to, mid) == true {
				go func(mid string) {
					client.NewLINECancelChat(to, mid)
				}(mid)
				Batas = Batas + 1
				if int64(Batas) >= int64(Canceler) {
					Batas = 0
					break
				}
			}
		}
	}(inv)
}

func (client *LineClient) CancelKickBans(to string, korban []string) {
	defer VHrecover("CancelKickBans")
	var Batas = 0
	go BanAll(korban, to)
	_, memlist, _ := client.GetChatListMapCek(to)
	go func(inv1 map[string]int64) {
		for i := range memlist {
			if IsBan(to, i) {
				go func(to string, i string) {
					client.NewLINEKickChat(to, i)
				}(to,i)
				Batas = Batas + 1
				if int64(Batas) >= int64(Kicker) {
					Batas = 0
					break
				}
			}
		}
	}(memlist)
	for _, i := range korban {
	    go func(i string){
		    client.NewLINECancelChat(to, i)
	    }(i)
	    Batas = Batas + 1
	    if int64(Batas) >= int64(Canceler) {
		    Batas = 0
			break
		}
	}
}

func (client *LineClient) KickCancelBans(to string, pelaku string, korban []string) {
	defer VHrecover("KickCancelBans")
	var Batas = 0
	go Banned.AddBan(pelaku, to)
	go BanAll(korban, to)
	_, _, inv := client.GetChatListMapCek(to)
	go func(to string, i string) {
	    client.NewLINEKickChat(to, i)
    }(to, pelaku)
	go func(inv2 map[string]int64){
		for mid := range inv2 {
			if IsBan(to, mid) == true {
				go func(to string, mid string) {
					client.NewLINECancelChat(to, mid)
				}(to, mid)
				Batas = Batas + 1
				if int64(Batas) >= int64(Canceler) {
					Batas = 0
					break
				}
			}
		}
	}(inv)
}

func (client *LineClient) TcrKickCancel(to string, pelaku string, korban []string) {
	defer VHrecover("TcrKickCancel")
	var Batas = 0
	go Banned.AddBan(pelaku, to)
	go BanAll(korban, to)
	go func(to string, i string) {
	    client.NewLINEKickChat(to, i)
    }(to, pelaku)
	var wg sync.WaitGroup
    wg.Add(len(korban))
    for _, i := range korban {
        go func(to string, i string) {
            client.NewLINECancelChat(to, i)
            wg.Done()
        }(to, i)
        Batas = Batas + 1
        if int64(Batas) >= int64(Canceler) {
	        Batas = 0
			break
		}
	}
	wg.Wait()
}