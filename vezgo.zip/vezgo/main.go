package main

/*Editing_By_SELFTCR
========================
Line Id : code-bot
Whatsapp : +6282278984821
Telegram : https://t.me/code_botTL
Discord : https://discord.gg/C3nqrKpv
========================
be careful in editing*/

import (
	//"encoding/base64"
	//"encoding/json"
	"fmt"
	"math/rand"
	"os"
	"runtime"
	"runtime/debug"
	"strings"
	"sync"
	"time"
	"./library/LineThrift"
	. "./library/engine"
	"./library/hashmap"
	"github.com/tidwall/sjson"
	"github.com/slayer/autorestart"
	"github.com/tidwall/gjson"
)

var cekGo = []int64{}
var Ceknuke = &hashmap.HashMap{}
var tempban = []string{}
var botleave = &hashmap.HashMap{}
var Aclear = time.Now()
var getmess = []int64{}
var waitkick = []int64{}
var iki = []*Jos{}
//var getAnn = &hashmap.HashMap{}

type Jos struct {
	ID     int32
	Optime int64
}

var lemes = []*Ah{}

type Ah struct {
	Enak   string
	Wayahe int64
}

func mentions(client *LineClient, to string, jenis string, memlist []string) {
	ta := false
	tx := ""
	tag := []string{}
	z := len(memlist) / 20
	y := z + 1
	for i := 0; i < y; i++ {
		if !ta {
			tx += fmt.Sprintf("%s:\n", jenis)
			ta = true
		}
		if i == z {
			tag = memlist[i*20:]
			no := i * 20
			no += 1
			for i := 0; i < len(tag); i++ {
				iki := no + i
				tx += fmt.Sprintf("\n%v. @!", iki)
			}
		} else {
			tag = memlist[i*20 : (i+1)*20]
			no := i * 20
			no += 1
			for i := 0; i < len(tag); i++ {
				iki := no + i
				if iki < 10 {
					tx += fmt.Sprintf("\n%v.  @!", iki)
				} else {
					tx += fmt.Sprintf("\n%v. @!", iki)
				}

			}
		}
		if len(tag) != 0 {
			tx += "\n\n" + TeamName
			client.SendMentionLINE(to, tx, tag)
		}
		tx = ""
	}
}

func Autoclear(client *LineClient, to string) {
	if len(Blacklist) != 0 {
		time.Sleep(15 * time.Second)
		//cl := Mclient[room.Tclient]
		jums := Blacklist
		Banned.ClearBan(to)
		jum := len(Blacklist)
		no := 1
		if jum != 0 {
			var str string
			Blacklist = []string{}
			t, r := GetRes("clearban")
			if t {
				if strings.Contains(r, "%v") {
					str = fmt.Sprintf(r, jum)
				} else {
					str = r
				}
			} else {
				str = fmt.Sprintf("Cleared %v blacklist.", jum)
			}
			for _, target := range jums {
				pr, _ := client.GetContact(target)
				name := pr.DisplayName
				str = fmt.Sprintf("\n%v. %s", no, name)
				no++
			}
			client.SendMessage(to, str)
			value, _ := sjson.Set(Settings, "status.blacklist", Blacklist)
			Settings = value
			JsonDump(true, JsonFile, Settings)
		}
	}
}

var letters = []rune("0123456789")
var randomizer = rand.New(rand.NewSource(time.Now().UTC().UnixNano()))
func randomString(length int) string {
	b := make([]rune, length)
	for i := range b {
		b[i] = letters[randomizer.Intn(len(letters))]
	}
	return string(b)
}

func main() {
	debug.SetGCPercent(1000)
	Settings = ReloadData(JsonFile)
	SetCMD = ReloadCMD(Cmd)
	DataBaseLoad()
	LoadSugest()
	var wmai sync.WaitGroup

	no := 0
	for vezr, ir := range gjson.Get(Settings, "authTokenPrimari").Array() {
		token := ir.String()
		randInt1 := fmt.Sprintf(ANDROID_DEVICE, randomString(5))
		//vez := SettingConnection(LINE_HOST_DOMAIN, token, randInt1, vezr)
		vez := SettingConnection(LINE_HOST_DOMAIN, token, randInt1, vezr)
		vez.AllowLiff()
		Client = append(Client, vez)
		no++
		dor := vez.GetProfile()
		vez.Mid = dor.Mid
		if v, ok := Limits[vez.Mid]; ok {
			KickBans = append(KickBans, vez)
			vez.Limiter = false
			vez.TimeBan = v
		}
		if v, ok := Kcount[vez.Mid]; ok {
			vez.KickCount = v
		}
		if vi, ok := Icount[vez.Mid]; ok {
			vez.InvCount = vi
		}
		if vez.Mid != "" {
		    vez.LoadPrimaryE2EEKeys()
	    }
		/*csk := gjson.Get(Settings, "dataE2EE."+vez.Mid)
		if !csk.Exists() {
			pri, pub := GenerateKey()
			keyid, _ := vez.NegotiateE2EEPublicKey(vez.Mid)
			if keyid.SpecVersion == -1 {
				return
			}
			keyId := keyid.PublicKey.KeyId
			res := vez.RegisterE2EEPublicKey(keyId, pub[:])
			data := map[string]interface{}{
				"publicKey": vez.Base64Encoding(pub[:]),
				"privateKey": vez.Base64Encoding(pri[:]),
				"keyId": int(res.KeyId),
				"version": 1,
			}
			jsonData, err := json.MarshalIndent(data, "", "    ")
			if err != nil {
				fmt.Printf("could not marshal json: %s\n", err)
				return
			}
			os.WriteFile(fmt.Sprintf("./database/%s/e2ee.json", vez.Mid), jsonData, 0644)
			vez.PrivateKEY = pri[:]
			vez.PublicKEY = pub[:]
			vez.KeyID = int(res.KeyId)
			vez.Version = 1
			SaveE2EESelfKeyData(vez.Mid, base64.StdEncoding.EncodeToString(vez.PublicKEY), base64.StdEncoding.EncodeToString(vez.PrivateKEY), vez.KeyID, vez.Version)
		}*/
		if vez.SeqMessage == 0 {
			csk := gjson.Get(Settings, "SeqMessage."+vez.Mid)
			if csk.Exists() {
				vez.SeqMessage = int32(csk.Int())
			}
		}
		Mclient[vez.Mid] = vez
		Squad = append(Squad, vez.Mid)
		vez.Name = dor.DisplayName
		qwe := string(ColorWhite) + "Bot" + string(ColorGreen) + fmt.Sprintf("%v", no) + ": "
		qwe += string(ColorWhite) + "\n  Name: " + string(ColorCyan) + dor.DisplayName
		qwe += string(ColorWhite) + "\n  Mid: " + string(ColorYellow) + dor.Mid
		qwe += string(ColorWhite) + "\n  AppName: " + string(ColorYellow) + randInt1
		qwe += string(ColorWhite) + "\n  LastRevision: " + string(ColorGreen) + fmt.Sprintf("%v", vez.Revision)
		qwe += string(ColorWhite) + "\n  ConnectionType: " + string(ColorGreen) + fmt.Sprintf("%v", vez.ConnectionType) + "\n"
		fmt.Println(qwe)
		fmt.Println(string(ColorReset))
	}

	Raflesia := gjson.Get(Settings, "Selfbot.AuthToken")
	if Raflesia.Exists() {
		qwe := string(ColorPurple) + "Selfbot's detected:\n"
		no := 0
		for cok := range Raflesia.Map() {
			Tok := gjson.Get(Settings, "Selfbot.AuthToken."+cok).String()
			if Tok != "" {
				randIntSB := fmt.Sprintf(SECONDARY_DEVICE3, rand.Intn(999-100))
				vez := SettingConnection(LINE_HOST_DOMAIN, Tok, randIntSB, 0)
				vez.AllowLiff()
				//vez.LoadPrimaryE2EEKeys()
				//vez.Checkban(gjson.Get(Settings, "mid_restart").String())
				ListSelf = append(ListSelf, vez)
				no++
				SelfAcc[cok] = vez
				dor := vez.GetProfile()
				vez.Mid = dor.Mid
				vez.Name = dor.DisplayName
				tcrprivkey := gjson.Get(Settings, "dataE2EE."+vez.Mid+".priKey").String()
				tcrpubkey := gjson.Get(Settings, "dataE2EE."+vez.Mid+".pubKey").String()
				tcrkeyid := gjson.Get(Settings, "dataE2EE."+vez.Mid+".keyId").Int()
				vez.PrivateKEY = vez.Base64Decoding(tcrprivkey)
				vez.PublicKEY = vez.Base64Decoding(tcrpubkey)
				vez.KeyID = int(tcrkeyid)
				vez.Version = int(1)
				//vez.LoadE2EEKeys()
				if vez.Mid == "" {
					UpdateSetString("Selfbot.AuthToken."+string(vez.Mid), "")
				}
				if vez.SeqMessage == 0 {
					cskx := gjson.Get(Settings, "SeqMessage."+vez.Mid)
					if cskx.Exists() {
						vez.SeqMessage = int32(cskx.Int())
					}
				}
				qwe += string(ColorWhite) + "Selfbot: " + string(ColorGreen) + fmt.Sprintf("%v", no)
				qwe += string(ColorWhite) + "\n  Name: " + string(ColorCyan) + dor.DisplayName
				qwe += string(ColorWhite) + "\n  Mid: " + string(ColorYellow) + dor.Mid
				qwe += string(ColorWhite) + "\n  LastRevision: " + string(ColorGreen) + fmt.Sprintf("%v", vez.Revision)
				qwe += string(ColorWhite) + "\n  ConnectionType: " + string(ColorGreen) + fmt.Sprintf("%v", vez.ConnectionType) + "\n"
				fmt.Println(qwe)
				fmt.Println(string(ColorReset))
			}
		}
	}
	fmt.Println(string(ColorGreen) + "Application version: " + Version + "\n")

	vu := len(Client)
	wmai.Add(vu)
	for i := 0; i < vu; i++ {
		go func(n int) {
			defer wmai.Done()
			FetchBot(Client[n])
		}(i)
	}

	sb := len(ListSelf)
	wmai.Add(sb)
	for i := 0; i < sb; i++ {
		go func(n int) {
			defer wmai.Done()
			Selfbot(ListSelf[n])
		}(i)
	}
	if len(Client) != 0 {
		for i := range Client {
			Client[i].Backup = Squad
		}
	}

	restart := autorestart.GetNotifier()
	go func() {
		<-restart
		fmt.Println("I will auto restart, Wait a moment..")
	}()

	if gjson.Get(Settings, "mid_restart").String() != "" {
		Client[0].SendMessage(gjson.Get(Settings, "mid_restart").String(), "Success Reboot !!!")
		UpdateSetString("mid_restart", "")
	}
	fmt.Println(fmt.Sprintf("Host Number: %v\nEncMode: %v", Vnum, EncMetode))
	TimeReboot = time.Now()
	for {
		autoset()
		time.Sleep(5 * time.Second)
	}
}

func puas(metu int64, dek string) bool {
	for _, unch := range lemes {
		if unch.Enak == dek && unch.Wayahe == metu {
			return false
		}
	}
	mas := &Ah{Enak: dek, Wayahe: metu}
	lemes = append(lemes, mas)
	return true
}
func cekBackup(op *LineThrift.Operation) bool {
	opt := op.CreatedTime
	id := op.Type
	for _, s := range iki {
		if LineThrift.OpType(s.ID) == id && s.Optime == opt {
			return false
		}
	}
	mas := &Jos{ID: int32(id), Optime: opt}
	iki = append(iki, mas)
	return true
}
func getArg() string {
	args := os.Args
	if len(os.Args) <= 1 {
		fmt.Println("\033[0;31m not enoght args")
		fmt.Println("\033[37m try :\n\t  \033[33m <app-name> <arg>")
		fmt.Println("\033[37m for example:\n\t \033[33m  ./main a")
		fmt.Println("\033[37m or\n\t \033[33m go run main a")
		os.Exit(0)
	}
	return args[1]
}

func Selfbot(client *LineClient) {
	defer VHrecover("SelfbotOps")
	var vzi sync.WaitGroup
	for {
		multiFc, edan := client.SyncS()
		if edan == nil {
			vzi.Add(1)
			go func(fetch []*LineThrift.Operation) {
				vzi.Done()
				var vzj sync.WaitGroup
				for _, ops := range fetch {
					vzj.Add(1)
					go func(op *LineThrift.Operation) {
						vzj.Done()
						switch op.Type {
						case 124: //13 NotifInvite
							params3 := strings.Split(op.Param3, "\x1e")
							if IsTeam(op.Param2) && Contains(params3, client.Mid) {
								client.NewAcceptLINE(op.Param1)
							}
						case 25: //receive pesan\
							MentionMsg := MentionList(op)
							ResetSuggest()
							LINEmsg(client, op, MentionMsg)

						}
					}(ops)
				}
			}(multiFc)
			for _, op := range multiFc {
				client.CorrectRevision(op, true, false, false)
			}
		} else {
			go fmt.Println(string(ColorRed)+"ErrorFetch:"+string(ColorReset), edan)
			return
		}
	}
}

func waits(to, u string) {
	room := GetRoom(to)
	if !IsBan(to, u) && !Contains(room.Kicked, u) {
		room.Kicked = append(room.Kicked, u)
	}
}
func delaywl(user string) {
	time.Sleep(10 * time.Second)
	Whitelist = Remove(Whitelist, user)
}
func setLock(to string) {
	if LockSet {
		GetRoom(to).Lqr = true
		if !Contains(ProQr, to) {
			ProQr = append(ProQr, to)
		}
	}
}

//NEW BACKUP 2025
func JoinKickLINE(client *LineClient, to string) {
	var Batas = 0
	_,memb,_ := client.GetChatListMapCek(to)
	for x := range memb {
		if IsBan(to, x) == true {
            go func(to string, mid string) {
				go client.NewLINEKickChat(to, mid)
			}(to,x)
			Batas = Batas + 1
			if int64(Batas) >= int64(Kicker) {
				Batas = 0
				break
			}
		}
	}
}
func JoinCancelLINE(client *LineClient, to string) {
	var Batas = 0
	_,_,memx := client.GetChatListMapCek(to)
	for x := range memx {
		if IsBan(to, x) == true {
            go func(to string, mod string) {
				go client.NewLINECancelChat(to, mod)
			}(to,x)
			Batas = Batas + 1
			if int64(Batas) >= int64(Canceler) {
				Batas = 0
				break
			}
		}
	}
}
func KickBansLINE(client *LineClient, to string) {
	go func() {
		JoinKickLINE(client, to);JoinCancelLINE(client, to)
	}()
}

func LINEKickInvite(client *LineClient, to string, pelaku string) {
	_, memb, _ := client.GetChatListMapCek(to)
	for x := range client.Backup {
		if _, blog := memb[client.Backup[x]]; blog {
			if client.Mid == client.Backup[x] {
				go Banned.AddBan(pelaku, to)
				go client.NewLINEKickChat(to, pelaku);inviteRecovery(client, to)
			}
			break
		} else {
			continue
		}
	}
}

func FetchBot(client *LineClient) {
	defer VHrecover("Operation")
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	for {
		multiF, edan := client.SyncOps(100)
		if edan == nil {
			go func(multiF []*LineThrift.Operation) {
				for _, op := range multiF {
					switch op.Type {
					case 121: //SelfQR
						go func(op *LineThrift.Operation) {
							if op.Param2 == "4" {
								room := GetRoom(op.Param1)
								if room.Qr {
									if len(room.Actor) > 0 {
										var wg sync.WaitGroup
										for _, cl := range room.Actor {
											wg.Add(1)
											go func(cl *LineClient) {
												cl.AcceptGroupInvitationByTicket(op.Param1, room.Link)
												wg.Done()
											}(cl)
										}
										wg.Wait()
										room.Actor = []*LineClient{}
										client.UpdateChatQrByte(op.Param1, true)
									}
								}
							}
						}(op)
						
					case 122: //11 NotifQR
						go func(op *LineThrift.Operation) {
							Group, Pelaku, Korban := op.Param1, op.Param2, op.Param3
							if IsWar(Group, client) {
								if CorrectClient(Group, client.Mid, "", false, 1) {
									if MemUser(Group, Pelaku) && Korban == "4" {
										if cekBackup(op) {
											if Contains(ProQr, Group) {//|| IsBan(Group, Pelaku) {
												go func() {
													client.UpdateChatQrByte(Group, true)
												}()
												client.NewLINEKickChat(Group, Pelaku)
												Banned.AddBan(Pelaku, Group)
											}
										}
									}
								} else if SecondCorrectClient(Group, client.Mid) {
									if MemUser(Group, Pelaku) && Korban == "4" {
										if cekBackup(op) {
											if Contains(ProQr, Group) {//|| IsBan(Group, Pelaku) {
												go func() {
													client.UpdateChatQrByte(Group, true)
												}()
												client.NewLINEKickChat(Group, Pelaku)
												Banned.AddBan(Pelaku, Group)
											}
										}
									}
								}
							}
							LogOp(op, client)
						}(op)
					case 123: //12 SelfInvite
					    //Group := op.Param1
						go func(op *LineThrift.Operation) {
							/*go func() {
								go KickBansLINE(client, Group)
							}()
							if wk(op.CreatedTime) {
								cl, ok := Mclient[op.Param2]
								if ok {
									if Purge {
										KickBl(cl, op.Param1)
									}
								}
							}*/
							LogOp(op, client)
						}(op)

					case 124: //NotifInvite //DONE
						go func(op *LineThrift.Operation) {
							Group, Pelaku, Korban := op.Param1, op.Param2, op.Param3
							invites := strings.Split(Korban, "\x1e")
							if !strings.Contains(Korban, client.Mid) {
								if CorrectClient(Group, client.Mid, "", false, 1) {
									if Contains(ProInvite, Group) {
										if MemUser(Group, Pelaku) {
											go func() {
												go client.TcrKickCancel(Group, Pelaku, invites)
											}()
												/*if len(invites) == 1 {
													go client.CancelChatInvitationByte(Group, Korban)
												} else {
													for _, target := range invites {
														var wg sync.WaitGroup
														wg.Add(len(invites))
														go func(target string) {
															defer wg.Done()
															go client.CancelChatInvitationByte(Group, target)
														}(target)
													}
												}
											}()
											if cekBackup(op) {
												go client.DeleteOtherFromChatByte(Group, Pelaku)
											}*/
											tempban = invites
											Banned.AddBan(Pelaku, Group)
											BanAll(invites, Group)
										} else {
											Addwl(Group, invites)
										}
									} else if IsBan(Group, Pelaku) {
										go func() {
											go client.CancelKickBans(Group, invites)
										}()
											/*if len(invites) == 1 {
												go client.CancelChatInvitationByte(Group, Korban)
											} else {
												for _, target := range invites {
													var wg sync.WaitGroup
													wg.Add(len(invites))
													go func(target string) {
														defer wg.Done()
														go client.CancelChatInvitationByte(Group, target)
													}(target)
												}
											}
										}()
										if cekBackup(op) {
											go client.DeleteOtherFromChatByte(Group, Pelaku)
										}
										BanAll(invites, Group)*/
									} else if IsBanArray(Group, invites) {
										go func() {
											go client.KickCancelBans(Group, Pelaku, invites)
										}()
											/*if len(invites) == 1 {
												go client.CancelChatInvitationByte(Group, Korban)
											} else {
												for _, target := range invites {
													var wg sync.WaitGroup
													wg.Add(len(invites))
													go func(target string) {
														defer wg.Done()
														go client.CancelChatInvitationByte(Group, target)
													}(target)
												}
											}
										}()
										if cekBackup(op) {
											if MemUser(Group, Pelaku) {
												go client.DeleteOtherFromChatByte(Group, Pelaku)
											}
										}
										Banned.AddBan(Pelaku, Group)*/
									}
								} else if SecondCorrectClient(Group, client.Mid) {
									if Contains(ProInvite, Group) || IsBan(Group, Pelaku) || IsBanArray(Group, invites) {
										go func() {
											go client.TcrKickCancel(Group, Pelaku, invites)
										}()
										/*go func() {
											if len(invites) == 1 {
												go client.CancelChatInvitationByte(Group, Korban)
											} else {
												for _, target := range invites {
													var wg sync.WaitGroup
													wg.Add(len(invites))
													go func(target string) {
														defer wg.Done()
														go client.CancelChatInvitationByte(Group, target)
													}(target)
												}
											}
										}()
										if cekBackup(op) {
											if MemUser(Group, Pelaku) {
												go client.DeleteOtherFromChatByte(Group, Pelaku)
											}
										}
										Banned.AddBan(Pelaku, Group)
										BanAll(invites, Group)*/
									}
								}
							} else {
								if Nukejoin == true {
									go client.NewLINEAcceptChat(Group)
								}
								if IsWar(Group, client) {
									if Contains(Squad, Pelaku) {
										go client.NewLINEAcceptChat(Group);KickBansLINE(client, Group)
									} else if Contains(Bot, Pelaku) || IsGbot(Group, Pelaku) {
										go client.NewLINEAcceptChat(Group);KickBansLINE(client, Group)
									} else if Grade(Group, Pelaku) <= Ginvite {
										go func() {
											go client.NewLINEAcceptChat(Group);KickBansLINE(client, Group)
											Optime := op.CreatedTime
											if !InArrayInt64(cekGo, Optime) {
												cekGo = append(cekGo, Optime)
												memlist, invs, qrs := client.FCKGetMember(Group)
												oke := []string{}
												exe := []*LineClient{}
												for _, mid := range memlist {
													if Contains(Squad, mid) {
														oke = append(oke, mid)
														cl := Mclient[mid]
														if cl.Limiter {
															exe = append(exe, cl)
														}
													}
												}
												if len(exe) != 0 {
													if Forcejoin {
														in := []string{}
														for _, mid := range Squad {
															if !Contains(oke, mid) {
																in = append(in, mid)
															}
														}
														if len(in) != 0 {
															cls := exe[0]
															in = Remove(in, cls.Mid)
															anu := len(memlist) + len(invs) + len(in)
															if anu > 500 {
																var wg sync.WaitGroup
																cok := anu - 500
																cva := []string{}
																for _, md := range invs {
																	if len(cva) >= cok {
																		break
																	} else if MemUser(Group, md) {
																		cva = append(cva, md)
																	}
																}
																for _, mid := range cva {
																	wg.Add(1)
																	go func(mid string) {
																		cls.CancelChatInvitation(Group, mid)
																		wg.Done()
																	}(mid)
																}
																wg.Wait()
															}
															link := cls.ReissueChatTicket(Group)
															if len(link) < 2 {
																for _, cll := range exe {
																	if cll != cls {
																		link = cll.ReissueChatTicket(Group)
																		if len(link) < 2 {
																			continue
																		} else {
																			cls = cll
																			break
																		}
																	}
																}
															}
															if len(link) > 2 {
																room := GetRoom(Group)
																room.Link = link
																room.Qr = true
																room.Actor = []*LineClient{}
																for _, clm := range in {
																	room.Actor = append(room.Actor, Mclient[clm])
																}
																cls.UpdateChatQrByte(Group, false)
															}

														}
													}
													if !qrs {
														exe[0].UpdateChatQrByte(Group, true)
													}
												}
											}
										}()
										invites := strings.Split(Korban, "\x1e")
										Optime := op.CreatedTime
										if !Attacking {
											if Nukejoin {
												_, ok := Ceknuke.Get(Optime)
												if !ok {
													Ceknuke.Set(Optime, 1)
												} else {
													return
												}
												GetRoom(Group).Nuke = false
											}
										}
										Addwl(Group, invites)

									} else if MemAkses(Group, Pelaku) {
										invites := strings.Split(Korban, "\x1e")
										Addwl(Group, invites)
									}
								} else {
									memlist, _, _ := client.FCKGetMember(Group)
									oke := []string{}
									for _, mid := range memlist {
										if Contains(Squad, mid) {
											oke = append(oke, mid)
										}
									}
									if len(oke) == 0 {
										Optime := op.CreatedTime
										if !InArrayInt64(cekGo, Optime) {
											cekGo = append(cekGo, Optime)
											cls := []*LineClient{}
											cli := GetRoom(Group).Client
											var wg sync.WaitGroup
											for n, cl := range GetRoom(Group).GoClient {
												if n < GoBatas {
													wg.Add(1)
													go func() {
														cl.NewLINEAcceptChat(Group)
														wg.Done()
													}()
													cls = append(cls, cl)
												}
											}
											for _, cl := range cls {
												GetRoom(Group).ConvertGo(cl)
											}
											go func() {
												wg.Wait()
												cc := len(cls)
												if cc > 1 {
													room := GetRoom(Group)
													link := cls[1].ReissueChatTicket(Group)
													room.Link = link
													room.Actor = append(room.Actor, cli...)
													room.Qr = true
													cls[0].UpdateChatQrByte(Group, false)
												} else if cc == 1 {
													room := GetRoom(Group)
													link := cls[0].ReissueChatTicket(Group)
													room.Link = link
													room.Actor = append(room.Actor, cli...)
													room.Qr = true
													cls[0].UpdateChatQrByte(Group, false)
												}
											}()
											if Staynuke && len(cls) > 1 {
												//stnukeAll(cls[0], Group)
											} else if len(cls) != 0 {
												//Purgesip(Group, cls[0])
											}
										}
									}
								}

							}

							LogOp(op, client)
						}(op)
						
					case 133:
						go func(op *LineThrift.Operation) {
							Group, Pelaku, Korban := op.Param1, op.Param2, op.Param3
							if client.Mid == Korban {
								Banned.AddBan(op.Param2, op.Param1)
								Gone(op.Param1, client)
							} else {
								if CorrectClient(Group, client.Mid, Korban, true, op.CreatedTime) {
									if IsWar(op.Param1, client) {
										if Contains(Squad, Korban) {
											if MemUser(Group, Pelaku) {
												if GetRoom(Group).CorrectParam2(Pelaku) {
													go client.GroupBackup2(op.Param1, op.Param2, op.Param3, true)
													setLock(Group)
												}
											}
										} else if Contains(Bot, Korban) || IsGbot(Group, Korban) {
											if MemUser(Group, Pelaku) {
												Banned.AddBan(Pelaku, Group)
												if cekBackup(op) {
													go func(tim int64, korban string) {
														if puas(tim, korban) {
															client.InviteIntoChatCheck(Group, []string{Korban},"","")
														}
													}(op.CreatedTime, Korban)
													if puas(op.CreatedTime, Pelaku) {
														go client.NewLINEKickChat(Group, Pelaku)
													}
												}
											}

										} else if MemAkses(Group, Korban) {
											if MemUser(Group, Pelaku) {
												waits(Group, Korban)
												Banned.AddBan(Pelaku, Group)
												if puas(op.CreatedTime, Pelaku) {
													go client.NewLINEKickChat(Group, Pelaku)
												}
											}
										} else if !Contains(Squad, Pelaku) && !Contains(Bot, Pelaku) && !IsGbot(Group, Pelaku) {
											if GradeKick(Group, Pelaku) > GradeKick(Group, Korban) {
												go func(tim int64, korban string) {
													if puas(tim, korban) {
														client.InviteIntoChatCheck(Group, []string{Korban},"","")
													}
												}(op.CreatedTime, Korban)
												if puas(op.CreatedTime, Pelaku) {
													go client.NewLINEKickChat(Group, Pelaku)
												}
											}

										}
									} else {
										Group := op.Param1
										memlist := client.GetGroupMember(Group)
										oke := []string{}
										for mid := range memlist {
											if Contains(Squad, mid) {
												oke = append(oke, mid)
											}
										}
										if len(oke) == 0 {
											cls := []*LineClient{}
											cli := GetRoom(Group).Client
											var wg sync.WaitGroup
											for n, cl := range GetRoom(Group).GoClient {
												if n < GoBatas {
													wg.Add(1)
													go func() {
														cl.NewLINEAcceptChat(Group)
														wg.Done()
													}()
													cls = append(cls, cl)
												}
											}
											for _, cl := range cls {
												GetRoom(Group).ConvertGo(cl)
											}
											go func() {
												wg.Wait()
												cc := len(cls)
												if cc > 1 {
													room := GetRoom(Group)
													link := cls[1].ReissueChatTicket(Group)
													room.Link = link
													room.Actor = append(room.Actor, cli...)
													room.Qr = true
													cls[0].UpdateChatQrByte(Group, false)
												} else if cc == 1 {
													room := GetRoom(Group)
													link := cls[0].ReissueChatTicket(Group)
													room.Link = link
													room.Actor = append(room.Actor, cli...)
													room.Qr = true
													cls[0].UpdateChatQrByte(Group, false)
												}
											}()
											if Staynuke && len(cls) > 1 {
												//stnukeAll(cls[0], Group)
											} else if len(cls) != 0 {
												//Purgesip(Group, cls[0])
											}
										}
									}
								} else if Contains(ProKick, Group) {
									if MemUser(Group, Pelaku) {
										Banned.AddBan(Pelaku, Group)
										if puas(op.CreatedTime, Pelaku) {
											go client.NewLINEKickChat(Group, Pelaku)
										}
									}
								} else if SecondCorrectClient(Group, client.Mid) {
									if IsWar(op.Param1, client) {
										if Contains(Squad, Korban) {
											if MemUser(Group, Pelaku) {
												if GetRoom(Group).CorrectParam2(Pelaku) {
													go client.SafeClient(op.Param1, op.Param2, op.Param3, true)
												}
											}
										}
									}
								}
							}
							LogOp(op, client)
						}(op)
					case 126:
						go func(op *LineThrift.Operation) {
							Group, Pelaku, Korban := op.Param1, op.Param2, op.Param3
							if client.Mid == Korban {
								Gone(op.Param1, client)
								Banned.AddBan(op.Param2, op.Param1)
							} else {
								if CorrectClient(Group, client.Mid, Korban, true, op.CreatedTime) {
									if IsWar(op.Param1, client) {
										if Contains(Squad, Korban) {
											if MemUser(Group, Pelaku) {
												go client.GroupBackup2(op.Param1, op.Param2, op.Param3, true)
												/*go func() {
													if puas(op.CreatedTime, Korban) {
														client.InviteIntoChats(Group, []string{Korban})
													}
												}()
												if puas(op.CreatedTime, Pelaku) {
													client.DeleteOtherFromChat(Group, Pelaku)
												}*/
											}
										} else if Contains(Bot, Korban) || IsGbot(Group, Korban) {
											if MemUser(Group, Pelaku) {
												Banned.AddBan(Pelaku, Group)
												if cekBackup(op) {
													go func(tim int64, korban string) {
														if puas(tim, korban) {
															client.InviteIntoChatCheck(Group, []string{Korban},"","")
														}
													}(op.CreatedTime, Korban)
													if puas(op.CreatedTime, Pelaku) {
														go client.NewLINEKickChat(Group, Pelaku)
													}
												}
											}

										} else if MemAkses(Group, Korban) {
											if MemUser(Group, Pelaku) {
												waits(Group, Korban)
												Banned.AddBan(Pelaku, Group)
												if puas(op.CreatedTime, Pelaku) {
													go client.NewLINEKickChat(Group, Pelaku)
												}
											}
										} else if !Contains(Squad, Pelaku) && !Contains(Bot, Pelaku) && !IsGbot(Group, Pelaku) {
											if GradeKick(Group, Pelaku) > GradeKick(Group, Korban) {
												go func(tim int64, korban string) {
													if puas(tim, korban) {
														client.InviteIntoChatCheck(Group, []string{Korban},"","")
													}
												}(op.CreatedTime, Korban)
												if puas(op.CreatedTime, Pelaku) {
													go client.NewLINEKickChat(Group, Pelaku)
												}
											}

										}
									}
								} else if Contains(ProCancel, Group) {
									if MemUser(Group, Pelaku) {
										Banned.AddBan(Pelaku, Group)
										if puas(op.CreatedTime, Pelaku) {
											go client.NewLINEKickChat(Group, Pelaku)
										}
									}
								} else if SecondCorrectClient(Group, client.Mid) {
									if IsWar(op.Param1, client) {
										if Contains(Squad, Korban) {
											if MemUser(Group, Pelaku) {
												go func() {
													if puas(op.CreatedTime, Korban) {
														client.InviteIntoChatByte(Group, []string{Korban})
													}
												}()
												if puas(op.CreatedTime, Pelaku) {
													go client.NewLINEKickChat(Group, Pelaku)
												}
											}
										}
									}
								}
							}
							LogOp(op, client)
						}(op)

					case 130: //17 NotifJoin
						go func(op *LineThrift.Operation) {
							Group, Pelaku := op.Param1, op.Param2
							qr,_,_ := client.GetChatListMapCek(Group)
							gr1 := GetRoom(Group)
							var valu1e = len(gr1.Bot) - 3
							if len(Blacklist) == valu1e {
								Killmode = "kill"
							}
							if IsWar(Group, client) {
								if IsBan(Group, Pelaku) {
									if CorrectClient(Group, client.Mid, "", false, 1) {
										if puas(op.CreatedTime, Pelaku) {
											go client.NewLINEKickChat(Group, Pelaku)
											if qr == false {
												go func() {
													client.UpdateChatQrByte(Group, true)
												}()
											}
										}
									} else if SecondCorrectClient(op.Param1, client.Mid) {
										if puas(op.CreatedTime, Pelaku) {
											go client.NewLINEKickChat(Group, Pelaku)
											if qr == false {
												go func() {
													client.UpdateChatQrByte(Group, true)
												}()
											}
										}
									}
								} else if Contains(ProJoin, Group) {
									if MemUser(Group, Pelaku) {
										if Contains(Whitelist, Pelaku) {
											if cekBackup(op) {
												go delaywl(Pelaku)
												if IsGreeting(Group) && !Contains(Squad, Pelaku) && !Contains(Bot, Pelaku) && !IsGbot(Group, Pelaku) {
													gms, _ := Greeting.Get(Group)
													con, err := client.GetContact(Pelaku)
													if err == nil {
														name := con.DisplayName
														gm := gms.(*Wellcome)
														su := gm.Msg
														msg := strings.Replace(su, "@user", name, 1)
														gn, _ := client.GetGroupName(Group)
														msg = strings.Replace(msg, "@group", gn, 1)
														client.SendMessage(Group, msg)
													}
												}
											}
											if CorrectClient(Group, client.Mid, "", false, 1) {
												if puas(op.CreatedTime, Pelaku) {
													client.NewLINEKickChat(Group, Pelaku)
												}
												Banned.AddBan(Pelaku, Group)
											}
										}
									}

								} else if Contains(Whitelist, Pelaku) {
									if puas(op.CreatedTime, Pelaku) {
										if IsGreeting(Group) && !Contains(Squad, Pelaku) && !Contains(Bot, Pelaku) && !IsGbot(Group, Pelaku) {
											gms, _ := Greeting.Get(Group)
											con, err := client.GetContact(Pelaku)
											if err == nil {
												name := con.DisplayName
												gm := gms.(*Wellcome)
												su := gm.Msg
												msg := strings.Replace(su, "@user", name, 1)
												gn, _ := client.GetGroupName(Group)
												msg = strings.Replace(msg, "@group", gn, 1)
												client.SendMessage(Group, msg)
											}
										}
										go delaywl(Pelaku)
									}

								} else if Contains(tempban, Pelaku) {
									if MemUser(Group, Pelaku) {
										if puas(op.CreatedTime, Pelaku) {
											go client.NewLINEKickChat(Group, Pelaku)
											tempban = Remove(tempban, Pelaku)
										}

									} else {
										tempban = Remove(tempban, Pelaku)
									}
								} else if IsGreeting(Group) && !Contains(Squad, Pelaku) && !Contains(Bot, Pelaku) && !IsGbot(Group, Pelaku) {
									if puas(op.CreatedTime, Pelaku) {
										gms, _ := Greeting.Get(Group)
										con, err := client.GetContact(Pelaku)
										if err == nil {
											name := con.DisplayName
											gm := gms.(*Wellcome)
											su := gm.Msg
											msg := strings.Replace(su, "@user", name, 1)
											gn, _ := client.GetGroupName(Group)
											msg = strings.Replace(msg, "@group", gn, 1)
											client.SendMessage(Group, msg)
										}
									}
								}
							}
							LogOp(op, client)
						}(op)

					case 5:
						if IsTeam(op.Param1) {
							fl := client.GetAllContactIds()
							if !Contains(fl, op.Param1) && op.Param1 != client.Mid {
								//client.AddFriendByMid(op.Param1)
								//client.AddFriendByte("",op.Param1)
								client.LINEAddFriendGroupMember("",op.Param1)
							}
						}
						LogOp(op, client)
						
					case 129: //SelfJoin
						group := op.Param1
						gr := GetRoom(group)
						gr.Joins(client)
						if Autocban == true {
							go func() {
								Autoclear(client, group)
							}()
						}
						
					case 26:
						if op.Message.ContentType != 18 {
							go func(op *LineThrift.Operation) {
								if getOp(op.Message.CreatedTime) {
									if !Contains(Protected, op.Message.To) {
										client.GetSquad(op.Message.To)
										Protected = append(Protected, op.Message.To)
									}
									MentionMsg := MentionList(op)
									ResetSuggest()
									MessageHandler(client, op, MentionMsg)
								}
								LogOp(op, client)
							}(op)
						}
					case 55:
						group := op.Param1
						room := GetRoom(group)
						if room.Lurk {
							if !Contains(room.Seen, op.Param2) {
								if CorrectClient(group, client.Mid, "", false, 1) {
								if strings.Contains(MsgSider, "@!") {
									client.SendMention(op.Param1, MsgSider, []string{op.Param2})
								} else {
									client.SendMention(op.Param1, "You can do it, buddy! @!", []string{op.Param2})
								}}
								room.Seen = append(room.Seen, op.Param2)
							}
						}
					case 132:
						/*Group := op.Param1
						if CorrectClient(Group, client.Mid, "", false, 1) {
						    if len(Blacklist) != 0 {
							    go func(Group string) {
								    go LINECanBanOnly(client, Group)
							    }(Group)
							}
						}*/
						go LogOp(op, client)
					case 125:
						/*Group := op.Param1
						if CorrectClient(Group, client.Mid, "", false, 1) {
						    if len(Blacklist) != 0 {
							    go func(Group string) {
								    go LINEKickBanOnly(client, Group)
							    }(Group)
							}
						}*/
						go LogOp(op, client)
					case 128:
						go LogOp(op, client)
					}
				}
			}(multiF)
			for _, ops := range multiF {
				client.SyncRevision(ops.Revision)
			}
		} else {
			//go fmt.Println(string(ColorRed)+"ErrorFetch:"+string(ColorReset), edan)
			//autorestart.RestartByExec()
		}
	}
}

func CorrectClient(to string, mid string, target string, asu bool, opt int64) bool {
	room := GetRoom(to)
	tcore := room.Tcore
	tclient := room.Tclient
	if Contains(tcore, mid) {
		return false
	} else if target == tclient {
		room.Tclient = mid
		if !Contains(tcore, target) {
			room.Tcore = append(room.Tcore, target)
		}
		return true
	} else if tclient == mid || tclient == "" {
		room.Tclient = mid
		return true
	}

	return false
}

func SecondCorrectClient(to string, mid string) bool {
	return Contains(GetRoom(to).Tcore, mid)
}

func wk(opt int64) bool {
	if InArrayInt64(waitkick, opt) {
		return false
	}
	waitkick = append(waitkick, opt)
	return true
}

func getOp(opt int64) bool {
	if InArrayInt64(getmess, opt) {
		return false
	}
	getmess = append(getmess, opt)
	return true
}


func autoset() {
	defer VHrecover("autoset")
	now := time.Now()
	for _, cl := range Waitadd {
		if now.Sub(cl.Timeadd) >= 24*time.Hour {
			if _, ok := GetBlockAdd.Get(cl.Mid); !ok {
				cl.Limitadd = true
				cl.Add = 0
				cl.Lastadd = now
				Waitadd = RemoveCl(Waitadd, cl)
				GetBlockAdd.Del(cl.Mid)
			}
		}
	}
	getmess = []int64{}

	if now.Sub(TimeBackup) >= 3*time.Hour {
		//BackupJson()
		TimeBackup = now
	}
	for _, cl := range Client {
		if now.Sub(cl.Lastadd) >= 10*time.Minute {
			cl.Add = 0
			cl.Lastadd = now
		}
		if now.Sub(cl.Lastkick) >= 1*time.Hour {
			cl.TempKick = 0
			cl.TempInv = 0
		}
		if now.Sub(cl.ResetTime) > 24*time.Hour {
			cl.TempKick = 0
			cl.TempInv = 0
			cl.CountDay = 0
		}
		if now.Sub(cl.TimeBan) <= 1*time.Second || now.Sub(cl.Timeqr) <= 1*time.Second {
			KickBans = RemoveCl(KickBans, cl)
			cl.Limiter = true
			cl.TempKick = 0
			cl.TempInv = 0
			cl.Ready = true
			GetBlock.Del(cl.Mid)
		}
	}
	for _, cl := range KickBans {
		v, ok := GetBlock.Get(cl.Mid)
		if !ok {
			if now.Sub(cl.TimeBan) >= 1*time.Hour {
				KickBans = RemoveCl(KickBans, cl)
				cl.Limiter = true
				cl.TempKick = 0
				cl.TempInv = 0
				cl.Ready = true
				GetBlock.Del(cl.Mid)
			}
		} else {
			if now.Sub(v.(time.Time)) >= 24*time.Hour {
				GetBlock.Del(cl.Mid)
				KickBans = RemoveCl(KickBans, cl)
				cl.Limiter = true
				cl.Ready = true
				cl.TempKick = 0
				cl.TempInv = 0
				cl.KickCount = 0
				cl.KickPoint = 0
				cl.InvCount = 0
				cl.CountDay = 0
				cl.ResetTime = now
			}
		}
	}
	for m, v := range HashToMap(GetBlockAdd) {
		cl := GetKorban(m)
		if cl.Limiter {
			if now.Sub(v.(time.Time)) >= 1*time.Hour {
				cl.Limitadd = true
				GetBlockAdd.Del(cl.Mid)
			}
		}
	}

	if now.Sub(Aclear) >= 30*time.Second {
		tempban = []string{}
		Ceknuke = &hashmap.HashMap{}
		cekGo = []int64{}
		Aclear = time.Now()
		tempban = []string{}
		WarPro =  false
	}
	for _, room := range SquadRoom {
		if !room.Fight.IsZero() {
			if now.Sub(room.Fight) >= 5*time.Second {
				room.Fight = time.Time{}
				var cll *LineClient
				if len(room.Client) != 0 {
					cll = room.Client[0]
				} else {
					cll = Client[0]
				}
				for _, cl := range room.Client {
					cl.Kicked = false
				}
				name, mem, invs := cll.GetChatList(room.Id)
				if len(mem) == 0 {
					for _, mid := range room.Bot {
						if mid != cll.Mid {
							cl := Mclient[mid]
							name, mem, invs = cl.GetChatList(room.Id)
							if len(mem) != 0 {
								break
							}
						}
					}
				}
				room.Name = name
				Attacking = false
				LogFight(room)
				room.Reset()
				iki = []*Jos{}
				lemes = []*Ah{}
				room.Tcore = []string{}
				room.Tclient = ""
				waitkick = []int64{}
				exe := []*LineClient{}
				for _, cls := range room.Client {
					if Contains(mem, cls.Mid) && !Contains(room.GoMid, cls.Mid) && cls.Ready && cls.Limiter {
						exe = append(exe, cls)
					}
				}
				if LockSet {
					if GetRoom(room.Id).Lqr {
						for _, qr := range ProQr {
							if qr == room.Id {
								ProQr = Remove(ProQr, room.Id)
							}
						}
						GetRoom(room.Id).Lqr = false
					}
				}
				if len(room.GoMid) != 0 && len(exe) != 0 {
					lea := []*LineClient{}
					ins := []string{}
					for _, mm := range room.GoMid {
						if Contains(mem, mm) {
							cl := GetKorban(mm)
							lea = append(lea, cl)
							ins = append(ins, mm)
						} else if !Contains(invs, mm) {
							ins = append(ins, mm)
						}
					}
					if len(lea) != 0 {
						for _, cl := range lea {
							GetRoom(room.Id).ConvertGo(cl)
						}
					}
				}
				if len(exe) != 0 {
					Group := room.Id
					groupRecovery(exe[0], Group)
					fmt.Println("Recovery Process")
					/*for _, cl := range exe {
						cl.UpdateChatQrByte(Group, true)
						break
					}*/
				}
				if len(room.Kicked) != 0 && len(exe) != 0 {
					inv := []string{}
					asu := room.Kicked
					for _, l := range asu {
						if !Contains(invs, l) && MemAkses(room.Id, l) {
							inv = append(inv, l)
						}
					}
					for _, l := range asu {
						if !IsBan(room.Id, l) && !Contains(inv, l) && !Contains(mem, l) && !Contains(invs, l) {
							inv = append(inv, l)
						}
					}
					Addwl(room.Id, inv)
					if len(inv) != 0 {
						nok := []*LineClient{}
						for _, cl := range exe {
							if cl.Limiter && cl.Limitadd {
								nok = append(nok, cl)
							}
						}
						exe = nok
						ban := inv
						celek := len(ban)
						no := 0
						bat := 10
						ClAct := len(exe)
						if ClAct != 0 {
							if celek < bat {
								for _, cl := range exe {
									for _, mid := range inv {
										cl.AddFriendByMid(mid)
									}
									fl := cl.GetAllContactIds()
									bb := []string{}
									for _, mid := range inv {
										if Contains(fl, mid) {
											bb = append(bb, mid)
										}
									}
									for _,x := range bb {
										cl.NewInviteLINE(room.Id, []string{x})
									}
									break
								}
							} else {
								Hajar := []string{}
								z := celek / bat
								y := z + 1
								for i := 0; i < y; i++ {
									if no >= ClAct {
										no = 0
									}
									client := exe[no]
									if i == z {
										Hajar = ban[i*bat:]
									} else {
										Hajar = ban[i*bat : (i+1)*bat]
									}
									if len(Hajar) != 0 {
										for _, mid := range Hajar {
											client.AddFriendByMid(mid)

										}
										fl := client.GetAllContactIds()
										bb := []string{}
										for _, mid := range Hajar {
											if Contains(fl, mid) {
												bb = append(bb, mid)
											}
										}
										for _,x := range bb {
											client.NewInviteLINE(room.Id, []string{x})
										}
									}
									no += 1
								}
							}
						}
					}
				}
				room.Kicked = []string{}
				tempban = []string{}
				WarPro =  false
				Killmode = "purge"
			}
		}
	}
	if now.Sub(TimeReboot) >= 24*time.Hour {
		autorestart.RestartByExec()
		TimeReboot = now
	}
	Killmode = "purge"
}

func groupRecovery(client *LineClient, to string) {
	defer VHrecover("groupRecovery")
	memlist := client.GetGroupMember(to)
	room := GetRoom(to)
	if len(memlist) == 0 {
		cans := room.Ava
		for _, cls := range cans {
			if cls.Exist {
				memlist = cls.Client.GetGroupMember(to)
				if len(memlist) != 0 {
					break
				}
			}
		}
	}
	bot := room.Client
	exe := []*LineClient{}
	exe2 := []*LineClient{}
	oke := []string{}
	for _, cl := range bot {
		if _, ok := memlist[cl.Mid]; ok {
			if cl.Kicked {
				exe2 = append(exe2, cl)
			} else {
				exe = append(exe, cl)
			}

		} else {
			oke = append(oke, cl.Mid)
		}
	}
	ci := append(exe2, exe...)
	ClAct := len(ci)
	if ClAct != 0 {
		invRec(ci, to, oke)
	}
}
func invRec(exe []*LineClient, to string, ban []string) {
	defer VHrecover("inv_backup")
	no := 0
	ClAct := len(exe)
	hajar := []string{}
	fmt.Println(len(ban))
	z := len(ban) / 3
	y := z + 1
	for i := 0; i < y; i++ {
		if no >= ClAct {
			no = 0
		}
		go func(to string, no int, i int, z int, ban []string, exe []*LineClient) {
			client := exe[no]
			if i == z {
				hajar = ban[i*Inviter:]
			} else {
				hajar = ban[i*Inviter : (i+1)*Inviter]
			}
			if len(hajar) != 0 {
				//go client.NewInviteLINE(to, hajar)
				for _, target := range hajar {
					go client.InviteIntoChatByte(to, []string{target})
				}
			}
		}(to, no, i, z, ban, exe)
		no += 1
	}
}

func inviteRecovery(client *LineClient, to string) {
	defer VHrecover("groupRecovery")
	memlist := client.GetGroupMember(to)
	room := GetRoom(to)
	if len(memlist) == 0 {
		cans := room.Ava
		for _, cls := range cans {
			if cls.Exist {
				memlist = cls.Client.GetGroupMember(to)
				if len(memlist) != 0 {
					break
				}
			}
		}
	}
	bot := room.Client
	exe := []*LineClient{}
	exe2 := []*LineClient{}
	oke := []string{}
	for _, cl := range bot {
		if _, ok := memlist[cl.Mid]; ok {
			if cl.Kicked {
				exe2 = append(exe2, cl)
			} else {
				exe = append(exe, cl)
			}

		} else {
			oke = append(oke, cl.Mid)
		}
	}
	ci := append(exe2, exe...)
	ClAct := len(ci)
	if ClAct != 0 {
		inviteRec(ci, to, oke)
	}
}

func inviteRec(exe []*LineClient, to string, ban []string) {
	defer VHrecover("inv_backup")
	no := 0
	ClAct := len(exe)
	hajar := []string{}
	fmt.Println(len(ban))
	z := len(ban) / 3
	y := z + 1
	for i := 0; i < y; i++ {
		if no >= ClAct {
			no = 0
		}
		go func(to string, no int, i int, z int, ban []string, exe []*LineClient) {
			client := exe[0]
			if i == z {
				hajar = ban[i*Inviter:]
			} else {
				hajar = ban[i*Inviter : (i+1)*Inviter]
			}
			if len(hajar) != 0 {
				go client.InviteIntoChatByte(to, hajar)
				/*for _, target := range hajar {
					go client.NewInviteLINE(to, []string{target})
				}*/
			}
		}(to, no, i, z, ban, exe)
		no += 1
	}
}